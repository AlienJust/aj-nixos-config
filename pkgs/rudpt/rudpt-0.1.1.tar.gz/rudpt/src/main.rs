use std::fs;
use std::io;
use std::net::IpAddr;
use std::net::SocketAddr;
use std::sync::Arc;

use chrono::{DateTime, Duration, Local};
use dashmap::DashMap;
use teloxide::prelude::*;
use tokio::net::UdpSocket;
use tokio::time::sleep;

use serde::{Deserialize, Serialize};

struct ServerLinkInfo {
    last_seen_time: DateTime<Local>,
    server_name: String,
}

#[derive(Debug, Deserialize)]
struct Config {
    tg_chat_id: i64,
    tg_bot_token: String,

    servers: Vec<ServerConfig>,
}

#[derive(Debug, Serialize, Deserialize)]
struct ServerConfig {
    name: String,
    addr: IpAddr, // Will parse from string automatically
    port: u16,
}

impl ServerConfig {
    // Helper method to get full socket address
    pub fn socket_addr(&self) -> SocketAddr {
        SocketAddr::new(self.addr, self.port)
    }
}

#[tokio::main]
async fn main() -> io::Result<()> {
    let filename = "config.toml";

    // Read the contents of the file using a `match` block
    // to return the `data: Ok(c)` as a `String`
    // or handle any `errors: Err(_)`.
    let contents = match fs::read_to_string(filename) {
        // If successful return the files text as `contents`.
        // `c` is a local variable.
        Ok(c) => c,
        // Handle the `error` case.
        Err(_) => {
            // Write `msg` to `stderr`.
            eprintln!("Could not read file `{}`", filename);
            // Exit the program with exit code `1`.
            panic!("Could not read file `{}`", filename);
        }
    };

    let config: Config = match toml::from_str(&contents) {
        // If successful, return data as `Data` struct.
        // `d` is a local variable.
        Ok(d) => d,
        // Handle the `error` case.
        Err(_) => {
            // Write `msg` to `stderr`.
            eprintln!("Cannot convert file `{}` content to config", filename);
            // Exit the program with exit code `1`.
            panic!("Cannot convert file `{}` content to config", filename);
        }
    };

    //let servers: DashMap<SocketAddr, ServerLinkInfo> = DashMap::new();
    let servers: DashMap<SocketAddr, ServerLinkInfo> = DashMap::new();
    let servers_tg_times: DashMap<SocketAddr, DateTime<Local>> = DashMap::new();

    for server in config.servers.iter() {
        println!("found server in config with name {}", server.name);

        let server1_socket = server.socket_addr();

        let server1 = ServerLinkInfo {
            last_seen_time: Local::now(),
            server_name: server.name.clone(),
        };

        servers.insert(server1_socket, server1);
        servers_tg_times.insert(server1_socket, Local::now());
    }

    let send_servers = Arc::new(servers);
    let recv_servers = send_servers.clone();

    let send_servers_tg_times = Arc::new(servers_tg_times);

    pretty_env_logger::init();
    log::info!("Starting admin bot...");

    //let bot = teloxide::Bot::from_env();
    let bot = teloxide::Bot::new(config.tg_bot_token);

    let chat_id = ChatId(config.tg_chat_id);
    if chat_id.is_channel_or_supergroup() {
        println!("Chat is channel");
    } else {
        println!("Chat is not channel");
    }

    let sock = UdpSocket::bind("0.0.0.0:36969").await?;
    let r = Arc::new(sock);
    let s = r.clone();

    let _handle = tokio::spawn(async move {
        //let srvs = send_servers;
        loop {
            for item in send_servers.iter() {
                let server = item.key();

                // https://docs.rs/tokio/latest/tokio/net/struct.UdpSocket.html
                let len = s
                    .send_to(
                        &[0x7A, 0x05, 0x0B, 0xFF, 0xFF, 0x01, 0x4B, 0xA6, 0x0D],
                        server,
                    )
                    .await;
                println!("{:?} bytes sent", len);
            }
            sleep(std::time::Duration::from_millis(2000)).await;
            for item in send_servers.iter() {
                let server = item.key();
                let last_time = item.value().last_seen_time;

                println!("Checking timeout, last time is {:?}", last_time);

                let not_seen_for = Local::now() - last_time;
                if not_seen_for > Duration::minutes(5) {
                    println!("No link too long, not_seen_for = {:?}", not_seen_for);
                    let mut message = "Нет связи c модулем опроса ".to_owned();
                    message.push_str(&server.to_string());
                    message.push_str(" (");
                    message.push_str(&item.value().server_name);
                    message.push_str(") ");
                    message.push_str(&not_seen_for.num_minutes().to_string());
                    message.push_str(" мин.");

                    let last_error_message_time =
                        *send_servers_tg_times.get_mut(&server).unwrap().value();

                    if Local::now() - last_error_message_time > Duration::minutes(5) {
                        let _msg_result = bot.send_message(chat_id, message).await;
                        println!("Message was sended to telegram");
                        *send_servers_tg_times.get_mut(&server).unwrap().value_mut() = Local::now();
                        println!("Message time was updated");
                    } else {
                        println!(
                            "It is not time to send message cause sending must be not too frequently"
                        );
                    }
                } else {
                    println!(
                        "Link is OK, server {:?} not_seen_for = {:?}",
                        &item.value().server_name,
                        not_seen_for
                    );
                }
            }
            sleep(std::time::Duration::from_millis(28000)).await;
        }
    });

    let mut buf = [0; 1024];
    loop {
        println!("Listening for data");

        let (len, addr) = r.recv_from(&mut buf).await?;
        println!("{:?} bytes received from {:?}", len, addr);

        if recv_servers.contains_key(&addr) {
            if len == 9
                && buf[0] == 0x7A // Start byte
                && buf[1] == 0x05 // Length
                && buf[2] == 0x14 // Cmd Code 20 (UDP ACK)
                && buf[3] == 0xFF // NetAddr b1
                && buf[4] == 0xFF // NetAddr b2
                && buf[5] == 0xFB // Payload (one byte 251 for UDP ACK)
                && buf[6] == 0xE3 // CRC
                && buf[7] == 0x0B // CS
                && buf[8] == 0x0D
            {
                println!("Received good answer from server, updating time");
                recv_servers.get_mut(&addr).unwrap().last_seen_time = Local::now();

                println!("Updated OK");
            }
        }
    }

    //handle.await.unwrap();
}
