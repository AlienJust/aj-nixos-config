ALTER TABLE `pb_command_parameter` ADD `conflicted_GUID` BINARY(16) NULL DEFAULT NULL AFTER `command`;
-- HPB-0.1.0 – 2025.02.20
ALTER TABLE `pb_subscriber` ADD `hide_for_production` BOOLEAN NOT NULL DEFAULT TRUE AFTER `description`;

CREATE TABLE `hpb`.`h_user`
(
    `ID`         INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    `username`  VARCHAR(32)       NOT NULL,
    `role`       TINYINT UNSIGNED NOT NULL,
    `password`   VARCHAR(255)     NOT NULL,
    `surname`    VARCHAR(64)      NOT NULL,
    `name`       VARCHAR(32)      NOT NULL,
    `patronymic` VARCHAR(32)      NOT NULL,
    `ban`        BOOLEAN          NOT NULL DEFAULT FALSE,
    PRIMARY KEY (`ID`)
) ENGINE = InnoDB;
CREATE TABLE `hpb`.`h_device`
(
    `user`                INT UNSIGNED     NOT NULL,
    `imprint`             VARCHAR(64)      NOT NULL,
    `attempts`            TINYINT UNSIGNED NOT NULL,
    `last_attempt_moment` TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `info`                VARCHAR(255)     NOT NULL,
    `token_moment`        TIMESTAMP        NULL     DEFAULT NULL,
    `access_token_hash`   VARCHAR(255)     NULL     DEFAULT NULL,
    `refresh_token_hash`  VARCHAR(255)     NULL     DEFAULT NULL
) ENGINE = InnoDB;
ALTER TABLE `h_device` ADD PRIMARY KEY(`user`, `imprint`);
CREATE TABLE `hpb`.`h_group`
(
    `ID`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `name`        VARCHAR(255)  NOT NULL,
    `description` VARCHAR(2000) NOT NULL,
    PRIMARY KEY (`ID`)
) ENGINE = InnoDB;
CREATE TABLE `hpb`.`h_group_tree`
(
    `master` INT UNSIGNED     NOT NULL,
    `slave`  INT UNSIGNED     NOT NULL,
    `level`  TINYINT UNSIGNED NOT NULL
) ENGINE = InnoDB;
ALTER TABLE `h_group_tree` ADD PRIMARY KEY(`master`, `slave`);

ALTER TABLE `h_group_tree`
    ADD FOREIGN KEY (`master`) REFERENCES `h_group` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `h_group_tree`
    ADD FOREIGN KEY (`slave`) REFERENCES `h_group` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE `hpb`.`h_group_x_user`
(
    `user_ID` INT UNSIGNED NOT NULL,
    `group_ID`  INT UNSIGNED NOT NULL
) ENGINE = InnoDB;
ALTER TABLE `h_group_x_user` ADD PRIMARY KEY(`user_ID`, `group_ID`);
ALTER TABLE `h_group_x_user` ADD FOREIGN KEY (`user_ID`) REFERENCES `h_user`(`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `h_group_x_user` ADD FOREIGN KEY (`group_ID`) REFERENCES `h_group`(`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE `hpb`.`h_group_x_protocol`
(
    `group_ID`    INT UNSIGNED NOT NULL,
    `protocol_ID` INT UNSIGNED NOT NULL
) ENGINE = InnoDB;
ALTER TABLE `h_group_x_protocol` ADD PRIMARY KEY(`group_ID`, `protocol_ID`);
ALTER TABLE `h_group_x_protocol` ADD FOREIGN KEY (`group_ID`) REFERENCES `h_group`(`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `h_group_x_protocol` ADD FOREIGN KEY (`protocol_ID`) REFERENCES `pb_protocol`(`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `pb_protocol` ADD `author` INT UNSIGNED NOT NULL AFTER `version`;
ALTER TABLE `pb_protocol` ADD INDEX(`author`);
UPDATE `pb_protocol` SET `author` = '4';
ALTER TABLE `pb_protocol` ADD FOREIGN KEY (`author`) REFERENCES `h_group`(`ID`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- 2025-09-17
CREATE TABLE `hpb`.`h_role` (`ID` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT , `name` VARCHAR(255) NOT NULL , PRIMARY KEY (`ID`)) ENGINE = InnoDB;

CREATE TABLE `hpb`.`h_role_action` (`role` SMALLINT UNSIGNED NOT NULL , `section` VARCHAR(255) NOT NULL , `action` VARCHAR(255) NOT NULL ) ENGINE = InnoDB;
ALTER TABLE `h_role_action` ADD PRIMARY KEY(`role`, `section`, `action`);

ALTER TABLE `h_role_action` ADD FOREIGN KEY (`role`) REFERENCES `h_role`(`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `pb_system_diagnostic_block` ADD `hide_for_production` BOOLEAN NOT NULL AFTER `inline`;
UPDATE `h_user` SET `role` = '1' WHERE `h_user`.`ID` IN (1,2);
ALTER TABLE `h_user` ADD INDEX(`role`);
ALTER TABLE `h_user` CHANGE `role` `role` SMALLINT UNSIGNED NOT NULL;
ALTER TABLE `h_user` ADD FOREIGN KEY (`role`) REFERENCES `h_role`(`ID`) ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE `h_user` ADD UNIQUE(`username`);

ALTER TABLE `pb_protocol` CHANGE `version` `version` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL;