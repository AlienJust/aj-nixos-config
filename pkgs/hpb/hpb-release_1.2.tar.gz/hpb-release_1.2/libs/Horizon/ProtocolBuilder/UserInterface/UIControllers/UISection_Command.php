<?php

namespace Horizon\ProtocolBuilder\UserInterface\UIControllers;

use Horizon\Auth\AccessDeniedException;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\Command;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToReply;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToRequest;
use Horizon\ProtocolBuilder\Exceptions\ActionAccessException;
use Horizon\ProtocolBuilder\Exceptions\DataAccessException;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\LogicItems\URL;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Command;
use Horizon\ProtocolBuilder\UserInterface\eUISection;
use Horizon\ProtocolBuilder\UserInterface\iUISectionActionEnum;
use Horizon\ProtocolBuilder\UserInterface\PageContent\_PageContentTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\CommandCopying;
use Horizon\ProtocolBuilder\UserInterface\PageContent\CommandCreation;
use Horizon\ProtocolBuilder\UserInterface\PageContent\CommandDeleteParameters;
use Horizon\ProtocolBuilder\UserInterface\PageContent\CommandDeleting;
use Horizon\ProtocolBuilder\UserInterface\PageContent\CommandEditing;
use Horizon\ProtocolBuilder\UserInterface\PageContent\CommandViewer;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCommandField;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecCommandCopying;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecCommandCreation;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecCommandDeleteParameters;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecCommandDeleting;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecCommandEditing;
use Horizon\UserInterface\Executor;

class UISection_Command extends UISectionProtected
{
    protected static eUISection $section = eUISection::command;
    private Command $command;

    public function __construct(?eUISA_Command $action = null, array $post = [])
    {
        parent::__construct($post);
        $this->action = $action;
        //if (is_null($this->getID())) $this->command = new Command($this->post['subscriber']);
    }

    public function setCommand(Command $command): static
    {
        $this->command = $command;
        return $this;
    }

    /**
     * @throws DBException
     */
    public function refCommand(): Command
    {
        return $this->command ?? ($this->command = Command::dbLoad($this->getID(), $this->post['subscriber']));
    }

    public function refAction(): ?eUISA_Command
    {
        return $this->action;
    }

    public function verifyAccessByData(): void
    {
        $this->refCommand()->refSubscriber()->refProtocol()->verifyAccess();
    }

    /**
     * @throws DBException
     */
    public function tag(): _PageContentTag
    {
        /**
         * @param ParameterToRequest[]|ParameterToReply[] $parameter_refs
         * @return array
         * @throws DBException
         */
        $get_parameters = function (array $parameter_refs): array {
            $parameters = [];
            foreach ($parameter_refs as $parameter) $parameters[$parameter->getGUID()] = $parameter->getName();
            return $parameters;
        };
        /**
         * @param ParameterToRequest[]|ParameterToReply[] $parameter_refs
         * @return array
         */
        $get_parameters_bits = function (array $parameter_refs): array {
            $parameters = [];
            foreach ($parameter_refs as $parameter) $parameters[] = [
                'name' => $parameter->getName(),
                'bits' => $parameter->getBits()
            ];
            return $parameters;
        };
        return match ($this->action) {
            eUISA_Command::view => new CommandViewer($this->refAction()->name(),
                $this->refCommand()->getName(),
                $this->refCommand()->isSystem(),
                $this->refCommand()->refRequest()->getLength(),
                $this->refCommand()->refReply()->getLength(),
                $this->refCommand()->refRequest()->getHeaderLength(),
                $this->refCommand()->refReply()->getHeaderLength(),
                $get_parameters_bits($this->refCommand()->arrParametersToRequest()),
                $get_parameters_bits($this->refCommand()->arrParametersToReply()),
                $this->refCommand()->refRequest()->getCycleMsTime(),
            ),
            eUISA_Command::new => $this->commandNewTag(),
            eUISA_Command::edit => new CommandEditing($this->refAction()->name(), $this->getURL(),
                $this->refCommand()->getName(),
                $this->refCommand()->isSystem(),
                $this->refCommand()->refRequest()->getLength(),
                $this->refCommand()->refReply()->getLength(),
                $this->refCommand()->refRequest()->getHeaderLength(),
                $this->refCommand()->refReply()->getHeaderLength(),
                $get_parameters_bits($this->refCommand()->arrParametersToRequest()),
                $get_parameters_bits($this->refCommand()->arrParametersToReply()),
                $this->refCommand()->refRequest()->getCycleMsTime(),
            )->addActionBlock(new CommandDeleting($this->refCommand()->getName(),
                eUISA_Command::delete->initController()->setCommand($this->refCommand())->getURL())),
            eUISA_Command::delete => throw new \Exception('To be implemented'),
            eUISA_Command::delete_parameters => new CommandDeleteParameters($this->refAction()->name(), $this->getURL(),
                $get_parameters($this->refCommand()->arrParametersToRequest()),
                $get_parameters($this->refCommand()->arrParametersToReply())),
        };
    }

    /**
     * @throws DBException
     */
    private function commandNewTag(): CommandCreation
    {
        $tag = new CommandCreation($this->refAction()->name(), $this->getURL(),
            $this->refCommand()->getName(),
            $this->refCommand()->isSystem(),
            $this->refCommand()->refRequest()->getLength(),
            $this->refCommand()->refReply()->getLength(),
            $this->refCommand()->refRequest()->getHeaderLength(),
            $this->refCommand()->refReply()->getHeaderLength(),
            $this->refCommand()->refRequest()->getCycleMsTime(),
        );
        $tag->addActionBlock(new CommandCopying(
            eUISA_Command::copy->value,
            eUISA_Command::copy->name(),
            eUISA_Command::copy->initController()->setCommand($this->command)->getURL())
        );
        return $tag;
    }

    /**
     * @throws DBException
     * @throws VException
     */
    public function initExecutor(): Executor
    {
        return match ($this->action) {
            eUISA_Command::new => new ExecCommandCreation($this->refCommand(),
                eCommandField::name->get($this->post),
                eCommandField::request_length->get($this->post),
                eCommandField::reply_length->get($this->post),
                eCommandField::request_header_length->get($this->post),
                eCommandField::reply_header_length->get($this->post),
                eCommandField::init_way->get($this->post),
                eCommandField::system->get($this->post),
                eCommandField::request_cycle_ms_time->get($this->post),
            ),
            eUISA_Command::copy => new ExecCommandCopying($this->refCommand(),
                eCommandField::source->get($this->post)
            ),
            eUISA_Command::edit => new ExecCommandEditing($this->refCommand(),
                eCommandField::name->get($this->post),
                eCommandField::request_length->get($this->post),
                eCommandField::reply_length->get($this->post),
                eCommandField::request_header_length->get($this->post),
                eCommandField::reply_header_length->get($this->post),
                eCommandField::system->get($this->post),
                eCommandField::request_cycle_ms_time->get($this->post),
            ),
            eUISA_Command::delete => new ExecCommandDeleting($this->refCommand()),
            eUISA_Command::delete_parameters => new ExecCommandDeleteParameters($this->refCommand(),
                eCommandField::parameters->get($this->post)),
        };
    }

    /**
     * @throws DBException
     */
    public function getCurrentID(): ?string
    {
        return $this->refCommand()->getID();
    }

    /**
     * @throws DBException
     */
    public function refURL(): URL
    {
        return new URL()
            ->setSectionAction(static::$section->value, $this->action?->value)
            ->setCommand(
                $this->refCommand()->refSubscriber()->getProtocol(),
                $this->refCommand()->getSubscriber(),
                $this->refCommand()->getID()
            );
    }

    /**
     * @throws DBException
     */
    public static function initWithAction(eUISA_Command|iUISectionActionEnum|null $action): ?static
    {
        $order = eUISA_Command::actionOrder();
        $controller = !is_null($action)
            ? $action->initController()
            : eUISA_Command::tryFrom($action?->value)?->initController();
        if ($controller !== null) try {
            $controller->verifyAccess();
            return $controller;
        } catch (AccessDeniedException|ActionAccessException|DataAccessException) {
            return static::initDefault($order);
        } else return static::initDefault($order);
    }
}