<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandNameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandReplyHeaderLengthTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandReplyLengthTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandRequestCycleMsTimeTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandRequestHeaderLengthTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandRequestLengthTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandSystemTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\UpdatingButton;
use Horizon\UserInterface\PresetTags\Division2Columns;
use Horizon\UserInterface\PresetTags\PostViewMatrix;
use Horizon\UserInterface\Tags\Fieldset;

class CommandEditing extends _PageContentTag
{
    public function __construct(string $header, string $action_URL, string $name, bool $system,
                                int $request_length, int $reply_length,
                                int $request_header_length, int $reply_header_length,
                                array $request_params, array $reply_params, ?float $cycle_ms_time)
    {
        parent::__construct($header);
        $this//->add(new Fieldset('Запрос')->add($request_tag = new PostViewMatrix($request_length, $request_header_length)))
            //->add(new Fieldset('Ответ')->add($reply_tag = new PostViewMatrix($reply_length, $reply_header_length)))
            ->add(new MainForm($action_URL)
                ->add(new CommandNameTag($name))
                ->add(new Division2Columns()
                    ->add(new CommandRequestLengthTag($request_length))
                    ->add(new CommandRequestHeaderLengthTag($request_header_length))
                    ->add(new CommandReplyLengthTag($reply_length))
                    ->add(new CommandReplyHeaderLengthTag($reply_header_length))
                    ->add(new CommandRequestCycleMsTimeTag($cycle_ms_time))
                    ->add(new CommandSystemTag($system)))
                ->add(new UpdatingButton()));
        //foreach ($request_params as $param) $request_tag->setParameter($param['name'], $param['bits']);
        //foreach ($reply_params as $param) $reply_tag->setParameter($param['name'], $param['bits']);
    }
}