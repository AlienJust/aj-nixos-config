<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_Protocol;

enum eUISA_Protocol: string implements iUISectionActionEnum
{
    case view = 'view';
    case new = 'new';
    case import = 'import';
    case edit = 'edit';
    case edit_author = 'edit_author';
    case delete = 'delete';
    case manual = 'manual';
    case init_psn_xml = 'init_psn_xml';
    case init_tabs_xml = 'init_tabs_xml';
    case init_main_xaml = 'init_main_xaml';

    case import_param_views = 'import_param_views';
    case system_diagnostic_tuning = 'system_diagnostic_tuning';
    case system_diagnostic_allocating = 'system_diagnostic_allocating';
    case system_diagnostic_renaming = 'system_diagnostic_editing';
    case groups_editing = 'groups_editing';

    public function code(): string
    {
        return $this->name;
    }

    public function name(): string
    {
        return match ($this) {
            self::view => 'Просмотр протокола',
            self::new => 'Создание протокола',
            self::import => 'Импорт протокола',
            self::edit => 'Изменение протокола',
            self::edit_author => 'Изменение автора протокола',
            self::delete => 'Удаление протокола',
            self::init_psn_xml => 'Инициализация psn.xml',
            self::init_tabs_xml => 'Инициализация tabs.xml',
            self::init_main_xaml => 'Инициализация main.xaml',
            self::import_param_views => 'Импорт представлений параметров',
            self::system_diagnostic_tuning => 'Настройка контента окна "Диагностика системы"',
            self::system_diagnostic_allocating => 'Распределение контента в окне "Диагностика системы"',
            self::system_diagnostic_renaming => 'Переименование параметров в окне "Диагностика системы"',
            self::manual => 'Руководство пользователя',
            self::groups_editing => 'Группы доступа',
        };
    }

    public function buttonName(): string
    {
        return match ($this) {
            self::view => 'Обзор',
            self::new => '+ протокол',
            self::import => 'Импорт',
            self::edit => 'Изменить',
            self::edit_author => 'Автор',
            self::delete => 'Удалить',
            self::manual => 'Руководство пользователя',
            self::init_psn_xml => 'PSN.XML',
            self::init_tabs_xml => 'TABS.XML',
            self::init_main_xaml => 'MAIN.XAML',
            self::import_param_views => 'Импорт ПП',
            self::system_diagnostic_tuning => 'ДС: контент',
            self::system_diagnostic_allocating => 'ДС: конструктор',
            self::system_diagnostic_renaming => 'ДС: переименование',
            self::groups_editing => 'Группы доступа',
        };
    }

    public static function controlPanel(): array
    {
        return [
            self::view,
            self::edit,
            self::groups_editing,
            self::import_param_views,
            self::init_psn_xml,
            self::init_tabs_xml,
            self::init_main_xaml,
            self::system_diagnostic_tuning,
            self::system_diagnostic_renaming,
        ];
    }

    public static function actionOrder(): array
    {
        return [
            self::edit,
            self::view,
            self::init_psn_xml,
            self::init_tabs_xml,
            self::init_main_xaml,
            self::groups_editing,
            self::import_param_views,
            self::system_diagnostic_tuning,
            self::system_diagnostic_renaming,
        ];
    }

    public function initController(array $post = [], array $files = []): UISection_Protocol
    {
        return new UISection_Protocol($this, $post, $files);
    }

    public function unlimitedAccess(): bool
    {
        return false;
    }
}