<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields;

use Horizon\ProtocolBuilder\Exceptions\UploadException;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\LogicItems\ToIntRequiredHandler;
use Horizon\ProtocolBuilder\LogicItems\ToStringNullableHandler;
use Horizon\ProtocolBuilder\LogicItems\ToStringRequiredHandler;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputModels\TempFile;

enum eProtocolField implements iTransmissionField
{
    case name;
    case description;
    case version;
    case GUID;
    case author;
    case groups;
    case psn_file;
    case tabs_file;
    case parameter_views;
    case summon_system_diagnostic_block_counter;
    case summon_system_diagnostic_virtual_parameter_counter;
    case summon_system_diagnostic_aggregate_group_counter;
    case summon_system_diagnostic_aggregate_parameter_counter;
    case blocks;
    case block_id;
    case block_name;
    case block_columns_count;
    case block_inline;
    case block_hide_for_production;
    case diagnostic_list;
    case parameter_view;
    case parameter_view_name;
    case virtual_parameters;
    case virtual_parameter_code;
    case virtual_parameter_new_code;
    case aggregate_groups;
    case aggregate_group_counter;
    case aggregate_group_id;
    case aggregate_group_label;
    case aggregate_parameters;
    case aggregate_parameter_code;

    public function code(mixed ...$options): string
    {
        return match ($this) {
            self::name,
            self::description,
            self::version,
            self::GUID,
            self::author,
            self::psn_file,
            self::tabs_file,
            self::parameter_views,
            self::summon_system_diagnostic_block_counter,
            self::summon_system_diagnostic_virtual_parameter_counter,
            self::summon_system_diagnostic_aggregate_group_counter,
            self::blocks,
            self::virtual_parameters,
            self::aggregate_groups,
            self::parameter_view => $this->name,
            self::block_id => self::blocks->code() . "[$options[0]][id]",
            self::block_name => self::blocks->code() . "[$options[0]][name]",
            self::block_columns_count => self::blocks->code() . "[$options[0]][columns_count]",
            self::block_inline => self::blocks->code() . "[$options[0]][inline]",
            self::block_hide_for_production => self::blocks->code() . "[$options[0]][block_hide_for_production]",
            self::diagnostic_list => $this->name . "[]",
            self::parameter_view_name => self::parameter_view->code() . "[$options[0]][name]",
            self::virtual_parameter_code => self::virtual_parameters->code() . "[$options[0]][code]",
            self::virtual_parameter_new_code => self::virtual_parameters->code() . "[$options[0]][new_code]",
            self::aggregate_group_counter => self::aggregate_groups->code() ."[$options[0]][counter]",
            self::aggregate_group_id => self::aggregate_groups->code() ."[$options[0]][id]",
            self::aggregate_group_label => self::aggregate_groups->code() ."[$options[0]][label]",
            self::summon_system_diagnostic_aggregate_parameter_counter => self::aggregate_groups->code() ."[$options[0]][parameter_counter]",
            self::aggregate_parameters => self::aggregate_groups->code() ."[$options[0]][parameters]",
            self::aggregate_parameter_code => self::aggregate_groups->code() ."[$options[0]][parameters][$options[1]][code]",
            self::groups => "$this->name[$options[0]]",
        };
    }

    /**
     * @throws UploadException
     * @throws VException
     */
    public function get(array $post): null|string|array|bool|TempFile
    {
        return match ($this) {
            self::name,
            self::description,
            self::version => ToStringRequiredHandler::run($post[$this->code()] ?? '', $this->name),
            self::GUID => ToStringNullableHandler::run($post[$this->code()] ?? null),
            self::author => ToIntRequiredHandler::run($post[$this->code()] ?? null, $this->name),
            self::groups => array_keys($post[$this->name] ?? []),
            self::psn_file, self::tabs_file => TempFile::fromFILES($_FILES[$this->code()]),
            self::parameter_views => array_keys($post[$this->code()] ?? []),
            self::summon_system_diagnostic_block_counter,
            self::summon_system_diagnostic_virtual_parameter_counter,
            self::summon_system_diagnostic_aggregate_group_counter => $post[$this->code()] ?? 0,
            self::blocks,
            self::virtual_parameters,
            self::aggregate_groups,
            self::diagnostic_list,
            self::parameter_view => $post[$this->name] ?? [],
            self::block_id,
            self::aggregate_group_id => $post['id'] ?? null,
            self::aggregate_group_counter => array_find($post, fn($name) =>
            preg_match('/^' .self::aggregate_groups->code() . '\{(.*)\}\{counter\}$/i', $name)) ?? 0,
            self::block_name,
            self::parameter_view_name => $post['name'] ?? '',
            self::block_columns_count => $post['columns_count'] ?? 1,
            self::block_inline => $post['inline'] ?? 0 == 1,
            self::block_hide_for_production => $post['block_hide_for_production'] ?? 0 == 1,
            self::virtual_parameter_code => $post['code'] ?? '',
            self::virtual_parameter_new_code => $post['new_code'] ?? '',
            self::aggregate_group_label => $post['label'] ?? '',
            self::summon_system_diagnostic_aggregate_parameter_counter => array_find($post, fn($name) =>
            preg_match('/^' .self::aggregate_groups->code() . '\{(.*)\}\{parameter_counter\}$/i', $name)) ?? 0,
            self::aggregate_parameters => $post['parameters'] ?? [],
            self::aggregate_parameter_code => $post['code'] ?? [],
        };
    }

    public function label(): string
    {
        return match ($this) {
            self::name => 'Наименование протокола',
            self::description => 'Описание протокола',
            self::version => 'Версия протокола',
            self::GUID => 'Уникальный идентификатор',
            self::author => 'Автор протокола',
            self::groups => throw new \Exception('To be implemented'),
            self::psn_file => throw new \Exception('To be implemented'),
            self::tabs_file => throw new \Exception('To be implemented'),
            self::parameter_views => throw new \Exception('To be implemented'),
            self::summon_system_diagnostic_block_counter => throw new \Exception('To be implemented'),
            self::summon_system_diagnostic_virtual_parameter_counter => throw new \Exception('To be implemented'),
            self::summon_system_diagnostic_aggregate_group_counter => throw new \Exception('To be implemented'),
            self::summon_system_diagnostic_aggregate_parameter_counter => throw new \Exception('To be implemented'),
            self::blocks => throw new \Exception('To be implemented'),
            self::block_id => throw new \Exception('To be implemented'),
            self::block_name => throw new \Exception('To be implemented'),
            self::block_columns_count => throw new \Exception('To be implemented'),
            self::block_inline => throw new \Exception('To be implemented'),
            self::block_hide_for_production => throw new \Exception('To be implemented'),
            self::diagnostic_list => throw new \Exception('To be implemented'),
            self::parameter_view => throw new \Exception('To be implemented'),
            self::parameter_view_name => throw new \Exception('To be implemented'),
            self::virtual_parameters => throw new \Exception('To be implemented'),
            self::virtual_parameter_code => throw new \Exception('To be implemented'),
            self::virtual_parameter_new_code => throw new \Exception('To be implemented'),
            self::aggregate_groups => throw new \Exception('To be implemented'),
            self::aggregate_group_counter => throw new \Exception('To be implemented'),
            self::aggregate_group_id => throw new \Exception('To be implemented'),
            self::aggregate_group_label => throw new \Exception('To be implemented'),
            self::aggregate_parameters => throw new \Exception('To be implemented'),
            self::aggregate_parameter_code => throw new \Exception('To be implemented'),
        };
    }

    public function title(): string
    {
        return match ($this) {
            self::name => 'Введите наименование протокола',
            self::description => 'Введите описание протокола',
            self::version => 'Введите версию протокола',
            self::GUID => 'Уникальный идентификатор генерируется автоматически',
            self::author => 'Выберите группу, которой будут принадлежать права на владение протоколом',
            self::groups => throw new \Exception('To be implemented'),
            self::psn_file => throw new \Exception('To be implemented'),
            self::tabs_file => throw new \Exception('To be implemented'),
            self::parameter_views => throw new \Exception('To be implemented'),
            self::summon_system_diagnostic_block_counter => throw new \Exception('To be implemented'),
            self::summon_system_diagnostic_virtual_parameter_counter => throw new \Exception('To be implemented'),
            self::summon_system_diagnostic_aggregate_group_counter => throw new \Exception('To be implemented'),
            self::summon_system_diagnostic_aggregate_parameter_counter => throw new \Exception('To be implemented'),
            self::blocks => throw new \Exception('To be implemented'),
            self::block_id => throw new \Exception('To be implemented'),
            self::block_name => throw new \Exception('To be implemented'),
            self::block_columns_count => throw new \Exception('To be implemented'),
            self::block_inline => throw new \Exception('To be implemented'),
            self::block_hide_for_production => throw new \Exception('To be implemented'),
            self::diagnostic_list => throw new \Exception('To be implemented'),
            self::parameter_view => throw new \Exception('To be implemented'),
            self::parameter_view_name => throw new \Exception('To be implemented'),
            self::virtual_parameters => throw new \Exception('To be implemented'),
            self::virtual_parameter_code => throw new \Exception('To be implemented'),
            self::virtual_parameter_new_code => throw new \Exception('To be implemented'),
            self::aggregate_groups => throw new \Exception('To be implemented'),
            self::aggregate_group_counter => throw new \Exception('To be implemented'),
            self::aggregate_group_id => throw new \Exception('To be implemented'),
            self::aggregate_group_label => throw new \Exception('To be implemented'),
            self::aggregate_parameters => throw new \Exception('To be implemented'),
            self::aggregate_parameter_code => throw new \Exception('To be implemented'),

        };
    }
}
