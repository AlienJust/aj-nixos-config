<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\Data\eCommandInitWay;
use Horizon\ProtocolBuilder\Data\eParameterType;
use Horizon\ProtocolBuilder\Data\eParameterVariableName;
use Horizon\ProtocolBuilder\DataBase\Tables\Command;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToReply;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToRequest;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\LogicItems\HexByte;
use Horizon\ProtocolBuilder\LogicItems\HexWord;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Command;
use Horizon\UserInterface\Executor;

class ExecCommandCreation extends Executor
{
    private ?int $command;
    private int $request_length;
    private int $reply_length;
    /**
     * @throws DBException
     * @throws VException
     */
    public function __construct(Command $command, string $name, int $request_length, int $reply_length,
                                int $request_header_length, int $reply_header_length, string $init_way, bool $system,
                                ?float $cycle_ms_time)
    {

        switch (eCommandInitWay::tryFrom($init_way)) {
            case eCommandInitWay::modbus_read:
                if ($request_length >= 6 + 2 && $reply_length >= 3 + 2) {
                    $request_header_length = 6;
                    $reply_header_length = 3;
                    $this->initCommand($command, $name, $request_length, $reply_length, $request_header_length, $reply_header_length, $system, $cycle_ms_time);
                    $register_count = new HexWord(($reply_length - 5) / 2);
                    $this->initModbusDefaultHeaders($register_count, $command->refSubscriber()->getAddress(), 3);
                    $this->initDefaultReplyParameter('Количество байт данных', $reply_length - 5, 16, 23);
                } else $this->initSimple($command, $name, $request_length, $reply_length, $system, $cycle_ms_time);
                break;
            case eCommandInitWay::modbus_write:
                if ($request_length >= 7 + 2 && $reply_length >= 6 + 2) {
                    $register_count = new HexWord(($request_length - 9) / 2);
                    $request_header_length = 7;
                    $reply_header_length = 6;
                    $this->initCommand($command, $name, $request_length, $reply_length, $request_header_length, $reply_header_length, $system, $cycle_ms_time);
                    $this->initModbusDefaultHeaders($register_count, $command->refSubscriber()->getAddress(), 16);
                    $this->initDefaultRequestParameter('Количество байт далее', $request_length - 9, 48, 55);
                    $this->initDefaultReplyParameter('Адрес первого регистра Hi', '0', 16, 23);
                    $this->initDefaultReplyParameter('Адрес первого регистра Lo', '0', 24, 31);
                    $this->initDefaultReplyParameter('Количество регистров Hi', $register_count->hi, 32, 39);
                    $this->initDefaultReplyParameter('Количество регистров Lo', $register_count->lo, 40, 47);
                } else $this->initSimple($command, $name, $request_length, $reply_length, $system, $cycle_ms_time);
                break;
            case eCommandInitWay::simple:
                $this->initSimple($command, $name, $request_length, $reply_length, $system, $cycle_ms_time);
                break;
            default:
                $this->initCommand($command, $name, $request_length, $reply_length, $request_header_length, $reply_header_length, $system, $cycle_ms_time);
        }
        $this->initCRCParameters();
        parent::__construct(eUISA_Command::edit->initController()->setCommand($command)->getURL());
    }

    /**
     * @throws DBException
     * @throws VException
     */
    private function initSimple(Command $command, string $name, int $request_length, int $reply_length, bool $system,
                                ?float  $cycle_ms_time): void
    {
        $request_header_length = $request_length >= 4 ? 2 : 0;
        $reply_header_length = $reply_length >= 4 ? 2 : 0;
        $this->initCommand($command, $name, $request_length, $reply_length, $request_header_length, $reply_header_length, $system, $cycle_ms_time);
        $this->initSimpleHeaders($command->refSubscriber()->getAddress(), null);
    }

    /**
     * @throws DBException
     */
    private function initCommand(Command $command, string $name, int $request_length, int $reply_length,
                                 int     $request_header_length, int $reply_header_length, bool $system,
                                 ?float  $cycle_ms_time): void
    {
        $request_required = $reply_header_length == $request_header_length && $reply_length == $request_length;
        $command->setName($name)->setSystem($system);
        $command->setRequest($request_length, 0, $request_header_length, $cycle_ms_time);
        $command->setReply($reply_length, $request_length, $reply_header_length, $request_required);
        $command->dbInsert();
        $this->command = $command->getID();
        $this->request_length = $request_length;
        $this->reply_length = $reply_length;
    }

    /**
     * @throws DBException
     * @throws VException
     */
    private function initDefaultRequestParameter(string $name, string $value, int $first_bit, int $last_bit): void
    {
        new ParameterToRequest($this->command)->initGUID()
            ->setName($name)
            ->setType(eParameterType::DefVal->value)
            ->setValue($value)
            ->setBits(range($first_bit, $last_bit))
            ->dbInsert();
    }

    /**
     * @throws DBException
     * @throws VException
     */
    private function initDefaultReplyParameter(string $name, string $value, int $first_bit, int $last_bit): void
    {
        new ParameterToReply($this->command)->initGUID()
            ->setName($name)
            ->setType(eParameterType::DefVal->value)
            ->setValue($value)
            ->setBits(range($first_bit, $last_bit))
            ->dbInsert();
    }

    /**
     * @throws DBException
     * @throws VException
     */
    private function initCRCParameters(): void
    {
        if ($this->request_length > 1) {
            new ParameterToRequest($this->command)->initGUID()
                ->setName(eParameterVariableName::CRC_h->value)
                ->setType(eParameterType::VarVal->value)
                ->setBits(range($this->request_length * 8 - 16, $this->request_length * 8 - 9))
                ->dbInsert();
            new ParameterToRequest($this->command)->initGUID()
                ->setName(eParameterVariableName::CRC_l->value)
                ->setType(eParameterType::VarVal->value)
                ->setBits(range($this->request_length * 8 - 8, $this->request_length * 8 - 1))
                ->dbInsert();
        }
        if ($this->reply_length > 1) {
            new ParameterToReply($this->command)->initGUID()
                ->setName(eParameterVariableName::CRC_h->value)
                ->setType(eParameterType::VarVal->value)
                ->setBits(range($this->reply_length * 8 - 16, $this->reply_length * 8 - 9))
                ->dbInsert();
            new ParameterToReply($this->command)->initGUID()
                ->setName(eParameterVariableName::CRC_l->value)
                ->setType(eParameterType::VarVal->value)
                ->setBits(range($this->reply_length * 8 - 8, $this->reply_length * 8 - 1))
                ->dbInsert();
        }
    }

    /**
     * @throws DBException
     * @throws VException
     */
    private function initSimpleHeaders(int $subscriber_address, ?int $command_address): void
    {
        $sa = new HexByte($subscriber_address);
        $ca = $command_address === null ? null : new HexByte($command_address);
        if ($this->request_length >= 4) {
            $this->initDefaultRequestParameter('#ADDR', $sa->hex, 0, 7);
            $this->initDefaultRequestParameter('#NCMD', $ca?->hex ?? '', 8, 15);
        }
        if ($this->reply_length >= 4) {
            $this->initDefaultReplyParameter('#ADDR', $sa->hex, 0, 7);
            $this->initDefaultReplyParameter('#NCMD', $ca?->hex ?? '', 8, 15);
        }
    }

    /**
     * @throws DBException
     * @throws VException
     */
    private function initModbusDefaultHeaders(HexWord $register_count, int $subscriber_address, int $command_address): void
    {
        $this->initSimpleHeaders($subscriber_address, $command_address);
        $this->initDefaultRequestParameter('Адрес первого регистра Hi', '0', 16, 23);
        $this->initDefaultRequestParameter('Адрес первого регистра Lo', '0', 24, 31);
        $this->initDefaultRequestParameter('Количество регистров Hi', $register_count->hi, 32, 39);
        $this->initDefaultRequestParameter('Количество регистров Lo', $register_count->lo, 40, 47);
    }
}