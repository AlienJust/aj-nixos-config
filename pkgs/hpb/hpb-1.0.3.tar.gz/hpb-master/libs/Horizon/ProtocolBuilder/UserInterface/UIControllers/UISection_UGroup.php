<?php

namespace Horizon\ProtocolBuilder\UserInterface\UIControllers;

use Horizon\Auth\AccessDeniedException;
use Horizon\Auth\DataBase\ListSources\UGroupListSource;
use Horizon\Auth\DataBase\Tables\Group;
use Horizon\Auth\DataBase\Tables\User;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\Exceptions\ActionAccessException;
use Horizon\ProtocolBuilder\Exceptions\DataAccessException;
use Horizon\ProtocolBuilder\Exceptions\UIEx;
use Horizon\ProtocolBuilder\Exceptions\UIException;
use Horizon\ProtocolBuilder\LogicItems\URL;
use Horizon\ProtocolBuilder\UserInterface\eUISA_UGroup;
use Horizon\ProtocolBuilder\UserInterface\eUISection;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecUGroupCreation;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecUGroupDeleting;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecUGroupEditing;
use Horizon\ProtocolBuilder\UserInterface\PageContent\_PageContentTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eUGroupField;
use Horizon\ProtocolBuilder\UserInterface\PageContent\UGroupCreation;
use Horizon\ProtocolBuilder\UserInterface\PageContent\UGroupDeleting;
use Horizon\ProtocolBuilder\UserInterface\PageContent\UGroupEditing;
use Horizon\ProtocolBuilder\UserInterface\PageContent\UGroupList;
use Horizon\UserInterface\Executor;

class UISection_UGroup extends UISection
{
    protected static eUISection $section = eUISection::user_group;
    private ?eUISA_UGroup $action;
    private Group $group;
    public function __construct(eUISA_UGroup $action, array $post = [])
    {
        parent::__construct($post);
        $this->action = $action;
    }

    public function setGroup(Group $group): static
    {
        $this->group = $group;
        return $this;
    }

    /**
     * @throws DBException
     */
    public function refGroup(): Group
    {
        return $this->group ?? ($this->group = Group::dbLoad($this->getID()));
    }

    public function refAction(): ?eUISA_UGroup
    {
        return $this->action;
    }

    /**
     * @throws DBException
     * @throws DataAccessException
     * @throws ActionAccessException
     */
    public function verifyAccess(): void
    {
        if (!User::current()->isAdmin()) throw new ActionAccessException();
        match ($this->action) {
            eUISA_UGroup::new,
            eUISA_UGroup::view => null,
            default => $this->refGroup()->verifyAccess()
        };
    }

    /**
     * @throws DBException
     * @throws UIException
     */
    public function tag(): _PageContentTag
    {
        return match ($this->action) {
            eUISA_UGroup::view => $this->groupListTag(),
            eUISA_UGroup::new => new UGroupCreation($this->getHeader(), $this->getURL(),
                '',
                '',
                null
            ),
            eUISA_UGroup::edit => new UGroupEditing($this->getHeader(), $this->getURL(),
                $this->refGroup()->name,
                $this->refGroup()->description,
                $this->refGroup()->getOwner(),
                $this->refGroup()->getID()
            )->addActionBlock(new UGroupDeleting($this->refGroup()->name,
                eUISA_UGroup::delete->initController()->setGroup($this->refGroup())->getURL())),
            //eUISA_UGroup::delete => throw new \Exception('To be implemented'),
            default => throw new UIException(UIEx::actionNotImplemented)
        };
    }

    public function initExecutor(): Executor
    {
        return match ($this->action) {
            //eUISA_UGroup::view => throw new \Exception('To be implemented'),
            eUISA_UGroup::new => new ExecUGroupCreation($this->refGroup(),
                eUGroupField::name->get($this->post),
                eUGroupField::description->get($this->post),
                eUGroupField::owner->get($this->post),
            ),
            eUISA_UGroup::edit => new ExecUGroupEditing($this->refGroup(),
                eUGroupField::name->get($this->post),
                eUGroupField::description->get($this->post),
                eUGroupField::owner->get($this->post),
            ),
            eUISA_UGroup::delete => new ExecUGroupDeleting($this->refGroup()),
            default => throw new UIException(UIEx::executeNotImplemented, $this->action->name())
        };
    }

    public function getCurrentID(): ?string
    {
        return $this->group->getID();
    }

    public function refURL(): URL
    {
        try {
            $ID = $this->refGroup()->exists() ? $this->refGroup()->getID() : null;
        } catch (DBException) {
            $ID = null;
        }
        return new URL()
            ->setSectionAction(static::$section->value, $this->action?->value)
            ->setAnyID($ID);
    }

    /**
     * @throws DBException
     */
    private function groupListTag(): UGroupList
    {
        $edit_controller = eUISA_UGroup::edit->initController();
        $tag = new UGroupList($this->refAction()->name());
        $viewer = new UGroupListSource(1, 3000, null);
        $groups = $viewer->loadData();
        foreach ($groups as $group) {
            $tag->addItem($group->name, $group->description, $group->getLevel(), $edit_controller->setGroup($group)->getURL());
        }
        return $tag;
    }
}