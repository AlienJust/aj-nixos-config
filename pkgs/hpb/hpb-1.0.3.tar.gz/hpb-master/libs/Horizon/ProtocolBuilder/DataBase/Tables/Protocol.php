<?php

namespace Horizon\ProtocolBuilder\DataBase\Tables;

use Horizon\Auth\DataBase\Tables\User;
use Horizon\DataBaseController\dbTableAI;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\DataBaseController\iTableConfig;
use Horizon\ProtocolBuilder\DataBase\eTable;
use Horizon\ProtocolBuilder\Exceptions\DAEx;
use Horizon\ProtocolBuilder\Exceptions\DataAccessException;
use PDO;

final class Protocol extends dbTableAI
{
    protected static iTableConfig $table_config = eTable::pb_protocol;
    public string $name = '';
    public string $description = '';
    public string $version = '';
    /**
     * @throws DBException
     */
    public string $GUID {
        set(?string $value) => $value ?? self::UUID();
        get => $this->GUID ?? ($this->GUID = self::UUID());
    }
    public int $author;

    public function __construct(?int $ID = null)
    {
        if (!is_null($ID)) $this->ID = $ID;
    }


    /**
     * @throws DBException
     */
    public function drawGroups(): string
    {
        $stmt = self::PDO()->prepare("SELECT GROUP_CONCAT(`name` SEPARATOR ', ') FROM `h_group` 
              WHERE `ID` IN (SELECT `group_ID` FROM `h_group_x_protocol` WHERE `protocol_ID` = :this);");
        $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchColumn();
    }

    /**
     * @throws DBException
     */
    public function arrGroups(): array
    {
        $stmt = self::PDO()->prepare("SELECT `group_ID` FROM `h_group_x_protocol` WHERE `protocol_ID` = :this;");
        $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
        $stmt->execute();
        return $this->asArray($stmt->fetchAll(PDO::FETCH_COLUMN));
    }

    /**
     * @return Subscriber[]
     * @throws DBException
     */
    public function arrSubscribers(): array
    {
        $stmt = self::PDO()->prepare('SELECT pbs.*, TRUE AS `exists` 
            FROM `pb_subscriber` AS pbs 
            WHERE pbs.`protocol`=:this;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, Subscriber::class));
    }

    /**
     * @return SystemDiagnosticBlock[]
     * @throws DBException
     */
    public function arrBlocks():array
    {
        $stmt = self::PDO()->prepare('SELECT psdb.*, TRUE AS `exists` 
            FROM `pb_system_diagnostic_block` AS psdb 
            WHERE psdb.`protocol`=:this
            ORDER BY psdb.`sort`, psdb.`ID`;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, SystemDiagnosticBlock::class));
    }

    /**
     * @return SystemDiagnosticBlock[]
     * @throws DBException
     */
    public function arrMainBlocks(): array
    {
        $stmt = self::PDO()->prepare('SELECT psdb.*, TRUE AS `exists` 
            FROM `pb_system_diagnostic_block` AS psdb 
            WHERE psdb.`protocol`=:this
              AND psdb.`inline` IS FALSE
            ORDER BY psdb.`sort`, psdb.`ID`;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, SystemDiagnosticBlock::class));
    }

    /**
     * @return SystemDiagnosticVirtualChunk[]
     * @throws DBException
     */
    public function arrVirtualParameters(): array
    {
        $stmt = self::PDO()->prepare('SELECT 
                psdvc.`block`, psdvc.`row_id`, psdvc.`column_id`, psdvc.`protocol`, psdvc.`code` 
            FROM `pb_system_diagnostic_virtual_chunk` AS psdvc 
            WHERE psdvc.`protocol`=:this
            ORDER BY psdvc.`code`;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_FUNC, SystemDiagnosticVirtualChunk::fromDataBase(...)));
    }

    /**
     * @return SystemDiagnosticAggregateChunk[]
     * @throws DBException
     */
    public function arrAggregateGroups(): array
    {
        $stmt = self::PDO()->prepare('SELECT 
                psdac.*, TRUE AS `exists` 
            FROM `pb_system_diagnostic_aggregate_chunk` AS psdac 
            WHERE psdac.`protocol`=:this
            ORDER BY psdac.`ID`;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, SystemDiagnosticAggregateChunk::class));
    }

    /**
     * @return ParameterView[]
     * @throws DBException
     */
    public function arrParameterViews(): array
    {
        $stmt = self::PDO()->prepare('SELECT 
                pcpv.`protocol`, 
                pcpv.`code`, 
                BinToUUID(pcpv.`identifier`) AS `identifier`, 
                pcpv.`comment`, 
                pcpv.`custom_name`, 
                pcpv.`format`, 
                pcpv.`mask`,
                TRUE AS `exists` 
            FROM `pb_command_parameter_view` AS pcpv 
            WHERE pcpv.`protocol`=:this
            ORDER BY pcpv.`code`;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, ParameterView::class));
    }

    /**
     * @throws DataAccessException
     * @throws DBException
     */
    public function verifyAccess(): void
    {
        if (!$this->exists()) throw new DataAccessException(DAEx::data_not_found);
        $stmt = self::PDO()->prepare("SELECT 
        EXISTS(SELECT * FROM `h_group_x_protocol` WHERE `protocol_ID` = :this AND `group_ID` IN (SELECT `slave` AS `gr`
            FROM `h_group_tree` -- все потомки доступных пользователю групп
            WHERE `master` IN (SELECT `group_ID` FROM `h_group_x_user` WHERE `user_ID` = :current_user)
            UNION ALL
            -- все доступные пользователю группы
            (SELECT `group_ID` AS `gr` FROM `h_group_x_user` WHERE `user_ID` = :current_user)))
        OR :author IN (SELECT `slave` AS `gr`
            FROM `h_group_tree` -- все потомки доступных пользователю групп
            WHERE `master` IN (SELECT `group_ID` FROM `h_group_x_user` WHERE `user_ID` = :current_user)
            UNION ALL
            -- все доступные пользователю группы
            (SELECT `group_ID` AS `gr` FROM `h_group_x_user` WHERE `user_ID` = :current_user));");
        $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
        $stmt->bindValue(':current_user', User::current()->getID(), PDO::PARAM_INT);
        $stmt->bindValue(':author', $this->author, PDO::PARAM_INT);
        $stmt->execute();
        if (!$stmt->fetchColumn()) throw new DataAccessException(DAEx::unavailable_data);
    }

    /**
     * @throws DBException
     */
    public function checkAuthor(): bool
    {
        $stmt = self::PDO()->prepare("SELECT EXISTS(SELECT * FROM `pb_protocol` 
        WHERE `ID`=:this 
          AND `author` IN (SELECT `slave` AS `gr`
            FROM `h_group_tree` -- все потомки доступных пользователю групп
            WHERE `master` IN (SELECT `group_ID` FROM `h_group_x_user` WHERE `user_ID` = :current_user)
            UNION ALL
            -- все доступные пользователю группы
            (SELECT `group_ID` AS `gr` FROM `h_group_x_user` WHERE `user_ID` = :current_user)));");
        $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
        $stmt->bindValue(':current_user', User::current()->getID(), PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchColumn();
    }

    /**
     * @throws DBException
     */
    public function dbUpdateGroups(array $groups): void
    {
        self::dbAction(function () use ($groups) {
            if (count($groups) == 0) {
                $stmt = self::PDO()->prepare("DELETE FROM `h_group_x_protocol` WHERE `protocol_ID`=:this;");
                $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
                $stmt->execute();
                return;
            }
            $x = implode(', ', array_map(fn($k) => ":x_$k", array_keys($groups)));
            $stmt = self::PDO()->prepare("DELETE FROM `h_group_x_protocol`  
                WHERE `protocol_ID` = :this
                  AND `group_ID` NOT IN ($x);");
            $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
            foreach ($groups as $k => $group) $stmt->bindValue(":x_$k", $group, PDO::PARAM_INT);
            $stmt->execute();
            $stmt = self::PDO()->prepare("INSERT IGNORE INTO `h_group_x_protocol`(`group_ID`,`protocol_ID`) VALUES (:gr,:this);");
            $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
            foreach ($groups as $group) {
                $stmt->bindValue(':gr', $group, PDO::PARAM_INT);
                $stmt->execute();
            }
        });
    }

    /**
     * @throws DBException
     */
    public function dbUpdateChunks(array $parameter_views): void
    {
        self::dbAction(function () use ($parameter_views) {
            if (count($parameter_views) > 0) {
                $x = implode(', ', array_map(fn($idx) => ":x_$idx", range(0, count($parameter_views) - 1)));
                $stmt = self::PDO()->prepare("DELETE
                FROM `pb_system_diagnostic_chunk`
                WHERE (`block` IS NULL OR `block` IN (SELECT `ID` FROM `pb_system_diagnostic_block` WHERE `protocol` = :this))
                  AND `protocol` = :this
                  AND `code` NOT IN ($x);");
                foreach ($parameter_views as $idx => $code) $stmt->bindValue(":x_$idx", $code);
            } else {
                $stmt = self::PDO()->prepare("DELETE
                FROM `pb_system_diagnostic_chunk`
                WHERE (`block` IS NULL OR `block` IN (SELECT `ID` FROM `pb_system_diagnostic_block` WHERE `protocol` = :this))
                  AND `protocol` = :this;");
            }
            $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
            $stmt->execute();

            $row = self::PDO()->query('SELECT 
                    IFNULL(MAX(`row_id`), 0) + 1 
                FROM `pb_system_diagnostic_chunk` 
                WHERE `block` IS NULL AND `column_id`=0;')->fetchColumn();
            foreach ($parameter_views as $code) try {
                SystemDiagnosticChunk::dbFind($this->getID(), $code)
                    ->tryUpdate();
            } catch (DBException) {
                new SystemDiagnosticChunk(null, $row, 0, $this->getID(), $code)
                    ->tryInsert();
                $row++;
            }
        });
    }

    /**
     * @throws DBException
     */
    public function dbClearBlocks(array $blocks): void
    {
        self::dbAction(function () use ($blocks) {
            $blocks = array_values($blocks);
            if (count($blocks) > 0) {
                $x = implode(', ', array_map(fn($idx) => ":x_$idx", range(0, count($blocks) - 1)));
                $stmt = self::PDO()->prepare("DELETE
                    FROM `pb_system_diagnostic_block`
                    WHERE `protocol` = :this
                      AND `ID` NOT IN ($x);");
                $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
                foreach ($blocks as $idx => $code) $stmt->bindValue(":x_$idx", $code);
                $stmt->execute();
            } else {
                $stmt = self::PDO()->prepare("DELETE
                    FROM `pb_system_diagnostic_block`
                    WHERE `protocol` = :this;");
                $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
                $stmt->execute();
            }
        });
    }

    /**
     * @throws DBException
     */
    public function dbClearVirtualChunks(array $chunks): void
    {
        self::dbAction(function () use ($chunks) {
            $chunks = array_values($chunks);
            if (count($chunks) > 0) {
                $x = implode(', ', array_map(fn($idx) => ":x_$idx", range(0, count($chunks) - 1)));
                $stmt = self::PDO()->prepare("DELETE
                    FROM `pb_system_diagnostic_virtual_chunk`
                    WHERE `protocol` = :this
                      AND `code` NOT IN ($x);");
                $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
                foreach ($chunks as $idx => $code) $stmt->bindValue(":x_$idx", $code);
                $stmt->execute();
            } else {
                $stmt = self::PDO()->prepare("DELETE
                    FROM `pb_system_diagnostic_virtual_chunk`
                    WHERE `protocol` = :this;");
                $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
                $stmt->execute();
            }
        });
    }

    /**
     * @param array $chunks
     * @return void
     * @throws DBException
     */
    public function dbClearAggregateChunks(array $chunks): void
    {
        self::dbAction(function () use ($chunks) {
            $chunks = array_values($chunks);
            if (count($chunks) > 0) {
                $x = implode(', ', array_map(fn($idx) => ":x_$idx", range(0, count($chunks) - 1)));
                $stmt = self::PDO()->prepare("DELETE
                    FROM `pb_system_diagnostic_aggregate_chunk`
                    WHERE `protocol` = :this
                      AND `ID` NOT IN ($x);");
                $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
                foreach ($chunks as $idx => $id) $stmt->bindValue(":x_$idx", $id);
                $stmt->execute();
            } else {
                $stmt = self::PDO()->prepare("DELETE
                    FROM `pb_system_diagnostic_aggregate_chunk`
                    WHERE `protocol` = :this;");
                $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
                $stmt->execute();
            }
        });
    }

    protected function tryInsert(): void
    {
        $stmt = self::PDO()->prepare('INSERT INTO `pb_protocol`(`GUID`,`name`, `description`, `version`, `author`) 
            VALUES (UUIDToBin(:GUID),:name, :description, :version, :author);');
        $stmt->bindValue(':GUID', $this->GUID);
        $stmt->bindValue(':name', $this->name);
        $stmt->bindValue(':description', $this->description);
        $stmt->bindValue(':version', $this->version);
        $stmt->bindValue(':author', $this->author, PDO::PARAM_INT);
        $stmt->execute();
        $this->ID = self::PDO()->lastInsertId();
    }

    protected function tryUpdate(): void
    {
        $stmt = self::PDO()->prepare('UPDATE `pb_protocol` SET 
                         `GUID`=UUIDToBin(:GUID),
                         `name`=:name,
                         `description`=:description,
                         `version`=:version,
                         `author`=:author
                     WHERE `ID`=:this;');
        $stmt->bindValue(':GUID', $this->GUID);
        $stmt->bindValue(':name', $this->name);
        $stmt->bindValue(':description', $this->description);
        $stmt->bindValue(':version', $this->version);
        $stmt->bindValue(':author', $this->author, PDO::PARAM_INT);
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
    }


    /**
     * @return Protocol[]
     * @throws DBException
     */
    public static function list(): array
    {
        return self::PDO()->query('SELECT 
                pbp.`ID`,
                BinToUUID(pbp.`GUID`) AS `GUID`, 
                pbp.`name`, 
                pbp.`description`, 
                pbp.`version`,
                pbp.`author`, 
                TRUE AS `exists` 
            FROM `pb_protocol` AS pbp 
            ORDER BY pbp.`name`, pbp.`ID`;')->fetchAll(PDO::FETCH_CLASS, static::class);

    }

    /**
     * @throws DBException
     */
    public static function dbLoad(?int $ID): static
    {
        $stmt = self::PDO()->prepare('SELECT 
                pbp.`ID`,
                BinToUUID(pbp.`GUID`) AS `GUID`, 
                pbp.`name`, 
                pbp.`description`, 
                pbp.`version`,
                pbp.`author`
            FROM `pb_protocol` AS pbp
            WHERE pbp.`ID`=:this;');
        $stmt->bindValue(':this', $ID);
        $stmt->execute();
        return static::intoMe($stmt->fetchObject(static::class, [$ID]), $ID);
    }

    /**
     * @throws DBException
     */
    public static function dbFind(?string $GUID): static
    {
        $stmt = self::PDO()->prepare('SELECT 
                pbp.`ID`,
                BinToUUID(pbp.`GUID`) AS `GUID`, 
                pbp.`name`, 
                pbp.`description`, 
                pbp.`version`,
                pbp.`author`
            FROM `pb_protocol` AS pbp
            WHERE pbp.`GUID`=UUIDToBin(:this);');
        $stmt->bindValue(':this', $GUID);
        $stmt->execute();
        $protocol = static::intoMe($stmt->fetchObject(static::class));
        $protocol->GUID = $GUID;
        return $protocol;
    }
}