<?php

namespace Horizon\Auth\DataBase\ListSources;

use Horizon\Auth\DataBase\Tables\User;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\DataBaseController\ListSourceTemplate;
use PDO;

class UsersListSource extends ListSourceTemplate
{

    public function __construct(int $page, int $limit, ?int $currentID)
    {
        parent::__construct($page, $limit, $currentID);
    }

    /**
     * @return User[]
     * @throws DBException
     */
    public function loadData(): array
    {
        $stmt = self::PDO()->prepare("SELECT t.*, TRUE AS `exists` 
            FROM `h_user` AS t 
            WHERE EXISTS(SELECT * FROM `h_group_x_user` WHERE `user_ID` = t.ID AND `group_ID` IN (SELECT `slave` AS `gr`
                        FROM `h_group_tree` -- все потомки доступных пользователю групп
                        WHERE `master` IN (SELECT `group_ID` FROM `h_group_x_user` WHERE `user_ID` = :current_user)
                        UNION ALL
                        -- все доступные пользователю группы
                        (SELECT `group_ID` AS `gr` FROM `h_group_x_user` WHERE `user_ID` = :current_user)))
            ORDER BY t.`surname`, t.`name`, t.`patronymic`, t.`username`, t.`role`, t.`ban`, t.`ID`
            LIMIT :limit OFFSET :offset;");
        $stmt->bindValue(":limit", $this->limit, PDO::PARAM_INT);
        $stmt->bindValue(":offset", $this->offset, PDO::PARAM_INT);
        $stmt->bindValue(':current_user', User::current()->getID(), PDO::PARAM_INT);
        $stmt->execute();
        return $this->asArray($stmt->fetchAll(PDO::FETCH_CLASS, User::class));
    }

    public function loadCurrentPage(): int
    {
        $stmt = self::PDO()->prepare("SELECT tt.`page`
            FROM (SELECT FLOOR((ROW_NUMBER() OVER (ORDER BY t.`surname`, t.`name`, t.`patronymic`, t.`username`, t.`role`, t.`ban`, t.`ID` DESC) - 1) / :limit) + 1 AS `page`,
                         t.`ID` AS `ID`
                  FROM `h_user` AS t
                  WHERE EXISTS(SELECT * FROM `h_group_x_user` WHERE `user_ID` = t.ID AND `group_ID` IN (SELECT `slave` AS `gr`
                        FROM `h_group_tree` -- все потомки доступных пользователю групп
                        WHERE `master` IN (SELECT `group_ID` FROM `h_group_x_user` WHERE `user_ID` = :current_user)
                        UNION ALL
                        -- все доступные пользователю группы
                        (SELECT `group_ID` AS `gr` FROM `h_group_x_user` WHERE `user_ID` = :current_user)))
                  ORDER BY t.`surname`, t.`name`, t.`patronymic`, t.`username`, t.`role`, t.`ban`, t.`ID`) AS tt
            WHERE tt.`ID` = :ID;");
        $stmt->bindValue(':limit', $this->limit, PDO::PARAM_INT);
        $stmt->bindValue(':ID', $this->currentID, PDO::PARAM_INT|PDO::PARAM_NULL);
        $stmt->bindValue(':current_user', User::current()->getID(), PDO::PARAM_INT);
        $stmt->execute();
        $page = $stmt->fetchColumn();
        return $page === false ? 1 : $page;
    }

    protected function loadDataCount(): float
    {
        $stmt = self::PDO()->prepare("SELECT COUNT(*) AS `count` 
        FROM `h_user` AS t
        WHERE EXISTS(SELECT * FROM `h_group_x_user` WHERE `user_ID` = t.ID AND `group_ID` IN (SELECT `slave` AS `gr`
                        FROM `h_group_tree` -- все потомки доступных пользователю групп
                        WHERE `master` IN (SELECT `group_ID` FROM `h_group_x_user` WHERE `user_ID` = :current_user)
                        UNION ALL
                        -- все доступные пользователю группы
                        (SELECT `group_ID` AS `gr` FROM `h_group_x_user` WHERE `user_ID` = :current_user)));");
        $stmt->bindValue(':current_user', User::current()->getID(), PDO::PARAM_INT);
        $stmt->execute();
        return (float) $stmt->fetchColumn();
    }
}