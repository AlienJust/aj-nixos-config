<?php

namespace Horizon\Auth\DataBase\PickSources;

use Horizon\Auth\DataBase\Tables\User;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\DataBaseController\PickSourceTemplate;
use Horizon\UserInterface\Controls\Components\Option;
use PDO;

class UGroupPick extends PickSourceTemplate
{
    private ?int $except_group;
    public function __construct(?int $except_group = null)
    {
        $this->except_group = $except_group;
    }

    /**
     * @throws DBException
     * Option[]
     */
    public function init(): array
    {
        $stmt = self::PDO()->prepare("SELECT t.`value`, t.`label`, t.`title`
            FROM (SELECT DISTINCT g.`gr`                                       AS `value`,
                                  CONCAT(REPEAT('&nbsp;', IFNULL((SELECT MAX(`level`) FROM `h_group_tree` WHERE `slave` = g.`gr`), 0) * 4),
                                         hg.`name`)                            AS `label`,
                                  hg.`description`                             AS `title`,
                                  CONCAT_WS(' ',
                                            (SELECT GROUP_CONCAT(hg2.`name`, ' ') -- GROUP_CONCAT(LPAD(`master`, 10, '0') SEPARATOR '_')
                                             FROM `h_group_tree` AS hgt,
                                                  `h_group` AS hg2
                                             WHERE hgt.`slave` = g.`gr`
                                               AND hg2.`ID` = hgt.`master`
                                             ORDER BY hgt.`level`), hg.`name`) AS `path`
                  FROM (SELECT `slave` AS `gr`
                        FROM `h_group_tree` -- все потомки доступных пользователю групп
                        WHERE `master` IN (SELECT `group_ID` FROM `h_group_x_user` WHERE `user_ID` = :current_user) 
                          AND `slave` <> :except
                        UNION ALL
                        -- все доступные пользователю группы
                        (SELECT `group_ID` AS `gr` FROM `h_group_x_user` WHERE `user_ID` = :current_user
                                                                           AND `group_ID` <> :except)) AS g,
                       `h_group` AS hg
                  WHERE hg.`ID` = g.`gr`) AS t
                    -- AND g.`gr` <> :except) AS t
            ORDER BY t.`path`, t.`value`;");
        $stmt->bindValue(':current_user', User::current()->getID(), PDO::PARAM_INT);
        $stmt->bindValue(':except', $this->except_group ?? 0, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_FUNC,
            fn(string $value, string $label, string $title): Option => new Option($value, $label, $title));
    }
}