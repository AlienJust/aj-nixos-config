<?php

namespace Horizon\Auth\DataBase\ListSources;

use Horizon\Auth\DataBase\Tables\Group;
use Horizon\Auth\DataBase\Tables\User;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\DataBaseController\ListSourceTemplate;
use PDO;

class UGroupFriendlyListSource extends ListSourceTemplate
{
    public function __construct(int $page, int $limit, ?int $currentID)
    {
        parent::__construct($page, $limit, $currentID);
    }

    /**
     * @return Group[]
     * @throws DBException
     */
    public function loadData(): array
    {
        $stmt = self::PDO()->prepare("SELECT t.*, TRUE AS `exists`,
               (SELECT `master` FROM `h_group_tree` WHERE `slave`=t.ID AND `level`=1) AS `owner`
        FROM `h_group` AS t
        WHERE t.`ID` NOT IN (SELECT `master` AS `gr`
                        FROM `h_group_tree` -- все родители доступных пользователю групп
                        WHERE `slave` IN (SELECT `group_ID` FROM `h_group_x_user` WHERE `user_ID` = :current_user))
        ORDER BY (CONCAT_WS(' ',
                            (SELECT GROUP_CONCAT(hg2.`name`, ' ')
                             FROM `h_group_tree` AS hgt,
                                  `h_group` AS hg2
                             WHERE hgt.`slave` = t.`ID`
                               AND hg2.`ID` = hgt.`master`
                             ORDER BY hgt.`level`), t.`name`)), t.`ID`
        LIMIT :limit OFFSET :offset;");
        $stmt->bindValue(":limit", $this->limit, PDO::PARAM_INT);
        $stmt->bindValue(":offset", $this->offset, PDO::PARAM_INT);
        $stmt->bindValue(':current_user', User::current()->getID(), PDO::PARAM_INT);
        $stmt->execute();
        return $this->asArray($stmt->fetchAll(PDO::FETCH_CLASS, Group::class));
    }

    public function loadCurrentPage(): int
    {
        $stmt = self::PDO()->prepare("SELECT tt.`page`
            FROM (SELECT FLOOR((ROW_NUMBER() OVER (ORDER BY (CONCAT_WS(' ',
                            (SELECT GROUP_CONCAT(hg2.`name`, ' ')
                             FROM `h_group_tree` AS hgt,
                                  `h_group` AS hg2
                             WHERE hgt.`slave` = t.`ID`
                               AND hg2.`ID` = hgt.`master`
                             ORDER BY hgt.`level`), t.`name`)), t.`ID` DESC) - 1) / :limit) + 1 AS `page`,
                         t.`ID` AS `ID`
                  FROM `h_group` AS t
                  WHERE t.`ID` NOT IN (SELECT `master` AS `gr`
                        FROM `h_group_tree` -- все родители доступных пользователю групп
                        WHERE `slave` IN (SELECT `group_ID` FROM `h_group_x_user` WHERE `user_ID` = :current_user))
                  ORDER BY (CONCAT_WS(' ',
                            (SELECT GROUP_CONCAT(hg2.`name`, ' ')
                             FROM `h_group_tree` AS hgt,
                                  `h_group` AS hg2
                             WHERE hgt.`slave` = t.`ID`
                               AND hg2.`ID` = hgt.`master`
                             ORDER BY hgt.`level`), t.`name`)), t.`ID`) AS tt
            WHERE tt.`ID` = :ID;");
        $stmt->bindValue(':limit', $this->limit, PDO::PARAM_INT);
        $stmt->bindValue(':ID', $this->currentID, PDO::PARAM_INT|PDO::PARAM_NULL);
        $stmt->bindValue(':current_user', User::current()->getID(), PDO::PARAM_INT);
        $stmt->execute();
        $page = $stmt->fetchColumn();
        return $page === false ? 1 : $page;
    }

    protected function loadDataCount(): float
    {
        $stmt = self::PDO()->prepare("SELECT COUNT(*) AS `count` 
        FROM `h_group` AS t
        WHERE t.`ID` NOT IN (SELECT `master` AS `gr`
                        FROM `h_group_tree` -- все родители доступных пользователю групп
                        WHERE `slave` IN (SELECT `group_ID` FROM `h_group_x_user` WHERE `user_ID` = :current_user));");
        $stmt->bindValue(':current_user', User::current()->getID(), PDO::PARAM_INT);
        $stmt->execute();
        return (float) $stmt->fetchColumn();
    }
}