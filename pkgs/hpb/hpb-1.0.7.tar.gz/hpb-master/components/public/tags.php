<?php
if (file_exists('../private/loader.php')) include_once '../private/loader.php';

try {
    $code = explode('__', $_POST['action'] ?? '')[0]??'';
    echo \Horizon\ProtocolBuilder\UserInterface\eUICallerAJAXAction::tryFrom($code)
        ->controller($_POST)->tag()
        ->draw();
} catch (Exception $e) {
    echo (new \Horizon\UserInterface\Tags\Trace($e))
        ->draw();
}