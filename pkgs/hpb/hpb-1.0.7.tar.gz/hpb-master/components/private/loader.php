<?php
//error_reporting(E_ALL & ~E_NOTICE);
$ROOT = $_SERVER['DOCUMENT_ROOT'];
$loader = require_once $ROOT . '/libs/Horizon/ClassLoader.php';
$loader->setNamespaces('Horizon');
$loader->setNamespaces('Parsedown');
$loader->setNamespaces('Firebase');
date_default_timezone_set('Asia/Yekaterinburg');
define('HORIZON_SETTINGS',
    parse_ini_file($ROOT . '/data/private/horizon.ini', true, INI_SCANNER_TYPED));
