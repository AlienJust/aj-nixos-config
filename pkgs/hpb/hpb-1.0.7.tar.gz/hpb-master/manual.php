<?php
include_once 'components/private/loader.php';
use Parsedown\Parsedown;

$parsedown = new Parsedown();
$markdown = file_get_contents('data/private/manual.md');
$html = $parsedown->text($markdown);
echo $html;