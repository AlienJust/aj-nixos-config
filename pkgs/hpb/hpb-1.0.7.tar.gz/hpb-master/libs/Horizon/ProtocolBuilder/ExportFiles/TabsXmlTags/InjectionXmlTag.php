<?php

namespace Horizon\ProtocolBuilder\ExportFiles\TabsXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class InjectionXmlTag extends XmlTag
{
    public readonly string $ParamNumberInPackage;
    public readonly string $ConvertExpression;
    public readonly string $InvertBytesOrder;

    public function __construct(string $ParamNumberInPackage, string $ConvertExpression, string $InvertBytesOrder)
    {
        parent::__construct('Injection');
        $this->ParamNumberInPackage = $ParamNumberInPackage;
        $this->ConvertExpression = $ConvertExpression;
        $this->InvertBytesOrder = $InvertBytesOrder;
    }

    public function add(InjectTextValueXmlTag $tag): void
    {
        $this->addTag($tag);
    }
}