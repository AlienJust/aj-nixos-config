<?php

namespace Horizon\ProtocolBuilder\ExportFiles\MainXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class app_SettableParamView extends XmlTag
{
    public readonly ?string $Grid___Column;
    public readonly ?string $Grid___Row;
    public readonly string $DataContext;

    public function __construct(string $DataContext, ?string $Grid___Column = null, ?string $Grid___Row = null)
    {
        parent::__construct('app:SettableParamView');
        $this->DataContext = $DataContext;
        $this->Grid___Column = $Grid___Column;
        $this->Grid___Row = $Grid___Row;
    }
}