<?php

namespace Horizon\ProtocolBuilder\ExportFiles;

use ReflectionClass;
use ReflectionProperty;

abstract class XmlTag
{
    private string $tag_name;
    /** @var XmlTag[] $tags */
    private array $tags = [];
    private ?string $text_content = null;
    private string $space = '';
    protected function __construct(string $tag_name)
    {
        $this->tag_name = $tag_name;
    }

    protected function addTag(XmlTag $tag): void
    {
        $this->tags[] = $tag;
        $tag->addSpace($this->space);
    }

    protected function addText(string $text): void
    {
        $this->text_content .= $text;
    }

    protected function addSpace(string $parent_space): void
    {
        $this->space = $parent_space . "  ";
        foreach ($this->tags as $tag) $tag->addSpace($this->space);
    }

    protected function drawAttributes(): string
    {
        $reflect = new ReflectionClass(static::class);
        $attributes = '';
        $properties = $reflect->getProperties(ReflectionProperty::IS_PUBLIC);
        foreach ($properties as &$property) if (!is_null($property->getValue($this)))
            $attributes .= ' ' . str_replace('___', '.', $property->getName()) . '="' . $property->getValue($this) . '"';
        return $attributes;
    }

    public function draw(): string
    {
        $attributes = $this->drawAttributes();
        $tags = '';
        foreach ($this->tags as $tag) $tags .= "\n" . $tag->draw();

        return $tags == ''
            ? (is_null($this->text_content)
                ? "$this->space<$this->tag_name$attributes />"
                : "$this->space<$this->tag_name$attributes>$this->text_content</$this->tag_name>")
            : "$this->space<$this->tag_name$attributes>$tags\n$this->space</$this->tag_name>";
    }
}