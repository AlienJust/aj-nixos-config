<?php

namespace Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class CommandsXmlTag extends XmlTag
{
    public function __construct()
    {
        parent::__construct('Commands');
    }

    public function add(CmdMaskXmlTag $tag): void
    {
        $this->addTag($tag);
    }
}