<?php

namespace Horizon\ProtocolBuilder\ExportFiles\MainXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class TabItemXmlTag extends XmlTag
{
    public readonly ?string $Visibility;
    public function __construct(?string $Visibility = null)
    {
        parent::__construct('TabItem');
        $this->Visibility = $Visibility;
    }

    public function add(TabItem_HeaderXmlTag|ScrollViewerXmlTag $tag): static
    {
        $this->addTag($tag);
        return $this;
    }
}