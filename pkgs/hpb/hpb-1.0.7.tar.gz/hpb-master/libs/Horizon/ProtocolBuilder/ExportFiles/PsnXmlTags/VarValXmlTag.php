<?php

namespace Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class VarValXmlTag extends XmlTag
{
    public readonly string $Position;
    public readonly string $Length;
    public readonly string $Name;
    public readonly string $Id;

    public function __construct(string $Position, string $Length, string $Name, string $Id)
    {
        parent::__construct('VarVal');
        $this->Position = $Position;
        $this->Length = $Length;
        $this->Name = htmlspecialchars($Name);
        $this->Id = $Id;
    }


}