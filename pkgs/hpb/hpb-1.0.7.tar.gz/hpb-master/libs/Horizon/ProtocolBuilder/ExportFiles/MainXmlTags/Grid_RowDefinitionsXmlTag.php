<?php

namespace Horizon\ProtocolBuilder\ExportFiles\MainXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class Grid_RowDefinitionsXmlTag extends XmlTag
{
    public function __construct()
    {
        parent::__construct('Grid.RowDefinitions');
    }

    public function add(RowDefinitionXmlTag $tag): static
    {
        $this->addTag($tag);
        return $this;
    }
}