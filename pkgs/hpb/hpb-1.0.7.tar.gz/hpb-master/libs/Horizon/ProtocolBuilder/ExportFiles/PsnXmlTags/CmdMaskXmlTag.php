<?php

namespace Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class CmdMaskXmlTag extends XmlTag
{
    public readonly string $Name;

    public function __construct(string $Name)
    {
        parent::__construct('CmdMask');
        $this->Name = $Name;
    }

    public function add(RequestXmlTag|ReplyXmlTag $tag): static
    {
        $this->addTag($tag);
        return $this;
    }

}