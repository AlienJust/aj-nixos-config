<?php

namespace Horizon\ProtocolBuilder\ExportFiles;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterViewInjection;
use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\ExportFiles\TabsXmlTags\BooleanViewXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\TabsXmlTags\InjectionXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\TabsXmlTags\InjectTextValueXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\TabsXmlTags\MultiViewXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\TabsXmlTags\NumberViewXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\TabsXmlTags\ParametersXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\TabsXmlTags\ParameterXmlTag;
use Horizon\ProtocolBuilder\LogicItems\MultiViewExpression;

class TabsXml
{
    private Protocol $protocol;
    public function __construct(Protocol $protocol)
    {
        $this->protocol = $protocol;
    }

    /**
     * @throws DBException
     */
    public function content(): string
    {
        $document = new ParametersXmlTag();
        foreach ($this->protocol->arrParameterViews() as &$view) {
            $document->add($parameter = new ParameterXmlTag($view->getCode(), $view->getIdentifier(), $view->getComment(), $view->getCustomName()));
            $values_count = $view->countViewValues();
            $numbers_count = $view->countViewNumbers();
            $multiview_expression = (new MultiViewExpression($view->getMask(), !is_null($view->getFormat()), $values_count, $numbers_count))->value;

            if ($values_count == 1 && $numbers_count == 0 && is_null($view->getFormat())) {
                $boolean_view = $view->arrViewValues()[0];
                $parameter->add(new BooleanViewXmlTag(
                    $boolean_view->getExpression(),
                    '{$text}',
                    $boolean_view->getResultTrue(),
                    $boolean_view->getResultFalse(),
                    $boolean_view->getColor()
                ));
            } elseif ($values_count > 0 || $numbers_count > 0) {
                $parameter->add($multi_view = new MultiViewXmlTag($multiview_expression));
                if (!is_null($view->getFormat())) $multi_view->add(new NumberViewXmlTag('[value]', $view->getFormat()));
                foreach ($view->arrViewValues() as $value) $multi_view->add(new BooleanViewXmlTag(
                    $value->getExpression(),
                    '{$text' . $value->getId() + 1 . '}',
                    $value->getResultTrue(),
                    $value->getResultFalse(),
                    $value->getColor()
                ));
                foreach ($view->arrViewNumbers() as $number) $multi_view->add(new NumberViewXmlTag(
                    $number->getExpression(),
                    $number->getFormat(),
                    '{$value' . $number->getId() + 1 . '}',
                ));
            } elseif (!is_null($view->getFormat())) {
                $parameter->add(new NumberViewXmlTag('[value]', $view->getFormat()));
            }

            $injection = ParameterViewInjection::dbLoad($view->getProtocol(), $view->getCode());
            if ($injection->exists()) {
                $parameter->add($injection_tag = new InjectionXmlTag(
                    $injection->getParamNumberInPackage(),
                    $injection->getConvertExpression(),
                    $injection->isInvertBytesOrder() ? 'True' : 'False'
                ));
                foreach ($injection->arrInjectValues() as $value)
                    $injection_tag->add(new InjectTextValueXmlTag($value->getText(), $value->getValue()));
            }
        }
        return '<?xml version="1.0" encoding="utf-8"?>
' . $document->draw();
    }
}