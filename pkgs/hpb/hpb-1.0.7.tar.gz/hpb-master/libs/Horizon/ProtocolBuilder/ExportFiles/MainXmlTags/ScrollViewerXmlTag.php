<?php

namespace Horizon\ProtocolBuilder\ExportFiles\MainXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class ScrollViewerXmlTag extends XmlTag
{
    public function __construct()
    {
        parent::__construct('ScrollViewer');
    }

    public function add(StackPanelXmlTag $tag): static
    {
        $this->addTag($tag);
        return $this;
    }
}