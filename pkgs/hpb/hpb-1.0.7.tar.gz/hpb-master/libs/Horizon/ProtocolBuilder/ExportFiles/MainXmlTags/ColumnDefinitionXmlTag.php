<?php

namespace Horizon\ProtocolBuilder\ExportFiles\MainXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class ColumnDefinitionXmlTag extends XmlTag
{
    public readonly ?string $Width;
    public function __construct(?string $Width = null)
    {
        parent::__construct('ColumnDefinition');
        $this->Width = $Width;
    }
}