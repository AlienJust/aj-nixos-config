<?php

namespace Horizon\ProtocolBuilder\ExportFiles\TabsXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class InjectTextValueXmlTag extends XmlTag
{
    public readonly string $Text;
    public readonly string $Value;

    public function __construct(string $Text, string $Value)
    {
        parent::__construct('InjectTextValue');
        $this->Text = $Text;
        $this->Value = $Value;
    }
}