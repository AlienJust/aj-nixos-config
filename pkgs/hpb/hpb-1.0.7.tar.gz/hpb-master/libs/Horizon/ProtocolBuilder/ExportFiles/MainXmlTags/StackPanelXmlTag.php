<?php

namespace Horizon\ProtocolBuilder\ExportFiles\MainXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class StackPanelXmlTag extends XmlTag
{
    public readonly ?string $Orientation;

    public function __construct(?string $Orientation = null)
    {
        parent::__construct('StackPanel');
        $this->Orientation = $Orientation;
    }

    public function add(TextBlockXmlTag|app_CommandPartViewXmlTag|app_ParameterViewXmlTag|GridXmlTag|LabelXmlTag $tag): static
    {
        $this->addTag($tag);
        return $this;
    }

}