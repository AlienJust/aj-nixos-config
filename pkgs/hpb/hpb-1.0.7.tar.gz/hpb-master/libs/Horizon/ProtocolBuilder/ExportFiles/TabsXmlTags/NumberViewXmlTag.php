<?php

namespace Horizon\ProtocolBuilder\ExportFiles\TabsXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class NumberViewXmlTag extends XmlTag
{
    public readonly string $Expression;
    public readonly string $StringFormat;
    public readonly string $Name;

    public function __construct(string $Expression, string $StringFormat, string $Name = '{$value}')
    {
        parent::__construct('NumberView');
        $this->Expression = $Expression;
        $this->StringFormat = $StringFormat;
        $this->Name = $Name;
    }
}