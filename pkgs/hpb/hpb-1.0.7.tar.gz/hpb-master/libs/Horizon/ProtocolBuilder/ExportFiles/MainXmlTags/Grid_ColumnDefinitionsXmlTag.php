<?php

namespace Horizon\ProtocolBuilder\ExportFiles\MainXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class Grid_ColumnDefinitionsXmlTag extends XmlTag
{
    public function __construct()
    {
        parent::__construct('Grid.ColumnDefinitions');
    }

    public function add(ColumnDefinitionXmlTag $tag): static
    {
        $this->addTag($tag);
        return $this;
    }
}