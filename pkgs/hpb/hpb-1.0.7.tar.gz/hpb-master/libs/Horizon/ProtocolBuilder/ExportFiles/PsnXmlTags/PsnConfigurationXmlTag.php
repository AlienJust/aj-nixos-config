<?php

namespace Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class PsnConfigurationXmlTag extends XmlTag
{
    public readonly string $Name;
    public readonly string $Version;
    public readonly string $Description;
    public readonly string $Id;
    public readonly string $RpdId;

    public function __construct(string $Name, string $Version, string $Description, string $Id, string $RpdId)
    {
        parent::__construct('PsnConfiguration');
        $this->Name = $Name;
        $this->Version = $Version;
        $this->Description = $Description;
        $this->Id = $Id;
        $this->RpdId = $RpdId;
    }

    public function add(PsnMetersXmlTag|CommandsXmlTag $tag): void
    {
        $this->addTag($tag);
    }
}