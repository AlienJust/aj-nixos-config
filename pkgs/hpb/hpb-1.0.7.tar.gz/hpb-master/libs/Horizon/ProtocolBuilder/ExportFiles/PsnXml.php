<?php

namespace Horizon\ProtocolBuilder\ExportFiles;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\Data\eParameterType;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToReply;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToRequest;
use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags\BitPrmXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags\CmdMaskXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags\CommandsXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags\CpzPrmXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags\DefValXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags\PsnConfigurationXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags\PsnMetersXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags\PsnMeterXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags\RCmdPartXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags\ReplyXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags\RequestXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags\VarValXmlTag;
use Horizon\ProtocolBuilder\LogicItems\HexByte;
use Horizon\ProtocolBuilder\LogicItems\ParameterExpression;

class PsnXml
{
    private Protocol $protocol;
    public function __construct(Protocol $protocol)
    {
        $this->protocol = $protocol;
    }


    /**
     * @throws DBException
     */
    private function setParameter(RCmdPartXmlTag $tag, ParameterToReply|ParameterToRequest $parameter): void
    {
        $bits = $parameter->getBits();
        switch ($parameter->getType()) {
            case eParameterType::CpzPrm->value:
                $tag->add(new CpzPrmXmlTag($parameter->getName(),
                    new ParameterExpression($bits, $parameter->isSigned(), $parameter->getLowestDigitPrice(),
                        $parameter->getByteOrder(), $parameter->getValueConversionFormula())->value,
                    $parameter->getGUID()));
                break;
            case eParameterType::BitPrm->value:
                $tag->add(new BitPrmXmlTag($this->getParameterByte($bits), $this->getParameterBitNumber($bits),
                    $parameter->isValueInverted() ? 'True' : 'False',
                    $parameter->getName(), $parameter->getGUID()));
                break;
            case eParameterType::DefVal->value:
                $tag->add(new DefValXmlTag($this->getParameterByte($bits) . '.' . $this->getParameterBitNumber($bits),
                    count($bits), $parameter->getValue(), $parameter->getName(), $parameter->getGUID()));
                break;
            case eParameterType::VarVal->value:
                $tag->add(new VarValXmlTag($this->getParameterByte($bits) . '.' . $this->getParameterBitNumber($bits),
                    count($bits), $parameter->getName(), $parameter->getGUID()));
                break;
        }
    }

    private function getParameterByte(array $bits): int
    {
        return floor($bits[0]/8);
    }

    private function getParameterBitNumber(array $bits): int
    {
        return 7 - max($bits) % 8;
    }

    /**
     * @throws DBException
     */
    public function content(): string
    {
        $document = (new PsnConfigurationXmlTag(
            $this->protocol->name,
            $this->protocol->version,
            $this->protocol->description,
            $this->protocol->GUID,
            $this->protocol->getID()));
        $document->add($meters = new PsnMetersXmlTag());
        $document->add($commands = new CommandsXmlTag());
        foreach ($this->protocol->arrSubscribers() as &$subscriber) {
            $meters->add(new PsnMeterXmlTag(
                new HexByte($subscriber->getAddress())->hex,
                $subscriber->getName()
            ));
            foreach ($subscriber->arrCommands() as &$command) {
                $commands->add(new CmdMaskXmlTag($command->initName($subscriber->getShortName()))
                    ->add($request = new RequestXmlTag($command->refRequest()->getLength(), $command->refRequest()->getStart(), $command->refRequest()->getCycleMsTime()))
                    ->add($reply = new ReplyXmlTag($command->refReply()->getLength(), $command->refReply()->getStart(),
                        $command->refReply()->isRequestRequired() ? 'True': null))
                );
                foreach ($command->arrParametersToReply() as &$parameter) $this->setParameter($reply, $parameter);
                foreach ($command->arrParametersToRequest() as &$parameter) $this->setParameter($request, $parameter);
            }
        }
        return '<?xml version="1.0" encoding="utf-8"?>
' . $document->draw();
    }
}