<?php

namespace Horizon\ProtocolBuilder\ExportFiles\MainXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class GridXmlTag extends XmlTag
{
    public readonly ?string $Grid___Column;
    public readonly ?string $Grid___Row;
    public readonly ?string $Grid___ColumnSpan;
    public function __construct(?string $Grid___Column = null, ?string $Grid___Row = null, ?string $Grid___ColumnSpan = null)
    {
        parent::__construct('Grid');
        $this->Grid___Column = $Grid___Column;
        $this->Grid___Row = $Grid___Row;
        $this->Grid___ColumnSpan = $Grid___ColumnSpan;
    }

    public function add(TextBlockXmlTag|
                        app_ParameterViewXmlTag|
                        Grid_ColumnDefinitionsXmlTag|
                        Grid_RowDefinitionsXmlTag|
                        GridXmlTag|
                        LabelXmlTag|
                        app_ComboSettableParamView|
                        controls_NumericUpDown|
                        app_SettableParamView $tag): static
    {
        $this->addTag($tag);
        return $this;
    }
}