<?php

namespace Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

abstract class RCmdPartXmlTag extends XmlTag
{
    public function add(BitPrmXmlTag|VarValXmlTag|DefValXmlTag|CpzPrmXmlTag $tag): void
    {
        $this->addTag($tag);
    }
}