<?php

namespace Horizon\ProtocolBuilder\ExportFiles\MainXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class TabItem_HeaderXmlTag extends XmlTag
{
    public function __construct()
    {
        parent::__construct('TabItem.Header');
    }

    public function add(StackPanelXmlTag $tag): static
    {
        $this->addTag($tag);
        return $this;
    }
}