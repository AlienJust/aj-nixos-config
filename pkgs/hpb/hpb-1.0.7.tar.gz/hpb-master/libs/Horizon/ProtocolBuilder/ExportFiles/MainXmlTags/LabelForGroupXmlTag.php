<?php

namespace Horizon\ProtocolBuilder\ExportFiles\MainXmlTags;

class LabelForGroupXmlTag extends LabelXmlTag
{
    public readonly string $BorderBrush;
    public readonly string $BorderThickness;
    public readonly string $Padding;
    public function __construct(?string $Grid___Column = null, ?string $Grid___Row = null) {
        parent::__construct(null, null, $Grid___Column, $Grid___Row);
        $this->BorderBrush = "LightGray";
        $this->BorderThickness = "0,0,0,1";
        $this->Padding = "31 4 5 1";
    }
}