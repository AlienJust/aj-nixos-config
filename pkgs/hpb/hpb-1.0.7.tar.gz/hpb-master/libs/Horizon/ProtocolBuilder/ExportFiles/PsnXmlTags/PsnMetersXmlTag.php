<?php

namespace Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class PsnMetersXmlTag extends XmlTag
{
    public function __construct()
    {
        parent::__construct('PsnMeters');
    }

    public function add(PsnMeterXmlTag $tag): void
    {
        $this->addTag($tag);
    }
}