<?php

namespace Horizon\ProtocolBuilder\ExportFiles\MainXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class TabControlXmlTag extends XmlTag
{
    public readonly string $ItemContainerStyle;
    private readonly string $Grid_Row;
    public readonly string $TabStripPlacement;

    public function __construct(string $ItemContainerStyle = "{StaticResource AzureTabItem}",
                                string $Grid_Row = "1",
                                string $TabStripPlacement = "Left")
    {
        parent::__construct('TabControl');
        $this->ItemContainerStyle = $ItemContainerStyle;
        $this->Grid_Row = $Grid_Row;
        $this->TabStripPlacement = $TabStripPlacement;
    }

    public function add(TabItemXmlTag $tag): static
    {
        $this->addTag($tag);
        return $this;
    }

    protected function drawAttributes(): string
    {
        return parent::drawAttributes()
            . ' Grid.Row="' . $this->Grid_Row . '"';
    }
}