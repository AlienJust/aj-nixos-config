<?php

namespace Horizon\ProtocolBuilder\ExportFiles\TabsXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class ParameterXmlTag extends XmlTag
{
    public readonly string $Key;
    public readonly string $Identifier;
    public readonly string $Comment;
    public readonly ?string $CustomName;

    public function __construct(string $Key, string $Identifier, string $Comment, ?string $CustomName = null)
    {
        parent::__construct('Parameter');
        $this->Key = $Key;
        $this->Identifier = $Identifier;
        $this->Comment = htmlspecialchars($Comment);
        $this->CustomName = !is_null($CustomName) ? htmlspecialchars($CustomName) : $CustomName;
    }

    public function add(MultiViewXmlTag|BooleanViewXmlTag|NumberViewXmlTag|InjectionXmlTag $tag): void
    {
        $this->addTag($tag);
    }
}