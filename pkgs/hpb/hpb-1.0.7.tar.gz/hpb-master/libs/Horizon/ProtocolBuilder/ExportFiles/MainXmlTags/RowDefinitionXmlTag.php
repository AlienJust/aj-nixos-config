<?php

namespace Horizon\ProtocolBuilder\ExportFiles\MainXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class RowDefinitionXmlTag extends XmlTag
{
    public function __construct()
    {
        parent::__construct('RowDefinition');
    }
}