<?php

namespace Horizon\ProtocolBuilder\ExportFiles;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterViewInjection;
use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\DataBase\Tables\SystemDiagnosticAggregateParameter;
use Horizon\ProtocolBuilder\ExportFiles\MainXmlTags\app_ComboSettableParamView;
use Horizon\ProtocolBuilder\ExportFiles\MainXmlTags\app_CommandPartViewXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\MainXmlTags\app_ParameterViewXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\MainXmlTags\app_SettableParamView;
use Horizon\ProtocolBuilder\ExportFiles\MainXmlTags\ColumnDefinitionXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\MainXmlTags\controls_NumericUpDown;
use Horizon\ProtocolBuilder\ExportFiles\MainXmlTags\Grid_ColumnDefinitionsXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\MainXmlTags\Grid_RowDefinitionsXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\MainXmlTags\GridXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\MainXmlTags\LabelForGroupXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\MainXmlTags\LabelXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\MainXmlTags\RowDefinitionXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\MainXmlTags\ScrollViewerXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\MainXmlTags\StackPanelXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\MainXmlTags\TabControlXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\MainXmlTags\TabItem_HeaderXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\MainXmlTags\TabItemXmlTag;
use Horizon\ProtocolBuilder\ExportFiles\MainXmlTags\TextBlockXmlTag;

class MainXml
{
    private Protocol $protocol;
    public function __construct(Protocol $protocol)
    {
        $this->protocol = $protocol;
    }

    /**
     * @throws DBException
     */
    public function content(): string
    {
        $document = new TabControlXmlTag();
        $document->add((new TabItemXmlTag())
            ->add((new TabItem_HeaderXmlTag())->add($menu_stack = new StackPanelXmlTag()))
            ->add((new ScrollViewerXmlTag())->add($stack = new StackPanelXmlTag('Vertical'))));
        $this->addMenuButton($menu_stack, 'ДС', 'Диагностика системы');

        foreach($this->protocol->arrMainBlocks() as $block) {
            $count_blocks_in_line = $block->getInlineBlocksCount();
            $columns_amount = $block->getColumnsCount();
            $rows_amount = $block->getRowCount();
            $ALL_COLS_AMOUNT = $columns_amount;
            $ALL_ROWS_AMOUNT = $rows_amount;
            $inline_blocks = $block->arrInlineBlocks();

            if ($count_blocks_in_line > 1) { // если несколько блоков в одну линию
                $stack->add($grid = (new GridXmlTag())
                    ->add($columns = new Grid_ColumnDefinitionsXmlTag())
                    ->add((new Grid_RowDefinitionsXmlTag())
                        ->add(new RowDefinitionXmlTag())));
                $columns->add(new ColumnDefinitionXmlTag($columns_amount == 1 ? "*" : "$columns_amount*"));
                $grid->add((new LabelXmlTag('{DynamicResource AccentColorBrush3}', 'SemiBold', $grid_column = 0))->add($block->getName()));
                //$inline_blocks = $block->arrInlineBlocks();
                foreach ($inline_blocks as $inline_block) {
                    $grid_column++;
                    $ca = $inline_block->getColumnsCount();
                    $ALL_COLS_AMOUNT += $ca;
                    $ALL_ROWS_AMOUNT = max($ALL_ROWS_AMOUNT, $inline_block->getRowCount());
                    $columns->add(new ColumnDefinitionXmlTag($ca == 1 ? "*" : "$ca*"));
                    $grid->add((new LabelXmlTag('{DynamicResource AccentColorBrush3}', 'SemiBold', $grid_column))->add($inline_block->getName()));
                }
            }
            elseif ($block->getName() != '') $stack->add((new LabelXmlTag())->add($block->getName()));

            $stack
                ->add($grid = (new GridXmlTag())
                ->add($columns = new Grid_ColumnDefinitionsXmlTag())
                ->add($rows = new Grid_RowDefinitionsXmlTag()));

            for ($i = 0; $i < $ALL_COLS_AMOUNT; $i++) $columns->add(new ColumnDefinitionXmlTag());
            for ($i = 0; $i < $ALL_ROWS_AMOUNT; $i++) $rows->add(new RowDefinitionXmlTag());
            foreach ($block->arrChunks() as $chunk) $this->addParameterToGrid(
                $grid, $chunk->getCode(), $chunk->getColumnId(), $chunk->getRowId(), $chunk->refInjection()
            );
            foreach ($block->arrVirtualChunks() as $chunk) $this->addParameterToGrid(
                $grid, $chunk->getCode(), $chunk->getColumnId(), $chunk->getRowId()
            );
            foreach ($block->arrAggregateChunks() as $chunk) $this->addParametersGroupToGrid(
                $grid, $chunk->getColumnId(), $chunk->getRowId(),
                $chunk->getColumnSpan(), $chunk->getLabel(), $chunk->arrParameters()
            );
            if ($count_blocks_in_line > 1) {
                $COLS_SHIFT = $columns_amount;
                foreach ($inline_blocks as $inline_block) {
                    foreach ($inline_block->arrChunks() as $chunk) $this->addParameterToGrid(
                        $grid, $chunk->getCode(), $chunk->getColumnId() + $COLS_SHIFT, $chunk->getRowId(), $chunk->refInjection()
                    );
                    foreach ($inline_block->arrVirtualChunks() as $chunk) $this->addParameterToGrid(
                        $grid, $chunk->getCode(), $chunk->getColumnId() + $COLS_SHIFT, $chunk->getRowId()
                    );
                    foreach ($inline_block->arrAggregateChunks() as $chunk) $this->addParametersGroupToGrid(
                        $grid, $chunk->getColumnId() + $COLS_SHIFT, $chunk->getRowId(),
                        $chunk->getColumnSpan(), $chunk->getLabel(), $chunk->arrParameters()
                    );
                    $COLS_SHIFT += $inline_block->getColumnsCount();
                }
            }
        }
        foreach ($this->protocol->arrSubscribers() as $subscriber) {
            $document->add((new TabItemXmlTag(
                $subscriber->isHideForProduction()
                    ? "{Binding Path=AppAbilities.Version,Converter={StaticResource FullAppVersionToVisibilityConverter}}"
                    : null))
                ->add((new TabItem_HeaderXmlTag())->add($menu_stack = new StackPanelXmlTag('Horizontal')))
                ->add((new ScrollViewerXmlTag())->add($stack = new StackPanelXmlTag('Vertical'))));
            $this->addMenuButton($menu_stack, $subscriber->getShortName(), $subscriber->getName());
            foreach ($subscriber->arrCommands() as $command) if (!$command->isSystem()) {
                $stack->add(new TextBlockXmlTag('Запрос: ' . $command->getName(), '16'))
                    ->add(new app_CommandPartViewXmlTag("{Binding Path={app:PathConstructor CommandParts[(0)],'" . $command->initCode(false, $subscriber->getShortName()) . "'}}"));
                foreach ($command->arrParameterViewCodesToRequest() as $code) $this->addParameterToStack($stack, $code);
                $stack->add(new TextBlockXmlTag('Ответ: ' . $command->getName(), '16'))
                    ->add(new app_CommandPartViewXmlTag("{Binding Path={app:PathConstructor CommandParts[(0)],'" . $command->initCode(true, $subscriber->getShortName()) . "'}}"));
                foreach ($command->arrParameterViewCodesToReply() as $code) $this->addParameterToStack($stack, $code);
            }
        }

        /*return '<?xml version="1.0" encoding="utf-8"?>
' . $document->draw();*/
        return $document->draw();
    }

    private function addMenuButton(StackPanelXmlTag $stack, string $short_name, string $name): void
    {
        $stack
            ->add(new TextBlockXmlTag($short_name, null,
                "{Binding Path=TabHeadersAreLong, Converter={StaticResource InvertedBtwConverter}}"))
            ->add(new TextBlockXmlTag($name, null,
                "{Binding Path=TabHeadersAreLong, Converter={StaticResource BtvConverter}}"));
    }

    /**
     * @throws DBException
     */
    private function addParameterToStack(StackPanelXmlTag $stack, string $code): void
    {
        $injection = ParameterViewInjection::dbLoad($this->protocol->getID(), $code);
        if ($injection->exists()) {
            $values = $injection->arrInjectValues();
            $stack->add($injection_grid = (new GridXmlTag())
                ->add((new Grid_ColumnDefinitionsXmlTag())
                    ->add(new ColumnDefinitionXmlTag('*'))
                    ->add(new ColumnDefinitionXmlTag('Auto'))
                    ->add(new ColumnDefinitionXmlTag('Auto')))
                ->add(new app_ParameterViewXmlTag("{Binding Parameters[$code]}")));
            if ($values) $injection_grid
                ->add(new app_ComboSettableParamView("{Binding Path=Parameters[$code].Setter}", 2));
            else $injection_grid
                ->add(new controls_NumericUpDown("{Binding Path=Parameters[$code].Setter.Value}", 1, null,
                    $injection->getMinValue(), $injection->getMaxValue(), $injection->getIntervalValue(), $injection->getStringFormat()))
                ->add(new app_SettableParamView("{Binding Path=Parameters[$code].Setter}", 2));
        } else $stack->add(new app_ParameterViewXmlTag("{Binding Parameters[$code]}"));
    }

    /**
     * @throws DBException
     */
    private function addParameterToGrid(GridXmlTag $grid, string $code, int $column_id, int $row_id, ?ParameterViewInjection $injection = null): void
    {
        if ($injection?->exists()) {
            $values = $injection->arrInjectValues();
            $grid->add($injection_grid = (new GridXmlTag($column_id, $row_id))
                ->add((new Grid_ColumnDefinitionsXmlTag())
                    ->add(new ColumnDefinitionXmlTag('*'))
                    ->add(new ColumnDefinitionXmlTag('Auto'))
                    ->add(new ColumnDefinitionXmlTag('Auto')))
                ->add(new app_ParameterViewXmlTag("{Binding Parameters[$code]}")));
            if ($values) $injection_grid
                ->add(new app_ComboSettableParamView("{Binding Path=Parameters[$code].Setter}", 2));
            else $injection_grid
                ->add(new controls_NumericUpDown("{Binding Path=Parameters[$code].Setter.Value}", 1, null,
                    $injection->getMinValue(), $injection->getMaxValue(), $injection->getIntervalValue(), $injection->getStringFormat()))
                ->add(new app_SettableParamView("{Binding Path=Parameters[$code].Setter}", 2));
        } else $grid->add(new app_ParameterViewXmlTag("{Binding Parameters[$code]}", $column_id, $row_id));
    }

    /**
     * @param GridXmlTag $grid
     * @param int $column_id
     * @param int $row_id
     * @param string $label
     * @param SystemDiagnosticAggregateParameter[] $parameters
     * @return void
     */
    private function addParametersGroupToGrid(GridXmlTag $grid, int $column_id, int $row_id, ?int $column_span, string $label, array $parameters): void
    {
        $columns_count = count($parameters);
        $group = (new GridXmlTag($column_id, $row_id, $column_span))
            ->add($columns = (new Grid_ColumnDefinitionsXmlTag())
                ->add(new ColumnDefinitionXmlTag("$columns_count*")));
        for ($i = 0; $i < $columns_count; $i++) {$columns->add(new ColumnDefinitionXmlTag('*'));}
        $group->add((new LabelForGroupXmlTag(0))->add($label));
        $i = 1;
        foreach ($parameters as $parameter) {
            $code = $parameter->getCode();
            $group->add(new app_ParameterViewXmlTag("{Binding Parameters[$code]}", $i));
            $i++;
        }
        $grid->add($group);
    }
}