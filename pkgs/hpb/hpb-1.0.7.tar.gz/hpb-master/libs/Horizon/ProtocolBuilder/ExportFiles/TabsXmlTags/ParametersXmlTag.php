<?php

namespace Horizon\ProtocolBuilder\ExportFiles\TabsXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class ParametersXmlTag extends XmlTag
{
    public function __construct()
    {
        parent::__construct('Parameters');
    }

    public function add(ParameterXmlTag $tag): void
    {
        $this->addTag($tag);
    }
}