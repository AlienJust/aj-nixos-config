<?php

namespace Horizon\ProtocolBuilder\ExportFiles\MainXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class TextBlockXmlTag extends XmlTag
{
    public readonly string $Text;
    public readonly ?string $FontSize;
    public readonly ?string $Visibility;

    public function __construct(string $Text, ?string $FontSize = null, ?string $Visibility = null)
    {
        parent::__construct('TextBlock');
        $this->Text = $Text;
        $this->FontSize = $FontSize;
        $this->Visibility = $Visibility;
    }


}