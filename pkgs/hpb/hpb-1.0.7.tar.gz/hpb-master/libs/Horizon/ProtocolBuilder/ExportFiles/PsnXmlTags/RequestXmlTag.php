<?php

namespace Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags;

class RequestXmlTag extends RCmdPartXmlTag
{
    public readonly string $Length;
    public readonly string $Position;
    public readonly ?string $CycleMsTime;

    public function __construct(string $Length, string $Position, ?string $CycleMsTime)
    {
        parent::__construct('Request');
        $this->Length = $Length;
        $this->Position = $Position;
        $this->CycleMsTime = $CycleMsTime;
    }


}