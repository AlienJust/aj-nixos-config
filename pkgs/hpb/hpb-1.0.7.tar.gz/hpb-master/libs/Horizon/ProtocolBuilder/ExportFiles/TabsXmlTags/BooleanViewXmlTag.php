<?php

namespace Horizon\ProtocolBuilder\ExportFiles\TabsXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class BooleanViewXmlTag extends XmlTag
{
    public readonly string $Expression;
    public readonly string $ResultTrue;
    public readonly string $ResultFalse;
    public readonly string $Name;
    public readonly ?string $Color;

    public function __construct(string $Expression, string $Name, string $ResultTrue, string $ResultFalse = '', ?string $Color = null)
    {
        parent::__construct('BooleanView');
        $this->Expression = $Expression;
        $this->ResultTrue = $ResultTrue;
        $this->ResultFalse = $ResultFalse;
        $this->Name = $Name;
        $this->Color = $Color;
    }
}