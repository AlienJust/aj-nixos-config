<?php

namespace Horizon\ProtocolBuilder\ExportFiles\MainXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class controls_NumericUpDown extends XmlTag
{
    public readonly ?string $Grid___Column;
    public readonly ?string $Grid___Row;
    public readonly string $Value;
    public readonly ?string $Minimum;
    public readonly ?string $Maximum;
    public readonly ?string $MinWidth;
    public readonly ?string $Interval;
    public readonly ?string $StringFormat;

    public function __construct(string $Value, ?string $Grid___Column = null, ?string $Grid___Row = null,
                                ?string $Minimum = null, ?string $Maximum = null, ?string $Interval = null,
                                ?string $StringFormat = null, ?string $MinWidth = '120')
    {
        parent::__construct('controls:NumericUpDown');
        $this->Value = $Value;
        $this->Grid___Column = $Grid___Column;
        $this->Grid___Row = $Grid___Row;
        $this->Minimum = $Minimum;
        $this->Maximum = $Maximum;
        $this->MinWidth = $MinWidth;
        $this->Interval = $Interval;
        $this->StringFormat = $StringFormat;
    }
}