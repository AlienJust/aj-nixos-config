<?php

namespace Horizon\ProtocolBuilder\ExportFiles\TabsXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class MultiViewXmlTag extends XmlTag
{
    public readonly string $Expression;
    public readonly string $Name;

    public function __construct(string $Expression, string $Name = '{$root}')
    {
        parent::__construct('MultiView');
        $this->Expression = $Expression;
        $this->Name = $Name;
    }

    public function add(NumberViewXmlTag|BooleanViewXmlTag $tag): void
    {
        $this->addTag($tag);
    }
}