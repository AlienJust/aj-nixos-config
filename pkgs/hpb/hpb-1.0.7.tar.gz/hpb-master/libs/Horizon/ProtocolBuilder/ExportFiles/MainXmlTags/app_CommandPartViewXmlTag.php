<?php

namespace Horizon\ProtocolBuilder\ExportFiles\MainXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class app_CommandPartViewXmlTag extends XmlTag
{
    public readonly string $DataContext;

    public function __construct(string $DataContext)
    {
        parent::__construct('app:CommandPartView');
        $this->DataContext = $DataContext;
    }
}