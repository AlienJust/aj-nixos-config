<?php

namespace Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class PsnMeterXmlTag extends XmlTag
{
    public readonly string $Address;
    public readonly string $Name;

    public function __construct(string $Address, string $Name)
    {
        parent::__construct('PsnMeter');
        $this->Address = $Address;
        $this->Name = $Name;
    }
}