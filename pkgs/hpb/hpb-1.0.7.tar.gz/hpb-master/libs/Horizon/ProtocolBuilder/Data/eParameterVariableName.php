<?php

namespace Horizon\ProtocolBuilder\Data;

enum eParameterVariableName: string
{
    case CRC_l = '#CRCL';
    case CRC_h = '#CRCH';
}
