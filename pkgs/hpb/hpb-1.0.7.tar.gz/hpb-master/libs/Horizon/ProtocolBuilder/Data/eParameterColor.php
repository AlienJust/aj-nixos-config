<?php

namespace Horizon\ProtocolBuilder\Data;

enum eParameterColor: string
{
    case black = 'Black';
    case red = 'Red';
    case green = 'Green';

    public function label(): string
    {
        return match ($this) {
            self::black => 'Черный',
            self::red => 'Красный',
            self::green => 'Зеленый',
        };
    }
}