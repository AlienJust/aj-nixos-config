<?php

namespace Horizon\ProtocolBuilder\Data;

/*
 * Перечень способов (алгоритмов) инициализации команды
 */
enum eCommandInitWay: string
{
    case modbus_read = 'modbus_read';
    case modbus_write = 'modbus_write';

    public function label(): string
    {
        return match ($this) {
            self::modbus_read => 'Modbus – чтение (0x03)',
            self::modbus_write => 'Modbus – запись (0x10)',
        };
    }
}