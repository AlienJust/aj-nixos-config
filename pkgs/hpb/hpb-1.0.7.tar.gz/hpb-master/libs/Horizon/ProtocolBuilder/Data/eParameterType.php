<?php

namespace Horizon\ProtocolBuilder\Data;

enum eParameterType: string
{
    case DefVal = 'DefVal';
    case VarVal = 'VarVal';
    case CpzPrm = 'CpzPrm';
    case BitPrm = 'BitPrm';
    
    public function label(): string
    {
        return match($this) {
            self::DefVal => 'Постоянное значение',
            self::VarVal => 'Вычисляемое значение',
            self::CpzPrm => 'Обычный параметр',
            self::BitPrm => 'Битовый параметр',

        };
    }

    public static function all(): array
    {
        $result = [];
        foreach(self::cases() as &$case) {
            $result[$case->name] = $case->label();
        }
        return $result;
    }
}
