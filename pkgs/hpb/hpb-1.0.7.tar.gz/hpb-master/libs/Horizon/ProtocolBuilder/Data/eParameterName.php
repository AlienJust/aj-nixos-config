<?php

namespace Horizon\ProtocolBuilder\Data;

enum eParameterName: string
{
    case address = '#ADDR';
    case command_number = '#NCMD';
    case start_param_hi = 'StartParamHi';
    case start_param_lo = 'StartParamLo';
    case count_hi = 'CountHi';
    case count_lo = 'CountLo';
    case bytes_count = 'BytesCount';
}
