<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageParts;

class PathToPageForListData extends PathToPage
{
    public function __construct(bool $enabled, string $main_name, string $main_url, ?string $name)
    {
        parent::__construct();
        if ($enabled) {
            $this->addStep(
                $main_name,
                $main_url
            );
            if ($name !== null) $this->addStep($name);
        }
    }
}