<?php

namespace Horizon\ProtocolBuilder\UserInterface\Menu;

use Exception;
use Horizon\ProtocolBuilder\DataBase\Tables\Command;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToReply;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToRequest;
use Horizon\ProtocolBuilder\UserInterface\eUISA_ReplyParameter;
use Horizon\ProtocolBuilder\UserInterface\eUISA_RequestParameter;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\Menu;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\MenuAction;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\MenuBlock;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\MenuItem;
use Horizon\UserInterface\Tags\Trace;

class ParametersMenu extends Menu
{
    public function __construct(Command $command, ?string $current_ID = null,
                                eUISA_RequestParameter|eUISA_ReplyParameter|null $action = null)
    {
        parent::__construct('parameters');
        try {
            $empty_request_parameter = new ParameterToRequest($command->getID());
            $empty_reply_parameter = new ParameterToReply($command->getID());
            $this
                ->addBlock($request_block = new MenuBlock('Параметры запроса')
                    ->addItem(
                        new MenuAction(
                            eUISA_RequestParameter::new->initController()->setParameter($empty_request_parameter),
                            $action
                        ),
                        new MenuAction(
                            eUISA_RequestParameter::new_default_value->initController()->setParameter($empty_request_parameter),
                            $action
                        ),
                        new MenuAction(
                            eUISA_RequestParameter::new_variable->initController()->setParameter($empty_request_parameter),
                            $action
                        ),
                        new MenuAction(
                            eUISA_RequestParameter::new_bits->initController()->setParameter($empty_request_parameter),
                            $action
                        )))
                ->addBlock($reply_block = new MenuBlock('Параметры ответа')
                    ->addItem(
                        new MenuAction(
                            eUISA_ReplyParameter::new->initController()->setParameter($empty_reply_parameter),
                            $action
                        ),
                        new MenuAction(
                            eUISA_ReplyParameter::new_default_value->initController()->setParameter($empty_reply_parameter),
                            $action
                        ),
                        new MenuAction(
                            eUISA_ReplyParameter::new_variable->initController()->setParameter($empty_reply_parameter),
                            $action
                        ),
                        new MenuAction(
                            eUISA_ReplyParameter::new_bits->initController()->setParameter($empty_reply_parameter),
                            $action
                        )));

            $parameters_to_request = $command->arrParametersToRequest();
            $parameters_to_reply = $command->arrParametersToReply();

            $ref_request_controller = $action == eUISA_RequestParameter::new_view
                ? $action->initController()
                : eUISA_RequestParameter::edit->initController();
            $ref_reply_controller = $action == eUISA_ReplyParameter::new_view
                ? $action->initController()
                : eUISA_ReplyParameter::edit->initController();


            foreach ($parameters_to_request as &$parameter) $request_block
                ->addItem(new MenuItem(
                    $ref_request_controller->setParameter($parameter),
                    $parameter->getName(),
                    $parameter->getGUID() == $current_ID
                ));
            foreach ($parameters_to_reply as &$parameter) $reply_block
                ->addItem(new MenuItem(
                    $ref_reply_controller->setParameter($parameter),
                    $parameter->getName(),
                    $parameter->getGUID() == $current_ID
                ));

        } catch (Exception $e) {
            $this->addBlock(new MenuBlock("Ошибка")->add(new Trace($e)));
        }
    }
}