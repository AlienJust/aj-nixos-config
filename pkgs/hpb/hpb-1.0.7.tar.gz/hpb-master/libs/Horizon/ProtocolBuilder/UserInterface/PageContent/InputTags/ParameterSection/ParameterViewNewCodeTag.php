<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputText;

class ParameterViewNewCodeTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eParameterField::view_new_code->code(), $value,
            'Код представления параметра', 'Введите код представления параметра', true);
        $this->addAttribute(Attribute::maxlength, '36');
    }
}