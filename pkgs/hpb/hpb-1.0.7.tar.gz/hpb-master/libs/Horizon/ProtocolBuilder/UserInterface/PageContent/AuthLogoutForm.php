<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\LogoutButton;

class AuthLogoutForm extends MainForm
{
    public function __construct(string $action_URL)
    {
        parent::__construct($action_URL);
        $this->add(new LogoutButton());
    }
}