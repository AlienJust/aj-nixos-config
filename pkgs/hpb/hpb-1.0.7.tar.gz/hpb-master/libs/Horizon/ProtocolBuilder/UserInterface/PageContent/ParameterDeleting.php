<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

class ParameterDeleting extends _Deleting
{
    public function __construct(string $GUID, string $action_URL)
    {
        parent::__construct("параметра", "параметр", $GUID, $action_URL);
    }
}