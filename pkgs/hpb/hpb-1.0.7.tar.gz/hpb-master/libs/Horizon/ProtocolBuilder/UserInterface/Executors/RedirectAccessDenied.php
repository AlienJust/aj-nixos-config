<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\UserInterface\Executor;

class RedirectAccessDenied extends Executor
{

    public function __construct()
    {
        parent::__construct('/');
    }
}