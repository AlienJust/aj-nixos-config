<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\eUICallerAJAXAction;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\PresetTags\SortableSummonList;

class ParameterViewNumberListTag extends SortableSummonList
{
    public function __construct()
    {
        parent::__construct(
            eUICallerAJAXAction::summon_parameter_view_number->value,
            eParameterField::summon_view_numbers_counter->code(),
            'Конвертированные значения'
        );
    }
}