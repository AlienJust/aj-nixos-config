<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection\UserGroupsCheckboxTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\UpdatingButton;
use Horizon\UserInterface\Tags\Fieldset;
use Horizon\UserInterface\TagsPack;

class UserGroupsEditing extends _PageContentTag
{
    private TagsPack $groups_tag;
    public function __construct(string $header, string $action_URL, string $user_name)
    {
        parent::__construct($header);
        $this->groups_tag = new TagsPack();
        $this->add(new MainForm($action_URL)
            ->add(new Fieldset("Выберите группы, контент которых будет доступен пользователю <b>&laquo;$user_name&raquo;</b>:")
                ->add($this->groups_tag))
            ->add(new UpdatingButton())
        );
    }

    public function addGroup(int $ID, string $name, bool $value, int $level): void
    {
        $this->groups_tag->add(new UserGroupsCheckboxTag($ID, $name, $value)
            ->addStyle('margin-left', ($level * 3) . 'rem'));
    }
}