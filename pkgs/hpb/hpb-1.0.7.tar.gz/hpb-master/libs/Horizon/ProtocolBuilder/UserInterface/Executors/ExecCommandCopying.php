<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\Data\eParameterName;
use Horizon\ProtocolBuilder\DataBase\Tables\Command;
use Horizon\ProtocolBuilder\DataBase\Tables\Parameter;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterView;
use Horizon\ProtocolBuilder\LogicItems\HexByte;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Command;
use Horizon\UserInterface\Executor;

class ExecCommandCopying extends Executor
{
    private Command $command;
    private ?int $protocol;
    /**
     * @throws DBException
     */
    public function __construct(Command $command, int $source)
    {
        $template = Command::dbLoad($source);
        $command->setName($template->getName())
            ->setSystem($template->isSystem());
        $command->setRequest(
            $template->refRequest()->getLength(),
            $template->refRequest()->getStart(),
            $template->refRequest()->getHeaderLength(),
            $template->refRequest()->getCycleMsTime()
        );
        $command->setReply(
            $template->refReply()->getLength(),
            $template->refReply()->getStart(),
            $template->refReply()->getHeaderLength(),
            $template->refReply()->isRequestRequired()
        );
        $command->dbInsert();
        $this->command = $command;
        $this->protocol = $command->refSubscriber()->getProtocol();
        foreach($template->arrParametersToRequest() as $parameter) $this->copyParameter($parameter);
        foreach($template->arrParametersToReply() as $parameter) $this->copyParameter($parameter);
        parent::__construct(eUISA_Command::edit->initController()->setCommand($command)->getURL());
    }

    /**
     * @throws DBException
     */
    private function copyParameter(Parameter $source): void
    {
        $copy = clone $source;
        $copy->setCommand($this->command);
        if ($copy->getName() == eParameterName::address->value) {
            $subscriber_address = new HexByte($this->command->refSubscriber()->getAddress());
            $copy->setValue($subscriber_address->hex);
        }
        $copy->dbInsert();
        foreach ($source->arrViews() as $view) {
            $add = $view->isByDiagnosticSystem() ? 'ds' : null;
            $new_view = (new ParameterView($this->protocol, $source->isPackage()
                    ? $this->command->refReply()->initCodeForParameterView(null, $add)
                    : $this->command->refRequest()->initCodeForParameterView(null, $add)))
                ->setIdentifier($copy->getGUID())
                ->setComment($view->getComment())
                ->setFormat($view->getFormat())
                ->setMask($view->getMask())
                ->setCustomName($view->getCustomName());
            $new_view->addViewValue(...$view->arrViewValues());
            $new_view->addViewNumber(...$view->arrViewNumbers());
            $injection = $view->refInjection();
            $injection?->addValue(...$injection->arrInjectValues());
            $new_view->setInjection($injection);
            $new_view->dbInsert();
        }
    }
}