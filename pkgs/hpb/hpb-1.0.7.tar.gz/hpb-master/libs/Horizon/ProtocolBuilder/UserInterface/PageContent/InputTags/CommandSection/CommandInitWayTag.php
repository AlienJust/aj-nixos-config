<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection;

use Horizon\ProtocolBuilder\Data\eCommandInitWay;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCommandField;
use Horizon\UserInterface\Controls\Components\Option;
use Horizon\UserInterface\Controls\InputSelect;

class CommandInitWayTag extends InputSelect
{
    public function __construct()
    {
        parent::__construct(eCommandField::init_way->code(), '',
            'Алгоритм для инициализации заголовков',
            'Выберите алгоритм для автоматической инициализации заголовков');
        $this->addOptions(true, ...array_map(fn(eCommandInitWay $case): Option => new Option($case->value, $case->label()), eCommandInitWay::cases()));
    }
}