<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolGroupsCheckboxTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\UpdatingButton;
use Horizon\UserInterface\Tags\Fieldset;
use Horizon\UserInterface\TagsPack;

class ProtocolGroupsEditing extends _PageContentTag
{
    private TagsPack $groups_tag;
    public function __construct(string $header, string $action_URL)
    {
        parent::__construct($header);
        $this->groups_tag = new TagsPack();
        $this->add(new MainForm($action_URL)
            ->add(new Fieldset('Выберите группы, которым будет доступен протокол:')
                ->add($this->groups_tag))
            ->add(new UpdatingButton())
        );
    }

    public function addGroup(int $ID, string $name, bool $value, int $level, bool $disabled): void
    {
        $this->groups_tag->add(new ProtocolGroupsCheckboxTag($ID, $name, $value)
            ->addStyle('margin-left', ($level * 3) . 'rem')->setDisabled($disabled));
    }
}