<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageParts;

use Horizon\UserInterface\Tags\Division;

class ControlPanel extends Division
{
    public function __construct()
    {
        parent::__construct();
        $this->addClass('control-panel');
    }

    public function addItem(ControlPanelItem ...$item): static
    {
        $this->add(...$item);
        return $this;
    }
}