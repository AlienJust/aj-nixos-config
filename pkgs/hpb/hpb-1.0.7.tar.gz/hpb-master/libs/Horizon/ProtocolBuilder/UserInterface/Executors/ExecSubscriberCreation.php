<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\Subscriber;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Subscriber;
use Horizon\UserInterface\Executor;

class ExecSubscriberCreation extends Executor
{
    /**
     * @throws DBException
     * @throws VException
     */
    public function __construct(Subscriber $subscriber, string $name, string $short_name, int $address, string $description, bool $hide_for_production)
    {
        $subscriber->setName($name);
        $subscriber->setShortName($short_name);
        $subscriber->setAddress($address);
        $subscriber->setDescription($description);
        $subscriber->setHideForProduction($hide_for_production);
        $subscriber->dbInsert();
        parent::__construct(eUISA_Subscriber::edit->initController()->setSubscriber($subscriber)->getURL());
    }
}