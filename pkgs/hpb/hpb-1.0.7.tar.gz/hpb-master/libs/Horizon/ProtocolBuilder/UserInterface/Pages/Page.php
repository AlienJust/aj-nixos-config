<?php

namespace Horizon\ProtocolBuilder\UserInterface\Pages;

abstract class Page
{
    protected array $CSS_links = [];
    protected array $JS_scripts = [];

    protected string $title = '';

    public function setCSS(string ...$links): static
    {
        $this->CSS_links = $links;
        return $this;
    }

    public function setJS(string ...$src): static
    {
        $this->JS_scripts = $src;
        return $this;
    }

    private function drawCSSLinks(): string
    {
        return implode("\n",
            array_map(fn($href) => '<link rel="stylesheet" type="text/css" href="' . $href . '" />', $this->CSS_links));
    }

    private function drawJSScripts(): string
    {
        return implode("\n",
            array_map(fn($src) => '<script type="text/javascript" src="' . $src . '"></script>', $this->JS_scripts));
    }

    abstract protected function drawBody(): string;

    public function draw(): string
    {
        return
'<!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <meta http-equiv="Content-Language" content="ru"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>' . $this->title . '</title>' . $this->drawCSSLinks() .' 
        <script type="text/javascript" src="js/jquery/jquery.js"></script>
        <script type="js/jquery/ui/jquery-ui.min.js"></script>' . $this->drawJSScripts() . '
        <script type="text/javascript" src="/js/horizon.js"></script>
        <script>
            window.onload = function () {
                window.horizon = new Horizon();
            };
        </script>
    </head>
    <body>
        ' . $this->drawBody() . '
    </body>
</html>';
    }
}