<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\ViewTags;

use Horizon\UserInterface\Tags\Header;
use const HORIZON_SETTINGS as HS;

class VersionView extends Header
{
    public function __construct()
    {
        parent::__construct(2, "Версия ". HS['ui']['version']);
    }
}