<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCommandField;
use Horizon\UserInterface\Controls\InputText;

class CommandNameTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eCommandField::name->code(), $value,
            'Наименование команды', 'Введите наименование команды', true);
    }
}