<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageParts;

use Exception;
use Horizon\ProtocolBuilder\DataBase\Tables\Command;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToReply;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToRequest;
use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\DataBase\Tables\Subscriber;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Command;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Protocol;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Subscriber;

class PathToPageForProtocol extends PathToPage
{
    public function __construct(Protocol $protocol, ?Subscriber $subscriber = null, ?Command $command = null,
                                ParameterToReply|ParameterToRequest|null $parameter = null)
    {
        parent::__construct();
        try {
            if ($protocol->exists()) $this->addStep($protocol->name, is_null($subscriber)
                ? null : eUISA_Protocol::edit->initController()->setProtocol($protocol)->getURL());
            if ($subscriber?->exists()) $this->addStep($subscriber->getName(), is_null($command)
                ? null : eUISA_Subscriber::edit->initController()->setSubscriber($subscriber)->getURL());
            if ($command?->exists()) $this->addStep($command->getName(), is_null($parameter)
                ? null : eUISA_Command::edit->initController()->setCommand($command)->getURL());
            if ($parameter?->exists()) $this->addStep($parameter->getName());
        } catch (Exception $e) {
            $this->addStep('Ошибка! ' . $e->getMessage(),'');
        }
    }
}