<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Controls\CheckboxBool;

class ProtocolGroupsCheckboxTag extends CheckboxBool
{
    public function __construct(string $ID, string $name, bool $value)
    {
        parent::__construct(eProtocolField::groups->code($ID), $value, $name,
            'Отметьте группу «' . $name . '», если нужно добавить её в список', false);
    }
}