<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\eUICallerAJAXAction;
use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCallerAJAXFields;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\SystemDiagnosticListEmptyRowDestinationTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\SystemDiagnosticListEmptyRowTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\UpdatingButton;
use Horizon\UserInterface\Constants\DataAttribute;
use Horizon\UserInterface\Controls\Button;
use Horizon\UserInterface\Controls\InputHiddenValue;
use Horizon\UserInterface\Tags\Anchor;
use Horizon\UserInterface\Tags\Division;
use Horizon\UserInterface\Tags\Header;
use Horizon\UserInterface\Tags\ListItem;
use Horizon\UserInterface\Tags\UnorderedList;
use Horizon\UserInterface\TagsPack;

class ProtocolSystemDiagnosticAllocating extends _PageContentTag
{
    private TagsPack $sortable_pack;
    private Division $last_block;
    private UnorderedList $last_column;
    public function __construct(string $id, string $header, string $action_URL)
    {
        parent::__construct($header, $id);
        $this->add((new MainForm($action_URL))
            ->add($this->sortable_pack = (new TagsPack())
                ->add(new Header(2, 'Параметры с неопределенным положением:'))
                ->add((new Button('summon_empty_row', 'Добавить пустую строку'))
                    ->addClass('call-form-elements')
                    ->addAttributeJSON(DataAttribute::calls, [
                        eCallerAJAXFields::action->code() => eUICallerAJAXAction::summon_system_diagnostic_empty_row->value,
                        eCallerAJAXFields::destination->code() => eUICallerAJAXAction::summon_system_diagnostic_empty_row->value,
                        eCallerAJAXFields::properties->code() => [],
                    ]))
                ->add($this->last_block = (new Division())->addClass('sortable-block')
                    ->add($this->last_column = (new UnorderedList())->addClass('sortable-column')
                        ->add(new SystemDiagnosticListEmptyRowDestinationTag())))
                ->add(new Header(2, 'Отображаемые блоки параметров:')))
            ->add(new UpdatingButton()));
    }

    public function addBlock(?int $id, int $sort, string $name): static
    {
        $this->sortable_pack->add(new Header(3, "#$sort $name"));
        $this->sortable_pack->add(new InputHiddenValue(eProtocolField::diagnostic_list->code(), "block=$id"));
        $this->sortable_pack->add($this->last_block = (new Division())->addClass('sortable-block'));
        return $this;
    }

    public function addColumn(int $id): static
    {
        $this->last_block->add($this->last_column = (new UnorderedList())->addClass('sortable-column'));
        $this->last_column->add(new InputHiddenValue(eProtocolField::diagnostic_list->code(), "column=$id"));
        return $this;
    }

    public function addChunk(string $id, string $name, string $url): static
    {
        $this->last_column->add((new ListItem())
            ->add(new InputHiddenValue(eProtocolField::diagnostic_list->code(), "parameter=$id"))
            ->add($name . ' ')
            ->add(new Anchor($url, 'Изменить'))
        );
        return $this;
    }

    public function addVirtualChunk(string $code): static
    {
        $this->last_column->add((new ListItem())
            ->add(new InputHiddenValue(eProtocolField::diagnostic_list->code(), "virtual_parameter=$code"))
            ->add($code)
        );
        return $this;
    }

    public function addAggregateChunk(int $id, string $label, int $param_count): static
    {
        $this->last_column->add((new ListItem())
            ->add(new InputHiddenValue(eProtocolField::diagnostic_list->code(), "aggregate_parameter=$id"))
            ->add("$label [$param_count шт.]")
        );
        return $this;
    }

    public function addEmptyRow(): static
    {
        $this->last_column->add(new SystemDiagnosticListEmptyRowTag());
        return $this;
    }
}