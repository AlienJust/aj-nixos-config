<?php

namespace Horizon\ProtocolBuilder\UserInterface\Pages;

class UnknownPage extends Page
{

    protected function drawBody(): string
    {
        return '<div class="solo-page">
404 Страница не найдена
</div>
';
    }
}