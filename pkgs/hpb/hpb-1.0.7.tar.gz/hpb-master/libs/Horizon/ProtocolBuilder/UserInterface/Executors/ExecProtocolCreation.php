<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Protocol;
use Horizon\UserInterface\Executor;

class ExecProtocolCreation extends Executor
{
    /**
     * @throws DBException
     */
    public function __construct(Protocol $protocol, string $name, string $description, string $version, string $GUID, int $author)
    {
        $protocol->name = $name;
        $protocol->description = $description;
        $protocol->version = $version;
        $protocol->GUID = $GUID;
        $protocol->author = $author;
        $protocol->dbInsert();
        parent::__construct(eUISA_Protocol::edit->initController()->setProtocol($protocol)->getURL());
    }
}