<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\SubscriberSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eSubscriberField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputText;

class SubscriberNameTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eSubscriberField::name->code(), $value,
            'Наименование абонента', 'Введите наименование абонента', true);
        $this->addAttribute(Attribute::maxlength, '255');
    }
}