<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCommandField;
use Horizon\UserInterface\Controls\CheckboxBool;

class CommandParameterCheckboxTag extends CheckboxBool
{
    public function __construct(string $GUID, string $name)
    {
        parent::__construct(eCommandField::parameters->code()."[$GUID]", false, $name,
            'Отметьте параметры, которые нужно удалить', false);
    }
}