<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Horizon\ProtocolBuilder\UserInterface\UIControllers\UICallerAJAX;

enum eUICallerAJAXAction: string
{
    case summon_system_diagnostic_block = 'summon_system_diagnostic_block';
    case summon_system_diagnostic_virtual_parameter = 'summon_system_diagnostic_virtual_parameter';
    case summon_system_diagnostic_aggregate_group = 'summon_system_diagnostic_aggregate_group';
    case summon_system_diagnostic_aggregate_parameter = 'summon_system_diagnostic_aggregate_parameter';
    case summon_parameter_view_value = 'summon_parameter_view_value';
    case summon_parameter_view_number = 'summon_parameter_view_number';
    case summon_system_diagnostic_empty_row = 'summon_system_diagnostic_empty_row';
    case summon_parameter_view_injection_value = 'summon_parameter_view_injection_value';

    public function controller(array $post = []): UICallerAJAX
    {
        return new UICallerAJAX($this, $post);
    }
}