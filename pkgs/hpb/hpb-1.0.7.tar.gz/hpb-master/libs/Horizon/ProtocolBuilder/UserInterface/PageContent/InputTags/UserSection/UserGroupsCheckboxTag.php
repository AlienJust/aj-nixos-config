<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eUserField;
use Horizon\UserInterface\Controls\CheckboxBool;

class UserGroupsCheckboxTag extends CheckboxBool
{
    public function __construct(string $ID, string $name, bool $value)
    {
        parent::__construct(eUserField::groups->code($ID), $value, $name,
            'Отметьте группу «' . $name . '», если нужно добавить её в список', false);
    }
}