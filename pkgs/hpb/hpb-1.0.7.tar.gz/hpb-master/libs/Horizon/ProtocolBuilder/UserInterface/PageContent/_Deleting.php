<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\DeleteButton;
use Horizon\UserInterface\Tags\Paragraph;

abstract class _Deleting extends _PageContentTag
{
    /**
     * @param string $subject_r Наименование удаляемого в родительном падеже – "Удаление чего?"
     * @param string $subject_v Наименование удаляемого в винительном падеже – "Удалить что?"
     * @param string $action_URL Путь для удаления
     * @param string $id ID заголовка
     */
    public function __construct(string $subject_r, string $subject_v, ?string $name, string $action_URL, string $id = 'delete')
    {
        if ($name !== null) $name = " <b>&laquo;$name&raquo;</b>";
        parent::__construct("Удаление $subject_r", $id);
        $this->add(new MainForm($action_URL)
            ->add(new Paragraph("Чтобы удалить $subject_v$name, нажмите кнопку ниже:"))
            ->add(new DeleteButton()));
    }
}