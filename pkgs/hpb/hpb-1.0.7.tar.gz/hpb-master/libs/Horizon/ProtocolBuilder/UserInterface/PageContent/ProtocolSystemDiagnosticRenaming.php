<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\UpdatingButton;
use Horizon\UserInterface\Controls\InputText;
use Horizon\UserInterface\Tags\Anchor;
use Horizon\UserInterface\Tags\Division;
use Horizon\UserInterface\Tags\Header;
use Horizon\UserInterface\Tags\ListItem;
use Horizon\UserInterface\Tags\UnorderedList;
use Horizon\UserInterface\TagsPack;

class ProtocolSystemDiagnosticRenaming extends _PageContentTag
{
    private TagsPack $main_pack;
    private Division $last_block;
    private UnorderedList $last_column;
    public function __construct(string $id, string $header, string $action_URL)
    {
        parent::__construct($header, $id);
        $this->add((new MainForm($action_URL))
            ->add($this->main_pack = new TagsPack())
            ->add(new UpdatingButton()));
    }

    public function addBlock(int $sort, string $name): static
    {
        $this->main_pack->add(new Header(2, "#$sort $name"));
        $this->main_pack->add($this->last_block = (new Division())->addClass('renaming-block'));
        return $this;
    }

    public function addColumn(): static
    {
        $this->last_block->add($this->last_column = (new UnorderedList())->addClass('renaming-column'));
        return $this;
    }

    public function addChunk(string $code, string $address, string $name, ?string $custom_name, string $url): static
    {
        $this->last_column->add((new ListItem())
            ->add(new InputText(eProtocolField::parameter_view_name->code($code), htmlspecialchars($custom_name ?? ''),
                htmlspecialchars("$address $code $name"), 'Введите иное наименование параметра, если оно отличается от оригинального'))
            ->add(new Anchor($url, 'Изменить'))
        );
        return $this;
    }
}