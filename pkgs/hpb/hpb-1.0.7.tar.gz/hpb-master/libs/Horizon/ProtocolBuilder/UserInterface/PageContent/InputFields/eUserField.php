<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields;

use Horizon\ProtocolBuilder\Exceptions\VEx;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\LogicItems\ArrayKeysRequiredHandler;
use Horizon\ProtocolBuilder\LogicItems\ToStringNullableHandler;
use Horizon\ProtocolBuilder\LogicItems\ToStringRequiredHandler;

enum eUserField implements iTransmissionField
{
    case username;

    case default_password;
    case surname;
    case name;
    case patronymic;
    case ban;
    case groups;

    public function code(...$options): string
    {
        return match ($this) {
            self::username,
            self::default_password,
            self::surname,
            self::name,
            self::patronymic,
            self::ban => $this->name,
            self::groups => "$this->name[$options[0]]"

        };
    }

    /**
     * @throws VException
     */
    public function get(array $post): string|bool|array|null
    {
        return match ($this) {
            self::username,
            self::surname,
            self::name => ToStringRequiredHandler::run($post[$this->code()] ?? '', $this->name),
            self::default_password => $post[$this->code()] ?? throw new VException(VEx::empty, $this->name),
            self::patronymic => ToStringNullableHandler::run(htmlspecialchars($post[$this->code()] ?? '')) ?? '',
            self::ban => ($post[$this->code()] ?? '0') == '1',
            self::groups => ArrayKeysRequiredHandler::run($post[$this->name] ?? [], $this->name),
        };
    }
}