<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_Command;

enum eUISA_Command: string implements iUISectionActionEnum
{
    case new = 'new';
    case copy = 'copy';
    case edit = 'edit';
    case delete = 'delete';
    case delete_parameters = 'delete_parameters';

    public function name(): string
    {
        return match ($this) {
            self::new => 'Создание команды',
            self::copy => 'Копирование команды',
            self::edit => 'Изменение команды',
            self::delete => 'Удаление команды',
            self::delete_parameters => 'Удаление параметров',
        };
    }

    public function buttonName(): string
    {
        return match ($this) {
            self::new => '+ команда',
            self::copy => '',
            self::edit => 'Изменить',
            self::delete => 'Удалить',
            self::delete_parameters => 'Удалить параметры',
        };
    }

    public static function controlPanel(): array
    {
        return [
            self::edit,
            self::delete_parameters,
        ];
    }

    public function initController(array $post = []): UISection_Command
    {
        return new UISection_Command($this, $post);
    }
}
