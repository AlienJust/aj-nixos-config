<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\ProtocolBuilder\ImportFiles\PsnXmlParser;
use Horizon\ProtocolBuilder\ImportFiles\XmlParserController;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Protocol;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputModels\TempFile;
use Horizon\UserInterface\Executor;

class ExecProtocolImport extends Executor
{

    public function __construct(TempFile $file, int $author)
    {
        $parser = new PsnXmlParser($author);
        new XmlParserController($parser, $file->path)->run();
        parent::__construct(eUISA_Protocol::edit->initController()->setProtocol($parser->refProtocol())->getURL());
    }
}