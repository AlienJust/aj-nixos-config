<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Controls\CheckboxMatrix;

class ParameterCheckboxMatrixTag extends CheckboxMatrix
{
    public function __construct(array $bits, int $count, array $unavailable_bits)
    {
        parent::__construct(eParameterField::bits->code(), $count, $unavailable_bits, $bits);
    }
}