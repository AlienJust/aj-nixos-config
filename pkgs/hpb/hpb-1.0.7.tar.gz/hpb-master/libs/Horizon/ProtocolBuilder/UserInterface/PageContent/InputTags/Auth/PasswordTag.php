<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\Auth;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eAuthField;
use Horizon\UserInterface\Controls\InputPassword;

class PasswordTag extends InputPassword
{
    public function __construct()
    {
        parent::__construct(eAuthField::password->code(), 'Пароль', 'Введите пароль', true);
    }
}