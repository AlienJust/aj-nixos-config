<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\Data\eParameterType;
use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewCommentTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewCustomNameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewFormatTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewInjectionTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewInjectionValueListTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewNewCodeTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewNumberListTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewValueListTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\CreationButton;
use Horizon\UserInterface\PresetTags\Division2Columns;
use Horizon\UserInterface\Tags\Header;

class ParameterViewCreation extends _PageContentTag
{

    public function __construct(string $header, string $action_URL, string $code, string $comment, ?string $type,
                                int $number_in_package)
    {
        parent::__construct($header);
        $type = eParameterType::tryFrom($type);
        $this->add((new MainForm($action_URL))
            ->add((new Division2Columns())
                ->add(new Header(3, $type?->label() ?? ''))
                ->add(new ParameterViewNewCodeTag($code))
                ->add(new ParameterViewCustomNameTag(''))
                ->add(new ParameterViewFormatTag(''))
                ->add(new ParameterViewCommentTag($comment)))
            ->add(new ParameterViewValueListTag())
            ->add(new ParameterViewNumberListTag())
            ->add((new ParameterViewInjectionTag(false, $number_in_package, '[value] * 1.0',
                true, null, null, null))
                ->add(new ParameterViewInjectionValueListTag()))
            ->add(new CreationButton()));
    }
}