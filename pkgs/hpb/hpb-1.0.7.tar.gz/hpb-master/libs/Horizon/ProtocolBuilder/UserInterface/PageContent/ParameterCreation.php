<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Exception;
use Horizon\ProtocolBuilder\Data\eParameterType;
use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterByteOrderTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterCheckboxMatrixTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterGUIDTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterLowestDigitPriceTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterNameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterSignedTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterTypeHiddenTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterValueConversionFormulaTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\CreationButton;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\PresetTags\Division2Columns;
use Horizon\UserInterface\Tags\Trace;

class ParameterCreation extends _PageContentTag
{
    public function __construct(string $header, string $action_URL,
                                string $GUID, string $name, ?string $value_conversion_formula, float $lowest_digit_price, bool $signed,
                                array $bits, int $count, array $unavailable_bits)
    {
        parent::__construct($header);
        try {
            $this->add((new MainForm($action_URL))
                ->add(new ParameterGUIDTag($GUID))
                ->add(new ParameterNameTag($name))
                ->add((new Division2Columns())
                    ->add(new ParameterValueConversionFormulaTag($value_conversion_formula))
                    ->add(new ParameterLowestDigitPriceTag($lowest_digit_price))
                    ->add(new ParameterSignedTag($signed))
                    ->add((new ParameterByteOrderTag(null))
                        ->addAttribute(Attribute::required, false)))
                ->add(new ParameterTypeHiddenTag(eParameterType::CpzPrm))
                ->add(new ParameterCheckboxMatrixTag($bits, $count, $unavailable_bits))
                ->add(new CreationButton())
            );
        } catch (Exception $exception) {
            $this->add(new Trace($exception));
        }
    }
}