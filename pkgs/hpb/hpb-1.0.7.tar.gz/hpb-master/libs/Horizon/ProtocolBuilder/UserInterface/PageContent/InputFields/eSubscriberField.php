<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields;

use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\LogicItems\ToIntRequiredHandler;
use Horizon\ProtocolBuilder\LogicItems\ToStringNullableHandler;
use Horizon\ProtocolBuilder\LogicItems\ToStringRequiredHandler;

enum eSubscriberField implements iTransmissionField
{
    case name;
    case short_name;
    case address;
    case description;
    case hide_for_production;

    public function code(mixed ...$options): string
    {
        return match ($this) {
            self::name,
            self::short_name,
            self::address,
            self::description,
            self::hide_for_production => $this->name,
        };
    }

    /**
     * @throws VException
     */
    public function get(array $post): null|string|array
    {
        return match ($this) {
            self::name,
            self::short_name => ToStringRequiredHandler::run($post[$this->code()] ?? null, $this->name),
            self::address => ToIntRequiredHandler::run($post[$this->code()] ?? null, $this->name),
            self::description => ToStringNullableHandler::run(htmlspecialchars($post[$this->code()] ?? '')) ?? '',
            self::hide_for_production => ($post[$this->code()] ?? '0') == '1'
        };
    }
}
