<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields;

interface iTransmissionField
{
    public function code(mixed ...$options): string;
    public function get(array $post): mixed;
}