<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\PageContent\Tables\UGroupsTable;

class UGroupList extends _PageContentTag
{
    private UGroupsTable $groups;
    public function __construct(?string $header = null)
    {
        parent::__construct($header);
        $this->groups = new UGroupsTable();
        $this->add($this->groups);
    }

    public function addItem(string $name, string $description, int $level, ?string $edit_URL): static
    {
        $this->groups->addItem($name, $description, $level, $edit_URL);
        return $this;
    }
}