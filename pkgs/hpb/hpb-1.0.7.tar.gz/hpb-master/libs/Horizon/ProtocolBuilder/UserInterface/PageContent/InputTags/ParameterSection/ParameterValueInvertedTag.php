<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Controls\CheckboxBool;

class ParameterValueInvertedTag extends CheckboxBool
{
    public function __construct(bool $value)
    {
        parent::__construct(eParameterField::value_inverted->code(), $value,
            'Инвертировать значение', 'Отметьте, нужно ли инвертировать битовое значение');
    }
}