<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\ViewTags;

use Exception;
use Horizon\ProtocolBuilder\UserInterface\PageContent\_PageContentTag;
use Horizon\UserInterface\Tags\Division;
use Horizon\UserInterface\Tags\Trace;

class ExceptionView extends _PageContentTag
{
    public function __construct(Exception $exception)
    {
        parent::__construct('Произошла ошибка');
        $this->add(new Division()->add(new Trace($exception))->addClass('attention'));
    }
}