<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputText;

class ParameterViewMaskTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eParameterField::view_mask->code(), $value,
            'Маска для отображения значения', 'Введите маску для отображения составного значения');
        $this->addAttribute(Attribute::maxlength, '255');
        $this->addAttribute(Attribute::placeholder, 'по умолчанию');
    }
}