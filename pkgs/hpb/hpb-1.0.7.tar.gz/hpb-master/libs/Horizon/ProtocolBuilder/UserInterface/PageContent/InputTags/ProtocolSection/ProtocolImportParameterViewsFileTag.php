<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputFile;

class ProtocolImportParameterViewsFileTag extends InputFile
{
    public function __construct()
    {
        parent::__construct(eProtocolField::tabs_file->code(), 'Файл с представлениями параметров протокола',
            'Выберите файл, из которого нужно импортировать представления параметров протокола', true);
        $this->addAttribute(Attribute::accept, '.xml');
    }
}