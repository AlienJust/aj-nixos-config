<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Controls\InputText;

class ProtocolVersionTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eProtocolField::version->code(), $value,
            'Версия протокола', 'Введите версию протокола', true);
    }
}