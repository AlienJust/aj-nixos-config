<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Controls\InputTextarea;

class ParameterDescriptionTag extends InputTextarea
{
    public function __construct(string $value)
    {
        parent::__construct(eParameterField::description->code(), $value,
            'Комментарий', 'Введите описание параметра', 2000);
    }
}