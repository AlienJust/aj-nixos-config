<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UGroupSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eUGroupField;
use Horizon\UserInterface\Controls\Components\Textarea;

class DescriptionTag extends Textarea
{
    public function __construct(string $value)
    {
        parent::__construct(eUGroupField::description->code(), $value, 1500);
    }
}