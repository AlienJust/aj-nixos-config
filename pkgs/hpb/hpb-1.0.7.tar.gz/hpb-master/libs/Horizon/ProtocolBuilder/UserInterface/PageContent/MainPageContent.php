<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\PageContent\ViewTags\CopyrightView;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ViewTags\VersionView;

class MainPageContent extends _PageContentTag
{
    public function __construct(string $action_URL)
    {
        parent::__construct('Конструктор протоколов');
        $this->add(new VersionView())
            ->add(new CopyrightView())
            ->add(new AuthLogoutForm($action_URL));
    }
}