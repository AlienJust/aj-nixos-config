<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCommandField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Constants\DataAttribute;
use Horizon\UserInterface\Controls\InputNumber;

class CommandRequestCycleMsTimeTag extends InputNumber
{
    public function __construct(?float $value)
    {
        $format_value = $value === null ? '' : number_format($value, 4, '.', '');
        parent::__construct(eCommandField::request_cycle_ms_time->code(), $format_value,
            'Время цикла', 'Введите длительность цикла в миллисекундах');
        $this->addAttribute(DataAttribute::min, '0');
        $this->addAttribute(Attribute::step, '0.0001');
    }
}