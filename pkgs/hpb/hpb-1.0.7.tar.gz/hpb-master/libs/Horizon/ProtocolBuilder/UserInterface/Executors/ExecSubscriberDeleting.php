<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\Subscriber;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Protocol;
use Horizon\UserInterface\Executor;

class ExecSubscriberDeleting extends Executor
{
    /**
     * @throws DBException
     */
    public function __construct(Subscriber $subscriber)
    {
        $subscriber->dbDelete();
        parent::__construct(eUISA_Protocol::edit->initController()->setProtocol($subscriber->refProtocol())->getURL());
    }
}