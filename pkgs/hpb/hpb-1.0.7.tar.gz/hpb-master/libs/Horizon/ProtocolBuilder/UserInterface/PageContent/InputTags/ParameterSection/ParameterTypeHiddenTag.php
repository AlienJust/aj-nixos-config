<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\Data\eParameterType;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Controls\InputHiddenValue;

class ParameterTypeHiddenTag extends InputHiddenValue
{
    public function __construct(eParameterType $value)
    {
        parent::__construct(eParameterField::type->code(), $value->value);
    }
}