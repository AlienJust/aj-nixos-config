<?php

namespace Horizon\ProtocolBuilder\UserInterface\Menu\Bricks;

use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Tags\Anchor;
use Horizon\UserInterface\Tags\Image;

class MenuLogo extends Anchor
{
    public function __construct()
    {
        parent::__construct('/', null);
        $this->addClass('main')
            ->add((new Image('/styles/images/logo_light.png'))->addClass('logo')
                ->addAttribute(Attribute::alt, 'ООО НПО Горизонт'));
    }
}