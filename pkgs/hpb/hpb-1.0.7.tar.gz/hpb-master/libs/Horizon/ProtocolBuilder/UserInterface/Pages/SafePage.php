<?php

namespace Horizon\ProtocolBuilder\UserInterface\Pages;

use Horizon\ProtocolBuilder\UserInterface\eUISA_Auth;
use Horizon\ProtocolBuilder\UserInterface\PageContent\AuthLoginForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ViewTags\AuthExceptionView;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ViewTags\CopyrightView;

class SafePage extends Page
{
    private AuthLoginForm $form;
    private ?AuthExceptionView $view = null;

    public function __construct()
    {
        $this->title = "КП · Авторизация";
        $this->form = new AuthLoginForm(eUISA_Auth::login->initController()->getURL());
    }

    public function setExceptionView(AuthExceptionView $view): static
    {
        $this->view = $view;
        return $this;
    }

    protected function drawBody(): string
    {
        return '<div class="solo-page">'
            . $this->view?->draw()
            . $this->form->draw()
            . (new CopyrightView())->draw()
            . '</div>';
    }

    public function setPath(string $path): void
    {
        $this->form->addPath($path);
    }
}