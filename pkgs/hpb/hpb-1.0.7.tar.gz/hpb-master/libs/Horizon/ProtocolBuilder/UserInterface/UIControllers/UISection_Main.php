<?php

namespace Horizon\ProtocolBuilder\UserInterface\UIControllers;

use Horizon\ProtocolBuilder\UserInterface\eUISA_Auth;
use Horizon\ProtocolBuilder\UserInterface\eUISection;
use Horizon\ProtocolBuilder\UserInterface\iUISectionActionEnum;
use Horizon\ProtocolBuilder\UserInterface\PageContent\MainPageContent;
use Horizon\ProtocolBuilder\UserInterface\PageContent\_PageContentTag;
use Horizon\UserInterface\Executor;

class UISection_Main extends UISection
{
    protected static eUISection $section = eUISection::main;
    public function __construct()
    {
        parent::__construct([]);
    }

    public function tag(): _PageContentTag
    {
        return new MainPageContent(eUISA_Auth::logout->initController()->getURL());
    }

    public function initExecutor(): Executor
    {
        return new Executor('');
    }

    public function getCurrentID(): ?string
    {
        return '';
    }

    public function refAction(): ?iUISectionActionEnum
    {
        return null;
    }
}