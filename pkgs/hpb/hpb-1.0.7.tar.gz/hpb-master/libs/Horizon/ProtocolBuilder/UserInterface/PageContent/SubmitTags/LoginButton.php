<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags;

use Horizon\UserInterface\Controls\ButtonSubmit;

class LoginButton extends ButtonSubmit
{
    public function __construct()
    {
        parent::__construct('execute', 'Войти');
    }
}