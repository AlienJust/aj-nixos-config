<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\Auth\DataBase\Tables\Group;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_UGroup;
use Horizon\UserInterface\Executor;

class ExecUGroupDeleting extends Executor
{
    /**
     * @throws DBException
     */
    public function __construct(Group $group)
    {
        $group->dbDelete();
        parent::__construct(eUISA_UGroup::view->initController()->getURL());
    }
}