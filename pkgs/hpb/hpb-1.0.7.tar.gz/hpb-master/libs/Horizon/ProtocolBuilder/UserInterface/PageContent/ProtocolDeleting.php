<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

class ProtocolDeleting extends _Deleting
{
    public function __construct(string $GUID, string $action_URL)
    {
        parent::__construct("протокола", "протокол", $GUID, $action_URL);

    }
}