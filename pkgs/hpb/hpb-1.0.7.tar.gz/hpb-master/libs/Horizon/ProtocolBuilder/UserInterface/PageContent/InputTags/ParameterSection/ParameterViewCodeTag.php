<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Controls\InputHiddenValue;
use Horizon\UserInterface\Controls\InputText;

class ParameterViewCodeTag extends InputHiddenValue
{
    public function __construct(string $value)
    {
        parent::__construct(eParameterField::view_code->code(), $value);
    }
}