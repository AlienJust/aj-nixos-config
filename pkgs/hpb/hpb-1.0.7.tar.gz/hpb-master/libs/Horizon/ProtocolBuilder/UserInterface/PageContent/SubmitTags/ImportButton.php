<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags;

use Horizon\UserInterface\Controls\ButtonSubmit;

class ImportButton extends ButtonSubmit
{
    public function __construct()
    {
        parent::__construct('execute', 'Импорт');
    }
}