<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\Auth\DataBase\PickSources\UGroupPick;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolAuthorTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\UpdatingButton;

class ProtocolAuthorEditing extends _PageContentTag
{
    /**
     * @throws DBException
     */
    public function __construct(string $header, string $action_URL, int $author)
    {
        parent::__construct($header);
        $this->add(new MainForm($action_URL)
            ->add(new ProtocolAuthorTag($author)->addOptions(true, ...new UGroupPick()->init()))
            ->add(new UpdatingButton()));
    }
}