<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_UGroup;

enum eUISA_UGroup: string implements iUISectionActionEnum
{
    case view = '';
    case new = 'new';
    case edit = 'edit';
    case delete = 'delete';

    public function name(): string
    {
        return match ($this) {
            self::new => 'Создание группы',
            self::edit => 'Изменение группы',
            self::delete => 'Удаление группы',
            self::view => 'Группы доступа к протоколам',
        };
    }

    public function buttonName(): string
    {
        return match ($this) {
            self::view => 'Группы доступа',
            self::new => '+ группа',
            self::edit => 'Изменить',
            self::delete => 'Удалить',
        };
    }

    public static function controlPanel(): array
    {
        return [
            self::edit,
        ];
    }

    public function initController(array $post = []): UISection_UGroup
    {
        return new UISection_UGroup($this, $post);
    }
}