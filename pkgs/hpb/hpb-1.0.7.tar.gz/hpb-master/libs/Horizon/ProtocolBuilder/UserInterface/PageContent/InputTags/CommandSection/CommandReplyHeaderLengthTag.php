<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCommandField;
use Horizon\UserInterface\Controls\InputNumber;

class CommandReplyHeaderLengthTag extends InputNumber
{
    public function __construct(string $value)
    {
        parent::__construct(eCommandField::reply_header_length->code(), $value,
            'Длина заголовка ответа (в байтах)', 'Введите длину заголовка ответа в байтах', true);
    }
}