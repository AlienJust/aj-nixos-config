<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\Auth\DataBase\Tables\User;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_User;
use Horizon\UserInterface\Executor;

class ExecUserGroupsEditing extends Executor
{
    /**
     * @throws DBException
     */
    public function __construct(User $user, array $groups)
    {
        $user->dbUpdateGroups($groups);
        parent::__construct(eUISA_User::groups_editing->initController()->setUser($user)->getURL());
    }
}