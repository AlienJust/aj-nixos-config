<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eUserField;
use Horizon\UserInterface\Controls\CheckboxBool;

class UserBanTag extends CheckboxBool
{
    public function __construct(bool $value)
    {
        parent::__construct(eUserField::ban->code(), $value,
            'Заблокировать пользователя',
            'Отметьте, если необходимо полностью ограничить доступ пользователя к контенту');
    }
}