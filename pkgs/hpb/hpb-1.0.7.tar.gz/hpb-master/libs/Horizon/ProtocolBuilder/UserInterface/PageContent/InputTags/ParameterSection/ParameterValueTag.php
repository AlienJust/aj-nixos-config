<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Controls\InputText;

class ParameterValueTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eParameterField::value->code(), $value,
            'Значение', 'Введите значение параметра');
    }
}