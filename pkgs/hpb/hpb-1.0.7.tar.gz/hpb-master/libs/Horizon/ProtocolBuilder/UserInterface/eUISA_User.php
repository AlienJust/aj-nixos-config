<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_User;

enum eUISA_User: string implements iUISectionActionEnum
{
    case view = '';
    case new = 'new';
    case edit = 'edit';
    case delete = 'delete';
    case password_resetting = 'password_resetting';
    case groups_editing = 'groups_editing';

    public function name(): string
    {
        return match ($this) {
            self::new => 'Создание пользователя',
            self::edit => 'Изменение пользователя',
            self::delete => 'Удаление пользователя',
            self::view => 'Пользователи',
            self::password_resetting => 'Сброс пароля',
            self::groups_editing => 'Изменение списка групп доступа',
        };
    }

    public function buttonName(): string
    {
        return match ($this) {
            self::view => 'Пользователи системы',
            self::new => '+ пользователь',
            self::edit => 'Изменить',
            self::delete => 'Удалить',
            self::password_resetting => 'Сбросить пароль',
            self::groups_editing => 'Группы доступа',
        };
    }

    public static function controlPanel(): array
    {
        return [
            self::edit,
            self::password_resetting,
            self::groups_editing,
        ];
    }

    public function initController(array $post = []): UISection_User
    {
        return new UISection_User($this, $post);
    }
}