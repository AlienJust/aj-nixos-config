<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Controls\InputText;

class ParameterNameTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eParameterField::name->code(), htmlspecialchars($value),
            'Наименование параметра', 'Введите наименование параметра', true);
    }
}