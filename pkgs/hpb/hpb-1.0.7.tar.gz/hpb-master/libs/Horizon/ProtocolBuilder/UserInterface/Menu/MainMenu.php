<?php

namespace Horizon\ProtocolBuilder\UserInterface\Menu;

use Exception;
use Horizon\Auth\DataBase\ListSources\ProtocolListSources;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Protocol;
use Horizon\ProtocolBuilder\UserInterface\eUISA_UGroup;
use Horizon\ProtocolBuilder\UserInterface\eUISA_User;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\Menu;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\MenuAction;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\MenuBlock;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\MenuItem;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\MenuLogo;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection;
use Horizon\UserInterface\Tags\Trace;
use const HORIZON_SETTINGS as HS;

class MainMenu extends Menu
{
    private ?eUISA_Protocol $action;
    public function __construct(?int $current_ID = null, ?eUISA_Protocol $action = null)
    {
        parent::__construct('protocols');
        $this->action = $action;
        $this->add(new MenuLogo());
        try {
            $this->addBlock(new MenuBlock(HS['ui']['version'])
                ->addItem(
                    new MenuAction(eUISA_Protocol::manual->initController(), $action),
                    $this->verifyAction(eUISA_User::view->initController()),
                    $this->verifyAction(eUISA_UGroup::view->initController())
                )
            )->addBlock($block = new MenuBlock('Протоколы')
                ->addItem(
                    new MenuAction(eUISA_Protocol::new->initController(), $action),
                    new MenuAction(eUISA_Protocol::import->initController(), $action)
                ));

            $protocols = new ProtocolListSources(1, 3000, null)->loadData();
            $ref_controller = eUISA_Protocol::edit->initController();
            foreach ($protocols as $protocol) $block->addItem(new MenuItem(
                $ref_controller->setProtocol($protocol),
                $protocol->name,
                $protocol->getID() == $current_ID
            ));
        } catch (Exception $e) {
            $this->addBlock(new MenuBlock("Ошибка")->add(new Trace($e)));
        }
    }

    private function verifyAction(UISection $ctrl): ?MenuAction
    {
        try {
            $ctrl->verifyAccess();
        } catch (Exception) {
            return null;
        }
        return new MenuAction($ctrl, $this->action);
    }
}