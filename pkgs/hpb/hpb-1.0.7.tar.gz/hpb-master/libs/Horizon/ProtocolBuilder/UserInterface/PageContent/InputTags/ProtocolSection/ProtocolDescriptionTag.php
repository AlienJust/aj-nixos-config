<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Controls\InputText;

class ProtocolDescriptionTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eProtocolField::description->code(), $value,
            'Описание протокола', 'Введите описание протокола', true);
    }
}