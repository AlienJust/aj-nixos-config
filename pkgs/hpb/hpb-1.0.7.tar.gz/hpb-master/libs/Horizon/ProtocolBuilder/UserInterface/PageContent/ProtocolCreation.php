<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\Auth\DataBase\PickSources\UGroupPick;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolAuthorTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolDescriptionTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolGUIDTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolNameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolVersionTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\CreationButton;

class ProtocolCreation extends _PageContentTag
{
    /**
     * @throws DBException
     */
    public function __construct(string $header, string $action_URL, string $GUID, string $name, string $version, string $description, int $author)
    {
        parent::__construct($header);
        $this->add(new MainForm($action_URL)
            ->add(new ProtocolGUIDTag($GUID))
            ->add(new ProtocolNameTag($name))
            ->add(new ProtocolVersionTag($version))
            ->add(new ProtocolDescriptionTag($description))
            ->add(new ProtocolAuthorTag($author)->addOptions(false, ...new UGroupPick()->init()))
            ->add(new CreationButton()));
    }
}