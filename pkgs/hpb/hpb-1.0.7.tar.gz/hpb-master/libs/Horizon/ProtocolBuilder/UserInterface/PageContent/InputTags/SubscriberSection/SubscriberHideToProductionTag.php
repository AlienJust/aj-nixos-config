<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\SubscriberSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eSubscriberField;
use Horizon\UserInterface\Controls\CheckboxBool;

class SubscriberHideToProductionTag extends CheckboxBool
{
    public function __construct(bool $value)
    {
        parent::__construct(eSubscriberField::hide_for_production->code(), $value,
            'Скрывать в урезанной версии', 'Отметьте, если вкладку с абонентом нужно скрыть в урезанной версии программы');
    }
}