<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\FormPOST;

class MainForm extends FormPOST
{
    public function __construct(string $action_URL)
    {
        parent::__construct($action_URL);
        $this->addAttribute(Attribute::id, 'main');
    }
}