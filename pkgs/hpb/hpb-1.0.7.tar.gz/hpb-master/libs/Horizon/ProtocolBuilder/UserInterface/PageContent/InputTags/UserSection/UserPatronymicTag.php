<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eUserField;
use Horizon\UserInterface\Controls\InputText;

class UserPatronymicTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eUserField::patronymic->code(), $value,
            'Отчество пользователя', 'Введите отчество пользователя');
    }
}