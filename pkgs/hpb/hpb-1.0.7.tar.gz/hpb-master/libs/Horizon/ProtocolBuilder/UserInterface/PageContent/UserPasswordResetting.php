<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection\UserPasswordDefaultTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\PasswordResettingButton;

class UserPasswordResetting extends _PageContentTag
{
    public function __construct(string $header, string $action_URL
    ){
        parent::__construct($header);
        $this->add(new MainForm($action_URL)
            ->add(new UserPasswordDefaultTag())
            ->add(new PasswordResettingButton()));
    }
}