<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Protocol;
use Horizon\UserInterface\Executor;

class ExecProtocolAuthorEditing extends Executor
{
    /**
     * @throws DBException
     */
    public function __construct(Protocol $protocol, int $author)
    {
        $protocol->author = $author;
        $protocol->dbUpdate();
        parent::__construct(eUISA_Protocol::edit->initController()->setProtocol($protocol)->getURL());
    }
}