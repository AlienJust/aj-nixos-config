<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

class SubscriberDeleting extends _Deleting
{
    public function __construct(string $name, string $action_URL)
    {
        parent::__construct('абонента', 'абонента', $name, $action_URL);
    }
}