<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\ViewTags;

use Horizon\ProtocolBuilder\UserInterface\PageContent\_PageContentTag;
use Horizon\UserInterface\Tags\Division;
use Parsedown\CustomParsedownExtra;

class ManualView extends _PageContentTag
{
    public function __construct(string $markdown_filename)
    {
        parent::__construct();

        $pd = new CustomParsedownExtra();
        $markdown = file_get_contents($markdown_filename);
        $html = $pd->text($markdown);
        $this
            //->add($pd->getTOC())
            ->add((new Division($html))->addClass('markdown-content'));
    }


}