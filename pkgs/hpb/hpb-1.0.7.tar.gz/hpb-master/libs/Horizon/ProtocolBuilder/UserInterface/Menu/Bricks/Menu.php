<?php

namespace Horizon\ProtocolBuilder\UserInterface\Menu\Bricks;

use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Tags\Division;

class Menu extends Division
{
    public function __construct(string $id)
    {
        parent::__construct();
        $this->addClass('sidebar');
        $this->addAttribute(Attribute::id, $id);
    }

    public function addBlock(MenuBlock $block): static
    {
        $this->add($block);
        return $this;
    }

    public function setCurrent(bool $is_current): static
    {
        $this->addClassIf('current', $is_current);
        return $this;
    }
}