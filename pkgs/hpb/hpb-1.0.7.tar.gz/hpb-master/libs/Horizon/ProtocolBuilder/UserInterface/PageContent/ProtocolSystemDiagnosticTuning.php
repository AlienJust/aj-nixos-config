<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\DataBase\Models\ParameterViewUsableBySystemDiagnosticChunk;
use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolAggregateGroupItemTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolAggregateGroupListTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolBlockItemTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolParameterViewCheckboxTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolBlockListTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolVirtualParameterItemTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolVirtualParameterListTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\UpdatingButton;
use Horizon\UserInterface\Tags\Division;
use Horizon\UserInterface\Tags\Header;
use Horizon\UserInterface\TagsPack;

class ProtocolSystemDiagnosticTuning extends _PageContentTag
{
    private Division $parameter_views_list;
    private ProtocolBlockListTag $block_list;
    private ProtocolVirtualParameterListTag $virtual_parameter_list;
    private ProtocolAggregateGroupListTag $aggregate_group_list;
    private ProtocolAggregateGroupItemTag $last_aggregate_group_item;

    public function __construct(string $header, string $action_URL)
    {
        parent::__construct($header);
        $this->add((new MainForm($action_URL))
            ->add($this->block_list = new ProtocolBlockListTag())
            ->add($this->virtual_parameter_list = new ProtocolVirtualParameterListTag())
            ->add($this->aggregate_group_list = new ProtocolAggregateGroupListTag())
            ->add($this->parameter_views_list = new Division())
            ->add(new UpdatingButton()));
    }

    /**
     * @param string $command
     * @param ParameterViewUsableBySystemDiagnosticChunk[] $request_parameters
     * @param ParameterViewUsableBySystemDiagnosticChunk[] $reply_parameters
     * @return void
     */
    public function addCommandName(string $command, array $request_parameters, array $reply_parameters): void
    {
        if ($request_parameters || $reply_parameters) {
            $request_tag = (new TagsPack())->add($request_parameters ? new Header(3, 'Запрос') : new TagsPack());
            foreach ($request_parameters as $pv) $request_tag
                ->add(new ProtocolParameterViewCheckboxTag($pv->code, $pv->getLabel(), $pv->is_use));
            $reply_tag = (new TagsPack())->add($reply_parameters ? new Header(3, 'Ответ') : new TagsPack());
            foreach ($reply_parameters as $pv) $reply_tag
                ->add(new ProtocolParameterViewCheckboxTag($pv->code, $pv->getLabel(), $pv->is_use));
            $this->parameter_views_list->add(new Header(2, $command))
                ->add((new Division())->addClass('columns')
                    ->add($request_tag)
                    ->add($reply_tag));
        }
    }

    public function addBlock(?int $id, string $name, int $columns_count, bool $is_inline): void
    {
        $this->block_list
            ->add(new ProtocolBlockItemTag($this->block_list->getItemsAmount(), $id, $name, $columns_count, $is_inline));
    }

    public function addVirtualParameter(string $code): void
    {
        $this->virtual_parameter_list
            ->add(new ProtocolVirtualParameterItemTag($this->virtual_parameter_list->getItemsAmount(), $code, $code));
    }

    public function addAggregateGroup(?int $id, string $label): void
    {
        $this->aggregate_group_list
            ->add($this->last_aggregate_group_item =
                new ProtocolAggregateGroupItemTag($this->aggregate_group_list->getItemsAmount(), $id, $label));
    }

    public function addAggregateParameter(string $code): void
    {
        $this->last_aggregate_group_item->addParameter($code);
    }
}