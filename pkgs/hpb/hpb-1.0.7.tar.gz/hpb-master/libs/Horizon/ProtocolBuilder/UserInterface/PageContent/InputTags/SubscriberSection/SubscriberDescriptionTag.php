<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\SubscriberSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eSubscriberField;
use Horizon\UserInterface\Controls\InputTextarea;

class SubscriberDescriptionTag extends InputTextarea
{
    public function __construct(string $value)
    {
        parent::__construct(eSubscriberField::description->code(), $value,
            'Комментарий', 'Введите дополнительные данные об абоненте', 2000);
    }
}