<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields;

use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\LogicItems\ToIntNullableHandler;
use Horizon\ProtocolBuilder\LogicItems\ToStringNullableHandler;
use Horizon\ProtocolBuilder\LogicItems\ToStringRequiredHandler;

enum eUGroupField implements iTransmissionField
{
    case name;
    case description;
    case owner;

    public function code(...$options): string
    {
        return match ($this) {
            self::name,
            self::description,
            self::owner => $this->name,
        };
    }

    /**
     * @throws VException
     */
    public function get(array $post): string|int|null
    {
        return match ($this) {
            self::name => ToStringRequiredHandler::run($post[$this->code()] ?? '', $this->name),
            self::description => ToStringNullableHandler::run(htmlspecialchars($post[$this->code()] ?? '')) ??'',
            self::owner => ToIntNullableHandler::run($post[$this->code()] ?? null),
        };
    }
}