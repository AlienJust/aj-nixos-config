<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\Auth\PasswordTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\Auth\PathTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\Auth\UsernameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\LoginButton;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Tags\Division;
use Horizon\UserInterface\Tags\Image;

class AuthLoginForm extends MainForm
{

    public function __construct(string $action_URL)
    {
        parent::__construct($action_URL);
        $this
            ->add((new Division())
                ->add((new Division())
                    ->addClass('logo')
                    ->add((new Image('/styles/images/logo_light.png'))->addClass('logo')
                        ->addAttribute(Attribute::alt, 'ООО НПО Горизонт')))
                ->add(new UsernameTag())
                ->add(new PasswordTag()))
            ->add(new LoginButton());
    }

    public function addPath(string $path): void
    {
        $this->add(new PathTag($path));
    }
}