<?php

namespace Horizon\ProtocolBuilder\UserInterface\Menu;

use Exception;
use Horizon\ProtocolBuilder\DataBase\Tables\Command;
use Horizon\ProtocolBuilder\DataBase\Tables\Subscriber;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Command;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\Menu;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\MenuAction;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\MenuBlock;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\MenuItem;
use Horizon\UserInterface\Tags\Trace;

class CommandsMenu extends Menu
{
    public function __construct(Subscriber $subscriber, ?int $current_ID = null, ?eUISA_Command $action = null)
    {
        parent::__construct('commands');
        try {
            $this->addBlock($block = new MenuBlock('Команды')
                ->addItem(new MenuAction(
                    eUISA_Command::new->initController()->setCommand(new Command($subscriber->getID())),
                    $action
                )));

            $commands = $subscriber->arrCommands();
            $ref_controller = eUISA_Command::edit->initController();

            foreach ($commands as &$command) $block
                ->addItem(new MenuItem(
                    $ref_controller->setCommand($command),
                    $command->getName(),
                    $command->getID() == $current_ID
                ));

        } catch (Exception $e) {
            $this->addBlock(new MenuBlock("Ошибка")->add(new Trace($e)));
        }
    }
}