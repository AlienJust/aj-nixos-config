<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eUserField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputText;

class UserUsernameTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eUserField::username->code(), $value,
            'Имя учетной записи пользователя', 'Введите имя учетной записи пользователя', true);
    }
}