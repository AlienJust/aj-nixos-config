<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\UserInterface\eUICallerAJAXAction;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\PresetTags\SortableSummonList;
use Horizon\UserInterface\PresetTags\SummonList;

class ProtocolAggregateParameterListTag extends SortableSummonList
{
    public function __construct(int $COUNTER)
    {
        parent::__construct(
            eUICallerAJAXAction::summon_system_diagnostic_aggregate_parameter->value . "__$COUNTER",
            eProtocolField::summon_system_diagnostic_aggregate_parameter_counter->code($COUNTER),
            'Агрегированные параметры'
        );
        $this->addInfluencingField(eProtocolField::aggregate_group_counter->code($COUNTER));
    }
}