<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_Auth;

enum eUISA_Auth: string implements iUISectionActionEnum
{
    case login = 'login';
    case logout = 'logout';

    public function name(): string
    {
        return match ($this) {
            self::login => 'Вход',
            self::logout => 'Выход',
        };
    }

    public function buttonName(): string
    {
        return match ($this) {
            self::login => 'Вход',
            self::logout => 'Выход',
        };
    }

    public static function controlPanel(): array
    {
        return [];
    }

    public function initController(array $post = []): UISection_Auth
    {
        return new UISection_Auth($this, $post);
    }
}