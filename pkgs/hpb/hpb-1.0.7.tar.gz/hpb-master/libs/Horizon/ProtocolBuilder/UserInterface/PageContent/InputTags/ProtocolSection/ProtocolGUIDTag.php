<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputText;

class ProtocolGUIDTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eProtocolField::GUID->code(), $value,
            'Уникальный идентификатор', 'Уникальный идентификатор генерируется автоматически', true);
        $this->addAttribute(Attribute::readonly, true);
    }
}