<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\Auth;

use Horizon\UserInterface\Controls\InputHiddenValue;

class PathTag extends InputHiddenValue
{
    public function __construct(string $value)
    {
        parent::__construct('path', $value);
    }
}