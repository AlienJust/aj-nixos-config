<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\Auth\DataBase\PickSources\UGroupPick;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UGroupSection\DescriptionTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UGroupSection\NameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UGroupSection\OwnerTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\CreationButton;

class UGroupCreation extends _PageContentTag
{
    /**
     * @throws DBException
     */
    public function __construct(string $header, string $action_URL,
                                string $name, string $description, ?int $owner
    ){
        parent::__construct($header);
        $this->add(new MainForm($action_URL)
            ->add(new NameTag($name))
            ->add(new DescriptionTag($description))
            ->add(new OwnerTag($owner ?? '')->addOptions(true, ...new UGroupPick()->init()))
            ->add(new CreationButton()));
    }
}