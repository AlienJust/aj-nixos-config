<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection\UserBanTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection\UserNameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection\UserPatronymicTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection\UserSurnameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection\UserUsernameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\UpdatingButton;

class UserEditing extends _PageContentTag
{
    public function __construct(string $header, string $action_URL,
                                string $username, string $surname, string $name, string $patronymic, bool $ban
    ){
        parent::__construct($header);
        $this->add(new MainForm($action_URL)->add(
            new UserUsernameTag($username),
            new UserSurnameTag($surname),
            new UserNameTag($name),
            new UserPatronymicTag($patronymic),
            new UserBanTag($ban),
            new UpdatingButton()
        ));
    }
}