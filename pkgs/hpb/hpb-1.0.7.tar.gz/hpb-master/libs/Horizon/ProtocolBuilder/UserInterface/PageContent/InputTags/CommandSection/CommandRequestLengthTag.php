<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCommandField;
use Horizon\UserInterface\Controls\InputNumber;

class CommandRequestLengthTag extends InputNumber
{
    public function __construct(string $value)
    {
        parent::__construct(eCommandField::request_length->code(), $value,
            'Длина запроса (в байтах)', 'Введите длину запроса в байтах', true);
    }
}