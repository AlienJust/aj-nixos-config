<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Controls\InputSelect;

class ProtocolAuthorTag extends InputSelect
{
    public function __construct(string $value)
    {
        parent::__construct(eProtocolField::author->code(), $value,
            'Автор протокола', 'Выберите группу, которой будут принадлежать права на владение протоколом', true);
    }
}