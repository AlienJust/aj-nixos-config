<?php

namespace Horizon\ProtocolBuilder\UserInterface\Menu\Bricks;

use Horizon\UserInterface\Tags\Division;
use Horizon\UserInterface\Tags\Trace;

class MenuBlock extends Division
{
    private Division $title_box;
    public function __construct(string $name)
    {
        parent::__construct();
        $this->title_box = new Division()
            ->addClass('title-box')
            ->add(new Division($name)->addClass('title'));
        $this->add($this->title_box);
    }

    public function addItem(MenuItem|Trace|null ...$items): static
    {
        foreach ($items as $item)
            if ($item === null) continue;
            elseif ($item::class == MenuAction::class) $this->title_box->add($item);
            else $this->add($item);
        return $this;
    }
}