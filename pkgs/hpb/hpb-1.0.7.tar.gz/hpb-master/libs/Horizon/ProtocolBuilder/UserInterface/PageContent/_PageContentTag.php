<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Exception;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Tags\Header;
use Horizon\UserInterface\Tags\HorizontalRule;
use Horizon\UserInterface\Tags\LineBreak;
use Horizon\UserInterface\Tags\Trace;
use Horizon\UserInterface\TagsPack;

abstract class _PageContentTag extends TagsPack
{
    public function __construct(?string $header = null, ?string $id = null)
    {
        parent::__construct();
        $this->add($header === null ? null : $header = new Header(1, $header));
        if (!is_null($id) && $header !== null) $header->addAttribute(Attribute::id, $id);
    }

    /**
     * @param _PageContentTag|null $page
     * @return $this Добавляет к странице иной контент
     */
    public function addActionBlock(?_PageContentTag $page): static
    {
        if ($page === null) return $this;
        try {
            $this->add(new LineBreak())
                ->add(new HorizontalRule())
                ->add($page);
        } catch (Exception $exception) {
            $this->add(new Trace($exception));
        }
        return $this;
    }
}