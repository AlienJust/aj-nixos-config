<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageParts;

use Horizon\ProtocolBuilder\UserInterface\iUISectionActionEnum;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection;
use Horizon\UserInterface\Tags\Anchor;

class ControlPanelItem extends Anchor
{
    public function __construct(UISection $controller, ?iUISectionActionEnum $current_action)
    {
        parent::__construct($controller->getURL(), $controller->refAction()->buttonName());
        $this->addClassIf('current', $controller->refAction() === $current_action);
    }
}