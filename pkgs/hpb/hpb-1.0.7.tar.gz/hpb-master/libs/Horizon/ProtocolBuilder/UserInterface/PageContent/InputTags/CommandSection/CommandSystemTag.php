<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCommandField;
use Horizon\UserInterface\Controls\CheckboxBool;

class CommandSystemTag extends CheckboxBool
{
    public function __construct(bool $value)
    {
        parent::__construct(eCommandField::system->code(), $value,
            'Пометить системной', 'Отметьте, если команду и параметры не нужно отображать пользователю');
    }
}