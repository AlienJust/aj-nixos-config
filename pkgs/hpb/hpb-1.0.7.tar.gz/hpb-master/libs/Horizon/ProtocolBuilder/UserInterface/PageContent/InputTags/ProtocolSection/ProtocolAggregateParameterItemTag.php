<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Controls\InputHiddenValue;
use Horizon\UserInterface\Controls\InputText;
use Horizon\UserInterface\Tags\Division;
use Horizon\UserInterface\TagsPack;

class ProtocolAggregateParameterItemTag extends TagsPack
{
    public function __construct(int $COUNTER_OUTSIDE, int $COUNTER, string $code)
    {
        parent::__construct();
        $this->add((new Division())
            ->add(new InputText(eProtocolField::aggregate_parameter_code->code($COUNTER_OUTSIDE, $COUNTER), $code,
                'Параметр', 'Выберите агрегированный параметр'))
        );
    }
}