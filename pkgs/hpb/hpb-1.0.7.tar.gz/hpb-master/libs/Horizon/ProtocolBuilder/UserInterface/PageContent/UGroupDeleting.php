<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

class UGroupDeleting extends _Deleting
{
    public function __construct(string $name, string $action_URL)
    {
        parent::__construct('группы', 'группу', $name, $action_URL);
    }
}