<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCommandField;
use Horizon\UserInterface\Controls\InputNumber;

class CommandRequestHeaderLengthTag extends InputNumber
{
    public function __construct(string $value)
    {
        parent::__construct(eCommandField::request_header_length->code(), $value,
            'Длина заголовка запроса (в байтах)', 'Введите длину заголовка запроса в байтах', true);
    }
}