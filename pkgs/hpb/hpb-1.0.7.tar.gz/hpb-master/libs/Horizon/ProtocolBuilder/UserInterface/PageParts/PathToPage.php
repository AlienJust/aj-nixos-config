<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageParts;

use Horizon\UserInterface\Tags\Anchor;
use Horizon\UserInterface\Tags\Division;

class PathToPage extends Division
{
    private bool $empty = true;

    /**
     * Формирует обратный путь страницы, который отображается в подзаголовке
     */
    public function __construct()
    {
        parent::__construct();
        $this->addClass('path');
    }

    public function addStep(string $name, ?string $href = null): static
    {
        if ($this->empty) $this->empty = false;
        else $this->add("&nbsp;&nbsp; › &nbsp;&nbsp;");
        if (is_null($href)) $this->add($name);
        else $this->add(new Anchor($href, $name));
        return $this;
    }
}