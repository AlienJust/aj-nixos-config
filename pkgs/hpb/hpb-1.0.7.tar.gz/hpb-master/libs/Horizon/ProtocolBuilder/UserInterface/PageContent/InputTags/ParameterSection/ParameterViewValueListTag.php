<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\eUICallerAJAXAction;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\PresetTags\SortableSummonList;

class ParameterViewValueListTag extends SortableSummonList
{
    public function __construct()
    {
        parent::__construct(
            eUICallerAJAXAction::summon_parameter_view_value->value,
            eParameterField::summon_view_values_counter->code(),
            'Интерпретация значения по условию'
        );
    }
}