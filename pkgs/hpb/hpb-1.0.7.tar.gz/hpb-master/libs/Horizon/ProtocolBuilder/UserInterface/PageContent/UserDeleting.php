<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

class UserDeleting extends _Deleting
{
    public function __construct(string $name, string $action_URL)
    {
        parent::__construct('пользователя', 'пользователя', $name, $action_URL);
    }
}