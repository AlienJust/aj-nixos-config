<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\Auth\DataBase\Tables\User;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_User;
use Horizon\UserInterface\Executor;

class ExecUserDeleting extends Executor
{
    /**
     * @throws DBException
     */
    public function __construct(User $user)
    {
        $user->dbDelete();
        parent::__construct(eUISA_User::view->initController()->getURL());
    }
}