<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields;

use Horizon\ProtocolBuilder\LogicItems\ToStringNullableHandler;

enum eCallerAJAXFields implements iTransmissionField
{
    case action;
    case destination;
    case properties;

    public function code(mixed ...$options) : string
    {
        return $this->name;
    }

    public function get(array $post): null|string|array
    {
        return match ($this) {
            self::action,
            self::destination => ToStringNullableHandler::run(htmlspecialchars($post[$this->code()] ?? '')),
            self::properties => $post[$this->code()] ?? []
        };
    }
}