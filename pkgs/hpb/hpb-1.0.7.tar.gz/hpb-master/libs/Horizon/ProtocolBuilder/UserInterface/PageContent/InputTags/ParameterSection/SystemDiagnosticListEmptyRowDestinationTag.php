<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\eUICallerAJAXAction;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Tags\Division;

class SystemDiagnosticListEmptyRowDestinationTag extends Division
{
    public function __construct()
    {
        parent::__construct();
        $this->addAttribute(Attribute::id, eUICallerAJAXAction::summon_system_diagnostic_empty_row->value);
    }
}