<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UGroupSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eUGroupField;
use Horizon\UserInterface\Controls\InputSelect;

class OwnerTag extends InputSelect
{
    public function __construct(string $value)
    {
        parent::__construct(eUGroupField::owner->code(), $value,
            'Вышестоящая группа', 'Выберите вышестоящую группу', false);
    }
}