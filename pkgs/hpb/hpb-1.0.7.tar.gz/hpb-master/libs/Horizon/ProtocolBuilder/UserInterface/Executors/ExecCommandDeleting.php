<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\Command;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Subscriber;
use Horizon\UserInterface\Executor;

class ExecCommandDeleting extends Executor
{
    /**
     * @throws DBException
     */
    public function __construct(Command $command)
    {
        $command->dbDelete();
        parent::__construct(eUISA_Subscriber::edit->initController()->setSubscriber($command->refSubscriber())->getURL());
    }
}