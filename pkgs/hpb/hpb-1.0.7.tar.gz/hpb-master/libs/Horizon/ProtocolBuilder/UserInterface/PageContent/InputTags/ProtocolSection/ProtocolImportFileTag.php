<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputFile;

class ProtocolImportFileTag extends InputFile
{
    public function __construct()
    {
        parent::__construct(eProtocolField::psn_file->code(), 'Файл с протоколом',
            'Выберите файл, из которого нужно импортировать протокол', true);
        $this->addAttribute(Attribute::accept, '.xml');
    }
}