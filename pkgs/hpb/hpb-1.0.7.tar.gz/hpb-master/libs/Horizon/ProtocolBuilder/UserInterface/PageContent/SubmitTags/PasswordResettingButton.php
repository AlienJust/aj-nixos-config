<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags;

use Horizon\UserInterface\Controls\ButtonSubmit;

class PasswordResettingButton extends ButtonSubmit
{
    public function __construct()
    {
        parent::__construct('execute', 'Сбросить пароль');
    }
}