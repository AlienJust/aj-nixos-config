<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\Auth;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eAuthField;
use Horizon\UserInterface\Controls\InputText;

class UsernameTag extends InputText
{
    public function __construct()
    {
        parent::__construct(eAuthField::username->code(), '',
            'Имя пользователя', 'Введите имя пользователя', true);
    }
}