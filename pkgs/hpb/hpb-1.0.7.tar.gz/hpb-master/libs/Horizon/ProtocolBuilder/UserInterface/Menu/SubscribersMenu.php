<?php

namespace Horizon\ProtocolBuilder\UserInterface\Menu;

use Exception;
use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\DataBase\Tables\Subscriber;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Subscriber;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\Menu;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\MenuAction;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\MenuBlock;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\MenuItem;
use Horizon\UserInterface\Tags\Trace;

class SubscribersMenu extends Menu
{
    public function __construct(Protocol $protocol, ?int $current_ID = null, ?eUISA_Subscriber $action = null)
    {
        parent::__construct('subscribers');
        try {
            $this->addBlock($block = new MenuBlock('Абоненты')
                ->addItem(new MenuAction(
                    eUISA_Subscriber::new->initController()->setSubscriber(new Subscriber($protocol->getID())),
                    $action
                )));

            $subscribers = $protocol->arrSubscribers();
            $ref_controller = eUISA_Subscriber::edit->initController();

            foreach ($subscribers as $subscriber) $block
                ->addItem(new MenuItem(
                    $ref_controller->setSubscriber($subscriber),
                    $subscriber->getName(),
                    $subscriber->getID() == $current_ID
                ));

        } catch (Exception $e) {
            $this->addBlock(new MenuBlock("Ошибка")->add(new Trace($e)));
        }
    }
}