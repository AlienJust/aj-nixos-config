<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eUserField;
use Horizon\UserInterface\Controls\InputText;

class UserNameTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eUserField::name->code(), $value,
            'Имя пользователя', 'Введите имя пользователя', true);
    }
}