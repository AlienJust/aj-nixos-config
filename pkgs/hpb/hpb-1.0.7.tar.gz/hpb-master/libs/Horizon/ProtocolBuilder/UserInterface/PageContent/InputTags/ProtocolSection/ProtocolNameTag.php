<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Controls\InputText;

class ProtocolNameTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eProtocolField::name->code(), $value,
            'Наименование протокола', 'Введите наименование протокола', true);
    }
}