<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags;

use Horizon\UserInterface\Controls\ButtonSubmit;

class UpdatingButton extends ButtonSubmit
{
    public function __construct()
    {
        parent::__construct('execute', 'Сохранить');
    }
}