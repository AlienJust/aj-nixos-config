<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Protocol;
use Horizon\UserInterface\Executor;

class ExecProtocolGroupsEditing extends Executor
{
    /**
     * @throws DBException
     */
    public function __construct(Protocol $protocol, array $groups)
    {
        $protocol->dbUpdateGroups($groups);
        parent::__construct(eUISA_Protocol::groups_editing->initController()->setProtocol($protocol)->getURL());
    }
}