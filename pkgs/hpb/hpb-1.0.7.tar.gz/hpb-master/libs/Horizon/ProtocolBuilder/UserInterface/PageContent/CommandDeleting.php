<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

class CommandDeleting extends _Deleting
{
    public function __construct(string $name, string $action_URL)
    {
        parent::__construct('команды','команду', $name, $action_URL);
    }
}