<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\SubscriberSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eSubscriberField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputNumber;

class SubscriberAddressTag extends InputNumber
{
    public function __construct(string $value)
    {
        parent::__construct(eSubscriberField::address->code(), $value,
            'Адрес абонента', 'Введите адрес абонента', true);
        $this->addAttribute(Attribute::min, '0')
            ->addAttribute(Attribute::max, '65535')
            ->addAttribute(Attribute::step, '1');
    }
}