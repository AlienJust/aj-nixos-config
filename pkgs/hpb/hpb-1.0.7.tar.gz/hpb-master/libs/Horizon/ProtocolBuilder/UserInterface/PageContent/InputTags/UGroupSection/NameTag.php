<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UGroupSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eUGroupField;
use Horizon\UserInterface\Controls\InputText;

class NameTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eUGroupField::name->code(), $value,
            'Наименование группы', 'Введите наименование группы пользователей', true);
    }
}