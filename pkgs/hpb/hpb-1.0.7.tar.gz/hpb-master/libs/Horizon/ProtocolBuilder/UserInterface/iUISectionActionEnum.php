<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection;

interface iUISectionActionEnum
{
    public function name(): string;
    public function buttonName(): string;
    public static function controlPanel(): array;
    public function initController(array $post = []): UISection;
}
