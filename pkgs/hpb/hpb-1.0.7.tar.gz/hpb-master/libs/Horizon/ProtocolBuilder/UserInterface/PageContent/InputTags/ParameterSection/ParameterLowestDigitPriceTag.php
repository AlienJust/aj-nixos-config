<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputNumber;

class ParameterLowestDigitPriceTag extends InputNumber
{
    public function __construct(float $value)
    {
        parent::__construct(eParameterField::lowest_digit_price->code(), $value,
            'Цена младшего разряда', 'Введите значение цены младшего разряда', true);
        $this->addAttribute(Attribute::step, '0.0000000000001');
    }
}