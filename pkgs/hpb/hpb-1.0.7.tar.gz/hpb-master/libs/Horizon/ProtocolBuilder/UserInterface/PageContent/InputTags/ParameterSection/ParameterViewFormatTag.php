<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputText;

class ParameterViewFormatTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eParameterField::view_format->code(), $value,
            'Формат значения', 'Введите формат отображения данных, например, f0');
        $this->addAttribute(Attribute::maxlength, '16');
    }
}