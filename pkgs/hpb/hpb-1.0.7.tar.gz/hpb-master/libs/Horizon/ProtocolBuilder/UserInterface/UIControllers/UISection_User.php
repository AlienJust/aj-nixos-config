<?php

namespace Horizon\ProtocolBuilder\UserInterface\UIControllers;

use Horizon\Auth\AccessDeniedEx;
use Horizon\Auth\AccessDeniedException;
use Horizon\Auth\DataBase\ListSources\UGroupListSource;
use Horizon\Auth\DataBase\ListSources\UsersListSource;
use Horizon\Auth\DataBase\Tables\User;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\Exceptions\ActionAccessException;
use Horizon\ProtocolBuilder\Exceptions\DataAccessException;
use Horizon\ProtocolBuilder\Exceptions\UIEx;
use Horizon\ProtocolBuilder\Exceptions\UIException;
use Horizon\ProtocolBuilder\LogicItems\URL;
use Horizon\ProtocolBuilder\UserInterface\eUISA_User;
use Horizon\ProtocolBuilder\UserInterface\eUISection;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecUserGroupsEditing;
use Horizon\ProtocolBuilder\UserInterface\PageContent\_PageContentTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eUserField;
use Horizon\ProtocolBuilder\UserInterface\PageContent\UserCreation;
use Horizon\ProtocolBuilder\UserInterface\PageContent\UserDeleting;
use Horizon\ProtocolBuilder\UserInterface\PageContent\UserEditing;
use Horizon\ProtocolBuilder\UserInterface\PageContent\UserGroupsEditing;
use Horizon\ProtocolBuilder\UserInterface\PageContent\UserList;
use Horizon\ProtocolBuilder\UserInterface\PageContent\UserPasswordResetting;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecUserCreation;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecUserDeleting;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecUserEditing;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecUserPasswordResetting;
use Horizon\UserInterface\Executor;

class UISection_User extends UISection
{
    protected static eUISection $section = eUISection::user;
    private ?eUISA_User $action;
    private User $user;
    public function __construct(eUISA_User $action, array $post = [])
    {
        parent::__construct($post);
        $this->action = $action;
    }

    public function setUser(User $user): static
    {
        $this->user = $user;
        return $this;
    }

    /**
     * @throws DBException
     */
    public function refUser(): User
    {
        return $this->user ?? ($this->user = User::dbLoad($this->getID()));
    }

    public function refAction(): ?eUISA_User
    {
        return $this->action;
    }

    /**
     * @throws DBException
     * @throws DataAccessException
     * @throws ActionAccessException
     * @throws AccessDeniedException
     */
    public function verifyAccess(): void
    {
        if (User::current() === null) throw new AccessDeniedException(AccessDeniedEx::fail);
        if (!User::current()->isAdmin()) throw new ActionAccessException();
        match ($this->action) {
            eUISA_User::new,
            eUISA_User::view => null,
            default => $this->refUser()->verifyAccess()
        };
    }

    /**
     * @throws DBException
     * @throws UIException
     */
    public function tag(): _PageContentTag
    {
        return match ($this->action) {
            eUISA_User::view => $this->listTag(),
            eUISA_User::new => new UserCreation($this->refAction()->name(), $this->getURL(),
                '',
                '',
                '',
                '',
                false,
            ),
            eUISA_User::edit => new UserEditing($this->refAction()->name(), $this->getURL(),
                $this->refUser()->username,
                $this->refUser()->surname,
                $this->refUser()->name,
                $this->refUser()->patronymic,
                $this->refUser()->ban,
            )->addActionBlock(new UserDeleting($this->refUser()->getSNP(),
                eUISA_User::delete->initController()->setUser($this->refUser())->getURL())),
            eUISA_User::password_resetting => new UserPasswordResetting($this->refAction()->name(), $this->getURL()),
            eUISA_User::groups_editing => $this->groupsEditingTag(),
            //eUISA_User::delete => throw new \Exception('To be implemented'),
            default => throw new UIException(UIEx::actionNotImplemented)
        };
    }

    public function initExecutor(): Executor
    {
        return match ($this->action) {
            eUISA_User::new => new ExecUserCreation($this->refUser(),
                eUserField::username->get($this->post),
                eUserField::default_password->get($this->post),
                eUserField::surname->get($this->post),
                eUserField::name->get($this->post),
                eUserField::patronymic->get($this->post),
                eUserField::ban->get($this->post)
            ),
            eUISA_User::edit => new ExecUserEditing($this->refUser(),
                eUserField::username->get($this->post),
                eUserField::surname->get($this->post),
                eUserField::name->get($this->post),
                eUserField::patronymic->get($this->post),
                eUserField::ban->get($this->post)
            ),
            eUISA_User::delete => new ExecUserDeleting($this->refUser()),
            eUISA_User::password_resetting => new ExecUserPasswordResetting($this->refUser(),
                eUserField::default_password->get($this->post)
            ),
            eUISA_User::groups_editing => new ExecUserGroupsEditing($this->refUser(),
                eUserField::groups->get($this->post)
            ),
            default => throw new UIException(UIEx::executeNotImplemented, $this->action->name())
        };
    }

    public function getCurrentID(): ?string
    {
        return $this->user->getID();
    }

    public function refURL(): URL
    {
        try {
            $ID = $this->refUser()->exists() ? $this->refUser()->getID() : null;
        } catch (DBException) {
            $ID = null;
        }
        return new URL()
            ->setSectionAction(static::$section->value, $this->action?->value)
            ->setAnyID($ID);
    }

    /**
     * @throws DBException
     */
    private function listTag(): UserList
    {
        $edit_controller = eUISA_User::edit->initController();
        $tag = new UserList($this->refAction()->name());
        $viewer = new UsersListSource(1, 3000, null);
        $users = $viewer->loadData();
        foreach ($users as $user) {
            $tag->addItem($user->getSNP(), $user->username, $user->drawGroups(), $user->ban, $edit_controller->setUser($user)->getURL());
        }
        return $tag;
    }

    /**
     * @throws DBException
     */
    private function groupsEditingTag(): UserGroupsEditing
    {
        $tag = new UserGroupsEditing($this->refAction()->name(), $this->getURL(), $this->refUser()->getSNP());
        $groups = new UGroupListSource(1, 3000, null)->loadData();
        $user_groups = $this->refUser()->arrGroups();
        foreach ($groups as $group) $tag
            ->addGroup($group->getID(), $group->name, in_array($group->getID(), $user_groups), $group->getLevel());
        return $tag;
    }
}