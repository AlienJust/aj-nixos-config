<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandSourceTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\CreationButton;

class CommandCopying extends _PageContentTag
{
    public function __construct(string $id, string $header, string $action_URL)
    {
        parent::__construct($header, $id);
        $this->add((new MainForm($action_URL))
            ->add(new CommandSourceTag())
            ->add(new CreationButton()));
    }
}