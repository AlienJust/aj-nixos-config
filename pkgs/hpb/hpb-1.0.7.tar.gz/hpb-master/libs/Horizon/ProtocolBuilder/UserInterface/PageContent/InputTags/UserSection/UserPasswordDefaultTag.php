<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eUserField;
use Horizon\UserInterface\Controls\InputText;

class UserPasswordDefaultTag extends InputText
{
    public function __construct()
    {
        parent::__construct(eUserField::default_password->code(), $this->initPassword(),
            'Пароль пользователя для первого входа', 'Введите первоначальный пароль. Не забудьте скопировать и передать его пользователю', true);
    }

    private function initPassword(): string
    {
        return substr(md5(time()), 5, 10);
    }
}