<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\Auth\AccessDeniedException;
use Horizon\Auth\AuthService;
use Horizon\UserInterface\Executor;

class ExecAuthLogin extends Executor
{
    /**
     * @throws AccessDeniedException
     */
    public function __construct(string $username, string $password, string $URL)
    {
        AuthService::login($username, $password);
        parent::__construct($URL);
    }
}