<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToReply;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToRequest;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Command;
use Horizon\UserInterface\Executor;

class ExecParameterDeleting extends Executor
{
    /**
     * @throws DBException
     */
    public function __construct(ParameterToRequest|ParameterToReply $parameter)
    {
        $parameter->dbDelete();
        parent::__construct(eUISA_Command::edit->initController()->setCommand($parameter->refCommand())->getURL());
    }
}