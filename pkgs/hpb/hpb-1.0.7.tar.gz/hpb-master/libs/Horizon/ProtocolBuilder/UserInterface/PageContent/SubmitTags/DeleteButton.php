<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags;

use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\ButtonSubmit;

class DeleteButton extends ButtonSubmit
{
    public function __construct()
    {
        parent::__construct('execute', 'Удалить');
        $this->addAttribute(Attribute::onclick,
            'return confirm(\'Точно-точно удалить? Это необратимая операция.\');');
    }
}