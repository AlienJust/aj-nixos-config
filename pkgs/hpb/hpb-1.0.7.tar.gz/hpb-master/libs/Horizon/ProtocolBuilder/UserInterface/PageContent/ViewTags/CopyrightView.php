<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\ViewTags;

use DateTime;
use Horizon\UserInterface\Tags\Paragraph;

class CopyrightView extends Paragraph
{
    public function __construct()
    {
        parent::__construct('© ООО «НПО Горизонт»,<br>' . $this->getYears());
        $this->addClass('footer');
    }

    private function getYears(): string
    {
        $start_year = '2023';
        $current_year = new DateTime()->format('Y');
        return $start_year == $current_year ? $start_year : "$start_year – $current_year";
    }
}