<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection\UserBanTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection\UserNameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection\UserPasswordDefaultTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection\UserPatronymicTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection\UserSurnameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection\UserUsernameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\CreationButton;

class UserCreation extends _PageContentTag
{
    public function __construct(string $header, string $action_URL,
                                string $username, string $surname, string $name, string $patronymic, bool $ban
    ){
        parent::__construct($header);
        $this->add(new MainForm($action_URL)
            ->add(new UserUsernameTag($username))
            ->add(new UserPasswordDefaultTag())
            ->add(new UserSurnameTag($surname))
            ->add(new UserNameTag($name))
            ->add(new UserPatronymicTag($patronymic))
            ->add(new UserBanTag($ban))
            ->add(new CreationButton()));
    }
}