<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields;

enum eCommandField implements iTransmissionField
{
    case name;
    case request_length;
    case request_start;
    case reply_length;
    case reply_start;
    case parameters;
    case request_header_length;
    case reply_header_length;
    case init_way;
    case system;
    case reply_request_required;
    case request_cycle_ms_time;
    case source;

    public function code(mixed ...$options): string
    {
        return match ($this) {
            self::request_length => 'request[length]',
            self::request_start => 'request[start]',
            self::request_header_length => 'request[header_length]',
            self::request_cycle_ms_time => 'request[cycle_ms_time]',
            self::reply_request_required => 'reply[request_required]',
            self::reply_length => 'reply[length]',
            self::reply_start => 'reply[start]',
            self::reply_header_length => 'reply[header_length]',
            self::name,
            self::parameters,
            self::init_way,
            self::source,
            self::system => $this->name,
        };
    }
    
    public function get(array $post): null|string|float|array
    {
        return match ($this) {
            self::name => $post[$this->code()] ?? null,
            self::request_length => $post['request']['length'] ?? null,
            self::request_start => $post['request']['start'] ?? null,
            self::request_header_length => $post['request']['header_length'] ?? null,
            self::request_cycle_ms_time => ($post['request']['cycle_ms_time'] ?? null) == '' ? null : $post['request']['cycle_ms_time'],
            self::reply_request_required => $post['reply']['request_required'] ?? false,
            self::reply_length => $post['reply']['length'] ?? null,
            self::reply_start => $post['reply']['start'] ?? null,
            self::reply_header_length => $post['reply']['header_length'] ?? null,
            self::parameters => array_keys($post[$this->code()] ?? []),
            self::init_way => $post[$this->code()] ?? '',
            self::system => $post['system'] ?? false,
            self::source => $post['source'] ?? null,
        };
    }
}
