<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Controls\InputHiddenValue;
use Horizon\UserInterface\Controls\InputText;
use Horizon\UserInterface\Tags\Division;
use Horizon\UserInterface\TagsPack;

class ProtocolAggregateGroupItemTag extends TagsPack
{
    protected ProtocolAggregateParameterListTag $parameters;
    private int $COUNTER;
    public function __construct(int $COUNTER, ?int $id, string $label)
    {
        parent::__construct();
        $this->add((new Division())
            ->add(is_null($id) ? null : new InputHiddenValue(eProtocolField::aggregate_group_id->code($COUNTER), $id))
            ->add(new InputHiddenValue(eProtocolField::aggregate_group_counter->code($COUNTER), $COUNTER))
            ->add(new InputText(eProtocolField::aggregate_group_label->code($COUNTER), $label,
                'Заголовок группы', 'Введите заголовок группы агрегированных параметров'))
            ->add($this->parameters = new ProtocolAggregateParameterListTag($COUNTER))
        );
        $this->COUNTER = $COUNTER;
    }

    public function addParameter(string $code): static
    {
        $this->parameters
            ->add(new ProtocolAggregateParameterItemTag($this->COUNTER, $this->parameters->getItemsAmount(), $code));
        return $this;
    }
}