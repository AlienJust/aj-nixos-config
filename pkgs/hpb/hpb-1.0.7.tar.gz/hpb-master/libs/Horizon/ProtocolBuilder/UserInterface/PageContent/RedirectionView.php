<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\UserInterface\Tags\Anchor;

class RedirectionView extends _PageContentTag
{
    public function __construct(string $URL)
    {
        parent::__construct('Перенаправление на другую страницу');
        $this->add('Если автоматическая переадресация не сработала, перейдите по ссылке: ')
            ->add(new Anchor($URL, $URL));
    }
}