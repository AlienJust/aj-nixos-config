<?php

namespace Horizon\ProtocolBuilder\UserInterface\Menu\Bricks;

use Horizon\ProtocolBuilder\UserInterface\iUISectionActionEnum;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection;

class MenuAction extends MenuItem
{
    public function __construct(UISection $controller, ?iUISectionActionEnum $current_action)
    {
        parent::__construct($controller,
            $controller->refAction()->buttonName(), $controller->refAction() === $current_action);
        $this->addClass('action');
    }
}