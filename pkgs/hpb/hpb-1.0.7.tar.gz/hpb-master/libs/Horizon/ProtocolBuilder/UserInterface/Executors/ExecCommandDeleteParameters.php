<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\Command;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Command;
use Horizon\UserInterface\Executor;

class ExecCommandDeleteParameters extends Executor
{
    /**
     * @throws DBException
     */
    public function __construct(Command $command, array $parameters)
    {
        $command->dbDeleteParameters($parameters);
        parent::__construct(eUISA_Command::delete_parameters->initController()->setCommand($command)->getURL());
    }
}