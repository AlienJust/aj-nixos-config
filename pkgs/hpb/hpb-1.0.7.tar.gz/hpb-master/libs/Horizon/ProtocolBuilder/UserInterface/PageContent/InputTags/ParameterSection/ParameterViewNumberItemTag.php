<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\Data\eParameterColor;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\Components\Option;
use Horizon\UserInterface\Controls\InputSelect;
use Horizon\UserInterface\Controls\InputText;
use Horizon\UserInterface\HTMLException;
use Horizon\UserInterface\PresetTags\Division2Columns;
use Horizon\UserInterface\TagsPack;

class ParameterViewNumberItemTag extends TagsPack
{
    /**
     * @throws HTMLException
     */
    public function __construct(int $COUNTER, string $expression, string $format, ?string $color)
    {
        parent::__construct();
        $this
            ->add((new Division2Columns())
                ->add((new InputText(eParameterField::view_number_expression->code($COUNTER), $expression,
                    'Формула для вычисления значения', 'Введите формулу для вычисления значения, например, [value] * 100 / 255', true))
                    ->addAttribute(Attribute::maxlength, '255'))
                ->add(new InputText(eParameterField::view_number_format->code($COUNTER), $format,
                    'Формат значения', 'Введите формат значения', true))
                /*->add((new InputSelect(eParameterField::view_number_color->code($COUNTER), $color ?? '',
                    'Цвет', 'Введите значение цвета, если нужно значение выделить'))
                    ->addOptions(true, ...(array_map(fn(eParameterColor $case): Option => new Option($case->value, $case->label()), eParameterColor::cases()))))*/
            );
    }
}