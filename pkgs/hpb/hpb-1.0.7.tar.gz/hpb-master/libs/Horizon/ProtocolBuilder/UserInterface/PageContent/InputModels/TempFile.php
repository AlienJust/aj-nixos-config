<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputModels;

use Horizon\ProtocolBuilder\Exceptions\UploadEx;
use Horizon\ProtocolBuilder\Exceptions\UploadException;

class TempFile
{
    public readonly string $name;
    public readonly string $type;
    public readonly string $path;
    public readonly int $size;

    /**
     * @param string $name
     * @param string $type
     * @param string $path
     * @param int $size
     * @param int $error
     * @throws UploadException
     */
    public function __construct(string $name, string $type, string $path, int $size, int $error)
    {
        $this->name = $name;
        $this->type = $type;
        $this->path = $path;
        $this->size = $size;
        $uploadError = UploadEx::tryFrom($error);
        if (!is_null($uploadError)) throw new UploadException($uploadError);
    }

    /**
     * @throws UploadException
     */
    public static function fromFILES(array $files): static
    {
        return new static($files['name'], $files['type'], $files['tmp_name'], $files['size'], $files['error']);
    }
}