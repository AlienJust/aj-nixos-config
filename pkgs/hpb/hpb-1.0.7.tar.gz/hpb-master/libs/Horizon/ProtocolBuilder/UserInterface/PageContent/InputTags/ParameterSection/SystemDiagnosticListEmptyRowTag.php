<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Controls\InputHiddenValue;
use Horizon\UserInterface\Tags\ListItem;

class SystemDiagnosticListEmptyRowTag extends ListItem
{
    public function __construct()
    {
        parent::__construct();
        $this->add(new InputHiddenValue(eProtocolField::diagnostic_list->code(), "row=empty"));
        $this->add('Пустая строка');
    }
}