<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields;

use Horizon\ProtocolBuilder\LogicItems\ToStringNullableHandler;

enum eParameterField implements iTransmissionField
{
    case GUID;
    case name;
    case type;
    case byte_order;
    case value_conversion_formula;
    case lowest_digit_price;
    case signed;
    case bits;
    case value;
    case value_inverted;

    case description;
    case view_code;
    case view_new_code;
    case view_comment;
    case view_custom_name;
    case view_format;
    case view_mask;
    case summon_view_values_counter;
    case summon_view_numbers_counter;
    case summon_view_injection_values_counter;
    case view_values;
    case view_numbers;
    //case view_value_code;
    case view_value_expression;
    case view_value_result_true;
    case view_value_result_false;
    case view_value_color;
    case view_number_expression;
    case view_number_format;
    case view_number_color;
    case injection_on;
    case injection;
    case injection_number;
    case injection_expression;
    case injection_order;
    case injection_min_value;
    case injection_max_value;
    case injection_interval_value;
    case injection_values;
    case injection_value_text;
    case injection_value_value;



    public function code(mixed ...$options): string
    {
        return match ($this) {
            self::GUID,
            self::name,
            self::type,
            self::byte_order,
            self::value_conversion_formula,
            self::lowest_digit_price,
            self::signed,
            self::bits,
            self::value,
            self::value_inverted ,
            self::description,
            self::view_values,
            self::view_numbers,
            self::summon_view_values_counter,
            self::summon_view_numbers_counter,
            self::summon_view_injection_values_counter,
            self::injection => $this->name,
            self::view_code,
            self::view_new_code,
            self::view_comment,
            self::view_custom_name,
            self::view_format,
            self::view_mask => 'view[' . str_replace('view_', '', $this->name) . ']',
            //self::view_value_code,
            self::view_value_expression,
            self::view_value_result_true,
            self::view_value_result_false,
            self::view_value_color => self::view_values->name . "[$options[0]][" . str_replace('view_value_', '', $this->name) . "]",
            self::view_number_expression,
            self::view_number_format,
            self::view_number_color => self::view_numbers->name . "[$options[0]][" . str_replace('view_number_', '', $this->name) . "]",
            self::injection_on,
            self::injection_number,
            self::injection_expression,
            self::injection_order,
            self::injection_min_value,
            self::injection_max_value,
            self::injection_interval_value,
            self::injection_values => 'injection[' . str_replace('injection_', '', $this->name) . ']',
            self::injection_value_text,
            self::injection_value_value => self::injection_values->code() . "[$options[0]][" . str_replace('injection_value_', '', $this->name) . "]",
        };
    }

    public function get(array $post): null|string|array|bool
    {
        return match ($this) {
            self::GUID,
            self::name,
            self::type,
            self::byte_order,
            self::lowest_digit_price,
            self::value,
            self::description => $post[$this->code()] ?? null,
            self::value_conversion_formula => $this->prepareConversionFormula($post[$this->code()] ?? null),
            self::bits => array_keys($post[$this->code()] ?? []),
            self::value_inverted,
            self::signed => ($post[$this->code()] ?? '0') == '1',
            self::view_code,
            self::view_new_code,
            self::view_comment => $post['view'][str_replace('view_', '', $this->name)] ?? '',
            self::view_custom_name,
            self::view_format,
            self::view_mask => ToStringNullableHandler::run($post['view'][str_replace('view_', '', $this->name)] ?? null),
            self::summon_view_values_counter,
            self::summon_view_numbers_counter,
            self::summon_view_injection_values_counter => $post[$this->code()] ?? 0,
            self::view_values,
            self::view_numbers,
            self::injection => $post[$this->code()] ?? [],
            //self::view_value_code,
            self::view_value_expression,
            self::view_value_result_true,
            self::view_value_result_false => $post[str_replace('view_value_', '', $this->name)] ?? '',
            self::view_number_expression,
            self::view_number_format => $post[str_replace('view_number_', '', $this->name)] ?? '',
            self::view_value_color => ToStringNullableHandler::run($post[str_replace('view_value_', '', $this->name)] ?? null),
            self::view_number_color => ToStringNullableHandler::run($post[str_replace('view_number_', '', $this->name)] ?? null),
            self::injection_on,
            self::injection_order => self::injection->get($post)[str_replace('injection_', '', $this->name)] ?? 0 == 1,
            self::injection_number => self::injection->get($post)[str_replace('injection_', '', $this->name)] ?? 0,
            self::injection_max_value,
            self::injection_min_value,
            self::injection_interval_value => ToStringNullableHandler::run(self::injection->get($post)[str_replace('injection_', '', $this->name)] ?? null),
            self::injection_expression => trim(self::injection->get($post)[str_replace('injection_', '', $this->name)] ?? ''),
            self::injection_values => self::injection->get($post)[str_replace('injection_', '', $this->name)] ?? [],
            self::injection_value_text => trim($post[str_replace('injection_value_', '', $this->name)] ?? ''),
            self::injection_value_value => $post[str_replace('injection_value_', '', $this->name)] ?? 0,
        };
    }

    private function prepareConversionFormula(?string $value): ?string
    {
        $value = ToStringNullableHandler::run($value);
        if ($value == 'x') $value = null;
        return $value;
    }
}
