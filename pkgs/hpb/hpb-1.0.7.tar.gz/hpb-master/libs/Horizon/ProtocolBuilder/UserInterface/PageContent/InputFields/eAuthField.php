<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields;

enum eAuthField implements iTransmissionField
{
    case username;
    case password;

    public function code(...$options): string
    {
        return $this->name;
    }

    public function get(array $post): string|null
    {
        return $post[$this->code()] ?? null;
    }
}