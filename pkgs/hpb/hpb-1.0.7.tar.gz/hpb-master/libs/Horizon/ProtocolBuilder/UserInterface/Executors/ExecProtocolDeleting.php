<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Protocol;
use Horizon\UserInterface\Executor;

class ExecProtocolDeleting extends Executor
{
    /**
     * @throws DBException
     */
    public function __construct(Protocol $protocol)
    {
        $protocol->dbDelete();
        parent::__construct(eUISA_Protocol::new->initController()->getURL());
    }
}