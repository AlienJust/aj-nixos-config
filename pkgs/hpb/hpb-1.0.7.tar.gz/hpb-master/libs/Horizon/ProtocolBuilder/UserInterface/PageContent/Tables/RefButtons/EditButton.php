<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\Tables\RefButtons;

use Horizon\UserInterface\Tags\Anchor;

class EditButton extends Anchor
{
    public function __construct(string $href)
    {
        parent::__construct($href, "✏️");
        $this->addClass("ref-button");
    }
}