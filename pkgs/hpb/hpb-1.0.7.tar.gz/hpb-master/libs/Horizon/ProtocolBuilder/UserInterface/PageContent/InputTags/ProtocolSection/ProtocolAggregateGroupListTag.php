<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\UserInterface\eUICallerAJAXAction;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\PresetTags\SummonList;

class ProtocolAggregateGroupListTag extends SummonList
{
    public function __construct()
    {
        parent::__construct(
            eUICallerAJAXAction::summon_system_diagnostic_aggregate_group->value,
            eProtocolField::summon_system_diagnostic_aggregate_group_counter->code(),
            'Группы агрегированных параметров'
        );
    }
}