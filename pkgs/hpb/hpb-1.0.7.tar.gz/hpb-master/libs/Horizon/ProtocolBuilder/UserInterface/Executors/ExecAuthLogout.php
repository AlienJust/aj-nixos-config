<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\Auth\AuthService;
use Horizon\UserInterface\Executor;

class ExecAuthLogout extends Executor
{
    public function __construct(string $URL)
    {
        AuthService::logout();
        parent::__construct($URL);
    }
}