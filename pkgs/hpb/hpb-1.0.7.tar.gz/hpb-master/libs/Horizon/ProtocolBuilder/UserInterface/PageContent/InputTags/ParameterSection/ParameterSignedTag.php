<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Controls\CheckboxBool;

class ParameterSignedTag extends CheckboxBool
{
    public function __construct(bool $value)
    {
        parent::__construct(eParameterField::signed->code(), $value,
            'Знаковое значение', 'Отметьте, если значение параметра со знаком');
    }
}