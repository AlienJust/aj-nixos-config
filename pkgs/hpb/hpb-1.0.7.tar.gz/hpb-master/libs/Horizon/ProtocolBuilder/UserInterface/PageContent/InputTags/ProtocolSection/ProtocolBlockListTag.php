<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\UserInterface\eUICallerAJAXAction;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\PresetTags\SortableSummonList;

class ProtocolBlockListTag extends SortableSummonList
{
    public function __construct()
    {
        parent::__construct(
            eUICallerAJAXAction::summon_system_diagnostic_block->value,
            eProtocolField::summon_system_diagnostic_block_counter->code(),
            'Блоки диагностики системы'
        );
    }
}