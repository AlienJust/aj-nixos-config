<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Exception;
use Horizon\ProtocolBuilder\Data\eParameterType;
use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterCheckboxMatrixTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterGUIDTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterNameWithDatalistTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterTypeHiddenTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterValueTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\CreationButton;
use Horizon\UserInterface\Tags\Trace;

class ParameterByDefaultValueCreation extends _PageContentTag
{
    public function __construct(string $header, string $action_URL,
                                string $GUID, string $value, string $name,
                                array $bits, int $count, array $unavailable_bits)
    {
        parent::__construct($header);
        try {
            $this->add((new MainForm($action_URL))
                ->add(new ParameterGUIDTag($GUID))
                ->add(new ParameterNameWithDatalistTag($name))
                ->add(new ParameterValueTag($value))
                ->add(new ParameterTypeHiddenTag(eParameterType::DefVal))
                ->add(new ParameterCheckboxMatrixTag($bits, $count, $unavailable_bits))
                ->add(new CreationButton())
            );
        } catch (Exception $exception) {
            $this->add(new Trace($exception));
        }
    }
}