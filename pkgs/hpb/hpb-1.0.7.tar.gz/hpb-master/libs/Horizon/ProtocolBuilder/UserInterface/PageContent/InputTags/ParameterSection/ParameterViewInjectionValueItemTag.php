<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputNumber;
use Horizon\UserInterface\Controls\InputText;
use Horizon\UserInterface\PresetTags\Division2Columns;
use Horizon\UserInterface\TagsPack;

class ParameterViewInjectionValueItemTag extends TagsPack
{
    public function __construct(int $COUNTER, ?float $value, string $text)
    {
        parent::__construct();
        $this->add((new Division2Columns())
            ->add(new InputNumber(eParameterField::injection_value_value->code($COUNTER), $value ?? '',
                'Числовое значение', 'Введите числовое значение параметра, которое будет отправлено', true))
            ->add((new InputText(eParameterField::injection_value_text->code($COUNTER), $text,
                'Текст', 'Введите текст, который соответствует числовому значению', true))
                ->addAttribute(Attribute::maxlength, '255'))
        );
    }
}