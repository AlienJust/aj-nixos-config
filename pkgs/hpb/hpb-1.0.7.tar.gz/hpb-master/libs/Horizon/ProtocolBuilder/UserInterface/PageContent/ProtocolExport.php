<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_Protocol;
use Horizon\UserInterface\Tags\Anchor;
use Horizon\UserInterface\Tags\ListItem;
use Horizon\UserInterface\Tags\UnorderedList;

class ProtocolExport extends _PageContentTag
{
    public function __construct(UISection_Protocol ...$controller)
    {
        parent::__construct('Экспорт протокола', 'export');
        $this->add($list = new UnorderedList());
        foreach ($controller as $item) $list
            ->add((new ListItem())->add(new Anchor($item->getURL(), $item->refAction()->name())));
    }
}