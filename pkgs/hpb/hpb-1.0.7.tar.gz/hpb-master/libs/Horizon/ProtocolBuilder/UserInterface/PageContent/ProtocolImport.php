<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\Auth\DataBase\PickSources\UGroupPick;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolAuthorTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolImportFileTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\ImportButton;

class ProtocolImport extends _PageContentTag
{
    /**
     * @throws DBException
     */
    public function __construct(string $header, string $action_URL)
    {
        parent::__construct($header);
        $this->add(new MainForm($action_URL)
            ->add(new ProtocolImportFileTag())
            ->add(new ProtocolAuthorTag('')->addOptions(true, ...new UGroupPick()->init()))
            ->add(new ImportButton()));
    }
}