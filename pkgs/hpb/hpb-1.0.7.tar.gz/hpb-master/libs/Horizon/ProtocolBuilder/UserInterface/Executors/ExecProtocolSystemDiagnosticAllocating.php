<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\DataBase\Tables\SystemDiagnosticAggregateChunk;
use Horizon\ProtocolBuilder\DataBase\Tables\SystemDiagnosticChunk;
use Horizon\ProtocolBuilder\DataBase\Tables\SystemDiagnosticVirtualChunk;
use Horizon\ProtocolBuilder\Exceptions\VEx;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Protocol;
use Horizon\UserInterface\Executor;

class ExecProtocolSystemDiagnosticAllocating extends Executor
{

    /**
     * @throws DBException
     * @throws VException
     */
    public function __construct(Protocol $protocol, array $diagnostic_list)
    {
        $block = null;
        $column = 0;
        $row = 0;
        foreach ($diagnostic_list as $item){
            list($type, $value) = explode('=', $item);
            switch($type) {
                case 'block':
                    $block = $value;
                    break;
                case 'column':
                    $column = $value;
                    $row = 0;
                    break;
                case 'parameter':
                    SystemDiagnosticChunk::dbFind($protocol->getID(), $value)
                        ->setBlock($block)
                        ->setColumnId($column)
                        ->setRowId($row)
                        ->dbUpdate();
                    $row++;
                    break;
                case 'virtual_parameter':
                    SystemDiagnosticVirtualChunk::dbFind($protocol->getID(), $value)
                        ->setBlock($block)
                        ->setColumnId($column)
                        ->setRowId($row)
                        ->dbUpdate();
                    $row++;
                    break;
                case 'aggregate_parameter':
                    SystemDiagnosticAggregateChunk::dbLoad($value, $protocol->getID())
                        ->setBlock($block)
                        ->setColumnId($column)
                        ->setRowId($row)
                        ->dbUpdate();
                    $row++;
                    break;
                case 'row':
                    if (!is_null($block)) $row++;
                    break;
                default:
                    throw new VException(VEx::unknownParameterType);
            }
        }
        parent::__construct(eUISA_Protocol::system_diagnostic_tuning->initController()->setProtocol($protocol)->getURL());
    }
}