<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCommandField;
use Horizon\UserInterface\Controls\InputNumber;

class CommandReplyLengthTag extends InputNumber
{
    public function __construct(string $value)
    {
        parent::__construct(eCommandField::reply_length->code(), $value,
            'Длина ответа (в байтах)', 'Введите длину ответа в байтах', true);
    }
}