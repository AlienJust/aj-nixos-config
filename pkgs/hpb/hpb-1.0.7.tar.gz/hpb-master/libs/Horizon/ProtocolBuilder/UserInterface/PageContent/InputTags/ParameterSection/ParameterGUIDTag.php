<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputText;

class ParameterGUIDTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eParameterField::GUID->code(), $value,
            'Уникальный идентификатор', 'Уникальный идентификатор генерируется автоматически', true);
        $this->addAttribute(Attribute::readonly, true);
    }
}