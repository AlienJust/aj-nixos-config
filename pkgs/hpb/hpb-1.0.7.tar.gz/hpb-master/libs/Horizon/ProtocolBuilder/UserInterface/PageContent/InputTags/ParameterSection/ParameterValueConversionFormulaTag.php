<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Controls\InputText;

class ParameterValueConversionFormulaTag extends InputText
{
    public function __construct(?string $value)
    {
        parent::__construct(eParameterField::value_conversion_formula->code(), $value ?? '',
            'Формула преобразования значения',
            'Введите формулу преобразования значения, используя x в качестве переменной значения');
    }
}