<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Controls\CheckboxBool;

class ProtocolParameterViewCheckboxTag extends CheckboxBool
{
    public function __construct(string $key, string $name, bool $value)
    {
        parent::__construct(eProtocolField::parameter_views->code() . "[$key]", $value, $name,
            'Отметьте параметры, которые нужно отображать в окне "Диагностика системы"', false);
    }
}