<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\Auth\DataBase\Tables\User;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_User;
use Horizon\UserInterface\Executor;

class ExecUserEditing extends Executor
{
    /**
     * @throws DBException
     */
    public function __construct(User $user,
                                string $username, string $surname, string $name, string $patronymic, bool $ban)
    {
        $user->username = $username;
        $user->surname = $surname;
        $user->name = $name;
        $user->patronymic = $patronymic;
        $user->ban = $ban;
        $user->dbUpdate();
        parent::__construct(eUISA_User::view->initController()->setUser($user)->getURL());
    }
}