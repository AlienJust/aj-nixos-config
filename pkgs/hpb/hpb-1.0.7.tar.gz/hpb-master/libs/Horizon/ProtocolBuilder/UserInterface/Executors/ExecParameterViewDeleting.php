<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToReply;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToRequest;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterView;
use Horizon\ProtocolBuilder\UserInterface\eUISA_ReplyParameter;
use Horizon\ProtocolBuilder\UserInterface\eUISA_RequestParameter;
use Horizon\UserInterface\Executor;

class ExecParameterViewDeleting extends Executor
{
    /**
     * @throws DBException
     */
    public function __construct(ParameterToRequest|ParameterToReply $parameter, string $code)
    {
        ParameterView::dbLoad($parameter->refCommand()->refSubscriber()->getProtocol(), $code)->dbDelete();
        parent::__construct(($parameter::class == ParameterToRequest::class
            ? eUISA_RequestParameter::new_view
            : eUISA_ReplyParameter::new_view
        )->initController()->setParameter($parameter)->getURL());
    }
}