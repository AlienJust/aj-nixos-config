<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Controls\InputHiddenValue;
use Horizon\UserInterface\Controls\InputText;
use Horizon\UserInterface\Tags\Division;
use Horizon\UserInterface\TagsPack;

class ProtocolVirtualParameterItemTag extends TagsPack
{
    public function __construct(int $COUNTER, ?string $code, string $new_code)
    {
        parent::__construct();
        $this->add((new Division())
            ->add(is_null($code) ? null : new InputHiddenValue(eProtocolField::virtual_parameter_code->code($COUNTER), $code))
            ->add(new InputText(eProtocolField::virtual_parameter_new_code->code($COUNTER), $new_code,
                'Код виртуального параметра', 'Введите код виртуального параметра, для которого написан алгоритм вычисления его значения'))
        );
    }
}