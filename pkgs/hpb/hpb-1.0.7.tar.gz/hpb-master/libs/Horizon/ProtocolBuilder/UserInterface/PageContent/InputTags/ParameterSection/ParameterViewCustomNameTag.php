<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputText;

class ParameterViewCustomNameTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eParameterField::view_custom_name->code(), htmlspecialchars($value),
            'Иное наименование', 'Введите наименование, если в представлении требуется его изменить');
        $this->addAttribute(Attribute::maxlength, '255');
    }
}