<?php

namespace Horizon\ProtocolBuilder\UserInterface\Menu\Bricks;

use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Tags\Anchor;

class MenuItem extends Anchor
{
    public function __construct(UISection $controller, string $text, bool $is_current)
    {
        parent::__construct($controller->getURL(), $text);
        $this->addClassIf('current', $is_current)
            ->addAttribute(Attribute::id, $controller->refURL()->getBookmark());
    }
}