<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\SubscriberSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eSubscriberField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputText;

class SubscriberShortNameTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eSubscriberField::short_name->code(), $value,
            'Краткое наименование абонента', 'Введите краткое наименование абонента', true);
        $this->addAttribute(Attribute::maxlength, '16');
    }
}