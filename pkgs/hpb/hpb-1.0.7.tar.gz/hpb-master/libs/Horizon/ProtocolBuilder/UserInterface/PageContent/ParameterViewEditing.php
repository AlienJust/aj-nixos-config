<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewCodeTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewCommentTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewCustomNameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewFormatTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewInjectionTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewInjectionValueItemTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewInjectionValueListTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewMaskTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewNewCodeTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewNumberItemTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewNumberListTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewValueItemTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewValueListTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\DeleteButton;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\UpdatingButton;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\HTMLException;
use Horizon\UserInterface\PresetTags\Division2Columns;
use Horizon\UserInterface\Tags\Header;
use Horizon\UserInterface\Tags\Paragraph;

class ParameterViewEditing extends _PageContentTag
{
    private string $action_URL;
    private string $delete_URL;
    private ParameterViewValueListTag $current_view_value_list;
    private ParameterViewNumberListTag $current_view_number_list;
    private ParameterViewInjectionValueListTag $current_view_injection_value_list;
    public function __construct(string $id, string $header, string $action_URL, string $delete_URL)
    {
        parent::__construct($header, $id);
        $this->action_URL = $action_URL;
        $this->delete_URL = $delete_URL;
    }

    public function addView(string $code, string $comment, ?string $custom_name, ?string $format, ?string $mask, ?string $current_mask,
                            int $number_in_package, ?string $injection_expression, ?bool $invert_bytes_order,
                            ?float $min_value, ?float $max_value, ?float $interval_value, bool $is_link_to_system_diagnostic): void
    {
        $this->add((new Division2Columns())
            ->add(new Header(2, "Представление $code"))
            ->add((new MainForm($this->delete_URL))->addAttribute(Attribute::id, 'delete')
                ->add(new ParameterViewCodeTag($code))
                ->add(new DeleteButton())))
            ->add($is_link_to_system_diagnostic ? new Header(3, "* Используется на экране \"Диагностика системы\"") : null)
            ->add((new MainForm($this->action_URL))
                ->add(new ParameterViewCodeTag($code))
                ->add((new Division2Columns())
                    ->add(new ParameterViewNewCodeTag($code))
                    ->add(new ParameterViewCommentTag($comment))
                    ->add(new ParameterViewCustomNameTag($custom_name ?? ''))
                    ->add(new ParameterViewFormatTag($format ?? ''))
                    ->add(new ParameterViewMaskTag($mask ?? '')))
                ->add(new Header(3, "Текущая маска по умолчанию: $current_mask"))
                ->add($this->current_view_value_list = new ParameterViewValueListTag())
                ->add($this->current_view_number_list = new ParameterViewNumberListTag())
                ->add((new ParameterViewInjectionTag(
                    !is_null($injection_expression),
                    $number_in_package,
                    $injection_expression ?? '[value] * 1.0',
                    $invert_bytes_order ?? true,
                    $min_value,
                    $max_value,
                    $interval_value
                ))->add($this->current_view_injection_value_list = new ParameterViewInjectionValueListTag()))
                ->add(new UpdatingButton()));
    }

    /**
     * @throws HTMLException
     */
    public function addViewValue(string $expression, string $result_true, string $result_false, ?string $color): void
    {
        $this->current_view_value_list->add(
            new ParameterViewValueItemTag($this->current_view_value_list->getItemsAmount(),
                $expression, $result_true, $result_false, $color)
        );
    }

    /**
     * @throws HTMLException
     */
    public function addViewNumber(string $expression, string $format, ?string $color): void
    {
        $this->current_view_number_list->add(
            new ParameterViewNumberItemTag($this->current_view_number_list->getItemsAmount(),
                $expression, $format, $color)
        );
    }

    public function addInjectionValue(float $value, string $text): void
    {
        $this->current_view_injection_value_list->add(
            new ParameterViewInjectionValueItemTag($this->current_view_injection_value_list->getItemsAmount(),
                $value, $text)
        );
    }
}