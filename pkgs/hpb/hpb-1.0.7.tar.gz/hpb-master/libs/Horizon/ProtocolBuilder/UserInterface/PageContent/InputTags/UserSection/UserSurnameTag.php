<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eUserField;
use Horizon\UserInterface\Controls\InputText;

class UserSurnameTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eUserField::surname->code(), $value,
            'Фамилия пользователя', 'Введите фамилию пользователя');
    }
}