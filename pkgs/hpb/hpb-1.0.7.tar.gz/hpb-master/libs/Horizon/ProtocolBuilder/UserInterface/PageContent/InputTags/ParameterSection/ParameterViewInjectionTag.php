<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\CheckboxBool;
use Horizon\UserInterface\Controls\InputNumber;
use Horizon\UserInterface\Controls\InputText;
use Horizon\UserInterface\PresetTags\Division2Columns;
use Horizon\UserInterface\PresetTags\SwitchableEnabling;

class ParameterViewInjectionTag extends SwitchableEnabling
{
    public function __construct(bool $value, int $number_in_package, string $expression, bool $invert_bytes_order,
                                ?float $min_value, ?float $max_value, ?float $interval_value)
    {
        parent::__construct(eParameterField::injection_on->code(), $value, 'Добавить инъекцию значения',
            'Отметьте, если необходимо перехватывать и изменять значение параметра программно', false);
        $this->add(
            (new Division2Columns())->add(
                (new InputNumber(eParameterField::injection_number->code(), $number_in_package,
                    'Номер в пакете', 'Введите адрес (номер параметра в пакете), куда будет производиться инъекция', true))
                    ->addAttribute(Attribute::min, '0')
                    ->addAttribute(Attribute::step, '1'),
                (new InputText(eParameterField::injection_expression->code(), $expression,
                    'Формула обратного преобразования', 'Введите формулу обратного преобразования значения, например, [value] * 1.0', true))
                    ->addAttribute(Attribute::maxlength, '255'),
                (new InputNumber(eParameterField::injection_min_value->code(), $min_value ?? '',
                    'Минимальное допустимое значение', 'Введите минимальное допустимое вводимое значение параметра'))
                    ->addAttribute(Attribute::placeholder, 'Нет')
                    ->addAttribute(Attribute::step, '0.0000001'),
                (new InputNumber(eParameterField::injection_max_value->code(), $max_value ?? '',
                    'Максимальное допустимое значение', 'Введите максимальное допустимое вводимое значение параметра'))
                    ->addAttribute(Attribute::placeholder, 'Нет')
                    ->addAttribute(Attribute::step, '0.0000001'),
                (new InputNumber(eParameterField::injection_interval_value->code(), $interval_value ?? '',
                    'Интервал изменения значения', 'Введите интервал допустимого значения'))
                    ->addAttribute(Attribute::placeholder, 'Нет')
                    ->addAttribute(Attribute::step, '0.0000001'),
                new CheckboxBool(eParameterField::injection_order->code(), $invert_bytes_order,
                    'Инвертировать порядок байтов (LoHi -> HiLo)', 'Отметьте, если порядок байтов HiLo, в противном случае он будет LoHi'),
            )
        );
    }
}