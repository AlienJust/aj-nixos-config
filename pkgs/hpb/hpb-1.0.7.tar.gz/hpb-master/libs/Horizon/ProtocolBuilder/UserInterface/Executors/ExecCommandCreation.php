<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\Data\eCommandInitWay;
use Horizon\ProtocolBuilder\Data\eParameterType;
use Horizon\ProtocolBuilder\Data\eParameterVariableName;
use Horizon\ProtocolBuilder\DataBase\Tables\Command;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToReply;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToRequest;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\LogicItems\HexByte;
use Horizon\ProtocolBuilder\LogicItems\HexWord;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Command;
use Horizon\UserInterface\Executor;

class ExecCommandCreation extends Executor
{
    private ?int $command;
    /**
     * @throws DBException
     * @throws VException
     */
    public function __construct(Command $command, string $name, int $request_length, int $reply_length,
                                int $request_header_length, int $reply_header_length, string $init_way, bool $system,
                                ?float $cycle_ms_time)
    {
        $request_required = $reply_header_length == $request_header_length && $reply_length == $request_length;
        $command->setName($name)->setSystem($system);
        $command->setRequest($request_length, 0, $request_header_length, $cycle_ms_time);
        $command->setReply($reply_length, $request_length, $reply_header_length, $request_required);
        $command->dbInsert();
        $this->command = $command->getID();
        switch (eCommandInitWay::tryFrom($init_way)) {
            case eCommandInitWay::modbus_read:
                $register_count = new HexWord(($reply_length - 5) / 2);
                $this->initModbusDefaultHeaders($register_count, $command->refSubscriber()->getAddress(), 3);
                $this->initDefaultReplyParameter('Количество байт данных', $reply_length - 5, 16, 23);
                break;
            case eCommandInitWay::modbus_write:
                $register_count = new HexWord(($request_length - 9) / 2);
                $this->initModbusDefaultHeaders($register_count, $command->refSubscriber()->getAddress(), 16);
                $this->initDefaultRequestParameter('Количество байт далее', $request_length - 9, 48, 55);
                $this->initDefaultReplyParameter('Адрес первого регистра Hi', '0', 16, 23);
                $this->initDefaultReplyParameter('Адрес первого регистра Lo', '0', 24, 31);
                $this->initDefaultReplyParameter('Количество регистров Hi', $register_count->hi, 32, 39);
                $this->initDefaultReplyParameter('Количество регистров Lo', $register_count->lo, 40, 47);
                break;
        }
        $this->initCRCParameters($request_length, $reply_length);
        parent::__construct(eUISA_Command::edit->initController()->setCommand($command)->getURL());
    }

    /**
     * @throws DBException
     * @throws VException
     */
    private function initDefaultRequestParameter(string $name, string $value, int $first_bit, int $last_bit): void
    {
        (new ParameterToRequest($this->command))->initGUID()
            ->setName($name)
            ->setType(eParameterType::DefVal->value)
            ->setValue($value)
            ->setBits(range($first_bit, $last_bit))
            ->dbInsert();
    }

    /**
     * @throws DBException
     * @throws VException
     */
    private function initDefaultReplyParameter(string $name, string $value, int $first_bit, int $last_bit): void
    {
        (new ParameterToReply($this->command))->initGUID()
            ->setName($name)
            ->setType(eParameterType::DefVal->value)
            ->setValue($value)
            ->setBits(range($first_bit, $last_bit))
            ->dbInsert();
    }

    /**
     * @throws DBException
     * @throws VException
     */
    private function initCRCParameters(int $request_length, int $reply_length): void
    {
        (new ParameterToRequest($this->command))->initGUID()
            ->setName(eParameterVariableName::CRC_h->value)
            ->setType(eParameterType::VarVal->value)
            ->setBits(range($request_length * 8 - 16, $request_length * 8 - 9))
            ->dbInsert();
        (new ParameterToRequest($this->command))->initGUID()
            ->setName(eParameterVariableName::CRC_l->value)
            ->setType(eParameterType::VarVal->value)
            ->setBits(range($request_length * 8 - 8, $request_length * 8 - 1))
            ->dbInsert();
        (new ParameterToReply($this->command))->initGUID()
            ->setName(eParameterVariableName::CRC_h->value)
            ->setType(eParameterType::VarVal->value)
            ->setBits(range($reply_length * 8 - 16, $reply_length * 8 - 9))
            ->dbInsert();
        (new ParameterToReply($this->command))->initGUID()
            ->setName(eParameterVariableName::CRC_l->value)
            ->setType(eParameterType::VarVal->value)
            ->setBits(range($reply_length * 8 - 8, $reply_length * 8 - 1))
            ->dbInsert();
    }

    /**
     * @throws DBException
     * @throws VException
     */
    private function initModbusDefaultHeaders(HexWord $register_count, int $subscriber_address, int $command_address): void
    {
        $subscriber_address = new HexByte($subscriber_address);
        $command_address = new HexByte($command_address);

        $this->initDefaultRequestParameter('#ADDR', $subscriber_address->hex, 0, 7);
        $this->initDefaultRequestParameter('#NCMD', $command_address->hex, 8, 15);
        $this->initDefaultRequestParameter('Адрес первого регистра Hi', '0', 16, 23);
        $this->initDefaultRequestParameter('Адрес первого регистра Lo', '0', 24, 31);
        $this->initDefaultRequestParameter('Количество регистров Hi', $register_count->hi, 32, 39);
        $this->initDefaultRequestParameter('Количество регистров Lo', $register_count->lo, 40, 47);

        $this->initDefaultReplyParameter('#ADDR', $subscriber_address->hex, 0, 7);
        $this->initDefaultReplyParameter('#NCMD', $command_address->hex, 8, 15);
    }
}