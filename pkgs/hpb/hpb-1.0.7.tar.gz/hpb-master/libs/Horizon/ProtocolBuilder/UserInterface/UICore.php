<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Exception;
use Horizon\Auth\AccessDeniedException;
use Horizon\Auth\AuthService;
use Horizon\Auth\DataBase\Tables\Group;
use Horizon\Auth\DataBase\Tables\User;
use Horizon\ProtocolBuilder\DataBase\Tables\Command;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToReply;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToRequest;
use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\DataBase\Tables\Subscriber;
use Horizon\ProtocolBuilder\Exceptions\ActionAccessException;
use Horizon\ProtocolBuilder\Exceptions\DataAccessException;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\Menu;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\MenuAction;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\MenuBlock;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\MenuItem;
use Horizon\ProtocolBuilder\UserInterface\Menu\CommandsMenu;
use Horizon\ProtocolBuilder\UserInterface\Menu\MainMenu;
use Horizon\ProtocolBuilder\UserInterface\Menu\ParametersMenu;
use Horizon\ProtocolBuilder\UserInterface\Menu\SubscribersMenu;
use Horizon\ProtocolBuilder\UserInterface\PageContent\RedirectionView;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ViewTags\AuthExceptionView;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ViewTags\ExceptionView;
use Horizon\ProtocolBuilder\UserInterface\PageParts\ControlPanelItem;
use Horizon\ProtocolBuilder\UserInterface\PageParts\PathToPageForListData;
use Horizon\ProtocolBuilder\UserInterface\PageParts\PathToPageForProtocol;
use Horizon\ProtocolBuilder\UserInterface\Pages\MainPage;
use Horizon\ProtocolBuilder\UserInterface\Pages\SafePage;
use Horizon\ProtocolBuilder\UserInterface\Pages\UnknownPage;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_Auth;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_Command;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_Protocol;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_ReplyParameter;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_RequestParameter;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_Subscriber;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_UGroup;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_User;
use Horizon\UserInterface\Executor;

class UICore
{
    private MainPage $page;
    private SafePage $safePage;
    private UnknownPage $unknownPage;
    private ?Executor $executor = null;

    private string $action;
    private array $post;

    private ?string $protocol;
    private ?string $subscriber;
    private ?string $command;
    private string|int|null $ID;

    private bool $execute;
    private ?UISection $controller;

    private bool $safe_mode = false;


    public function __construct(MainPage $page, SafePage $safePage, UnknownPage $unknownPage)
    {
        $this->page = $page;
        $this->safePage = $safePage;
        $this->unknownPage = $unknownPage;

        //VariableView::output($_POST, $_GET);

        $this->post = empty($_POST) ? $_GET : array_merge($_GET, $_POST);
        $this->action = $this->pullPOST('action') ?? '';
        $this->protocol = $this->pullPOST('protocol');
        $this->subscriber = $this->pullPOST('subscriber');
        $this->command = $this->pullPOST('command');
        $this->ID = $this->pullPOST_ID();
        $this->execute = !is_null($this->pullPOST('execute'));

        // Конфигурируем положение меню на странице
        $this->page->isHiddenSidebar = ($this->pullPOST('hamburger') ?? '0') == '1';

        AuthService::authBySession();
        // Инициализируем контроллер страницы
        $this->initController(eUISection::tryFrom($this->pullPOST('section') ?? ''));
        // Передаем путь на страницу авторизации (если мы уже не на ней)
        if ($this->controller !== null && $this->controller::class != UISection_Auth::class)
            $this->safePage->setPath($this->controller->getURL());
    }

    private function initController(?eUISection $section): void
    {
        try {
            $this->controller = $section?->controller($this->action, $this->post, $_FILES);
        } catch (Exception $e) {
            $this->page->setContent(new ExceptionView($e), $e->getMessage());
        }
        try {
            $ctrl = $this->controller;
            if ($ctrl !== null) switch ($ctrl::class) {
                case UISection_Protocol::class:
                    $ctrl->setProtocol(Protocol::dbLoad($this->ID));
                    break;
                case UISection_Subscriber::class:
                    $ctrl->setSubscriber(Subscriber::dbLoad($this->ID, $this->protocol));
                    break;
                case UISection_Command::class:
                    $ctrl->setCommand(Command::dbLoad($this->ID, $this->subscriber));
                    break;
                case UISection_ReplyParameter::class:
                    $ctrl->setParameter(ParameterToReply::dbLoad($this->ID, $this->command));
                    break;
                case UISection_RequestParameter::class:
                    $ctrl->setParameter(ParameterToRequest::dbLoad($this->ID, $this->command));
                    break;
                case UISection_User::class:
                    $ctrl->setUser(User::dbLoad($this->ID));
                    break;
                case UISection_UGroup::class:
                    $ctrl->setGroup(Group::dbLoad($this->ID));
                    break;
                case UISection_Auth::class:
                    break;
            }
        } catch (Exception $e) {
            $this->page->setContent(new ExceptionView($e), $e->getMessage());
        }
    }

    private function checkAccess(): bool
    {
        try {
            $this->controller->verifyAccess();
            return true;
        } catch (Exception) {
            return false;
        }
    }

    /**
     * @return void Формируем контент или переадресацию
     */
    private function initContent(): void
    {
        try {
            try {
                $this->controller->verifyAccess(); // проверка доступа к данным и операциям
            } catch (Exception $e) {
                $this->page->addMenu(new MainMenu());
                throw $e;
            }
            $ctrl = $this->controller;
            switch ($ctrl::class) {
                case UISection_Protocol::class:
                    $protocol = $ctrl->refProtocol();
                    $this->page->setPath(new PathToPageForProtocol($protocol));

                    if ($protocol->exists()) foreach (eUISA_Protocol::controlPanel() as $item) {
                        try {
                            $item_ctrl = $item->initController()->setProtocol($protocol);
                            $item_ctrl->verifyAccess();
                            $this->page->addControlPanelItem(new ControlPanelItem($item_ctrl, $ctrl->refAction()));
                        } catch (ActionAccessException) {}
                    }

                    $this->page->addMenu(new MainMenu($this->ID, $ctrl->refAction()));
                    if ($ctrl->refProtocol()->exists()) $this->page->addMenu(new SubscribersMenu($ctrl->refProtocol()));
                    break;
                case UISection_Subscriber::class:
                    $protocol = Protocol::dbLoad($this->protocol);
                    $subscriber = $ctrl->refSubscriber();
                    $this->page->setPath(new PathToPageForProtocol($protocol, $subscriber));

                    if ($subscriber->exists()) foreach (eUISA_Subscriber::controlPanel() as $item)
                        $this->page->addControlPanelItem(
                            new ControlPanelItem($item->initController()->setSubscriber($subscriber), $ctrl->refAction()));

                    $this->page->addMenu(new MainMenu($this->protocol));
                    $this->page->addMenu(new SubscribersMenu($protocol, $this->ID, $ctrl->refAction()));
                    if ($ctrl->refSubscriber()->exists()) $this->page->addMenu(new CommandsMenu($ctrl->refSubscriber()));
                    break;
                case UISection_Command::class:
                    $protocol = Protocol::dbLoad($this->protocol);
                    $subscriber = Subscriber::dbLoad($this->subscriber);
                    $command = $ctrl->refCommand();
                    $this->page->setPath(new PathToPageForProtocol($protocol, $subscriber, $command));

                    if ($command->exists()) foreach (eUISA_Command::controlPanel() as $item)
                        $this->page->addControlPanelItem(
                            new ControlPanelItem($item->initController()->setCommand($command), $ctrl->refAction()));

                    $this->page->addMenu(new MainMenu($this->protocol));
                    $this->page->addMenu(new SubscribersMenu($protocol, $this->subscriber));
                    $this->page->addMenu(new CommandsMenu($subscriber, $this->ID, $ctrl->refAction()));
                    if ($ctrl->refCommand()->exists()) $this->page->addMenu(new ParametersMenu($ctrl->refCommand()));
                    break;
                case UISection_ReplyParameter::class:
                    $protocol = Protocol::dbLoad($this->protocol);
                    $subscriber = Subscriber::dbLoad($this->subscriber);
                    $command = Command::dbLoad($this->command);
                    $parameter = $ctrl->refParameter();
                    $this->page->setPath(new PathToPageForProtocol($protocol, $subscriber, $command, $parameter));

                    if ($parameter->exists()) foreach (eUISA_ReplyParameter::controlPanel() as $item)
                        $this->page->addControlPanelItem(
                            new ControlPanelItem($item->initController()->setParameter($parameter), $ctrl->refAction()));

                    $this->page->addMenu(new MainMenu($this->protocol));
                    $this->page->addMenu(new SubscribersMenu($protocol, $this->subscriber));
                    $this->page->addMenu(new CommandsMenu($subscriber, $this->command));
                    $this->page->addMenu(new ParametersMenu($command, $this->ID, $ctrl->refAction()));
                    break;
                case UISection_RequestParameter::class:
                    $protocol = Protocol::dbLoad($this->protocol);
                    $subscriber = Subscriber::dbLoad($this->subscriber);
                    $command = Command::dbLoad($this->command);
                    $parameter = $ctrl->refParameter();
                    $this->page->setPath(new PathToPageForProtocol($protocol, $subscriber, $command, $parameter));

                    if ($parameter->exists()) foreach (eUISA_RequestParameter::controlPanel() as $item)
                        $this->page->addControlPanelItem(
                            new ControlPanelItem($item->initController()->setParameter($parameter), $ctrl->refAction()));

                    $this->page->addMenu(new MainMenu($this->protocol));
                    $this->page->addMenu(new SubscribersMenu($protocol, $this->subscriber));
                    $this->page->addMenu(new CommandsMenu($subscriber, $this->command));
                    $this->page->addMenu(new ParametersMenu($command, $this->ID, $ctrl->refAction()));
                    break;
                case UISection_User::class:
                    $user = $ctrl->refUser();
                    $this->page->setPath(new PathToPageForListData(
                        $ctrl->refAction() != eUISA_User::view,
                        eUISA_User::view->buttonName(),
                        eUISA_User::view->initController()->setUser($user)->getURL(),
                        $user->exists() ? $user->getSNP() : null
                    ));
                    $this->page->addControlPanelItem(
                        new ControlPanelItem(eUISA_User::new->initController(), $ctrl->refAction())
                    );
                    if ($ctrl->refAction() != eUISA_User::view && $user->exists()) foreach (eUISA_User::controlPanel() as $item)
                        $this->page->addControlPanelItem(
                            new ControlPanelItem($item->initController()->setUser($user), $ctrl->refAction()));
                    $this->page->addMenu(new MainMenu());
                    break;
                case UISection_UGroup::class:
                    $group = $ctrl->refGroup();
                    $this->page->setPath(new PathToPageForListData(
                        $ctrl->refAction() != eUISA_UGroup::view,
                        eUISA_UGroup::view->buttonName(),
                        eUISA_UGroup::view->initController()->setGroup($group)->getURL(),
                        $group->exists() ? $group->name : null
                    ));
                    $this->page->addControlPanelItem(
                        new ControlPanelItem(eUISA_UGroup::new->initController(), $ctrl->refAction())
                    );
                    if ($ctrl->refAction() != eUISA_UGroup::view && $group->exists()) foreach (eUISA_UGroup::controlPanel() as $item)
                        $this->page->addControlPanelItem(
                            new ControlPanelItem($item->initController()->setGroup($group), $ctrl->refAction())
                        );
                    $this->page->addMenu(new MainMenu());
                    break;
                default:
                    $this->page->addMenu(new MainMenu());
            }
            if ($this->execute) {
                $this->executor = $ctrl->initExecutor();
                $this->page->setContent(new RedirectionView($this->executor->URL));
            } else $this->page->setContent($ctrl->tag(), $ctrl->getTitle(), $ctrl->refAction()?->name());
        } catch (AccessDeniedException $e) {
            $this->safePage->setExceptionView(new AuthExceptionView($e));
            $this->safe_mode = true;
        } catch (Exception $e) {
            $this->page->setContent(new ExceptionView($e), $e->getMessage());
        }
    }

    public function output(): void
    {
        if ($this->controller === null) echo $this->unknownPage->draw();
        elseif (User::current()?->exists() || $this->controller::class == UISection_Auth::class) {
            $this->initContent();
            if (!is_null($this->executor)) $this->executor->redirect();
            echo $this->safe_mode ? $this->safePage->draw() : $this->page->draw();
        } else echo $this->safePage->draw();
    }

    private function pullPOST(string $code): ?string
    {
        $value = $this->post[$code] ?? null;
        if (isset($this->post[$code])) unset($this->post[$code]);
        return $value;
    }

    private function pullPOST_ID(): string|int|null
    {
        $ID = $this->pullPOST('ID');
        if ($ID == '') $ID = null;
        if (is_numeric($ID)) $ID = (int)$ID;
        return $ID;
    }
}