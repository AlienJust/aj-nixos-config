<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\ViewTags;

use Horizon\Auth\AccessDeniedException;
use Horizon\UserInterface\Tags\Division;
use Horizon\UserInterface\Tags\Trace;

class AuthExceptionView extends Division
{
    public function __construct(AccessDeniedException $exception)
    {
        parent::__construct();
        $this->add(new Trace($exception));
    }
}