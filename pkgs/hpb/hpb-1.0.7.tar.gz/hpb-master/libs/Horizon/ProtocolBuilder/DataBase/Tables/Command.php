<?php

namespace Horizon\ProtocolBuilder\DataBase\Tables;

use Horizon\DataBaseController\dbTableAI;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\DataBaseController\iTableConfig;
use Horizon\ProtocolBuilder\Data\eParameterName;
use Horizon\ProtocolBuilder\DataBase\eTable;
use Horizon\ProtocolBuilder\DataBase\Models\ParameterViewUsableBySystemDiagnosticChunk;
use Horizon\ProtocolBuilder\Exceptions\VEx;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\UserInterface\Controls\Components\Option;
use Horizon\UserInterface\Controls\Components\OptionGroup;
use PDO;

final class Command extends dbTableAI
{
    protected static iTableConfig $table_config = eTable::pb_command;
    private int $subscriber;
    private string $name = '';
    private bool $system = false;

    private Subscriber $REF_subscriber;
    private CommandRequest $REF_request;
    private CommandReply $REF_reply;

    public function __construct(?int $subscriber = null)
    {
        if (!is_null($subscriber)) $this->subscriber = $subscriber;
    }

    public function setSubscriber(int $subscriber): void
    {
        $this->subscriber = $subscriber;
    }

    public function setName(string $name): static
    {
        $this->name = $name;
        return $this;
    }

    public function setSystem(bool $system): self
    {
        $this->system = $system;
        return $this;
    }

    /**
     * @throws DBException
     */
    public function setRequest(int $length, int $start, int $header_length, ?float $cycle_ms_time): self
    {
        $this->REF_request = CommandRequest::dbLoad($this)
            ->setLength($length)
            ->setStart($start)
            ->setHeaderLength($header_length)
            ->setCycleMsTime($cycle_ms_time);
        return $this;
    }

    /**
     * @throws DBException
     */
    public function setReply(int $length, int $start, int $header_length, bool $request_required): self
    {
        $this->REF_reply = CommandReply::dbLoad($this)
            ->setLength($length)
            ->setStart($start)
            ->setHeaderLength($header_length)
            ->setRequestRequired($request_required);
        return $this;
    }

    public function getSubscriber(): int
    {
        return $this->subscriber;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function isSystem(): bool
    {
        return $this->system;
    }

    /**
     * @throws DBException
     */
    public function refSubscriber(): Subscriber
    {
        return $this->REF_subscriber ?? ($this->REF_subscriber = Subscriber::dbLoad($this->subscriber));
    }

    /**
     * @throws DBException
     */
    public function refRequest(): CommandRequest
    {
        return $this->REF_request ?? ($this->REF_request = CommandRequest::dbLoad($this));
    }

    /**
     * @throws DBException
     */
    public function refReply(): CommandReply
    {
        return $this->REF_reply ?? ($this->REF_reply = CommandReply::dbLoad($this));
    }

    /**
     * @return ParameterToRequest[]
     * @throws DBException
     */
    public function arrParametersToRequest(): array
    {
        $stmt = self::PDO()->prepare('SELECT BinToUUID(pbcrp.`GUID`) AS `GUID`, pbcrp.`command`, 
                IF(pbcrp.`conflicted_GUID` IS NULL, NULL, BinToUUID(pbcrp.`conflicted_GUID`)) AS `conflicted_GUID`,
                pbcrp.`name`, pbcrp.`type`, pbcrp.`byte_order`, pbcrp.`value_conversion_formula`, 
                pbcrp.`lowest_digit_price`, pbcrp.`signed`, pbcrp.`bits`, pbcrp.`sorting_bit`, 
                pbcrp.`value`, pbcrp.`value_inverted`, TRUE AS `exists` 
            FROM `pb_command_parameter` AS pbcrp
            WHERE pbcrp.`command`=:this
              AND pbcrp.`package`=0
            ORDER BY pbcrp.`sorting_bit`;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, ParameterToRequest::class));
    }

    /**
     * @return ParameterToReply[]
     * @throws DBException
     */
    public function arrParametersToReply(): array
    {
        $stmt = self::PDO()->prepare('SELECT BinToUUID(pbcrp.`GUID`) AS `GUID`, pbcrp.`command`, 
                IF(pbcrp.`conflicted_GUID` IS NULL, NULL, BinToUUID(pbcrp.`conflicted_GUID`)) AS `conflicted_GUID`,
                pbcrp.`name`, pbcrp.`type`, pbcrp.`byte_order`, pbcrp.`value_conversion_formula`, 
                pbcrp.`lowest_digit_price`, pbcrp.`signed`, pbcrp.`bits`, pbcrp.`sorting_bit`, 
                pbcrp.`value`, pbcrp.`value_inverted`, TRUE AS `exists` 
            FROM `pb_command_parameter` AS pbcrp
            WHERE pbcrp.`command`=:this
              AND pbcrp.`package`=1
            ORDER BY pbcrp.`sorting_bit`;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, ParameterToReply::class));
    }

    /**
     * @throws DBException
     */
    public function arrParameterViewCodesToRequest(): array
    {
        $stmt = self::PDO()->prepare('WITH `views` AS (SELECT `code`, `identifier`
                             FROM `pb_command_parameter_view`
                             WHERE `code` IN (SELECT MIN(`code`)
                                              FROM `pb_command_parameter_view`
                                              GROUP BY `identifier`))
            SELECT v.`code`
            FROM `pb_command_parameter` AS pcp
                     INNER JOIN `views` AS v ON pcp.`GUID` = v.`identifier`
            WHERE pcp.`command` = :this
              AND pcp.`package` = 0
            ORDER BY pcp.`sorting_bit`;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_COLUMN));
    }

    /**
     * @throws DBException
     */
    public function arrParameterViewCodesToReply(): array
    {
        $stmt = self::PDO()->prepare('WITH `views` AS (SELECT `code`, `identifier`
                             FROM `pb_command_parameter_view`
                             WHERE `code` IN (SELECT MIN(`code`)
                                              FROM `pb_command_parameter_view`
                                              GROUP BY `identifier`))
            SELECT v.`code`
            FROM `pb_command_parameter` AS pcp
                     INNER JOIN `views` AS v ON pcp.`GUID` = v.`identifier`
            WHERE pcp.`command` = :this
              AND pcp.`package` = 1
            ORDER BY pcp.`sorting_bit`;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_COLUMN));
    }

    /**
     * @return ParameterViewUsableBySystemDiagnosticChunk[]
     * @throws DBException
     */
    public function arrParameterViewsToRequest(): array
    {
        $stmt = self::PDO()->prepare('SELECT pcpv.`code`,
                   IFNULL(pcpv.custom_name, pcp.`name`)    AS `name`,
                   EXISTS(SELECT *
                          FROM `pb_system_diagnostic_chunk` AS psdc,
                               `pb_command` AS pc,
                               `pb_subscriber` AS ps
                          WHERE psdc.`protocol` = ps.`protocol`
                            AND psdc.`code` = pcpv.`code`
                            AND pc.`ID` = pcp.`command`
                            AND ps.`ID` = pc.`subscriber`) AS `is_use`,
                   pcp.`sorting_bit`                       AS `bit`,
                   IF(pcp.`package`,pcr1.`header_length`,pcr0.`header_length`)       AS `header_length`,
                   LENGTH(pcp.`bits`) - LENGTH(REPLACE(pcp.`bits`, \',\', \'\')) + 1 AS `length`
            FROM `pb_command_parameter_view` AS pcpv
                     LEFT OUTER JOIN `pb_command_parameter` AS pcp ON pcp.`GUID` = pcpv.`identifier`
                     LEFT OUTER JOIN `pb_command_request` AS pcr0 ON pcr0.`ID`=pcp.`command`
                     LEFT OUTER JOIN `pb_command_reply` AS pcr1 ON pcr1.`ID`=pcp.`command`
            WHERE pcp.`command` = :this
              AND pcp.`package` = 0
            ORDER BY pcp.`sorting_bit`, pcp.`bits`, pcp.`GUID`, pcpv.`code`;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, ParameterViewUsableBySystemDiagnosticChunk::class));
    }

    /**
     * @return ParameterViewUsableBySystemDiagnosticChunk[]
     * @throws DBException
     */
    public function arrParameterViewsToReply(): array
    {
        $stmt = self::PDO()->prepare('SELECT pcpv.`code`,
                   IFNULL(pcpv.custom_name, pcp.`name`)    AS `name`,
                   EXISTS(SELECT *
                          FROM `pb_system_diagnostic_chunk` AS psdc,
                               `pb_command` AS pc,
                               `pb_subscriber` AS ps
                          WHERE psdc.`protocol` = ps.`protocol`
                            AND psdc.`code` = pcpv.`code`
                            AND pc.`ID` = pcp.`command`
                            AND ps.`ID` = pc.`subscriber`) AS `is_use`,
                   pcp.`sorting_bit`                       AS `bit`,
                   IF(pcp.`package`,pcr1.`header_length`,pcr0.`header_length`)       AS `header_length`,
                   LENGTH(pcp.`bits`) - LENGTH(REPLACE(pcp.`bits`, \',\', \'\')) + 1 AS `length`
            FROM `pb_command_parameter_view` AS pcpv
                     LEFT OUTER JOIN `pb_command_parameter` AS pcp ON pcp.`GUID` = pcpv.`identifier`
                     LEFT OUTER JOIN `pb_command_request` AS pcr0 ON pcr0.`ID`=pcp.`command`
                     LEFT OUTER JOIN `pb_command_reply` AS pcr1 ON pcr1.`ID`=pcp.`command`
            WHERE pcp.`command` = :this
              AND pcp.`package` = 1
            ORDER BY pcp.`sorting_bit`, pcp.`bits`, pcp.`GUID`, pcpv.`code`;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, ParameterViewUsableBySystemDiagnosticChunk::class));
    }

    /**
     * @return OptionGroup[]
     * @throws DBException
     */
    public static function arrList(): array
    {
        $stmt = self::PDO()->prepare('SELECT 
                CONCAT_WS(\'-\', pbp.`ID`, pbs.`ID`) AS `group_id`,
                CONCAT_WS(\' \', pbp.`name`, pbs.`name`) AS `group_name`,
                pbc.`ID` AS `value`, 
                pbc.`name` AS `label`
            FROM `pb_command` AS `pbc`,
                 `pb_subscriber` AS `pbs`,
                 `pb_protocol` AS `pbp`
            WHERE pbc.subscriber = pbs.`ID`
              AND pbs.protocol = pbp.`ID`
            ORDER BY pbp.`ID`, pbs.`ID`, pbc.`ID`;');
        $stmt->execute();
        $groups = [];
        self::PDOInspect($stmt->fetchAll(PDO::FETCH_FUNC,
            function (string $group_id, string $group_name, int $value, string $label) use (&$groups): bool {
                if (!isset($groups[$group_id])) $groups[$group_id] = new OptionGroup($group_name);
                $groups[$group_id]->add(new Option($value, $label));
                return true;
            }));
        return $groups;
    }

    /**
     * @throws DBException
     */
    public function getLastNumberInPackage(string $type, bool $package_is_reply): int
    {
        $code = implode('_', $this->initCodeOrigin($type, $package_is_reply)) . '%';
        $stmt = self::PDO()->prepare('SELECT COUNT(pcp.`GUID`) + 1 AS `cnt`, MAX(pcpv.`code`) AS `last_code`
            FROM `pb_command_parameter` AS pcp,
                 `pb_command_parameter_view` AS pcpv
            WHERE pcpv.`identifier` = pcp.`GUID`
              AND pcpv.`protocol` = :protocol
              AND pcpv.`code` LIKE :code
              AND LENGTH(pcpv.`code`) = LENGTH(:code) + 3;');
        $stmt->bindValue(':protocol', $this->refSubscriber()->getProtocol(), PDO::PARAM_INT);
        $stmt->bindValue(':code', $code);
        $stmt->execute();
        list($count, $last_code) = $stmt->fetch(PDO::FETCH_BOTH);
        if ($last_code === null) return $count;
        $code_components = explode('_', $last_code);

        $characters = str_split(array_pop($code_components));
        $numbers = array_filter($characters, 'ctype_digit');
        if (count($numbers) == 0) {
            $characters = str_split(array_pop($code_components));
            $numbers = array_filter($characters, 'ctype_digit');
        }
        $number = (int)implode('', $numbers);
        $last_number = $number + 1;

        return max($last_number, $count);
    }
    public function initCodeOrigin(string $type, bool $package_is_reply): array
    {
        $code = [$type];
        $stmt = self::PDO()->prepare('SELECT `value` FROM `pb_command_parameter` 
               WHERE `command`=:this 
                 AND `package`=0 
                 AND `name`=:name;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->bindValue(':name', eParameterName::address->value);
        $stmt->execute();
        $num = $stmt->fetchColumn() ?? '';
        $code[] = str_pad((str_contains($num, 'x') ? hexdec($num) : $num), 3, '0', STR_PAD_LEFT);
        $stmt->bindValue(':name', eParameterName::command_number->value);
        $stmt->execute();
        $num = $stmt->fetchColumn() ?? '';
        $code[] = str_pad((str_contains($num, 'x') ? hexdec($num) : $num), 3, '0', STR_PAD_LEFT);
        $code[] = $package_is_reply ? 'reply' : 'request';
        return $code;
    }

    // От этого названия зависит то, будет ли отображаться посылка целиком или нет!
    // Прежде, чем менять эту функцию, обрати внимание на ::dbFind()!
    public function initName(string $subscriber_name): string
    {
        return $subscriber_name . ' – ' . $this->getName();
    }

    public function initCode(bool $package_is_reply, string $subscriber_name): string
    {
        $code = $this->initCodeOrigin('cmdpart', $package_is_reply);
        $code[] = $this->initName($subscriber_name) . ': '. ($package_is_reply ? 'ответ' : 'запрос');
        return implode('_', $code);
    }

    protected function tryInsert(): void
    {
        $stmt = self::PDO()->prepare('INSERT INTO `pb_command`(`subscriber`, `name`, `system`) 
            VALUES (:subscriber, :name, :system);');
        $stmt->bindValue(':subscriber', $this->subscriber, PDO::PARAM_INT);
        $stmt->bindValue(':name', $this->name);
        $stmt->bindValue(':system', $this->system, PDO::PARAM_BOOL);
        $stmt->execute();
        $this->ID = self::PDO()->lastInsertId();
        $this->refRequest()->tryInsert();
        $this->refReply()->tryInsert();
    }

    protected function tryUpdate(): void
    {
        $stmt = self::PDO()->prepare('UPDATE `pb_command` SET `name`=:name , `system`=:system
            WHERE `ID`=:this;');
        $stmt->bindValue(':name', $this->name);
        $stmt->bindValue(':system', $this->system, PDO::PARAM_BOOL);
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        $this->refRequest()->tryUpdate();
        $this->refReply()->tryUpdate();
    }

    /**
     * @throws DBException
     */
    public function dbDeleteParameters(array $parameters): void
    {
        self::dbAction(function () use ($parameters) {
            if (!$parameters) throw new VException(VEx::emptyParameters);
            $x = implode(', ', array_map(fn($value) => "UUIDToBin(:x_$value)", array_keys($parameters)));

            $stmt = self::PDO()->prepare("DELETE FROM `pb_command_parameter`  
                WHERE `command`=:this
                  AND `GUID` IN ($x);");
            $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
            foreach ($parameters as $key => $parameter) $stmt->bindValue(":x_$key", $parameter);
            $stmt->execute();
        });
    }

    /**
     * @throws DBException
     */
    public static function dbLoad(?int $ID, ?int $subscriber = null): static
    {
        return static::intoMe(static::PDOStatementForLoad($ID)->fetchObject(static::class, [$subscriber]), $subscriber);
    }

    /**
     * @throws DBException
     */
    public static function dbFind(int $subscriber, string $name): static
    {
        $subscriber_REF = Subscriber::dbLoad($subscriber);
        // Если есть такой абонент, то надо на всякий случай почистить название команды, оно может быть составным
        if ($subscriber_REF->exists())
            $name = str_replace($subscriber_REF->getShortName() . ' – ', '', $name);
        $stmt = self::PDO()->prepare('SELECT pbc.*, TRUE AS `exists` 
            FROM `pb_command` AS pbc
            WHERE pbc.`subscriber`=:subscriber
              AND pbc.`name`=:name;');
        $stmt->bindValue(':subscriber', $subscriber, PDO::PARAM_INT);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        return static::intoMe($stmt->fetchObject(static::class, [$subscriber]), $subscriber)->setName($name);
    }
}