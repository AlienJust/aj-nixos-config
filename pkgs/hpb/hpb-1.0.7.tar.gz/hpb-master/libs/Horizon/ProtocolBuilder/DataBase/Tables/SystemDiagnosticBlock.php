<?php

namespace Horizon\ProtocolBuilder\DataBase\Tables;

use Horizon\DataBaseController\dbTableAI;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\DataBaseController\iTableConfig;
use Horizon\ProtocolBuilder\DataBase\eTable;
use Horizon\ProtocolBuilder\DataBase\Models\SystemDiagnosticChunkWithParameterName;
use PDO;

final class SystemDiagnosticBlock extends dbTableAI
{
    protected static iTableConfig $table_config = eTable::pb_system_diagnostic_block;
    protected int $protocol;
    protected int $sort = 0;
    protected string $name = '';
    protected int $columns_count;
    protected bool $inline;
    public function __construct(?int $protocol = null)
    {
        if (!is_null($protocol)) $this->protocol = $protocol;
    }

    public function setSort(int $sort): self
    {
        $this->sort = $sort;
        return $this;
    }

    public function setName(string $name): self
    {
        $this->name = $name;
        return $this;
    }

    public function setColumnsCount(int $column_count): self
    {
        $this->columns_count = $column_count;
        return $this;
    }

    public function setInline(bool $inline): self
    {
        $this->inline = $inline;
        return $this;
    }


    public function getProtocol(): int
    {
        return $this->protocol;
    }

    public function getSort(): int
    {
        return $this->sort;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getColumnsCount(): int
    {
        return $this->columns_count;
    }

    public function isInline(): bool
    {
        return $this->inline;
    }


    /**
     * @throws DBException
     */
    public function getRowCount(): int
    {
        $stmt = self::PDO()->prepare('SELECT MAX(t.`total`) AS `total`
            FROM (SELECT IFNULL(MAX(`row_id`), 0) + 1 AS `total`
                  FROM `pb_system_diagnostic_chunk`
                  WHERE IF(:this IS NULL, `block` IS NULL, `block` = :this)
                    AND `protocol` = :protocol
                  UNION ALL
                  SELECT IFNULL(MAX(`row_id`), 0) + 1 AS `total`
                  FROM `pb_system_diagnostic_virtual_chunk`
                  WHERE IF(:this IS NULL, `block` IS NULL, `block` = :this)
                    AND `protocol` = :protocol
                  UNION ALL
                  SELECT IFNULL(MAX(`row_id`), 0) + 1 AS `total`
                  FROM `pb_system_diagnostic_aggregate_chunk`
                  WHERE IF(:this IS NULL, `block` IS NULL, `block` = :this)
                    AND `protocol` = :protocol) AS `t`;');
        $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT|PDO::PARAM_NULL);
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchColumn();
    }

    /**
     * @throws DBException
     */
    public function getInlineBlocksCount(): int
    {
        $stmt = self::PDO()->prepare('SELECT COUNT(psdb.`ID`) AS `cnt`
            FROM `pb_system_diagnostic_block` AS psdb
            WHERE psdb.`protocol` = :protocol
              AND psdb.`sort` > :sort
              AND (NOT EXISTS(SELECT `sort`
                              FROM `pb_system_diagnostic_block`
                              WHERE `protocol` = :protocol
                                AND `sort` > :sort
                                AND `inline` IS FALSE
                              ORDER BY `sort`)
                OR psdb.`sort` < (SELECT `sort`
                                  FROM `pb_system_diagnostic_block`
                                  WHERE `protocol` = :protocol
                                    AND `sort` > :sort
                                    AND `inline` IS FALSE
                                  ORDER BY `sort`
                                  LIMIT 1))
              AND psdb.`inline` IS TRUE;');
        $stmt->bindValue(':sort', $this->getSort(), PDO::PARAM_INT);
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchColumn() + 1;
    }

    /**
     * @return SystemDiagnosticBlock[]
     * @throws DBException
     */
    public function arrInlineBlocks(): array
    {
        $stmt = self::PDO()->prepare('SELECT psdb.*, TRUE AS `exists` 
            FROM `pb_system_diagnostic_block` AS psdb 
            WHERE psdb.`protocol`=:protocol
              AND psdb.`sort` > :sort
              AND (NOT EXISTS(SELECT `sort`
                              FROM `pb_system_diagnostic_block`
                              WHERE `protocol` = :protocol
                                AND `sort` > :sort
                                AND `inline` IS FALSE
                              ORDER BY `sort`)
                OR psdb.`sort` < (SELECT `sort`
                                  FROM `pb_system_diagnostic_block`
                                  WHERE `protocol` = :protocol
                                    AND `sort` > :sort
                                    AND `inline` IS FALSE
                                  ORDER BY `sort`
                                  LIMIT 1))
              AND psdb.`inline` IS TRUE
            ORDER BY psdb.`sort`, psdb.`ID`;');
        $stmt->bindValue(':sort', $this->getSort(), PDO::PARAM_INT);
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, SystemDiagnosticBlock::class));
    }

    /**
     * @return SystemDiagnosticChunkWithParameterName[]
     * @throws DBException
     */
    public function arrChunksWithNameForColumn(int $column): array
    {
        $stmt = self::PDO()->prepare('SELECT -- psdc.`row_id` AS `k`,
                psdc.`code`, 
                pcp.`name`                             AS `name`,
                pcpv.`custom_name`                     AS `custom_name`,
                pcp.`sorting_bit`                      AS `bit`,
                IF(pcp.`package`,pcr1.`header_length`,pcr0.`header_length`)       AS `header_length`,
                LENGTH(pcp.`bits`) - LENGTH(REPLACE(pcp.`bits`, \',\', \'\')) + 1 AS `length`,
                BinToUUID(pcpv.`identifier`)           AS `parameter_GUID`,
                pcp.`package`                          AS `package`,
                psdc.`row_id`                          AS `row_id`
            FROM `pb_system_diagnostic_chunk` AS `psdc`, 
                 `pb_command_parameter_view` AS pcpv,
                 `pb_command_parameter` AS pcp,
                 `pb_command_request` AS pcr0,
                 `pb_command_reply` AS pcr1
            WHERE IF(:this IS NULL, psdc.`block` IS NULL, psdc.`block`=:this)
              AND psdc.`protocol`=:protocol
              AND psdc.`column_id`=:column_id
              AND psdc.`protocol`=pcpv.`protocol`
              AND psdc.`code`=pcpv.`code`
              AND pcpv.`identifier`=pcp.`GUID`
              AND pcr0.`ID`=pcp.`command`
              AND pcr1.`ID`=pcp.`command`
            ORDER BY psdc.`row_id`;');
        $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT|PDO::PARAM_NULL);
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':column_id', $column, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, SystemDiagnosticChunkWithParameterName::class));
    }

    /**
     * @return SystemDiagnosticVirtualChunk[]
     * @throws DBException
     */
    public function arrVirtualChunksForColumn(int $column):array
    {
        $stmt = self::PDO()->prepare('SELECT 
               psdvc.`block`, psdvc.`row_id`, psdvc.`column_id`, psdvc.`protocol`, psdvc.`code` 
            FROM `pb_system_diagnostic_virtual_chunk` AS psdvc 
            WHERE IF(:this IS NULL, psdvc.`block` IS NULL, psdvc.`block`=:this)
              AND psdvc.`protocol`=:protocol
              AND psdvc.`column_id`=:column_id
            ORDER BY psdvc.`row_id`;');
        $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT|PDO::PARAM_NULL);
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':column_id', $column, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_FUNC, SystemDiagnosticVirtualChunk::fromDataBase(...)));
    }

    /**
     * @return SystemDiagnosticAggregateChunk[]
     * @throws DBException
     */
    public function arrAggregateChunksForColumn(int $column):array
    {
        $stmt = self::PDO()->prepare('SELECT 
               psdac.*, TRUE AS `exists`
            FROM `pb_system_diagnostic_aggregate_chunk` AS psdac 
            WHERE IF(:this IS NULL, psdac.`block` IS NULL, psdac.`block`=:this)
              AND psdac.`protocol`=:protocol
              AND psdac.`column_id`=:column_id
            ORDER BY psdac.`row_id`;');
        $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT|PDO::PARAM_NULL);
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':column_id', $column, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, SystemDiagnosticAggregateChunk::class));
    }

    /**
     * @return SystemDiagnosticChunk[]
     * @throws DBException
     */
    public function arrChunks(): array
    {
        $stmt = self::PDO()->prepare('SELECT `block`, `row_id`, `column_id`, `protocol`, `code`
            FROM `pb_system_diagnostic_chunk`
            WHERE IF(:this IS NULL, `block` IS NULL, `block`=:this)
              AND `protocol`=:protocol
            ORDER BY `block`, `column_id`, `row_id`, `code`;');
        $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT|PDO::PARAM_NULL);
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_FUNC, SystemDiagnosticChunk::fromDataBase(...)));
    }

    /**
     * @return SystemDiagnosticVirtualChunk[]
     * @throws DBException
     */
    public function arrVirtualChunks(): array
    {
        $stmt = self::PDO()->prepare('SELECT 
               `block`, `row_id`, `column_id`, `protocol`, `code` 
            FROM `pb_system_diagnostic_virtual_chunk`
            WHERE IF(:this IS NULL, `block` IS NULL, `block`=:this)
              AND `protocol`=:protocol
            ORDER BY `block`, `column_id`, `row_id`, `code`;');
        $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT|PDO::PARAM_NULL);
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_FUNC, SystemDiagnosticVirtualChunk::fromDataBase(...)));
    }

    /**
     * @return SystemDiagnosticAggregateChunk[]
     * @throws DBException
     */
    public function arrAggregateChunks(): array
    {
        $stmt = self::PDO()->prepare('SELECT 
               psdac.*, TRUE AS `exists`
            FROM `pb_system_diagnostic_aggregate_chunk` AS psdac
            WHERE IF(:this IS NULL, psdac.`block` IS NULL, psdac.`block`=:this)
              AND psdac.`protocol`=:protocol
            ORDER BY psdac.`block`, psdac.`column_id`, psdac.`row_id`, psdac.`ID`;');
        $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT|PDO::PARAM_NULL);
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, SystemDiagnosticAggregateChunk::class));
    }

    protected function tryInsert(): void
    {
        $stmt = self::PDO()->prepare('INSERT INTO `pb_system_diagnostic_block`(
                                         `protocol`, `sort`, `name`, `columns_count`, `inline`
                                         ) VALUES (:protocol, :sort, :name, :columns_count, :inline);');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':sort', $this->sort, PDO::PARAM_INT);
        $stmt->bindValue(':name', $this->name);
        $stmt->bindValue(':columns_count', $this->columns_count, PDO::PARAM_INT);
        $stmt->bindValue(':inline', $this->inline, PDO::PARAM_BOOL);
        $stmt->execute();
    }

    protected function tryUpdate(): void
    {
        $stmt = self::PDO()->prepare('UPDATE `pb_system_diagnostic_block` SET 
                                        `protocol`=:protocol,
                                        `sort`=:sort,
                                        `name`=:name,
                                        `columns_count`=:columns_count,
                                        `inline`=:inline
                                      WHERE `ID`=:this;');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':sort', $this->sort, PDO::PARAM_INT);
        $stmt->bindValue(':name', $this->name);
        $stmt->bindValue(':columns_count', $this->columns_count, PDO::PARAM_INT);
        $stmt->bindValue(':inline', $this->inline, PDO::PARAM_BOOL);
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
    }

    /**
     * @throws DBException
     */
    public static function dbLoad(?int $ID, int $protocol): self
    {
        return self::intoMe(self::PDOStatementForLoad($ID)->fetchObject(self::class, [$protocol]), $protocol);
    }
}