<?php

namespace Horizon\ProtocolBuilder\DataBase\Tables;

use Horizon\DataBaseController\dbTable;
use PDO;

class ParameterViewNumber extends dbTable
{
    protected int $protocol;
    protected string $code;
    protected int $id;
    protected string $expression;
    protected string $format;
    protected ?string $color;

    public function __construct(?int $protocol = null, ?string $code = null, ?int $id = null)
    {
        if (!is_null($protocol)) $this->protocol = $protocol;
        if (!is_null($code)) $this->code = $code;
        if (!is_null($id)) $this->id = $id;
    }

    public function setProtocol(int $protocol): self
    {
        $this->protocol = $protocol;
        return $this;
    }

    public function setCode(string $code): self
    {
        $this->code = $code;
        return $this;
    }

    public function setExpression(string $expression): self
    {
        $this->expression = $expression;
        return $this;
    }

    public function setFormat(string $format): self
    {
        $this->format = $format;
        return $this;
    }

    public function setColor(?string $color): self
    {
        $this->color = $color;
        return $this;
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function getExpression(): string
    {
        return htmlentities($this->expression, ENT_XML1);
    }

    public function getFormat(): string
    {
        return $this->format;
    }

    public function getColor(): ?string
    {
        return $this->color;
    }

    protected function tryInsert(): void
    {
        $stmt = self::PDO()->prepare('INSERT INTO `pb_command_parameter_view_number`(
                `protocol`, `code`, `id`, `expression`, `format`, `color`
            ) VALUES (:protocol, :code, :id, :expression, :format, :color);');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->bindValue(':id', $this->id, PDO::PARAM_INT);
        $stmt->bindValue(':expression', $this->expression);
        $stmt->bindValue(':format', $this->format);
        $stmt->bindValue(':color', $this->color, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->execute();
    }

    protected function tryUpdate(): void
    {
        $stmt = self::PDO()->prepare('UPDATE `pb_command_parameter_view_number` 
            SET `expression`=:expression,
                `format`=:format,
                `color`=:color 
            WHERE `protocol`=:protocol AND `code`=:code AND `id`=:id;');
        $stmt->bindValue(':expression', $this->expression);
        $stmt->bindValue(':format', $this->format);
        $stmt->bindValue(':color', $this->color, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->bindValue(':id', $this->id, PDO::PARAM_INT);
        $stmt->execute();
    }

    protected function tryDelete(): void
    {
        $stmt = self::PDO()->prepare('DELETE FROM `pb_command_parameter_view_number`
            WHERE `protocol`=:protocol AND `code`=:code AND `id`=:id;');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->bindValue(':id', $this->id, PDO::PARAM_INT);
        $stmt->execute();
    }
}