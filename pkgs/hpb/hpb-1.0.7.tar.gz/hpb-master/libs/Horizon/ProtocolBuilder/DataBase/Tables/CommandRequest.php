<?php
namespace Horizon\ProtocolBuilder\DataBase\Tables;

use Horizon\DataBaseController\dbTableAI;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\DataBaseController\iTableConfig;
use Horizon\ProtocolBuilder\DataBase\eTable;
use PDO;

final class CommandRequest extends dbTableAI
{
    protected static iTableConfig $table_config = eTable::pb_command_request;
    private int $length = 8;
    private int $start;
    private int $header_length = 7;
    private ?int $cycle_ms_time = null;

    private Command $REF_command;

    public function __construct(Command $command)
    {
        $this->REF_command = $command;
    }

    public function setLength(int $length): self
    {
        $this->length = $length;
        return $this;
    }

    public function setStart(int $start): self
    {
        $this->start = $start;
        return $this;
    }

    public function setHeaderLength(int $header_length): self
    {
        $this->header_length = $header_length;
        return $this;
    }

    public function setCycleMsTime(?float $cycle_ms_time): self
    {
        $this->cycle_ms_time = $cycle_ms_time === null ? null : round($cycle_ms_time * 10000);
        return $this;
    }

    public function getLength(): int
    {
        return $this->length;
    }

    public function getStart(): int
    {
        return $this->start;
    }

    public function getHeaderLength(): int
    {
        return $this->header_length;
    }

    public function getCycleMsTime(): ?float
    {
        return $this->cycle_ms_time === null ? null : $this->cycle_ms_time / 10000;
    }

    /**
     * @throws DBException
     */
    public function getUnavailableBits(): array
    {
        $parameters = $this->REF_command->arrParametersToRequest();
        $result = [];
        foreach ($parameters as &$parameter)
            $result = array_merge($result, $parameter->getBits());
        return $result;
    }

    /**
     * @throws DBException
     */
    public function getLastNumberInPackage(): int
    {
        return $this->REF_command->getLastNumberInPackage('param', false);
    }

    /**
     * @throws DBException
     */
    public function initCodeForParameterView(?int $id, ?string $add): string
    {
        $code = $this->REF_command->initCodeOrigin('param', false);
        $code[] = str_pad($id ?? $this->getLastNumberInPackage(), 3, '0', STR_PAD_LEFT);
        if (!is_null($add)) $code[] = $add;
        return implode('_', $code);
    }

    protected function tryInsert(): void
    {
        $stmt = self::PDO()->prepare('INSERT 
            INTO `pb_command_request`(`ID`, `length`, `start`, `header_length`, `cycle_ms_time`) 
            VALUES (:this,:length,:start,:header_length,:cycle_ms_time) 
            ON DUPLICATE KEY UPDATE `length`=:length, 
                                    `start`=:start, 
                                    `header_length`=:header_length, 
                                    `cycle_ms_time`=:cycle_ms_time;');
        $stmt->bindValue(':this', $this->REF_command->getID(), PDO::PARAM_INT);
        $stmt->bindValue(':length', $this->length, PDO::PARAM_INT);
        $stmt->bindValue(':start', $this->start, PDO::PARAM_INT);
        $stmt->bindValue(':header_length', $this->header_length, PDO::PARAM_INT);
        $stmt->bindValue(':cycle_ms_time', $this->cycle_ms_time, PDO::PARAM_INT|PDO::PARAM_NULL);
        $stmt->execute();
    }

    protected function tryUpdate(): void
    {
        $this->tryInsert();
    }

    protected function tryDelete(): void
    {
        // TODO: Implement tryDelete() method.
    }

    /**
     * @throws DBException
     */
    public static function dbLoad(Command $command): self
    {
        return static::intoMe(static::PDOStatementForLoad($command->getID())
            ->fetchObject(static::class, [$command]), $command);
    }
}