<?php

namespace Horizon\ProtocolBuilder\DataBase\Tables;

use Horizon\DataBaseController\dbTableAI;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\DataBaseController\iTableConfig;
use Horizon\ProtocolBuilder\DataBase\eTable;
use PDO;

final class CommandReply extends dbTableAI
{
    protected static iTableConfig $table_config = eTable::pb_command_reply;
    private int $length = 8;
    private int $start;
    private int $header_length = 3;
    private bool $request_required = false;

    private Command $REF_command;

    public function __construct(Command $command)
    {
        $this->REF_command = $command;
    }

    public function setLength(int $length): self
    {
        $this->length = $length;
        return $this;
    }

    public function setStart(int $start): self
    {
        $this->start = $start;
        return $this;
    }

    public function setHeaderLength(int $header_length): self
    {
        $this->header_length = $header_length;
        return $this;
    }

    public function setRequestRequired(bool $request_required): self
    {
        $this->request_required = $request_required;
        return $this;
    }

    public function getLength(): int
    {
        return $this->length;
    }

    public function getStart(): int
    {
        return $this->start;
    }

    public function getHeaderLength(): int
    {
        return $this->header_length;
    }

    public function isRequestRequired(): bool
    {
        return $this->request_required;
    }

    /**
     * @throws DBException
     */
    public function getUnavailableBits(): array
    {
        $parameters = $this->REF_command->arrParametersToReply();
        $result = [];
        foreach ($parameters as &$parameter)
            $result = array_merge($result, $parameter->getBits());
        return $result;
    }

    /**
     * @throws DBException
     */
    public function getLastNumberInPackage(): int
    {
        return $this->REF_command->getLastNumberInPackage('param', true);
    }

    /**
     * @throws DBException
     */
    public function initCodeForParameterView(?int $id, ?string $add): string
    {
        $code = $this->REF_command->initCodeOrigin('param', true);
        $code[] = str_pad($id ?? $this->getLastNumberInPackage(), 3, '0', STR_PAD_LEFT);
        if (!is_null($add)) $code[] = $add;
        return implode('_', $code);
    }

    protected function tryInsert(): void
    {
        $stmt = self::PDO()->prepare('INSERT INTO `pb_command_reply`(`ID`, `length`, `start`, `header_length`, `request_required`) 
            VALUES (:this,:length,:start,:header_length,:request_required) 
            ON DUPLICATE KEY UPDATE `length`=:length, `start`=:start, `header_length`=:header_length, `request_required`=:request_required;');
        $stmt->bindValue(':this', $this->REF_command->getID(), PDO::PARAM_INT);
        $stmt->bindValue(':length', $this->length, PDO::PARAM_INT);
        $stmt->bindValue(':start', $this->start, PDO::PARAM_INT);
        $stmt->bindValue(':header_length', $this->header_length, PDO::PARAM_INT);
        $stmt->bindValue(':request_required', $this->request_required, PDO::PARAM_BOOL);
        $stmt->execute();
    }

    protected function tryUpdate(): void
    {
        $this->tryInsert();
    }

    protected function tryDelete(): void
    {
        // TODO: Implement tryDelete() method.
    }

    /**
     * @throws DBException
     */
    public static function dbLoad(Command $command): static
    {
        return static::intoMe(static::PDOStatementForLoad($command->getID())
            ->fetchObject(static::class, [$command]), $command);
    }
}