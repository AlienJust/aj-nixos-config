<?php

namespace Horizon\ProtocolBuilder\DataBase\Models;

class ParameterViewUsableBySystemDiagnosticChunk extends SystemDiagnosticChunkWithParameterName
{
    public readonly string $code;
    public readonly string $name;
    public readonly int $bit;
    public readonly int $header_length;
    public readonly bool $is_use;
    protected readonly int $length;
}