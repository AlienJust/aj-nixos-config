<?php

namespace Horizon\ProtocolBuilder\DataBase\Tables;

use Horizon\DataBaseController\dbTable;
use Horizon\DataBaseController\Exceptions\DBException;
use PDO;

final class ParameterView extends dbTable
{
    protected int $protocol;
    protected string $code;
    protected string $code_new;
    protected string $identifier;
    protected string $comment;
    protected ?string $custom_name = null;
    protected ?string $format = null;
    protected ?string $mask = null;

    /** @var ParameterViewValue[]|null $ARR_values */
    protected ?array $ARR_values = null;
    /** @var ParameterViewNumber[]|null $ARR_numbers */
    protected ?array $ARR_numbers = null;
    protected ?ParameterViewInjection $REF_injection = null;

    public function __construct(?int $protocol = null, ?string $key = null)
    {
        if(!is_null($protocol)) $this->protocol = $protocol;
        if(!is_null($key)) $this->code = $key;
    }

    public function setCode(string $code): self
    {
        $this->code_new = $code;
        return $this;
    }

    public function setIdentifier(string $identifier): self
    {
        $this->identifier = $identifier;
        return $this;
    }

    public function setComment(string $comment): self
    {
        $this->comment = $comment;
        return $this;
    }

    public function setCustomName(?string $custom_name): self
    {
        $this->custom_name = $this->setterHandlerForStringToNull($custom_name);
        return $this;
    }

    public function setFormat(?string $format): self
    {
        $this->format = $this->setterHandlerForStringToNull($format);
        return $this;
    }

    public function setMask(?string $mask): self
    {
        $this->mask = $mask;
        return $this;
    }

    public function addViewValue(ParameterViewValue ...$values): void
    {
        if (is_null($this->ARR_values)) $this->ARR_values = [];
        foreach ($values as $value) $this->ARR_values[] = $value;
    }

    public function addViewNumber(ParameterViewNumber ...$numbers): self
    {
        if (is_null($this->ARR_numbers)) $this->ARR_numbers = [];
        foreach ($numbers as $number) $this->ARR_numbers[] = $number;
        return $this;
    }

    public function setInjection(?ParameterViewInjection $injection): self
    {
        $this->REF_injection = $injection;
        return $this;
    }

    public function getProtocol(): int
    {
        return $this->protocol;
    }

    public function getCode(): string
    {
        return $this->code;
    }

    public function getIdentifier(): string
    {
        return $this->identifier;
    }

    public function getComment(): string
    {
        return $this->comment;
    }

    public function getCustomName(): ?string
    {
        return $this->custom_name;
    }

    public function getFormat(): ?string
    {
        return $this->format;
    }

    public function getMask(): ?string
    {
        return $this->mask;
    }

    public function isByDiagnosticSystem(): bool
    {
        return mb_substr($this->code, -3) == '_ds';
    }

    public function refInjection(): ?ParameterViewInjection
    {
        $injection = ParameterViewInjection::dbLoad($this->protocol, $this->code);
        return $injection->exists() ? $injection : null;
    }

    /**
     * @throws DBException
     */
    public function refSystemDiagnosticView(): self
    {
        if ($this->isByDiagnosticSystem()) return $this;
        $code_parts = array_slice(explode('_', $this->code),0,5);
        $code_parts[] = 'ds';
        $view = ParameterView::dbLoad($this->protocol, implode('_', $code_parts));
        if (!$view->exists()) $view->setIdentifier($this->identifier)
            ->setComment($this->comment)
            ->setFormat($this->format)
            ->setCustomName($this->custom_name);
        return $view;
    }

    /**
     * @throws DBException
     */
    public function isLinkToSystemDiagnostic(): bool
    {
        $stmt = self::PDO()->prepare('SELECT EXISTS(SELECT * FROM `pb_system_diagnostic_chunk` 
                       WHERE `protocol`=:protocol 
                         AND `code`=:code);');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->execute();
        $result1 = $stmt->fetchColumn();
        $stmt = self::PDO()->prepare('SELECT EXISTS(SELECT * FROM `pb_system_diagnostic_aggregate_parameter` 
                       WHERE `protocol`=:protocol 
                         AND `code`=:code);');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->execute();
        $result2 = $stmt->fetchColumn();
        return $result1 || $result2;
    }

    /**
     * @return ParameterViewValue[]
     * @throws DBException
     */
    public function arrViewValues(): array
    {
        $stmt = self::PDO()->prepare('SELECT pcpvv.*, TRUE AS `exists` 
            FROM `pb_command_parameter_view_value` AS pcpvv 
            WHERE pcpvv.`protocol`=:protocol
              AND pcpvv.`code`=:code
            ORDER BY pcpvv.`id`;');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, ParameterViewValue::class));
    }

    /**
     * @return ParameterViewNumber[]
     * @throws DBException
     */
    public function arrViewNumbers(): array
    {
        $stmt = self::PDO()->prepare('SELECT pcpvv.*, TRUE AS `exists` 
            FROM `pb_command_parameter_view_number` AS pcpvv 
            WHERE pcpvv.`protocol`=:protocol
              AND pcpvv.`code`=:code
            ORDER BY pcpvv.`id`;');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, ParameterViewNumber::class));
    }

    /**
     * @return int
     * @throws DBException
     */
    public function getNexIDForViewNumbers(): int
    {
        $stmt = self::PDO()->prepare('SELECT COUNT(pcpvv.`id`) AS `cnt`
            FROM `pb_command_parameter_view_number` AS pcpvv 
            WHERE pcpvv.`protocol`=:protocol
              AND pcpvv.`code`=:code;');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->execute();
        return self::PDOObjectInspect($stmt->fetchColumn());
    }

    protected function tryInsert(): void
    {
        $stmt = self::PDO()->prepare('INSERT INTO `pb_command_parameter_view`(
                 `protocol`,`code`, `identifier`, `comment`, `custom_name`, `format`, `mask`
            ) VALUES (:protocol, :code, UUIDToBin(:identifier), :comment, :custom_name, :format, :mask);');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->bindValue(':identifier', $this->identifier);
        $stmt->bindValue(':comment', $this->comment);
        $stmt->bindValue(':custom_name', $this->custom_name, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->bindValue(':format', $this->format, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->bindValue(':mask', $this->mask, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->execute();
        if (!is_null($this->ARR_values)) foreach ($this->ARR_values as $value)
            $value->setProtocol($this->protocol)->setCode($this->code)->tryInsert();
        if (!is_null($this->ARR_numbers)) foreach ($this->ARR_numbers as $number)
            $number->setProtocol($this->protocol)->setCode($this->code)->tryInsert();
        if (!is_null($this->REF_injection))
            $this->REF_injection->setProtocol($this->protocol)->setCode($this->code)->tryInsert();
    }

    protected function tryUpdate(): void
    {
        $stmt = self::PDO()->prepare('UPDATE `pb_command_parameter_view` 
            SET `code`=:code_new,
                `identifier`=UUIDToBin(:identifier),
                `comment`=:comment,
                `custom_name`=:custom_name,
                `format`=:format,
                `mask`=:mask
            WHERE `protocol`=:protocol
              AND `code`=:code;');
        $stmt->bindValue(':code_new', $this->code_new ?? $this->code);
        $stmt->bindValue(':identifier', $this->identifier);
        $stmt->bindValue(':comment', $this->comment);
        $stmt->bindValue(':custom_name', $this->custom_name, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->bindValue(':format', $this->format, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->bindValue(':mask', $this->mask, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->bindValue(':code', $this->code);
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->execute();
        $this->code = $this->code_new ?? $this->code;
        $this->tryClearValues();
        if (!is_null($this->ARR_values)) foreach ($this->ARR_values as $value)
            $value->setProtocol($this->protocol)->setCode($this->code)->tryInsert();
        if (!is_null($this->ARR_numbers)) foreach ($this->ARR_numbers as $number)
            $number->setProtocol($this->protocol)->setCode($this->code)->tryInsert();
        if (is_null($this->REF_injection)) ParameterViewInjection::dbLoad($this->protocol, $this->code)->tryDelete();
        else {
            $this->REF_injection->setProtocol($this->protocol)->setCode($this->code)->tryInsertUpdate();
        }
    }

    protected function tryDelete(): void
    {
        $stmt = self::PDO()->prepare('DELETE FROM `pb_command_parameter_view` 
            WHERE `protocol`=:protocol
              AND `code`=:code;');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->execute();
    }

    /**
     * @throws DBException
     */
    public function tryClearValues(): void
    {
        $stmt = self::PDO()->prepare('DELETE FROM `pb_command_parameter_view_value`
                WHERE `protocol`=:protocol 
                  AND `code`=:code;');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->execute();
        $stmt = self::PDO()->prepare('DELETE FROM `pb_command_parameter_view_number`
                WHERE `protocol`=:protocol 
                  AND `code`=:code;');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->execute();
        $stmt = self::PDO()->prepare('DELETE FROM `pb_command_parameter_view_inject_value`
                WHERE `protocol`=:protocol 
                  AND `code`=:code;');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->execute();
    }

    /**
     * @throws DBException
     */
    public function countViewValues(): int
    {
        $stmt = self::PDO()->prepare('SELECT COUNT(`id`) FROM `pb_command_parameter_view_value`
                WHERE `protocol`=:protocol 
                  AND `code`=:code;');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->execute();
        return $stmt->fetchColumn();
    }

    /**
     * @throws DBException
     */
    public function countViewNumbers(): int
    {
        $stmt = self::PDO()->prepare('SELECT COUNT(`id`) FROM `pb_command_parameter_view_number`
                WHERE `protocol`=:protocol 
                  AND `code`=:code;');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->execute();
        return $stmt->fetchColumn();
    }

    /**
     * @throws DBException
     */
    public function countViewInjectValues(): int
    {
        $stmt = self::PDO()->prepare('SELECT COUNT(`id`) FROM `pb_command_parameter_view_inject_value`
                WHERE `protocol`=:protocol 
                  AND `code`=:code;');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->execute();
        return $stmt->fetchColumn();
    }

    /**
     * @throws DBException
     */
    public static function dbLoad(int $protocol, string $key): self
    {
        $stmt = self::PDO()->prepare('SELECT 
                BinToUUID(`identifier`) AS identifier, 
                `comment`, 
                `custom_name`, 
                `format`,
                `mask`
            FROM `pb_command_parameter_view` 
            WHERE `protocol`=:protocol
              AND `code`=:code;');
        $stmt->bindValue(':protocol', $protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $key);
        $stmt->execute();
        return self::intoMe($stmt->fetchObject(self::class, [$protocol,$key]), $protocol, $key);
    }
}