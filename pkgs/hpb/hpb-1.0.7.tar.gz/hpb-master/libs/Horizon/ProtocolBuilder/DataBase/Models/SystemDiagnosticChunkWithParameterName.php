<?php

namespace Horizon\ProtocolBuilder\DataBase\Models;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToReply;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToRequest;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\LogicItems\ParameterAddress;
use Horizon\ProtocolBuilder\UserInterface\eUISA_ReplyParameter;
use Horizon\ProtocolBuilder\UserInterface\eUISA_RequestParameter;

class SystemDiagnosticChunkWithParameterName
{
    public readonly string $code;
    public readonly string $name;
    public readonly ?string $custom_name;
    public readonly int $bit;
    public readonly int $header_length;
    protected readonly int $length;
    protected readonly string $parameter_GUID;
    protected readonly bool $package;
    public readonly int $row_id;

    public function getRowId(): int
    {
        return $this->row_id;
    }

    public function getLabel(): string
    {
        $address = $this->getAddress();
        $name = $this->custom_name ?? $this->name;
        return "$address - $name ($this->code)";
    }

    public function getAddress(): string
    {
        return (new ParameterAddress($this->bit, $this->header_length, $this->length))->draw();
    }

    /**
     * @throws DBException
     * @throws VException
     */
    public function getURL(): string
    {
        return $this->package
            ? eUISA_ReplyParameter::new_view->initController()
                ->setParameter(ParameterToReply::dbLoad($this->parameter_GUID))
                ->refURL()//->setQueryItem(eParameterField::view_code->code(), $this->code)
                ->draw()
            : eUISA_RequestParameter::new_view->initController()
                ->setParameter(ParameterToRequest::dbLoad($this->parameter_GUID))
                ->refURL()//->setQueryItem(eParameterField::view_code->code(), $this->code)
                ->draw();
    }
}