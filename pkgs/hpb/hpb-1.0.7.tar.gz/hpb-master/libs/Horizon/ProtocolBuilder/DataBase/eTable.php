<?php

namespace Horizon\ProtocolBuilder\DataBase;

use Horizon\DataBaseController\iTableConfig;

enum eTable implements iTableConfig
{
    case pb_command;
    case pb_command_reply;
    case pb_command_parameter;
    case pb_command_request;
    case pb_command_request_parameter;
    case pb_protocol;
    case pb_subscriber;
    case pb_system_diagnostic_block;
    case pb_system_diagnostic_chunk;
    case pb_system_diagnostic_virtual_chunk;
    case pb_system_diagnostic_aggregate_chunk;
    case pb_system_diagnostic_aggregate_parameter;

    public function getName(): string
    {
        return $this->name;
    }
}