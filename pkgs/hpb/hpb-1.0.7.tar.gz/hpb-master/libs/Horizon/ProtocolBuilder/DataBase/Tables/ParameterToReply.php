<?php

namespace Horizon\ProtocolBuilder\DataBase\Tables;

final class ParameterToReply extends Parameter
{
    protected const true PACKAGE_TYPE = true;
}