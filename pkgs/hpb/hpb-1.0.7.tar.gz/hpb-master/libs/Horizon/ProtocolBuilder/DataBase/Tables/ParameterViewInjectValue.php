<?php

namespace Horizon\ProtocolBuilder\DataBase\Tables;

use Horizon\DataBaseController\dbTable;
use PDO;

class ParameterViewInjectValue extends dbTable
{
    protected int $protocol;
    protected string $code;
    protected int $id;
    protected string $text;
    protected string $value;

    public function __construct(?int $protocol = null, ?string $code = null, ?int $id = null)
    {
        if (!is_null($protocol)) $this->protocol = $protocol;
        if (!is_null($code)) $this->code = $code;
        if (!is_null($id)) $this->id = $id;
    }

    public function setProtocol(int $protocol): self
    {
        $this->protocol = $protocol;
        return $this;
    }

    public function setCode(string $code): self
    {
        $this->code = $code;
        return $this;
    }

    public function setText(string $text): self
    {
        $this->text = $text;
        return $this;
    }

    public function setValue(string $value): self
    {
        $this->value = $value;
        return $this;
    }

    public function getText(): string
    {
        return $this->text;
    }

    public function getValue(): string
    {
        return $this->value;
    }

    protected function tryInsert(): void
    {
        $stmt = self::PDO()->prepare('INSERT INTO `pb_command_parameter_view_inject_value`(
            `protocol`, `code`, `id`, `text`, `value`
        ) VALUES (:protocol, :code, :id, :text, :value);');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->bindValue(':id', $this->id, PDO::PARAM_INT);
        $stmt->bindValue(':text', $this->text);
        $stmt->bindValue(':value', $this->value);
        $stmt->execute();
    }

    protected function tryUpdate(): void
    {
        // TODO: Implement tryUpdate() method.
    }

    protected function tryDelete(): void
    {
        // TODO: Implement tryDelete() method.
    }
}