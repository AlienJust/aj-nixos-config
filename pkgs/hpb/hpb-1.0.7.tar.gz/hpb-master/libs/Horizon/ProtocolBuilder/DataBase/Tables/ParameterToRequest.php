<?php

namespace Horizon\ProtocolBuilder\DataBase\Tables;

final class ParameterToRequest extends Parameter
{
    protected const false PACKAGE_TYPE = false;
}