<?php

namespace Horizon\ProtocolBuilder\DataBase\Tables;

use Horizon\DataBaseController\dbTableAI;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\DataBaseController\iTableConfig;
use Horizon\ProtocolBuilder\DataBase\eTable;
use Horizon\ProtocolBuilder\Exceptions\VEx;
use Horizon\ProtocolBuilder\Exceptions\VException;
use PDO;

final class Subscriber extends dbTableAI
{
    protected static iTableConfig $table_config = eTable::pb_subscriber;
    private int $protocol;
    private int $address;
    private string $name = '';
    private string $short_name = '';
    private string $description = '';
    private bool $hide_for_production = true;

    private Protocol $REF_protocol;

    public function __construct(?int $protocol = null, ?int $address = null)
    {
        if (!is_null($protocol)) $this->protocol = $protocol;
        if (!is_null($address)) $this->address = $address;
    }

    public function setAddress(int $address): static
    {
        $this->address = $address;
        return $this;
    }

    /**
     * @throws VException
     */
    public function setName(string $name): static
    {
        $this->name = $name;
        if ($this->name == '') throw new VException(VEx::empty);
        return $this;
    }

    /**
     * @throws VException
     */
    public function setShortName(string $short_name): static
    {
        $this->short_name = $short_name;
        if ($this->short_name == '') throw new VException(VEx::empty);
        return $this;
    }

    public function setDescription(string $description): static
    {
        $this->description = $description;
        return $this;
    }

    public function setHideForProduction(bool $hide_for_production): static
    {
        $this->hide_for_production = $hide_for_production;
        return $this;
    }

    public function getProtocol(): int
    {
        return $this->protocol;
    }

    public function getAddress(): int
    {
        return $this->address;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getShortName(): string
    {
        return $this->short_name;
    }

    public function getDescription(): string
    {
        return $this->description;
    }

    public function isHideForProduction(): bool
    {
        return $this->hide_for_production;
    }

    /**
     * @throws DBException
     */
    public function refProtocol(): Protocol
    {
        return $this->REF_protocol ?? ($this->REF_protocol = Protocol::dbLoad($this->protocol));
    }

    /**
     * @return Command[]
     * @throws DBException
     */
    public function arrCommands(): array
    {
        $stmt = self::PDO()->prepare('SELECT pbc.*, TRUE AS `exists` 
            FROM `pb_command` AS pbc 
            WHERE pbc.`subscriber`=:this;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, Command::class));
    }

    protected function tryInsert(): void
    {
        $stmt = self::PDO()->prepare('INSERT INTO `pb_subscriber`(
                            `protocol`, `address`, `name`, `short_name`, `description`, `hide_for_production`
                            ) VALUES (:protocol, :address, :name, :short_name, :description, :hide_for_production);');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':address', $this->address, PDO::PARAM_INT);
        $stmt->bindValue(':name', $this->name);
        $stmt->bindValue(':short_name', $this->short_name);
        $stmt->bindValue(':description', $this->description);
        $stmt->bindValue(':hide_for_production', $this->hide_for_production, PDO::PARAM_BOOL);
        $stmt->execute();
        $this->ID = self::PDO()->lastInsertId();
    }

    protected function tryUpdate(): void
    {
        $stmt = self::PDO()->prepare('UPDATE `pb_subscriber` SET 
                           `protocol`=:protocol, 
                           `address`=:address, 
                           `name`=:name,
                           `short_name`=:short_name,
                           `description`=:description,
                           `hide_for_production`=:hide_for_production
            WHERE `ID`=:this;');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':address', $this->address, PDO::PARAM_INT);
        $stmt->bindValue(':name', $this->name);
        $stmt->bindValue(':short_name', $this->short_name);
        $stmt->bindValue(':description', $this->description);
        $stmt->bindValue(':hide_for_production', $this->hide_for_production, PDO::PARAM_BOOL);
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
    }

    /**
     * @throws DBException
     */
    public static function dbLoad(?int $ID, ?int $protocol = null): static
    {
        return static::intoMe(static::PDOStatementForLoad($ID)->fetchObject(static::class, [$protocol]), $protocol);
    }

    /**
     * @throws DBException
     * @throws VException
     */
    public static function dbFind(int $protocol, int $address, string $name): static
    {
        $stmt = self::PDO()->prepare('SELECT pbs.*, TRUE AS `exists`
            FROM `pb_subscriber` AS pbs
            WHERE pbs.`protocol`=:protocol
              AND pbs.`address`=:address
              AND pbs.`name`=:name;');
        $stmt->bindValue(':protocol', $protocol, PDO::PARAM_INT);
        $stmt->bindValue(':address', $address, PDO::PARAM_INT);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        return static::intoMe($stmt->fetchObject(static::class, [$protocol, $address]), $protocol, $address)
            ->setName($name);
    }
}