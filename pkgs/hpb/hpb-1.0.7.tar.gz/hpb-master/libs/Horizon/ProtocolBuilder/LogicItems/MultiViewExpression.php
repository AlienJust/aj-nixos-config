<?php

namespace Horizon\ProtocolBuilder\LogicItems;

class MultiViewExpression
{
    public readonly string $value;
    public function __construct(?string $mask, bool $is_format_exists, int $bool_view_count, int $number_view_count)
    {
        if (is_null($mask)) {
            $codes = [];
            if ($is_format_exists) $codes[] = '{$value}';
            if ($bool_view_count > 0) $codes[] = implode("", array_map(fn(int $id) => '{$text' . $id . '}', range(1, $bool_view_count)));
            if ($number_view_count > 0) $codes[] = implode(" ", array_map(fn(int $id) => '{$text' . $id . '}', range(1, $number_view_count)));
            $this->value = implode(" – ", $codes);
        } else $this->value = $mask;
    }
}