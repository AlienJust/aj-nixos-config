<?php

namespace Horizon\ProtocolBuilder\LogicItems;

class ValueBitChunk
{
    private int $byte;
    private int $bit;
    private int $count;
    private bool $sign = false;

    public function __construct(int $byte, int $bit)
    {
        $this->byte = $byte;
        $this->bit = $bit;
        $this->count = 1;
    }

    public function setSign(bool $sign): void
    {
        $this->sign = $sign;
    }

    public function getByte(): int
    {
        return $this->byte;
    }

    public function getCount():int
    {
        return $this->count;
    }

    public function addBit(int $bit): ?static
    {
        if ($this->bit - $bit == 1) {
            $this->bit = $bit;
            $this->count++;
            return null;
        } else return new ValueBitChunk($this->byte, $bit);
    }

    public function draw(string $power): string
    {
        if ($this->bit == 0 && $this->count == 8) {
            $sign = $this->sign ? 's' : 'u';
            return "[$sign$this->byte]$power";
        } else {
            if ($this->sign) {
                $count = $this->count - 1;
                $sign = $this->bit + $count;
                return "[$this->byte.$this->bit.$count] * ([$this->byte.$sign.1] * 2 - 1)$power";
            } else return "[$this->byte.$this->bit.$this->count]$power";
        }
    }
}