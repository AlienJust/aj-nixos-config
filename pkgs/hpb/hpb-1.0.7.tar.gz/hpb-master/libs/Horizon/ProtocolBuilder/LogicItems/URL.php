<?php

namespace Horizon\ProtocolBuilder\LogicItems;

class URL
{
    private string $address;
    private array $query_parameters = [];
    private ?string $bookmark = null;

    /* @todo: использовать это, когда изменим в .htaccess обработку URL-адресов

    if (static::$section->value != '') $URL[] = static::$section->value;
    if (!is_null($ID)) $URL[] = strval($ID);
    if (!is_null($action)) $URL[] = $action;
    return implode('/', $URL);

     */

    public function __construct(string $address = '/')
    {
        $this->address = $address;
    }

    public function setBookmark(?string $bookmark): void
    {
        $this->bookmark = $bookmark;
    }

    public function setQueryItem(string $name, string|array|null $value): self
    {
        if (!is_null($value)) $this->query_parameters[$name] = $value;
        return $this;
    }

    private function clearQueryItem(string $name): void
    {
        if (isset($this->query_parameters[$name])) unset($this->query_parameters[$name]);
    }

    private function initBookmark(?string $ID): void
    {
        if (!is_null($ID)) {
            $bookmark = [];
            if (isset($this->query_parameters['section'])) $bookmark[] = $this->query_parameters['section'];
            $bookmark[] = $ID;
            $this->setBookmark(implode('_', $bookmark));
        }
    }

    public function setSectionAction(?string $section, ?string $action): self
    {
        $this->setQueryItem('section', $section);
        $this->setQueryItem('action', $action);
        return $this;
    }

    public function setProtocol(?int $ID): self
    {
        $this->setQueryItem('ID', $ID);
        $this->initBookmark($ID);
        return $this;
    }

    public function setSubscriber(int $protocol, ?int $ID): self
    {
        $this->setQueryItem('protocol', $protocol);
        $this->setQueryItem('ID', $ID);
        $this->initBookmark($ID);
        return $this;
    }

    public function setCommand(int $protocol, int $subscriber, ?int $ID): self
    {
        $this->setQueryItem('protocol', $protocol);
        $this->setQueryItem('subscriber', $subscriber);
        $this->setQueryItem('ID', $ID);
        $this->initBookmark($ID);
        return $this;
    }

    public function setParameter(int $protocol, int $subscriber, int $command, ?string $GUID): self
    {
        $this->setQueryItem('protocol', $protocol);
        $this->setQueryItem('subscriber', $subscriber);
        $this->setQueryItem('command', $command);
        $this->setQueryItem('ID', $GUID);
        $this->initBookmark($GUID);
        return $this;
    }

    public function setAnyID(?int $ID): self
    {
        $this->setQueryItem('ID', $ID);
        $this->initBookmark($ID);
        return $this;
    }

    public function getBookmark(): string
    {
        return $this->bookmark ?? '';
    }

    public function draw(): string
    {
        if (empty($this->query_parameters) && is_null($this->bookmark) && $this->address == '/') return '';
        $query = http_build_query($this->query_parameters);
        $query = $query == '' ? $query : "?$query";
        $bookmark = is_null($this->bookmark) ? '' : "#$this->bookmark";
        return $this->address . $query . $bookmark;
    }
}