<?php

namespace Horizon\ProtocolBuilder\LogicItems;

class ToIntNullableHandler
{
    private function __construct()
    {
    }

    public static function run(?string $text): ?int
    {
        $text = ToStringNullableHandler::run($text);
        if (!is_numeric($text)) return null;
        else return (int)$text;
    }
}