<?php

namespace Horizon\ProtocolBuilder\LogicItems;

use Horizon\ProtocolBuilder\Exceptions\VEx;
use Horizon\ProtocolBuilder\Exceptions\VException;

class ToIntRequiredHandler
{
    private function __construct()
    {
    }

    /**
     * @throws VException
     */
    public static function run(?string $text, string $param): ?int
    {
        $text = ToStringNullableHandler::run($text);
        if (!is_numeric($text)) throw new VException(VEx::empty, $param);
        else return (int)$text;
    }
}