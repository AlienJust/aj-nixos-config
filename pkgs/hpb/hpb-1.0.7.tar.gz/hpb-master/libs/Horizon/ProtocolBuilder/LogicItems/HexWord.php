<?php

namespace Horizon\ProtocolBuilder\LogicItems;

class HexWord
{
    public readonly string $hi;
    public readonly string $lo;
    public function __construct(int $value)
    {
        $hex = str_pad(dechex($value), 4, "0", STR_PAD_LEFT);
        list($hi, $lo) = mb_str_split($hex, 2);
        if (hexdec($hi) == 0) {
            $this->hi = 0;
            $this->lo = hexdec($lo);
        } else {
            $this->hi = "0x$hi";
            $this->lo = "0x$lo";
        }
    }
}