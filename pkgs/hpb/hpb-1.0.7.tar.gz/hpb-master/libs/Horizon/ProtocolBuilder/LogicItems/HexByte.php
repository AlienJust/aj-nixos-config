<?php

namespace Horizon\ProtocolBuilder\LogicItems;

class HexByte
{
    public readonly string $hex;

    public function __construct(int $value)
    {
        $this->hex = '0x' . mb_strtoupper(str_pad(dechex($value), 2, '0', STR_PAD_LEFT));
    }
}