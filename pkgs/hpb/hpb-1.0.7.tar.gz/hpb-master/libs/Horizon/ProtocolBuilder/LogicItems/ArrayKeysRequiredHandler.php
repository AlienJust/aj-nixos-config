<?php

namespace Horizon\ProtocolBuilder\LogicItems;

use Horizon\ProtocolBuilder\Exceptions\VEx;
use Horizon\ProtocolBuilder\Exceptions\VException;

class ArrayKeysRequiredHandler
{
    private function __construct()
    {
    }

    /**
     * @throws VException
     */
    public static function run(array $arr, string $param): ?array
    {
        $arr = array_keys($arr);
        if (count($arr) == 0) throw new VException(VEx::empty, $param);
        return $arr;
    }
}