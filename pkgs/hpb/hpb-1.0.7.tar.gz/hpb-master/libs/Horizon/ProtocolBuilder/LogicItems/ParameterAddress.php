<?php

namespace Horizon\ProtocolBuilder\LogicItems;

class ParameterAddress
{
    private int $byte;
    private ?int $bit;
    public readonly ?int $word_number;
    private ?int $word_bit;
    private bool $unknown;

    public function __construct(?int $bit, int $offset, int $length)
    {
        if ($bit === null) $this->unknown = true;
        else {
            $this->unknown = false;
            $this->byte = floor($bit / 8);
            $this->bit = $length % 8 == 0 ? null : 7 - $bit % 8;
            $this->word_number = floor(($this->byte - $offset) / 2);
            $this->word_bit = $length % 8 == 0 ? null : 15 - ($bit - $offset * 8) % 16;
        }
    }


    public function draw(): string
    {
        if ($this->unknown) return "-?-";
        $word_bit = is_null($this->word_bit) ? '' : ".$this->word_bit";
        $word_number = !is_null($this->word_number) && $this->word_number >= 0 ? " [$this->word_number$word_bit]" : '';
        $byte = str_pad($this->byte + 1, 2, "0", STR_PAD_LEFT);
        $bit = is_null($this->bit) ? '' : "-b.$this->bit";
        return "$byte$bit$word_number";
    }
}