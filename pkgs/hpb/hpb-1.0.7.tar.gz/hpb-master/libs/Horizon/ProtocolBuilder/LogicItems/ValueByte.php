<?php

namespace Horizon\ProtocolBuilder\LogicItems;

class ValueByte
{
    /** @var ValueBitChunk[] $bit_chunks */
    private array $bit_chunks;

    public function __construct(int $bit_number)
    {
        $this->bit_chunks = [new ValueBitChunk(floor($bit_number/8), 7 - $bit_number % 8)];
    }

    public function setSign(bool $sign): void
    {
        end($this->bit_chunks)->setSign($sign);
    }

    public function addBit(int $bit_number): ?static
    {
        if (end($this->bit_chunks)->getByte() == floor($bit_number / 8)) {
            $new_chunk = end($this->bit_chunks)->addBit(7 - $bit_number % 8);
            if ($new_chunk instanceof ValueBitChunk) {
                $this->bit_chunks[] = $new_chunk;
            }
            return null;
        }
        return new self($bit_number);
    }

    public function reverse(): void
    {
        $this->bit_chunks = array_reverse($this->bit_chunks);
    }

    public function draw(int &$exponent, bool $hide_null_exponent): string
    {
        $power = ($hide_null_exponent || count($this->bit_chunks) > 1) && $exponent == 0 ? ''
            : sprintf(" * %01.1f", pow(2, $exponent));
        $chunks = [];
        foreach ($this->bit_chunks as $bit_chunk) {
            $chunks[] = $bit_chunk->draw($power);
            $exponent += $bit_chunk->getCount();
        }
        return implode(' + ', $chunks);
    }
}