<?php

namespace Horizon\ProtocolBuilder\LogicItems;

use Horizon\ProtocolBuilder\Exceptions\VEx;
use Horizon\ProtocolBuilder\Exceptions\VException;

class ToStringRequiredHandler
{
    private function __construct()
    {
    }

    /**
     * @throws VException
     */
    public static function run(string $text, string $param): ?string
    {
        $text = trim($text);
        if ($text == '') throw new VException(VEx::empty, $param);
        return htmlspecialchars($text);
    }
}