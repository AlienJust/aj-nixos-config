<?php

namespace Horizon\ProtocolBuilder\Exceptions;

enum UploadEx: int
{
    case UPLOAD_ERR_INI_SIZE = 1;
    case UPLOAD_ERR_FORM_SIZE = 2;
    case UPLOAD_ERR_PARTIAL = 3;
    case UPLOAD_ERR_NO_FILE = 4;
    case UPLOAD_ERR_NO_TMP_DIR = 6;
    case UPLOAD_ERR_CANT_WRITE = 7;
    case UPLOAD_ERR_EXTENSION = 8;

    public function message(): string
    {
        return match ($this) {
            self::UPLOAD_ERR_INI_SIZE => 'Размер принятого файла превысил максимально допустимый размер, который задан директивой upload_max_filesize конфигурационного файла php.ini',
            self::UPLOAD_ERR_FORM_SIZE => 'Размер загружаемого файла превысил значение MAX_FILE_SIZE, указанное в HTML-форме',
            self::UPLOAD_ERR_PARTIAL => 'Загружаемый файл был получен только частично',
            self::UPLOAD_ERR_NO_FILE => 'Файл не был загружен',
            self::UPLOAD_ERR_NO_TMP_DIR => 'Отсутствует временная папка',
            self::UPLOAD_ERR_CANT_WRITE => 'Не удалось записать файл на диск',
            self::UPLOAD_ERR_EXTENSION => 'Модуль PHP остановил загрузку файла', // PHP не предоставляет способа определить, какой модуль остановил загрузку файла; в этом может помочь просмотр списка загруженных модулей с помощью phpinfo()
        };
    }
}
