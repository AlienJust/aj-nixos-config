<?php

namespace Horizon\ProtocolBuilder\Exceptions;

use Exception;

class DataAccessException extends Exception
{
    public function __construct(DAEx $exception, ...$options)
    {
        parent::__construct($exception->message( ...$options), $exception->value);
    }
}