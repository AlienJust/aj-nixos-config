<?php

namespace Horizon\ProtocolBuilder\Exceptions;

enum UIEx: int
{
    case sectionNotImplemented = 0;
    case actionNotImplemented = 1;
    case fieldIsHidden = 2;
    case executeNotImplemented = 3;
    case accessNotImplemented = 4;

    public function message(...$options): string
    {
        return match ($this) {
            self::sectionNotImplemented => 'Секция не реализована',
            self::actionNotImplemented => 'Операция не реализована',
            self::fieldIsHidden => 'Нельзя обращаться к полю напрямую',
            self::executeNotImplemented => "Выполнение операции &quot;$options[0]&quot; не реализовано",
            self::accessNotImplemented => 'Доступ к операции запрещён'
        };
    }
}
