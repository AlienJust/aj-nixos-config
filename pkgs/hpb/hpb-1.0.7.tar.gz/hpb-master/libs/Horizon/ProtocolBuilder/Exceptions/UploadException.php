<?php

namespace Horizon\ProtocolBuilder\Exceptions;

use Exception;

class UploadException extends Exception
{
    public function __construct(UploadEx $exception)
    {
        parent::__construct($exception->message(), $exception->value);
    }
}