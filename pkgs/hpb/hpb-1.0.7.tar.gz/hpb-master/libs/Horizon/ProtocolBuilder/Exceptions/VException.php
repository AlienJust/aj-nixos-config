<?php

namespace Horizon\ProtocolBuilder\Exceptions;

use Exception;

class VException extends Exception
{
    public function __construct(VEx $exception, ...$options)
    {
        parent::__construct($exception->message(...$options), $exception->value);
    }
}