<?php

namespace Horizon\ProtocolBuilder\Exceptions;

use Exception;

class UIException extends Exception
{
    public function __construct(UIEx $exception, ...$options)
    {
        parent::__construct($exception->message( ...$options), $exception->value);
    }
}