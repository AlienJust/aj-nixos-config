<?php

namespace Horizon\ProtocolBuilder\Exceptions;

enum DAEx: int
{
    case unavailable_data = 1;
    case data_not_found = 2;
    public function message(...$options): string
    {
        return match ($this) {
            self::unavailable_data => "Доступ к этим данным запрещён",
            self::data_not_found => "Запрашиваемые данные не найдены",
        };
    }
}