<?php

namespace Horizon\ProtocolBuilder\ImportFiles;

class XmlParserController
{
    private XmlParserTemplate $parser;
    private string $file_path;
    public function __construct(XmlParserTemplate $parser, string $file_path)
    {
        $this->parser = $parser;
        $this->file_path = $file_path;
    }

    public function run(): void
    {
        $stream = fopen($this->file_path, 'r');
        // установить обработчики
        while (($data = fread($stream, 16384))) {
            $this->parser->parse($data); // разобрать текущую часть
        }
        fclose($stream);
    }
}