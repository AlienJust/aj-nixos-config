<?php

namespace Horizon\ProtocolBuilder\ImportFiles\PsnXmlModels;

use Horizon\ProtocolBuilder\Data\eParameterByteOrder;
use Horizon\ProtocolBuilder\Data\eParameterType;

final readonly class ParameterParser
{
    public string $GUID;
    public int $command;
    public string $name;
    public string $type;
    public ?string $byte_order;
    public array $bits;
    public float $lowest_digit_price;
    public bool $signed;
    public ?string $value;
    public bool $value_inverted;

    private function __construct(string $GUID, string $name, string $type, array $bits,
                                 float $lowest_digit_price = 1, bool $signed = false,
                                 ?eParameterByteOrder $byte_order = null,
                                 ?string $value = null, bool $value_inverted = false)
    {
        $this->GUID = $GUID;
        $this->name = $name;
        $this->type = $type;
        $this->byte_order = $byte_order?->value;
        $this->bits = $bits;
        $this->lowest_digit_price = $lowest_digit_price;
        $this->signed = $signed;
        $this->value = $value;
        $this->value_inverted = $value_inverted;
    }

    public static function fromVarVal(DataPosition $position, int $length, string $name, string $GUID): self
    {
        return new self($GUID, $name, eParameterType::VarVal->value, $position->initBits($length));
    }

    public static function fromDefVal(DataPosition $position, int $length, ?string $value, string $name, string $GUID): self
    {
        return new self($GUID, $name, eParameterType::DefVal->value, $position->initBits($length),
            1, false, null, $value);
    }

    public static function fromBitPrm(DataPosition $position, bool $is_value_inverted, string $name, string $GUID): self
    {
        return new self($GUID, $name, eParameterType::BitPrm->value, $position->initBits(),
            1, false,null, null, $is_value_inverted);
    }

    public static function fromCpzPrm(string $expression, string $name, string $GUID): self
    {
        $signed = false;
        $expression = str_replace(' ', '', $expression);
        preg_match_all('/\[(.+?)]/', $expression, $bytes);
        $bits = [];
        foreach ($bytes[1] as &$byte) {
            $first_symbol = mb_substr($byte, 0, 1);
            if (is_numeric($first_symbol)) {
                list($byte, $bit, $count) = explode('.', $byte);
                $bits = range($byte * 8 + 8 - $bit - $count, $byte * 8 + 8 - $bit - 1);
            } else {
                if ($first_symbol == 's') $signed = true;
                $byte = (int)mb_substr($byte, 1);
                $bits = array_merge($bits, range($byte * 8, ($byte + 1) * 8 - 1));
            }
        }
        $strings = explode('*', $expression);
        $price_of_the_lowest_digit = array_pop($strings);
        $left_string = implode('*', $strings);
        $first_symbol = mb_substr($left_string, 0, 1);
        $last_symbol = mb_substr($left_string, -1);
        if (!(mb_substr_count($left_string, '[') == 1 || $first_symbol == '(' && $last_symbol == ')')
            || !is_numeric($price_of_the_lowest_digit)
        ) {
            $price_of_the_lowest_digit = 1;
            $left_string = $expression;
        } elseif ($first_symbol == '(' && $last_symbol == ')') {
            // Ищем строку в скобках без круглых скобок, начинающуюся с квадратной скобки
            preg_match('/\((\[[^()]*)\)/', $left_string, $matches);
            $left_string = $matches[1];
        }

        $byte_order = null; // Определяем порядок байт, если их больше одного
        if (mb_substr_count($left_string, '[') > 1) {
            $byte_order = mb_substr($left_string, -1) == ']'
                ? eParameterByteOrder::HiLo
                : eParameterByteOrder::LoHi;
        }

        return new self($GUID, $name, eParameterType::CpzPrm->value, $bits, $price_of_the_lowest_digit, $signed, $byte_order);
    }
}