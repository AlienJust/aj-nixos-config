<?php

namespace Horizon\ProtocolBuilder\ImportFiles;

enum eTabsXmlTag: string
{
    case PARAMETERS = 'PARAMETERS';
    case PARAMETER = 'PARAMETER';
    case NUMBERVIEW = 'NUMBERVIEW';
    case BOOLEANVIEW = 'BOOLEANVIEW';
    case INJECTION = 'INJECTION';
    case INJECTTEXTVALUE = 'INJECTTEXTVALUE';
    case MULTIVIEW = 'MULTIVIEW';
}
