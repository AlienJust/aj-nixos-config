<?php

namespace Horizon\ProtocolBuilder\ImportFiles;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\DataBase\Tables\Subscriber;
use Horizon\ProtocolBuilder\Exceptions\DAEx;
use Horizon\ProtocolBuilder\Exceptions\DataAccessException;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\ImportFiles\PsnXmlModels\CommandParser;
use Horizon\ProtocolBuilder\ImportFiles\PsnXmlModels\DataPosition;
use Horizon\ProtocolBuilder\ImportFiles\PsnXmlModels\ParameterParser;
use XMLParser;

class PsnXmlParser extends XmlParserTemplate
{
    private Protocol $protocol;
    private array $subscribers;
    private CommandParser $command_parser;
    private int $author;

    public function __construct(int $author)
    {
        parent::__construct();
        $this->author = $author;
    }

    public function refProtocol(): Protocol
    {
        return $this->protocol;
    }

    /**
     * @throws DBException
     * @throws VException
     * @throws DataAccessException
     */
    function onTagOpenHandler(XMLParser $parser, string $tag, array $attributes): void
    {

        switch (ePsnXmlTag::tryFrom($tag)) {
            case ePsnXmlTag::PSNCONFIGURATION:
                $this->protocol = Protocol::dbFind($attributes['ID'] ?? null);
                $this->protocol->name = htmlspecialchars_decode($attributes['NAME'] ?? '');
                $this->protocol->version = $attributes['VERSION'] ?? '';
                $this->protocol->description = htmlspecialchars_decode($attributes['DESCRIPTION'] ?? '');
                if ($this->protocol->exists() && !$this->protocol->checkAuthor())
                    throw new DataAccessException(DAEx::unavailable_data);
                $this->protocol->author = $this->author;
                $this->protocol->dbInsertUpdate();
                break;
            case ePsnXmlTag::PSNMETER:
                var_dump($tag, $attributes);
                $this->subscribers[hexdec($attributes['ADDRESS'] ?? '')] = Subscriber::dbFind(
                    $this->protocol->getID(),
                    hexdec($attributes['ADDRESS'] ?? ''),
                    htmlspecialchars_decode($attributes['NAME'] ?? '')
                )->dbInsertUpdate()->getID();
                break;
            case ePsnXmlTag::CMDMASK:
                $this->command_parser = new CommandParser($this->subscribers, htmlspecialchars_decode($attributes['NAME'] ?? ''));
                break;
            case ePsnXmlTag::REQUEST:
                $this->command_parser->setRequest(
                    $attributes['LENGTH'] ?? '0',
                    $attributes['POSITION'] ?? '0',
                    $attributes['CYCLEMSTIME'] ?? null
                );
                break;
            case ePsnXmlTag::REPLY:
                $this->command_parser->setReply(
                    $attributes['LENGTH'] ?? '0',
                    $attributes['POSITION'] ?? '0',
                    $attributes['ISREQUESTREQUIRED'] ?? false
                );
                break;
            case ePsnXmlTag::DEFVAL:
                $this->command_parser->addParameter(ParameterParser::fromDefVal(
                    DataPosition::fromText($attributes['POSITION'] ?? '0.0'),
                    (int)($attributes['LENGTH'] ?? '0'),
                    $attributes['VALUE'] ?? null,
                    htmlspecialchars_decode($attributes['NAME'] ?? ''),
                    $attributes['ID'] ?? ''
                ));
                break;
            case ePsnXmlTag::VARVAL:
                $this->command_parser->addParameter(ParameterParser::fromVarVal(
                    DataPosition::fromText($attributes['POSITION'] ?? '0.0'),
                    (int)($attributes['LENGTH'] ?? '0'),
                    htmlspecialchars_decode($attributes['NAME'] ?? ''),
                    $attributes['ID'] ?? ''
                ));
                break;
            case ePsnXmlTag::BITPRM:
                $this->command_parser->addParameter(ParameterParser::fromBitPrm(
                    new DataPosition((int)($attributes['BYTE'] ?? '0'), (int)($attributes['BIT'] ?? '0')),
                    ($attributes['ISVALUEINVERTED'] ?? 'False') == 'True',
                    htmlspecialchars_decode($attributes['NAME'] ?? ''),
                    $attributes['ID'] ?? ''
                ));
                break;
            case ePsnXmlTag::CPZPRM:
                $this->command_parser->addParameter(ParameterParser::fromCpzPrm(
                    htmlspecialchars_decode($attributes['EXPRESSION'] ?? ''),
                    htmlspecialchars_decode($attributes['NAME'] ?? ''),
                    $attributes['ID'] ?? ''
                ));
        }
    }

    function onCharacterDataHandler(XMLParser $parser, string $cdata): void
    {
        // в нашем файле нет текстовых данных внутри тегов
    }

    /**
     * @throws DBException
     * @throws VException
     */
    function onTagCloseHandler(XMLParser $parser, string $tag): void
    {
        switch (ePsnXmlTag::tryFrom($tag)) {
            case ePsnXmlTag::CMDMASK:
                $this->command_parser->upload();
                unset($this->command_parser);
                break;
        }
    }
}