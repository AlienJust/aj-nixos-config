<?php

namespace Horizon\ProtocolBuilder\ImportFiles;

enum ePsnXmlTag: string
{
    case PSNCONFIGURATION = 'PSNCONFIGURATION';
    case PSNMETER = 'PSNMETER';
    case CMDMASK = 'CMDMASK';
    case REQUEST = 'REQUEST';
    case REPLY = 'REPLY';
    case DEFVAL = 'DEFVAL';
    case VARVAL = 'VARVAL';
    case BITPRM = 'BITPRM';
    case CPZPRM = 'CPZPRM';
}