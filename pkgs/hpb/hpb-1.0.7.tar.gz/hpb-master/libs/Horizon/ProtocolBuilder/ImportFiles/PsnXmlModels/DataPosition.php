<?php

namespace Horizon\ProtocolBuilder\ImportFiles\PsnXmlModels;

class DataPosition
{
    private int $byte;
    private int $bit;

    public function __construct(int $byte, int $bit)
    {
        $this->byte = $byte;
        $this->bit = $bit;
    }

    private function startBit(): int
    {
        return ($this->byte + 1) * 8 - ($this->bit + 1);
    }

    public function initBits(int $length = 1): array
    {
        $start_bit = $this->startBit();
        return range($start_bit, $start_bit + 1 - $length, -1);
    }

    static public function fromText(string $position): self
    {
        list($byte, $bit) = explode('.', $position);
        return new self((int)$byte, (int)$bit);
    }
}