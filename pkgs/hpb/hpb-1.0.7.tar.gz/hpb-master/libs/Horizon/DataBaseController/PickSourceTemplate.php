<?php

namespace Horizon\DataBaseController;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\UserInterface\Controls\Components\Option;
use Horizon\UserInterface\Controls\Components\OptionGroup;

abstract class PickSourceTemplate extends ConnectedToDataBase
{

    /**
     * @throws DBException
     * Option|OptionGroup[]
     */
    abstract public function init(): array;
}