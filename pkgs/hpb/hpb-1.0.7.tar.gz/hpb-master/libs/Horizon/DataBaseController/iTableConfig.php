<?php

namespace Horizon\DataBaseController;

interface iTableConfig
{
    public function getName(): string;
}