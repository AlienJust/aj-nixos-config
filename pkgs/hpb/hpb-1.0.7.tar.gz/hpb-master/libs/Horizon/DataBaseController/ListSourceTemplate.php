<?php

namespace Horizon\DataBaseController;

use Horizon\DataBaseController\Exceptions\DBException;

abstract class ListSourceTemplate extends ConnectedToDataBase
{
    protected int $limit;
    protected float $offset;
    protected string|int|null $currentID;
    protected int $max_page;

    /**
     * @throws DBException
     */
    public function __construct(int $page, int $limit, string|int|null $currentID)
    {
        if ($page < 1) $page = 1;
        $this->limit = $limit;
        $this->offset = ($page - 1) * $limit;
        $this->currentID = $currentID;

        $max_offset = $this->loadDataCount();
        if ($this->offset > $max_offset) $this->offset = floor(($max_offset - 1) / $this->limit) * $this->limit;

        $this->max_page = ceil($max_offset / $this->limit);
    }

    /**
     * @throws DBException
     */
    abstract public function loadData(): array;
    /**
     * @throws DBException
     */
    abstract public function loadCurrentPage(): int;
    /**
     * @throws DBException
     */
    abstract protected function loadDataCount(): float;
}