<?php

namespace Horizon\DataBaseController;

use Horizon\DataBaseController\Exceptions\DBEx;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\LogicItems\ToStringNullableHandler;
use PDOException;

abstract class dbTable extends ConnectedToDataBase
{

    protected static iTableConfig $table_config;
    protected bool $exists;

    protected function setToNotExists(): static
    {
        $this->exists = false;
        return $this;
    }

    protected function setToExists(): static
    {
        $this->exists = true;
        return $this;
    }

    protected function setterHandlerForStringToNull(?string $text): ?string
    {
        return ToStringNullableHandler::run($text);
    }

    public function exists(): bool
    {
        return $this->exists;
    }

    /**
     * @throws DBException
     */
    public function throwExceptionExists(): static
    {
        if (!$this->exists) throw new DBException(DBEx::notExists);
        return $this;
    }

    /**
     * @throws PDOException|DBException
     */
    protected function tryInsertUpdate(): void
    {
        if ($this->exists()) $this->tryUpdate();
        else {
            $this->tryInsert();
            $this->setToExists();
        }
    }
    /**
     * @throws PDOException|DBException
     */
    protected abstract function tryInsert(): void;
    /**
     * @throws PDOException|DBException
     */
    protected abstract function tryUpdate(): void;
    /**
     * @throws PDOException|DBException
     */
    protected abstract function tryDelete(): void;

    /**
     * @throws DBException
     */
    final protected static function dbAction(callable $function,
                                             DBEx     $db_exception = DBEx::notAction,
                                             mixed ...$parameters): void
    {
        self::PDO()->beginTransaction();
        try {
            call_user_func_array($function, $parameters);
            self::PDO()->commit();
        } catch (PDOException $e) {
            self::PDO()->rollBack();
            throw new DBException($db_exception, $e);
        }
    }

    /**
     * @throws DBException
     */
    final public function dbInsertUpdate(): static
    {
        self::PDO()->beginTransaction();
        try {
            $this->tryInsertUpdate();
            self::PDO()->commit();
        } catch (PDOException $e) {
            self::PDO()->rollBack();
            throw new DBException(DBEx::notUpdate, $e);
        }
        return $this;
    }

    /**
     * @throws DBException
     */
    public function dbInsert(): void
    {
        self::PDO()->beginTransaction();
        try {
            $this->tryInsert();
            $this->setToExists();
            self::PDO()->commit();
        } catch (PDOException $e) {
            self::PDO()->rollBack();
            throw new DBException(DBEx::notInsert, $e);
        }
    }

    /**
     * @throws DBException
     */
    final public function dbUpdate(): void
    {
        self::PDO()->beginTransaction();
        try {
            $this->tryUpdate();
            self::PDO()->commit();
        } catch (PDOException $e) {
            self::PDO()->rollBack();
            throw new DBException(DBEx::notUpdate, $e);
        }
    }

    /**
     * @throws DBException
     */
    final public function dbDelete(): void
    {
        self::PDO()->beginTransaction();
        try {
            $this->tryDelete();
            $this->setToNotExists();
            self::PDO()->commit();
        } catch (PDOException $e) {
            self::PDO()->rollBack();
            throw new DBException(DBEx::notDelete, $e);
        }
    }

    final protected static function intoMe(self|false|null $value, mixed ...$arguments): static
    {
        if (!is_object($value)) return new static(...$arguments)->setToNotExists();
        else return $value->setToExists();
    }

    final protected static function intoNull(self|false|null $value): ?static
    {
        if (!is_object($value)) return null;
        else return $value->setToExists();
    }

    /**
     * @throws DBException
     */
    final protected static function UUID(): string
    {
        return self::PDO()->query('SELECT UUID();')->fetchColumn();
    }
}