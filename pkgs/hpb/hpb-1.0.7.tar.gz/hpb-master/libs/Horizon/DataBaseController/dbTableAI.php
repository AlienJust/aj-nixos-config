<?php

namespace Horizon\DataBaseController;

use Horizon\DataBaseController\Exceptions\DBEx;
use Horizon\DataBaseController\Exceptions\DBException;
use PDO;
use PDOException;
use PDOStatement;

abstract class dbTableAI extends dbTable
{
    protected int $ID;

    protected function tryDelete(): void
    {
        $table = static::$table_config->getName();
        $stmt = self::PDO()->prepare("DELETE FROM `$table` WHERE `ID`=:this;");
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
    }

    public function getID(): ?int
    {
        return $this->ID ?? null;
    }

    final public function tryInsertUpdate(): void
    {
        parent::tryInsertUpdate();
    }

    /**
     * @throws DBException
     */
    final public function dbInsert(): void
    {
        self::PDO()->beginTransaction();
        try {
            $this->tryInsert();
            $this->ID = $this->ID ?? self::PDO()->lastInsertId();
            $this->setToExists();
            self::PDO()->commit();
        } catch (PDOException $e) {
            self::PDO()->rollBack();
            throw new DBException(DBEx::notInsert, $e);
        }
    }

    /**
     * @throws DBException
     */
    protected final static function PDOStatementForLoad(?int $ID): PDOStatement
    {
        $table = static::$table_config->getName();
        $stmt = self::PDO()->prepare("SELECT t.*, TRUE AS `exists` FROM `$table` AS t WHERE t.`ID`=:this;");
        $stmt->bindValue(':this', $ID, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt;
    }
}