<?php

namespace Horizon\DataBaseController;

use Horizon\DataBaseController\Exceptions\DBEx;
use Horizon\DataBaseController\Exceptions\DBException;
use PDO;
use PDOException;
use const HORIZON_SETTINGS as HS;

final class MySQL
{
    private const OPTIONS = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_ORACLE_NULLS => PDO::NULL_NATURAL
    ];

    private function __construct()
    {
    }

    /**
     * @throws DBException
     */
    public static function connect(): PDO
    {
        $host = HS['database']['host'] ?? throw new DBException(DBEx::notHost);
        $name = HS['database']['name'] ?? throw new DBException(DBEx::notName);
        $charset = HS['database']['charset'] ?? throw new DBException(DBEx::notCharset);
        $user = HS['database']['user'] ?? throw new DBException(DBEx::notUser);
        $password = HS['database']['password'] ?? throw new DBException(DBEx::notPassword);
        try {
            $connection = new PDO('mysql:host=' . $host . ';dbname=' . $name . ';charset=' . $charset,
                $user, $password, self::OPTIONS);
            $connection->query("SET NAMES `utf8mb4` COLLATE `utf8mb4_unicode_ci`;");
            return $connection;
        } catch (PDOException $exception) {
            throw new DBException(DBEx::PDO, $exception);
        }
    }
}