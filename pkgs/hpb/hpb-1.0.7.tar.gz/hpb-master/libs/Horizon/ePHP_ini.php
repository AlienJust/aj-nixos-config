<?php

namespace Horizon;

enum ePHP_ini: string
{
    case display_errors = 'display_errors';
    case log_errors = 'log_errors';
    case sendmail_from = 'sendmail_from';


    public function get(): false|string
    {
        return ini_get($this->value);
    }

    public function set(bool|float|int|null|string $value): false|string
    {
        return ini_set($this->value, $value);
    }
}
