<?php

namespace Horizon\Session\Models;

readonly class AuthToken
{
    public string $token;
    public int $moment;

    public function __construct(string $token, int $moment) {
        $this->token = $token;
        $this->moment = $moment;
    }
}