<?php

namespace Horizon\Session;

use Horizon\Session\Models\AuthToken;
use ReflectionClass;
use ReflectionProperty;

final class HorizonSession
{
    protected ?AuthToken $auth_token = null;

    public function __construct()
    {
        session_start();
        $this->auth_token = isset($_SESSION['auth_token'])
            ? new AuthToken($_SESSION['auth_token']['token'], $_SESSION['auth_token']['moment']) : null;
        session_commit();
    }

    public function setAuthToken(string $token, int $moment): void
    {
        $this->auth_token = new AuthToken($token, $moment);
        $this->save();
    }

    public function resetAuthToken(): void
    {
        $this->auth_token = null;
        $this->save();
    }

    public function getAuthToken(): ?AuthToken
    {
        return $this->auth_token;
    }

    public function save(): void
    {
        session_start();
        $reflect = new ReflectionClass(self::class);
        $properties = $reflect->getProperties(ReflectionProperty::IS_PROTECTED);
        foreach ($properties as $property) {
            $value = $property->getValue($this);
            if ($value === null) {
                if (isset($_SESSION[$property->getName()])) unset($_SESSION[$property->getName()]);
                continue;
            }
            if (is_object($value)) $value = (array)$value;
            $_SESSION[$property->getName()] = $value;
        }
        session_commit();
    }

}