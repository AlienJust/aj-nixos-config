<?php

namespace Horizon\Auth;

use Exception;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use stdClass;

class AuthToken
{
    public readonly string $username;
    public readonly string $imprint;
    public readonly string $token;

    private const string KEY = '3b8a1f117eee2107da1964cc21676a1f';
    private const string ALGORITHM = 'HS256';

    public function __construct(string $username, string $imprint, string $token)
    {
        $this->username = $username;
        $this->imprint = $imprint;
        $this->token = $token;
    }

    public function encode(): string
    {
        return JWT::encode((array)$this, self::KEY, self::ALGORITHM);
    }

    /**
     * @throws AccessDeniedException
     */
    public static function init(string $access_token): self
    {
        try {
            $headers = new StdClass();
            $decoded = JWT::decode($access_token, new Key(self::KEY, self::ALGORITHM), $headers);
        } catch (Exception $e) {
            throw new AccessDeniedException(AccessDeniedEx::corrupt_token, $e);
        }
        return new self(
            $decoded->username ?? throw new AccessDeniedException(AccessDeniedEx::corrupt_token),
            $decoded->imprint ?? throw new AccessDeniedException(AccessDeniedEx::corrupt_token),
            $decoded->token ?? throw new AccessDeniedException(AccessDeniedEx::corrupt_token)
        );
    }
}