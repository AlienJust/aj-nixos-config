<?php

namespace Horizon\Auth;

class TemporaryBlockingException extends AccessDeniedException
{
    public function __construct(int $block_time, string $left_time)
    {
        $this->addon = "Аккаунт заблокирован на $block_time минут. Осталось ждать $left_time.";
        parent::__construct(AccessDeniedEx::temporary_block);
    }
}