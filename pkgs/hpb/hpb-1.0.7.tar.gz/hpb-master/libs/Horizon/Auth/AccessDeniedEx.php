<?php

namespace Horizon\Auth;

enum AccessDeniedEx: int
{
    case corrupt_token = 0;
    case not_data = 1;
    case fail = 2;
    case banned = 3;
    case other = 4;
    case temporary_block = 5;

    public function message(string $addon): string
    {
        return match ($this) {
            self::corrupt_token => 'Токен поврежден',
            self::not_data => 'Данные для входа не предоставлены',
            self::fail => 'Некорректные данные для входа',
            self::banned => 'Доступ запрещён',
            self::other => 'Ошибка при авторизации',
            self::temporary_block => "Превышено количество попыток входа. $addon",
        };
    }
}
