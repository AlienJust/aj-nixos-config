<?php

namespace Horizon\Auth;

use Exception;
use Horizon\Auth\DataBase\Tables\Device;
use Horizon\Auth\DataBase\Tables\User;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\Session\HorizonSession;
use Random\RandomException;

class AuthService
{

    private Device $device;


    public function __construct(Device $device)
    {
        $this->device = $device;
    }

    private function refDevice(): Device
    {
        return $this->device;
    }

    /**
     * @throws RandomException
     */
    private function generateToken(): string
    {
        return bin2hex(random_bytes(32));
    }

    private static function getDeviceImprint(): string
    {
        $name = 'imprint';
        $imprint = $_COOKIE[$name] ?? null;
        if ($imprint === null) {
            $imprint = md5(implode('|', [$_SERVER['HTTP_USER_AGENT'], $_SERVER['REMOTE_ADDR'], time()]));
            setcookie($name, $imprint, time() + (86400 * 365 * 2));
        }
        //setcookie($name, '', time() - 3600);
        return $imprint;
    }

    private static function getDeviceInfo(): string
    {
        return mb_substr($_SERVER['HTTP_USER_AGENT'], 0, 255);
    }

    /**
     * @throws AccessDeniedException
     */
    public static function login(string $username, string $password, ?string $imprint = null, ?string $info = null): void
    {
        try {
            $user = User::dbFind($username);
            if ($user === null) throw new AccessDeniedException(AccessDeniedEx::fail);
            $service = self::dbLoad($user->getID(), $imprint, $info);
            $service->refDevice()->verifyAttempts();
            $service->refDevice()->verifyBanned();
            if ($user->verifyPassword($password)) {
                $token_key = $service->generateToken();
                $service->refDevice()->setTokenKey($token_key)->dbUpdate();
                $service->refDevice()->regLogin();
                $token = new AuthToken($user->username, $service->refDevice()->getImprint(), $token_key);
                $session = new HorizonSession();
                $session->setAuthToken($token->encode(), $service->refDevice()->getTokenMoment());
                User::setCurrentUser($user);
            } else {
                $service->refDevice()->regAttempt();
                throw new AccessDeniedException(AccessDeniedEx::fail);
            }
        } catch (AccessDeniedException $e) {
            throw $e;
        } catch (Exception $e) {
            throw new AccessDeniedException(AccessDeniedEx::other, $e);
        }
    }

    public static function logout(): void
    {
        $session = new HorizonSession();
        $session->resetAuthToken();
    }

    public static function authBySession(): bool
    {
        try {
            $session = new HorizonSession();
            $coded_token = $session->getAuthToken();
            if ($coded_token === null) return false;
            $token = AuthToken::init($coded_token->token);
            $device = Device::dbFind($token->username, $token->imprint);
            if ($device === null) return false;
            $verify_result = $device->verifyTokenMoment($coded_token->moment)
                && $device->verifyAccessToken($token->token);
            if ($verify_result) User::setCurrentUser($device->refUser());
            return $verify_result;
        } catch (DBException|AccessDeniedException) {
            User::setCurrentUser(null);
            return false;
        }
    }

    /**
     * @throws DBException
     */
    public static function dbLoad(int $userID, ?string $imprint, ?string $info): self
    {
        $device = Device::dbLoad($userID, $imprint ?? self::getDeviceImprint());
        $device->setInfo($info ?? self::getDeviceInfo());
        $device->dbInsertUpdate();
        return new self($device);
    }
}