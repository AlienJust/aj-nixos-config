<?php

namespace Horizon\Auth;

use Throwable;

class AccessDeniedException extends \Exception
{
    protected string $addon = '';

    public function __construct(AccessDeniedEx $ex, ?Throwable $previous = null)
    {
        parent::__construct($ex->message($this->addon), $ex->value, $previous);
    }
}