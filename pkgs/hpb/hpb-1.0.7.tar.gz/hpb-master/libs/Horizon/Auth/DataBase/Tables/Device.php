<?php

namespace Horizon\Auth\DataBase\Tables;

use Horizon\Auth\AccessDeniedEx;
use Horizon\Auth\AccessDeniedException;
use Horizon\Auth\TemporaryBlockingException;
use Horizon\Auth\DataBase\eTable;
use Horizon\DataBaseController\dbTable;
use Horizon\DataBaseController\Exceptions\DBEx;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\DataBaseController\iTableConfig;
use PDO;

final class Device extends dbTable
{
    protected static iTableConfig $table_config = eTable::h_device;
    private int $user;
    private string $imprint;
    private int $attempts = 0;
    private int $last_attempt_moment;
    private string $info = '';
    private ?int $token_moment = null;
    private ?string $access_token_hash = null;
    private ?string $refresh_token_hash = null;

    private const int TOKEN_LIFETIME = 60 * 60 * 24;


    private function setImportantData(int $user, string $imprint): self
    {
        $this->user = $user;
        $this->imprint = $imprint;
        return $this;
    }

    public function setInfo(string $info): void
    {
        $this->info = $info;
    }

    public function setTokenKey(string $access_token, ?string $refresh_token = null): self
    {
        $this->token_moment = time();
        $this->access_token_hash = password_hash($access_token, PASSWORD_DEFAULT);
        if ($refresh_token !== null) $this->refresh_token_hash = password_hash($refresh_token, PASSWORD_DEFAULT);
        return $this;
    }

    public function getImprint(): string
    {
        return $this->imprint;
    }

    public function getTokenMoment(): ?int
    {
        return $this->token_moment;
    }

    /**
     * @throws DBException
     */
    public function refUser(): User
    {
        return User::dbLoad($this->user);
    }

    /**
     * @throws TemporaryBlockingException
     */
    public function verifyAttempts(): bool
    {
        if ($this->attempts < 5 || $this->attempts % 5 != 0) return true;
        $diff = time() - $this->last_attempt_moment;
        $left = $this->attempts * 60 - $diff;
        if ($left <= 0) return true;
        $left_m = floor($left / 60);
        $left_s = $left % 60;
        throw new TemporaryBlockingException($this->attempts,
            ($left_m > 0 ? " $left_m мин" : "") . ($left_s > 0 ? " $left_s сек" : ""));
    }

    /**
     * @throws DBException
     * @throws AccessDeniedException
     */
    public function verifyBanned(): void
    {
        if ($this->refUser()->ban) throw new AccessDeniedException(AccessDeniedEx::banned);
    }

    public function verifyTokenMoment(int $moment): bool
    {
        return $this->token_moment == $moment;
    }

    public function verifyAccessToken(string $access_token): bool
    {
        if (time() - $this->token_moment > self::TOKEN_LIFETIME) return false;
        return password_verify($access_token, $this->access_token_hash);
    }

    public function verifyRefreshToken(string $refresh_token): bool
    {
        return password_verify($refresh_token, $this->refresh_token_hash);
    }

    /**
     * @throws DBException
     */
    public function regAttempt(): void
    {
        $this->attempts += 1;
        $this->last_attempt_moment = time();
        $this->tryUpdateAttempt();
    }

    /**
     * @throws DBException
     */
    public function regLogin():void
    {
        $this->attempts = 0;
        $this->last_attempt_moment = time();
        $this->tryUpdateAttempt();
    }

    /**
     * @throws DBException
     */
    private function tryUpdateAttempt(): void
    {
        $stmt = self::PDO()->prepare("UPDATE `h_device` SET
                    `attempts` = :attempts,
                    `last_attempt_moment` = FROM_UNIXTIME(:last_attempt_moment)
                  WHERE `user` = :user AND `imprint` = :imprint;");
        $stmt->bindValue(':user', $this->user,PDO::PARAM_INT);
        $stmt->bindValue(':imprint', $this->imprint);
        $stmt->bindValue(':attempts', $this->attempts,PDO::PARAM_INT);
        $stmt->bindValue(':last_attempt_moment', $this->last_attempt_moment,PDO::PARAM_INT);
        $stmt->execute();
    }

    protected function tryInsert(): void
    {
        $stmt = self::PDO()->prepare("INSERT INTO `h_device`(
                       `user`, `imprint`, `attempts`, `info`
                       ) VALUES (:user, :imprint, :attempts, :info);");
        $stmt->bindValue(':user', $this->user,PDO::PARAM_INT);
        $stmt->bindValue(':imprint', $this->imprint);
        $stmt->bindValue(':attempts', $this->attempts, PDO::PARAM_INT);
        $stmt->bindValue(':info', $this->info);
        $stmt->execute();
    }

    protected function tryUpdate(): void
    {
        $stmt = self::PDO()->prepare("UPDATE `h_device` SET
                    `info` = :info,
                    `token_moment` = IF(:token_moment IS NULL, NULL, FROM_UNIXTIME(:token_moment)),
                    `access_token_hash` = :access_token_hash, 
                    `refresh_token_hash` = :refresh_token_hash 
                  WHERE `user` = :user AND `imprint` = :imprint;");
        $stmt->bindValue(':user', $this->user,PDO::PARAM_INT);
        $stmt->bindValue(':imprint', $this->imprint);
        $stmt->bindValue(':info', $this->info);
        $stmt->bindValue(':token_moment', $this->token_moment, PDO::PARAM_INT|PDO::PARAM_NULL);
        $stmt->bindValue(':access_token_hash', $this->access_token_hash, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->bindValue(':refresh_token_hash', $this->refresh_token_hash, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->execute();
    }

    protected function tryDelete(): void
    {
        throw new DBException(DBEx::cantDelete);
    }

    /**
     * @throws DBException
     */
    public static function dbLoad(int $user, string $imprint): self
    {
        $stmt = self::PDO()->prepare("SELECT 
                `user`, 
                `imprint`, 
                `attempts`, 
                UNIX_TIMESTAMP(`last_attempt_moment`) AS `last_attempt_moment`, 
                `info`, 
                UNIX_TIMESTAMP(`token_moment`) AS `token_moment`,
                `access_token_hash`, 
                `refresh_token_hash` 
            FROM `h_device` 
            WHERE `user` = :user 
              AND `imprint` = :imprint;");
        $stmt->bindValue(':user', $user,PDO::PARAM_INT);
        $stmt->bindValue(':imprint', $imprint);
        $stmt->execute();
        return self::intoMe($stmt->fetchObject(Device::class))->setImportantData($user, $imprint);
    }

    /**
     * @throws DBException
     */
    public static function dbFind(string $username, string $imprint): ?self
    {
        $stmt = self::PDO()->prepare("SELECT 
                `user`, 
                `imprint`, 
                `attempts`, 
                UNIX_TIMESTAMP(`last_attempt_moment`) AS `last_attempt_moment`, 
                `info`, 
                UNIX_TIMESTAMP(`token_moment`) AS `token_moment`,
                `access_token_hash`, 
                `refresh_token_hash` 
            FROM `h_device` 
            WHERE `user` = (SELECT `ID` FROM `h_user` WHERE `username` = :username)
              AND `imprint` = :imprint;");
        $stmt->bindValue(':username', $username);
        $stmt->bindValue(':imprint', $imprint);
        $stmt->execute();
        return self::intoNull($stmt->fetchObject(Device::class));
    }
}