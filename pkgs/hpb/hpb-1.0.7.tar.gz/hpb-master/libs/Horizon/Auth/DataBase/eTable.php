<?php

namespace Horizon\Auth\DataBase;

use Horizon\DataBaseController\iTableConfig;

enum eTable implements iTableConfig
{
    case h_user;
    case h_device;
    case h_group;
    case h_group_tree;

    public function getName(): string
    {
        return $this->name;
    }
}
