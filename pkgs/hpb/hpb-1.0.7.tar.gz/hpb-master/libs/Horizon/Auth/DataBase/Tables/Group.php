<?php

namespace Horizon\Auth\DataBase\Tables;

use Horizon\Auth\DataBase\eTable;
use Horizon\DataBaseController\dbTableAI;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\DataBaseController\iTableConfig;
use Horizon\ProtocolBuilder\Exceptions\DAEx;
use Horizon\ProtocolBuilder\Exceptions\DataAccessException;
use PDO;

final class Group extends dbTableAI
{
    protected static iTableConfig $table_config = eTable::h_group;

    public string $name = '' {
        get {
            return $this->name;
        }
        set {
            $this->name = $value;
        }
    }
    public string $description = '' {
        get {
            return $this->description;
        }
        set {
            $this->description = $value;
        }
    }

    private ?int $owner = null;

    public function setOwner(?int $owner): void
    {
        $this->owner = $owner;
    }

    public function getOwner(): ?int
    {
        return $this->owner;
    }

    /**
     * @throws DBException
     */
    public function getLevel(): int
    {
        $stmt = self::PDO()->prepare("SELECT MAX(`level`) FROM `h_group_tree` WHERE `slave`=:this;");
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchColumn() ?? 0;
    }

    /**
     * @throws DBException
     * @throws DataAccessException
     */
    public function verifyAccess(): void
    {
        if (!$this->exists()) throw new DataAccessException(DAEx::data_not_found);
        $stmt = self::PDO()->prepare("SELECT :this IN (SELECT DISTINCT g.`gr`
        FROM (SELECT `slave` AS `gr`
              FROM `h_group_tree` -- все потомки доступных пользователю групп
              WHERE `master` IN (SELECT `group_ID` FROM `h_group_x_user` WHERE `user_ID` = :current)
              UNION ALL
              -- все доступные пользователю группы
              (SELECT `group_ID` AS `gr` FROM `h_group_x_user` WHERE `user_ID` = :current)) AS g) AS `verify`;");
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->bindValue(':current', User::current()?->getID(), PDO::PARAM_INT);
        $stmt->execute();
        if ($stmt->fetchColumn() != 1) throw new DataAccessException(DAEx::unavailable_data);
    }

    protected function tryInsert(): void
    {
        $stmt = self::PDO()->prepare("INSERT INTO `h_group`(`name`, `description`) 
            VALUES (:name,:description);");
        $stmt->bindValue(':name', $this->name);
        $stmt->bindValue(':description', $this->description);
        $stmt->execute();
        $this->ID = self::PDO()->lastInsertId();
        $this->tryUpdateTree();
    }

    protected function tryUpdate(): void
    {
        $stmt = self::PDO()->prepare("UPDATE `h_group` SET 
                     `name`=:name, 
                     `description`=:description 
                 WHERE `ID`=:this;");
        $stmt->bindValue(':name', $this->name);
        $stmt->bindValue(':description', $this->description);
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        $this->tryUpdateTree();
    }

    /**
     * @throws DBException
     */
    private function tryUpdateTree(): void
    {
        $stmt = self::PDO()->prepare('DELETE FROM `h_group_tree` 
            WHERE `master` IN (SELECT * FROM (SELECT `master` FROM `h_group_tree` WHERE `slave`=:this) as `masters`)
              AND `slave` IN (SELECT * FROM (SELECT `slave` FROM `h_group_tree` WHERE `master`=:this UNION ALL SELECT :this) as `slaves`);');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        if (isset($this->owner)) {
            $stmt = self::PDO()->prepare("INSERT INTO `h_group_tree`
                    (`master`, `slave`, `level`)
                      SELECT -- все прародители нового родителя получат нового потомка
                        praparent.`master`,
                        :this,
                        praparent.`level` + 1
                      FROM `h_group_tree` AS praparent
                      WHERE `slave` = :master
                      UNION ALL
                      SELECT -- новый родитель получит нового потомка
                        :master,
                        :this,
                        1
                      UNION ALL
                      SELECT -- все прародители нового родителя получат всех потомков нового потомка
                        praparent.`master`,
                        child.`slave`,
                        praparent.`level` + child.`level` + 1
                      FROM `h_group_tree` AS child,
                        `h_group_tree` AS praparent
                      WHERE child.`master` = :this
                        AND praparent.`slave` = :master
                      UNION ALL
                      SELECT -- новый родитель получит всех потомков нового потомка
                        :master,
                        child.`slave`,
                        child.`level` + 1
                      FROM `h_group_tree` AS child
                      WHERE child.`master` = :this;");
            $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
            $stmt->bindValue(':master', $this->owner, PDO::PARAM_INT);
            $stmt->execute();
        }
    }

    /**
     * @throws DBException
     */
    public static function dbLoad(?int $ID): Group
    {
        $stmt = self::PDO()->prepare("SELECT hg.*, TRUE AS `exists`, 
                (SELECT `master` FROM `h_group_tree` WHERE `slave`=:this AND `level`=1) AS `owner`
            FROM `h_group` AS hg 
            WHERE hg.`ID`=:this;");
        $stmt->bindValue(':this', $ID, PDO::PARAM_INT);
        $stmt->execute();
        return Group::intoMe($stmt->fetchObject(Group::class));
    }
}