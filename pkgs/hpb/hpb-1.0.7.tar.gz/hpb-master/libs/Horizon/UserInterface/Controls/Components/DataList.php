<?php

namespace Horizon\UserInterface\Controls\Components;

use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\HTMLEx;
use Horizon\UserInterface\HTMLException;
use Horizon\UserInterface\iTag;
use Horizon\UserInterface\Tag;

class DataList extends Tag
{
    public function __construct(string $id)
    {
        parent::__construct('datalist');
        $this->addAttribute(Attribute::id, $id);
    }

    /**
     * @throws HTMLException
     */
    public function add(iTag|string|null ...$content): static
    {
        foreach($content as $tag) if (is_object($tag) && get_class($tag) != Option::class || is_string($tag))
            throw new HTMLException(HTMLEx::tagNotSupport);
        return parent::add(...$content);
    }
}