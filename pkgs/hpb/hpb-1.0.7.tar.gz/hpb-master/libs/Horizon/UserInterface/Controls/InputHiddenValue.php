<?php

namespace Horizon\UserInterface\Controls;

class InputHiddenValue extends Input
{
    public function __construct(string $name, string $value)
    {
        parent::__construct('hidden', $name, $value);
    }
}