<?php

namespace Horizon\UserInterface\Controls;

use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\SingleTag;

abstract class Input extends SingleTag
{
    public function __construct(string $type, string $name, string $value)
    {
        parent::__construct('input');
        $this->addAttribute(Attribute::type, $type)
            ->addAttribute(Attribute::name, $name)
            ->addAttribute(Attribute::value, $value);
    }

    public function setDisabled(bool $value): static
    {
        $this->addAttribute(Attribute::disabled, $value);
        return $this;
    }
}