<?php

namespace Horizon\UserInterface\Controls;

class FormPOST extends Form
{
    public function __construct(string $action_URL)
    {
        parent::__construct($action_URL, 'POST');
    }
}