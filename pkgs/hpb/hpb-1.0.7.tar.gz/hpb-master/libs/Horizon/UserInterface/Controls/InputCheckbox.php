<?php

namespace Horizon\UserInterface\Controls;

use Horizon\UserInterface\Constants\Attribute;

class InputCheckbox extends Input
{
    public function __construct(string $name, bool $value)
    {
        parent::__construct('checkbox', $name, '1');
        $this->addAttribute(Attribute::checked, $value);
    }
}