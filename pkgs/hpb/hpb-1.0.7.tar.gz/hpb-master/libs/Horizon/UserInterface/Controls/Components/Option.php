<?php

namespace Horizon\UserInterface\Controls\Components;

use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\HTMLEx;
use Horizon\UserInterface\HTMLException;
use Horizon\UserInterface\iTag;
use Horizon\UserInterface\Tag;
use StringBackedEnum;

class Option extends Tag
{
    public function __construct(string $value, string $label, ?string $title = null)
    {
        parent::__construct('option');
        $this->addAttribute(Attribute::value, $value);
        if (!is_null($title)) $this->addAttribute(Attribute::title, $title);
        parent::add($label);
    }

    /**
     * @throws HTMLException
     */
    public function add(iTag|string|null ...$content): static
    {
        foreach($content as $tag) if (!is_string($tag) && !is_null($tag))
            throw new HTMLException(HTMLEx::tagNotSupport);
        return parent::add(...$content);
    }

    public function getValue(): string
    {
        return $this->getAttribute(Attribute::value) ?? '';
    }

    /**
     * @param array $options
     * @return static[]
     */
    public static function init(array $options): array
    {
        return array_map(fn(string $k, array|string $v): static => is_array($v)
            ? new static($v['value'] ?? '', $v['label'] ?? '', $v['title'] ?? null)
            : new static($k, $v), $options);
    }

    /**
     * @param StringBackedEnum[] $cases
     * @return Option[]
     */
    public static function initFromStringBackedEnumCases(array $cases): array
    {
        return array_map(fn($v) => new static($v->value, $v->value), $cases);
    }
}