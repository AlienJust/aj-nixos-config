<?php

namespace Horizon\UserInterface\Controls;

use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\PresetTags\RequiredView;
use Horizon\UserInterface\Tags\Label;

class InputFile extends Input
{
    protected Label $label;
    public function __construct(string $name, string $label, string $title, ?bool $required = false)
    {
        parent::__construct('file', $name, '');
        $this->label = new Label();
        $this->label->add($label);
        $this->addAttribute(Attribute::title, $title);
        if ($required) $this->addAttribute(Attribute::required, $required);
    }

    public function draw(): string
    {
        $label = clone $this->label;
        return $label->add(parent::draw(), new RequiredView())->draw();
    }
}