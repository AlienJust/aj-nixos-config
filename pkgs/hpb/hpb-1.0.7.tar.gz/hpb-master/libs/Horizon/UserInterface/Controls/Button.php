<?php

namespace Horizon\UserInterface\Controls;

class Button extends Input
{
    public function __construct(string $name, string $text)
    {
        parent::__construct('button', $name, $text);
    }
}