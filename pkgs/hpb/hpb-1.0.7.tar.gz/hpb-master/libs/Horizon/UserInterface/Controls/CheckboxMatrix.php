<?php

namespace Horizon\UserInterface\Controls;

use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Tags\Division;
use Horizon\UserInterface\Tags\Label;
class CheckboxMatrix extends Division
{
    public function __construct(string $name, int $count, array $unavailable_bits, array $checked_bits)
    {
        parent::__construct();
        $this->addClass('bytes');
        for ($i = 0; $i < $count; $i++) {
            $this->add($div = new Division()->addClass('bits')
                ->add(new Label()->addClass('byte')
                    ->add(new Division())
                    ->add(new InputCheckbox('_'. $name . '[' . $i . ']', false)->addClass('hide')
                        ->addAttribute(Attribute::onclick, 'horizon.changeCheckboxes(this);'))));
            for ($j = 0; $j < 8; $j++)
                $div->add(new Label()->addClass('bit')
                    ->add(new InputCheckbox($name . '[' . $i * 8 + $j . ']', false)->addClass('hide')
                        ->addAttribute(Attribute::disabled, in_array($i * 8 + $j, $unavailable_bits))
                        ->addAttribute(Attribute::checked, in_array($i * 8 + $j, $checked_bits)))
                    ->add(new Division()));
        }
    }
}