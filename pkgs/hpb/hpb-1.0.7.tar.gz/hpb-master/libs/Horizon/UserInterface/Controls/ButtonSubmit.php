<?php

namespace Horizon\UserInterface\Controls;

class ButtonSubmit extends Input
{
    public function __construct(string $name, string $text)
    {
        parent::__construct('submit', $name, $text);
    }
}