<?php

namespace Horizon\UserInterface\Controls\Components;

use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Tag;

class Textarea extends Tag
{
    public function __construct(string $name, string $value, ?int $maxlength = null)
    {
        parent::__construct('textarea');
        parent::add($value);
        parent::addAttribute(Attribute::name, $name);
        if (!is_null($maxlength)) parent::addAttribute(Attribute::maxlength, $maxlength);
    }
}