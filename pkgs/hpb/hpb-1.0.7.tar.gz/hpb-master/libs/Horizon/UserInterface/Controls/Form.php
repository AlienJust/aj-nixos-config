<?php

namespace Horizon\UserInterface\Controls;

use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Tag;

abstract class Form extends Tag
{
    public function __construct(string $action_URL, string $method)
    {
        parent::__construct('form');
        $this->addAttribute(Attribute::enctype,'multipart/form-data')
            ->addAttribute(Attribute::action, $action_URL)
            ->addAttribute(Attribute::method, $method);
    }
}