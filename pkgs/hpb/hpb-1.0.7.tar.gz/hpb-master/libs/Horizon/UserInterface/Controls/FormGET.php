<?php

namespace Horizon\UserInterface\Controls;

class FormGET extends Form
{
    public function __construct(string $action_URL)
    {
        parent::__construct($action_URL, 'GET');
    }
}