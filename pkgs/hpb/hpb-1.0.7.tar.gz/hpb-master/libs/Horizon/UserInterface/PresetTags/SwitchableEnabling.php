<?php

namespace Horizon\UserInterface\PresetTags;

use Horizon\UserInterface\Controls\CheckboxBool;
use Horizon\UserInterface\iTag;
use Horizon\UserInterface\Tags\Division;

class SwitchableEnabling extends Division
{
    private CheckboxBool $switcher;
    private Division $slaves;

    public function __construct(string $name, bool $value, string $label, string $title, bool $stable = true)
    {
        parent::__construct();
        $this->addClass('tree-box');
        parent::add((new CheckboxBool($name, $value, $label, $title, $stable))->addClass('tree-master'));
        parent::add($this->slaves = (new Division())->addClass('tree-slaves'));
    }

    public function add(string|iTag|null ...$content): static
    {
        $this->slaves->add(...$content);
        return $this;
    }
}