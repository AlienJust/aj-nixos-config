<?php

namespace Horizon\UserInterface\PresetTags;

class SortableSummonList extends SummonList
{
    public function __construct(string $id, string $counter_field_code, ?string $legend = null)
    {
        parent::__construct($id, $counter_field_code, $legend);
        $this->list->addClass('sortable-ul');
    }
}