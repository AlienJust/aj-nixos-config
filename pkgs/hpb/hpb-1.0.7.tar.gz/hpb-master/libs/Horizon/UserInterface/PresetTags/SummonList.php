<?php

namespace Horizon\UserInterface\PresetTags;


use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCallerAJAXFields;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Constants\DataAttribute;
use Horizon\UserInterface\Controls\Button;
use Horizon\UserInterface\Controls\InputHiddenValue;
use Horizon\UserInterface\iTag;
use Horizon\UserInterface\Tags\Division;
use Horizon\UserInterface\Tags\Fieldset;
use Horizon\UserInterface\Tags\Italic;
use Horizon\UserInterface\Tags\ListItem;
use Horizon\UserInterface\Tags\UnorderedList;
use Horizon\UserInterface\TagsPack;

class SummonList extends Fieldset
{
    private string $id;
    private string $counter_field_code;
    protected UnorderedList $list;
    private TagsPack $items;
    private InputHiddenValue $counter_tag;
    private Button $summon_button;
    private int $summon_min = 0;
    private int $items_amount = 0;
    private array $influencing_properties = [];

    public function __construct(string $id, string $counter_field_code, ?string $legend = null)
    {
        parent::__construct($legend);
        $this->id = $id;
        $this->counter_field_code = $counter_field_code;
        $this->summon_button = (new Button($this->id, '+'))->addClass('call-form-elements');
        $this->addInfluencingField($this->counter_field_code);
        parent::add(
            (new Division())->addClass('summon')->add($this->summon_button),
            $this->list = (new UnorderedList())->addClass('summon-ul')
                ->add($this->items = new TagsPack())
                ->add($this->tagSummonMark())
        );
    }

    /**
     * @param string ...$field_codes
     * @return $this Добавляет имена полей, от которых будет зависеть логика призыва контента
     */
    public function addInfluencingField(string ...$field_codes): static
    {
        foreach ($field_codes as $field_code) $this->influencing_properties[] = $field_code;
        $this->summon_button->addAttributeJSON(DataAttribute::calls, [
            eCallerAJAXFields::action->code() => $this->id,
            eCallerAJAXFields::destination->code() => $this->id,
            eCallerAJAXFields::properties->code() => $this->influencing_properties,
        ]);
        return $this;
    }

    public function setMin(int $value): static
    {
        $this->summon_min = $value;
        return $this;
    }

    public function setMax(int $value): static
    {
        $this->summon_button->addAttribute(DataAttribute::max, $value);
        return $this;
    }

    public function add(string|iTag|null ...$content): static
    {
        $this->items->add(...array_map(fn($tag) => $this->tagItem($tag), $content));
        return $this;
    }

    public function getItemsAmount(): int
    {
        $actual_amount = $this->items->countContent();
        if ($this->items_amount < $actual_amount) $this->items_amount = $actual_amount;
        return $this->items_amount;
    }

    /**
     * Увеличивает счетчик на 1 относительно переданного предыдущего значения
     * @param int $previous_value
     * @return static
     */
    public function increaseCounter(int $previous_value): static
    {
        $this->items_amount = $previous_value + 1;
        return $this;
    }

    protected function tagItem(iTag $element): ListItem
    {
        return (new ListItem())
            ->add(new Italic())
            ->add((new Division())->add($element))
            ->add((new Button('delete', '–'))->addAttribute(DataAttribute::min, $this->summon_min));
    }

    protected function tagSummonMark(): Division
    {
        return (new Division('Нажмите кнопку "+", чтобы добавить элемент в список »'))
            ->addClass('summon-mark')
            ->addAttribute(Attribute::id, $this->id)
            ->add($this->counter_tag = new InputHiddenValue($this->counter_field_code, $this->getItemsAmount()));
    }

    public function draw(): string
    {
        $this->counter_tag->addAttribute(Attribute::value, $this->getItemsAmount());
        return parent::draw();
    }

    public function tagNewItem(iTag $element): TagsPack
    {
        return (new TagsPack())
            ->add($this->tagItem($element))
            ->add($this->tagSummonMark());
    }
}