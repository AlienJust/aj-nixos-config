<?php

namespace Horizon\UserInterface\PresetTags;

use Horizon\UserInterface\Tags\Division;

class RequiredView extends Division
{
    public function __construct()
    {
        parent::__construct('*');
        $this->addClass('required-marker');
    }
}