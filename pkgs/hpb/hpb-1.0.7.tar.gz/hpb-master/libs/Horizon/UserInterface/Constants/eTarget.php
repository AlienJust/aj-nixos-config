<?php

namespace Horizon\UserInterface\Constants;

enum eTarget
{
    case _blank;
    case _self;
    case _parent;
    case _top;
}
