<?php

namespace Horizon\UserInterface\Constants;

enum DataAttribute: string
{
    case title = 'data-title';
    case min = 'data-min';
    case max = 'data-max';
    case calls = 'data-calls';
}