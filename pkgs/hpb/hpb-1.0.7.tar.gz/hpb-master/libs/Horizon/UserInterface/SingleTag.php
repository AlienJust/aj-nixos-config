<?php

namespace Horizon\UserInterface;

use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Constants\DataAttribute;

abstract class SingleTag implements iTag
{
    protected string $tag_name;
    /** @var string[] $classes */
    protected array $classes = [];
    /** @var string[] $styles */
    protected array $styles = [];
    protected array $other_attributes = [];

    protected function __construct(string $tag_name)
    {
        $this->tag_name = $tag_name;
    }

    public function addClass(string $class): static
    {
        $this->classes[] = $class;
        return $this;
    }

    public function addClassIf(string $class, bool $condition): static
    {
        if ($condition) $this->addClass($class);
        return $this;
    }

    public function addStyle(string $name, string $value): static
    {
        $this->styles[$name] = $value;
        return $this;
    }

    public function addAttribute(Attribute|DataAttribute $name, string|bool $value): static
    {
        $this->other_attributes[$name->value] = $value;
        return $this;
    }

    public function addAttributeJSON(Attribute|DataAttribute $name, array $values): static
    {
        $this->addAttribute($name, count($values) == 0 ? ''
            : str_replace('"', "'", json_encode($values)));
        return $this;
    }

    public function setDisabled(bool $value): static
    {
        return $this;
    }

    protected function getAttribute(Attribute|DataAttribute $name): string|bool|null
    {
        return $this->other_attributes[$name->value] ?? null;
    }

    protected function arrAttributes(): array
    {
        $attributes = [];
        if (!empty($this->classes)) $attributes['class'] = implode(' ', array_unique($this->classes));
        if (!empty($this->styles)) $attributes['style'] = implode(';', array_map(
            fn(string $k, string $v): string => "$k:$v",
            array_keys($this->styles), array_values($this->styles)
        ));
        $attributes = array_merge($attributes, array_filter($this->other_attributes, fn(string|bool $v): bool => $v !== false));
        return array_map(
            fn(string $k, string|bool $v): string => $v === true ? $k . '="' . $k . '"' : $k . '="' . $v . '"',
            array_keys($attributes), array_values($attributes)
        );
    }

    public function draw(): string
    {
        $tag = array_merge([$this->tag_name], $this->arrAttributes());
        return '<' . implode(' ', $tag) . '>';
    }
}