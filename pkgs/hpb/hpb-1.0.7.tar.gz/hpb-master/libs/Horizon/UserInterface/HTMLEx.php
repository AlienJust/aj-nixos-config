<?php

namespace Horizon\UserInterface;

enum HTMLEx: int
{
    case tagNotSupport = 0;

    public function message(): string
    {
        return match ($this) {
            self::tagNotSupport => 'Тег не поддерживается в данном контексте',
        };
    }
}
