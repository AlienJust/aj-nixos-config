<?php

namespace Horizon\UserInterface;

interface iTag
{
    public function draw(): string;
    public function setDisabled(bool $value): static;
}