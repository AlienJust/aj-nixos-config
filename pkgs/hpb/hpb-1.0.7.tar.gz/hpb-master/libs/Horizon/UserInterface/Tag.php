<?php

namespace Horizon\UserInterface;

abstract class Tag extends SingleTag
{
    protected TagsPack $pack;

    protected function __construct(string $tag_name)
    {
        parent::__construct($tag_name);
        $this->pack = new TagsPack();
    }

    public function add(iTag|string|null ...$content): static
    {
        foreach($content as $tag) $this->pack->add($tag);
        return $this;
    }

    public function setDisabled(bool $value): static
    {
        $this->pack->setDisabled($value);
        return parent::setDisabled($value);
    }

    protected function arrContent(): array
    {
        return $this->pack->arrContent();
    }

    public function draw(): string
    {
        return parent::draw() . $this->pack->draw() . '</' . $this->tag_name . '>';
    }
}