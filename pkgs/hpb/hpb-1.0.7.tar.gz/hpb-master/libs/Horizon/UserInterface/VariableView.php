<?php

namespace Horizon\UserInterface;

use Horizon\UserInterface\Tags\LineBreak;

class VariableView extends Tag
{
    protected function __construct(mixed ...$variables)
    {
        parent::__construct('pre');
        foreach ($variables as &$variable) $this->add(print_r($variable, true))->add(new LineBreak());
    }

    public static function output(mixed ...$variable): void
    {
        echo (new static(...$variable))->draw();
    }
}