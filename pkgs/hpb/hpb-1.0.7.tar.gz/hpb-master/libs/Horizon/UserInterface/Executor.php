<?php

namespace Horizon\UserInterface;

class Executor
{
    public string $URL = '' {
        get {
            return $this->URL;
        }
    }

    public function __construct(string $URL)
    {
        $this->URL = $URL;
        if (trim($this->URL) == '') $this->URL = "/";
    }

    final public function redirect(): void
    {
        header('Location:' . $this->URL);
    }
}