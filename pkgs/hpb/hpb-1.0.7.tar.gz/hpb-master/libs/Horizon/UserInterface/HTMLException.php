<?php

namespace Horizon\UserInterface;

use Exception;
use Throwable;

class HTMLException extends Exception
{
    public function __construct(HTMLEx $exception, ?Throwable $previous = null)
    {
        parent::__construct($exception->message(), $exception->value, $previous);
    }
}