<?php

namespace Horizon\UserInterface;

class TagsPack implements iTag
{
    /**
     * @var iTag[]|string[] $content
     */
    protected array $content = [];

    public function __construct()
    {
    }

    public function add(iTag|string|null ...$content): static
    {
        foreach ($content as &$tag) if (!is_null($tag)) $this->content[] = $tag;
        return $this;
    }

    public function countContent(): int
    {
        return count($this->content);
    }

    public function arrContent(): array
    {
        return $this->content;
    }

    public function draw(): string
    {
        $tags = array_map(fn(iTag|string $tag): string => is_string($tag) ? $tag : $tag->draw(), $this->content);
        return implode('', $tags);
    }

    public function isEmpty(): bool
    {
        return count($this->content) == 0;
    }

    public function setDisabled(bool $value): static
    {
        foreach ($this->content as &$tag) if (!is_string($tag)) $tag->setDisabled($value);
        return $this;
    }
}