<?php

namespace Horizon\UserInterface\Tags;

use Horizon\UserInterface\Tag;

class TableData extends Tag
{
    public function __construct(?string $text = null)
    {
        parent::__construct('td');
        $this->add($text);
    }
}