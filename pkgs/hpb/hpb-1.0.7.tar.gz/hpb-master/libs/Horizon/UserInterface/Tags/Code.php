<?php

namespace Horizon\UserInterface\Tags;

use Horizon\UserInterface\Tag;

class Code extends Tag
{
    public function __construct(?string $content = null)
    {
        parent::__construct('code');
        $this->add($content);
    }
}