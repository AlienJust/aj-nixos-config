<?php

namespace Horizon\UserInterface\Tags;

use Horizon\UserInterface\Tag;

class TableRow extends Tag
{
    public function __construct()
    {
        parent::__construct('tr');
    }
}