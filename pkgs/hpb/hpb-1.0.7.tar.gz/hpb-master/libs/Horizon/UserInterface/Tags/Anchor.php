<?php

namespace Horizon\UserInterface\Tags;

use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Constants\eTarget;
use Horizon\UserInterface\Tag;

class Anchor extends Tag
{
    public function __construct(string $href, ?string $text, eTarget $target = eTarget::_self)
    {
        parent::__construct('a');
        $this->addAttribute(Attribute::href, $href);
        if ($target !== eTarget::_self) $this->addAttribute(Attribute::target, $target->name);
        $this->add($text);

    }
}