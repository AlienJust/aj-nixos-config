<?php

namespace Horizon\UserInterface\Tags;

use Horizon\UserInterface\Tag;

class Division extends Tag
{
    public function __construct(?string $content = null)
    {
        parent::__construct('div');
        parent::add($content);
    }
}