<?php

namespace Horizon\UserInterface\Tags;

use Horizon\UserInterface\Tag;

class TableHeader extends Tag
{
    public function __construct(?string $text = null)
    {
        parent::__construct('th');
        $this->add($text);
    }
}