<?php

namespace Horizon\UserInterface\Tags;

use Horizon\UserInterface\HTMLEx;
use Horizon\UserInterface\HTMLException;
use Horizon\UserInterface\iTag;
use Horizon\UserInterface\Tag;
use Horizon\UserInterface\TagsPack;

class UnorderedList extends Tag
{
    public function __construct()
    {
        parent::__construct('ul');
    }
}