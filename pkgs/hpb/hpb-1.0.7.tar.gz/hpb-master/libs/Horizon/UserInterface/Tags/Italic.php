<?php

namespace Horizon\UserInterface\Tags;

use Horizon\UserInterface\Tag;

class Italic extends Tag
{
    public function __construct()
    {
        parent::__construct('i');
    }
}