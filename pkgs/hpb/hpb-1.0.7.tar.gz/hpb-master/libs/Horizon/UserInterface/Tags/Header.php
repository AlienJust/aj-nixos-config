<?php

namespace Horizon\UserInterface\Tags;

use Horizon\UserInterface\Tag;

class Header extends Tag
{
    public function __construct(int $level, string $text = '')
    {
        parent::__construct('h' . $level);
        $this->add($text);
    }
}