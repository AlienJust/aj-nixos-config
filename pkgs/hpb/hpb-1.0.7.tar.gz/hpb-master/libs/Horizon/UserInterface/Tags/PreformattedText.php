<?php

namespace Horizon\UserInterface\Tags;

use Horizon\UserInterface\Tag;

class PreformattedText extends Tag
{
    public function __construct(?string $content = null)
    {
        parent::__construct('pre');
        $this->add($content);
    }
}