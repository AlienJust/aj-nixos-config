<?php

namespace Horizon\UserInterface\Tags;

use Horizon\UserInterface\Tag;

class ListItem extends Tag
{
    public function __construct()
    {
        parent::__construct('li');
    }
}