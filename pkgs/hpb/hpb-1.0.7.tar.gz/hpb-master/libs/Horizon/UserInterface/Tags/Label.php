<?php

namespace Horizon\UserInterface\Tags;

use Horizon\UserInterface\Tag;

class Label extends Tag
{
    public function __construct()
    {
        parent::__construct('label');
    }
}