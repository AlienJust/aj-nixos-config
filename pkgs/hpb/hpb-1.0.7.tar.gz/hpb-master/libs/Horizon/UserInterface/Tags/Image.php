<?php

namespace Horizon\UserInterface\Tags;

use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\SingleTag;

class Image extends SingleTag
{
    public function __construct(string $src)
    {
        parent::__construct('img');
        parent::addAttribute(Attribute::src, $src);
    }
}