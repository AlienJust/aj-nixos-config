<?php

namespace Horizon\UserInterface\Tags;

use Horizon\UserInterface\Tag;

class Legend extends Tag
{
    public function __construct(?string $content = null)
    {
        parent::__construct('legend');
        $this->add($content);
    }
}