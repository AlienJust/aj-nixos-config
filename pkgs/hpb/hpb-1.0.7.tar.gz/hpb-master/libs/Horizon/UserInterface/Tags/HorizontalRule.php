<?php

namespace Horizon\UserInterface\Tags;

use Horizon\UserInterface\SingleTag;

class HorizontalRule extends SingleTag
{
    public function __construct()
    {
        parent::__construct('hr');
    }
}