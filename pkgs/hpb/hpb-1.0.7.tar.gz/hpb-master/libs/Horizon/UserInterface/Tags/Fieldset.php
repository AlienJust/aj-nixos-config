<?php

namespace Horizon\UserInterface\Tags;

use Horizon\UserInterface\Tag;

class Fieldset extends Tag
{
    public function __construct(?string $legend = null)
    {
        parent::__construct('fieldset');
        if(!is_null($legend)) parent::add(new Legend($legend));
    }
}