<?php

namespace Horizon\UserInterface\Tags;

use Horizon\UserInterface\SingleTag;

class LineBreak extends SingleTag
{
    public function __construct()
    {
        parent::__construct('br');
    }
}