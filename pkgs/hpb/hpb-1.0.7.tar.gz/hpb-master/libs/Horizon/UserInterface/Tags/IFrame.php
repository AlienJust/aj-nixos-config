<?php

namespace Horizon\UserInterface\Tags;

use Horizon\UserInterface\Tag;

class IFrame extends Tag
{
    public function __construct()
    {
        parent::__construct('iframe');
    }
}