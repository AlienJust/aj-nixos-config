<?php

namespace Horizon\UserInterface\Tags;

use Horizon\UserInterface\Tag;

class Table extends Tag
{
    public function __construct()
    {
        parent::__construct('table');
    }
}