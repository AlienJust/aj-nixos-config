<?php

namespace Horizon\UserInterface\Tags;

use Horizon\UserInterface\Tag;

class Paragraph extends Tag
{
    public function __construct(?string $text = null)
    {
        parent::__construct('p');
        $this->add($text);
    }
}