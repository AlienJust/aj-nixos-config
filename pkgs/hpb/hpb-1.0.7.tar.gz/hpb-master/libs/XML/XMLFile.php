<?php

namespace XML;

class XMLFile
{
    private XMLAttribute $version;
    private XMLAttribute $encoding;
    private XMLNode $main_node;

    private function __construct(string $version, string $encoding)
    {
        $this->version = new XMLAttribute('version', $version);
        $this->encoding = new XMLAttribute('encoding', $encoding);
    }

    public function refNode(): XMLNode
    {
        return $this->main_node;
    }

    public function addContent(XMLNode $main_node): static
    {
        $this->main_node = $main_node;
        return $this;
    }

    public function draw(): string
    {
        return '<?xml' . $this->version->draw() . $this->encoding->draw() . '?>'
            . $this->main_node->draw();
    }

    public static function init(string $version = '1.0', string $encoding = 'utf-8'): static
    {
        return new static($version, $encoding);
    }
}