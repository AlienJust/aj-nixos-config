<?php

namespace XML;

class XMLAttribute
{
    private string $name;
    private string $value;

    public function __construct(string $name, string $value)
    {
        $this->name = $name;
        $this->value = $value;
    }

    public function draw(): string
    {
        return ' ' . $this->name . ' ="' . $this->value . '"';
    }
}