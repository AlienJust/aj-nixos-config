<?php

namespace XML;

class XMLNode
{
    private string $name;
    /** @var XMLAttribute[] $attributes */
    private array $attributes = [];
    /** @var XMLNode[] $nodes */
    private array $nodes = [];

    private function __construct(string $name)
    {
        $this->name = $name;
    }

    public function addAttribute(string $name, string $value): static
    {
        $this->attributes[] = new XMLAttribute($name, $value);
        return $this;
    }

    public function addNode(XMLNode $node): static
    {
        $this->nodes[] = $node;
        return $this;
    }

    public function draw(): string
    {
        $result = PHP_EOL . '<' . $this->name;
        foreach ($this->attributes as $attribute) $result .= $attribute->draw();
        $result .= '>';
        foreach ($this->nodes as $node) $result .= $node->draw();
        $result .= (count($this->nodes) > 0) ? PHP_EOL . '</' . $this->name . '>' : ' />';
        return $result;
    }

    public static function init(string $name): static
    {
        return new static($name);
    }
}