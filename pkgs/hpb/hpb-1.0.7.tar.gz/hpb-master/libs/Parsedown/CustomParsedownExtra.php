<?php

namespace Parsedown;

/**
 * Надстройка DeepSeek для того, чтобы заголовки имели якоря для оглавления.
 */
class CustomParsedownExtra extends ParsedownExtra
{
    protected array $toc = []; // Массив для хранения оглавления
    protected array $toc_calc = []; // Массив для подсчета повторяющихся ID заголовков в документе

    /**
     * @return string Метод для генерации оглавления
     */
    public function getTOC(): string
    {
        if (empty($this->toc)) {
            return '';
        }

        $tocHtml = '<ul>';
        $currentLevel = 2; // Начинаем с h2

        foreach ($this->toc as $item) {
            // Если уровень заголовка повысился, открываем новый <ul>
            while ($currentLevel < $item['level']) {
                $tocHtml .= '<ul>';
                $currentLevel++;
            }

            // Если уровень заголовка понизился, закрываем предыдущие <ul>
            while ($currentLevel > $item['level']) {
                $tocHtml .= '</ul>';
                $currentLevel--;
            }

            // Добавляем пункт оглавления
            $tocHtml .= sprintf(
                '<li><a href="#%s">%s</a></li>',
                $item['anchor'],
                $item['text']
            );
        }

        // Закрываем все открытые <ul>
        while ($currentLevel > 2) {
            $tocHtml .= '</ul>';
            $currentLevel--;
        }

        $tocHtml .= '</ul>';
        return $tocHtml;
    }

    protected function blockHeader($Line) {
        $block = parent::blockHeader($Line);
        if (isset($block['element']['text']) && $block['element']['name'] !== 'h1') {
            $text = $block['element']['text'];
            $anchor = $this->createAnchor($text);
            // Добавляем id к заголовку
            $block['element']['attributes']['id'] = $anchor;
            // Добавляем заголовок в TOC
            $this->toc[] = [
                'level' => (int) substr($block['element']['name'], 1), // Уровень заголовка (2, 3, ...)
                'text' => $text,
                'anchor' => $anchor,
            ];
        }
        return $block;
    }

    protected function createAnchor($text): string
    {
        $text = mb_strtolower($text); // Переводим в нижний регистр
        $text = preg_replace('/[^a-z0-9а-яё \-]/u', '', $text); // Удаляем спецсимволы
        $text = preg_replace('/[^a-z0-9а-яё\-]/u', '-', $text); // Заменяем пробелы на дефисы
        $text =  trim($text, '-'); // Убираем дефисы по краям
        $this->toc_calc[$text] = ($this->toc_calc[$text] ?? -1) + 1;
        if ($this->toc_calc[$text] > 0) $text = $text . '-' . $this->toc_calc[$text];
        return $text;
    }
}