function Horizon() {
    const horizon = this;

    this.changeCheckboxes = function (checkbox) {
        let checkboxes = checkbox.parentNode.parentNode.querySelectorAll('input');
        for (let i = 1; i < checkboxes.length; i++) {
            checkboxes[i].checked = checkbox.checked;
        }
    }

    this.parseOptions = function (options) {
        return options === '' || options === undefined ? null : $.parseJSON(options.replace(/'/g, '"'));
    };

    this.getLoader = function () {
        return '<div class="cssload-loader">' +
            '<div class="cssload-inner cssload-one"></div>' +
            '<div class="cssload-inner cssload-two"></div>' +
            '<div class="cssload-inner cssload-three"></div>' +
            '</div>';
    };

    this.drawLoader = function (content, timeOut) {
        if (timeOut !== 'undefined') {
            clearTimeout(timeOut);
        }
        return setTimeout(function () {
            content.html(horizon.getLoader());
            content.find('.cssload-loader').hide().fadeIn(200);
        }, 300);
    };

    this.loadFormElementsAJAX = async function (action, properties, destination,
                                                replace = false, delay_ms = 0) {
        replace = replace || false;
        let form = destination.closest('form');
        form.addClass('disabled');
        const moment = performance.now();
        destination.data('moment', moment);
        let timeOut = this.drawLoader(replace ? destination.prepend('<div></div>').find('div'): destination);
        await new Promise(r => setTimeout(r, delay_ms));
        if (destination.data('moment') === moment) {
            $.ajax({
                url: "/components/public/tags.php",
                method: "POST",
                data: {
                    action: action,
                    properties: properties
                },
                dataType: "html"
            }).done(function (msg) {
                clearTimeout(timeOut);
                if (destination.data('moment') === moment) {
                    if (replace) {
                        $.when(destination.replaceWith(msg)).then(function () {
                            //dobro.initTitle();
                            //dobro.initMask();
                            //dobro.initObjectProperties();
                            form.removeClass('disabled');
                        });
                    } else {
                        $.when(destination.html(msg)).then(function () {
                            //dobro.initTitle();
                            //dobro.initMask();
                            //dobro.initObjectProperties();
                            form.removeClass('disabled');
                        });
                    }
                }
            }).fail(function (jqxhr, textStatus, error) {
                const err = textStatus + ", " + error;
                console.error("Request Failed: ", err);
                destination.text(err);
            });
        } else {
            clearTimeout(timeOut);
        }
        //return true;
    };

    this.parseCallFormElements = function(elem, value){
        const calls = this.parseOptions(elem.data('calls'));
        $(calls).each(function () {
            let properties = {}, name;
            if (value !== undefined)
                properties[elem.attr('name').replace(/\[/g, '{').replace(/]/g, '}')] = value;
            $(this.properties).each(function () {
                var properties_element = elem.closest('form').find('[name="' + this + '"][type="radio"]:checked');
                if (properties_element.length === 0) {
                    properties_element = elem.closest('form').find('[name="' + this + '"]:not(.inflight)');
                }
                if (properties_element.length > 1) {
                    properties_element.each(function (index, obj) {
                        name = $(obj).attr('name').replace(/\[/g, '{').replace(/]/g, '}');
                        if (properties[name] === undefined) {
                            properties[name] = [];
                        }
                        properties[name][$(properties[name]).length]
                            = $(obj).val();
                    });

                } else if (properties_element.length > 0) {
                    properties[properties_element.attr('name').replace(/\[/g, '{').replace(/]/g, '}')]
                        = properties_element.val();
                }
            });
            horizon.loadFormElementsAJAX(this.action, properties,
                elem.closest('form').find('div#' + this.destination), elem.attr('type') === 'button');
        });
    };

    this.initTreeBoxes = function () {
        let masters = $('.tree-box > .tree-master input[type="checkbox"]');
        console.log('init tree', masters);
        function changeSlavesState(master){
            const checked = master.prop('checked'), //&& !master.prop('disabled'),
                disabled = master.prop('disabled'),
                boxes = master.closest('.tree-box').children('.tree-slaves'),
                slaves = boxes
                    .children('*:not(.tree-box)')
                    .find('select:not([readonly]), input:not([readonly]), textarea:not([readonly])'),
                slaves_checkbox = boxes
                    .children('*:not(.tree-box)')
                    .find('input[type="checkbox"]'),
                masters_inside = boxes
                    .children('.tree-box')
                    .children('.tree-master')
                    .find('input[type="checkbox"]');
            $.when(slaves.attr('disabled', !checked || disabled)).then(function () {
                /*if(masters_inside.length > 0) {
                    masters_inside.each(function () {
                        changeSlavesState($(this)); //Рекурсия для чекбоксов-мастеров внутри нашего мастера
                    });
                }*/
            });
            slaves_checkbox.val(checked ? 1 : 0);
            if (checked) {
                boxes.removeClass('disabled');
            } else {
                /*slaves.nextAll('.error_box').text('');
                slaves.each(function () {
                    this.setCustomValidity('');
                });*/
                boxes.addClass('disabled');
            }
        }
        masters.each(function(){
            changeSlavesState($(this));
        });
        masters.on('change',function (ev) {
            changeSlavesState($(ev.target));
        });
    };

    this.initEvents = function(){
        $(document)
            .on('click', 'input[type="button"].call-form-elements, input[type="number"].call-form-elements',
                function (ev) {
                    horizon.parseCallFormElements($(ev.currentTarget),$(ev.currentTarget).val());
                })
            .on('click', 'input[name="delete"]',
                function (ev) {
                    var button = $(ev.currentTarget),
                        del = button.parent(),
                        parent = del.parent();
                    if (button.data('min') === undefined
                        || button.data('min') < parent.children('*:not([class*="summon"])').length) {
                        if (del.find('input,select').val() !== '' && del.find('input,select').val() !== null) {
                            if (button.data('not-confirm') !== undefined
                                || confirm('Удалить строку?')) {
                                del.replaceWith('');
                                //parent.children('*[class*="summon"]').empty();
                            }
                        }
                        else del.replaceWith('');
                    } else alert('Удаление невозможно. Достигнуто минимальное количество строк.');

                });
        $('.sortable-ul').sortable({items:'li',cancel: '.disable',handle: 'i',revert: 100});
        $('.sortable-column').sortable({
            connectWith: ".sortable-column"
        });
        this.initTreeBoxes();
    }

    this.initEvents();
}