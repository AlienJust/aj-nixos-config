<?php
include_once 'components/private/loader.php';

(new \Horizon\ProtocolBuilder\UserInterface\UICore(
    \Horizon\ProtocolBuilder\UserInterface\Pages\MainPage::go()
        ->setCSS('styles/main.css')
        ->setJS('js/jquery/jquery.js', 'js/jquery/ui/jquery-ui.min.js'),
    (new \Horizon\ProtocolBuilder\UserInterface\Pages\SafePage())
        ->setCSS('styles/main.css'),
    (new \Horizon\ProtocolBuilder\UserInterface\Pages\UnknownPage())
        ->setCSS('styles/main.css')
))->output();
