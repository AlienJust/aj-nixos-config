ALTER TABLE `pb_command_parameter` ADD `conflicted_GUID` BINARY(16) NULL DEFAULT NULL AFTER `command`;
-- HPB-0.1.0 – 2025.02.20
ALTER TABLE `pb_subscriber` ADD `hide_for_production` BOOLEAN NOT NULL DEFAULT TRUE AFTER `description`;

CREATE TABLE `hpb`.`h_user`
(
    `ID`         INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    `username`  VARCHAR(32)       NOT NULL,
    `role`       TINYINT UNSIGNED NOT NULL,
    `password`   VARCHAR(255)     NOT NULL,
    `surname`    VARCHAR(64)      NOT NULL,
    `name`       VARCHAR(32)      NOT NULL,
    `patronymic` VARCHAR(32)      NOT NULL,
    `ban`        BOOLEAN          NOT NULL DEFAULT FALSE,
    PRIMARY KEY (`ID`)
) ENGINE = InnoDB;
CREATE TABLE `hpb`.`h_device`
(
    `user`                INT UNSIGNED     NOT NULL,
    `imprint`             VARCHAR(64)      NOT NULL,
    `attempts`            TINYINT UNSIGNED NOT NULL,
    `last_attempt_moment` TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `info`                VARCHAR(255)     NOT NULL,
    `token_moment`        TIMESTAMP        NULL     DEFAULT NULL,
    `access_token_hash`   VARCHAR(255)     NULL     DEFAULT NULL,
    `refresh_token_hash`  VARCHAR(255)     NULL     DEFAULT NULL
) ENGINE = InnoDB;
ALTER TABLE `h_device` ADD PRIMARY KEY(`user`, `imprint`);
CREATE TABLE `hpb`.`h_group`
(
    `ID`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `name`        VARCHAR(255)  NOT NULL,
    `description` VARCHAR(2000) NOT NULL,
    PRIMARY KEY (`ID`)
) ENGINE = InnoDB;
CREATE TABLE `hpb`.`h_group_tree`
(
    `master` INT UNSIGNED     NOT NULL,
    `slave`  INT UNSIGNED     NOT NULL,
    `level`  TINYINT UNSIGNED NOT NULL
) ENGINE = InnoDB;
ALTER TABLE `h_group_tree` ADD PRIMARY KEY(`master`, `slave`);

ALTER TABLE `h_group_tree`
    ADD FOREIGN KEY (`master`) REFERENCES `h_group` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `h_group_tree`
    ADD FOREIGN KEY (`slave`) REFERENCES `h_group` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE `hpb`.`h_group_x_user`
(
    `user_ID` INT UNSIGNED NOT NULL,
    `group_ID`  INT UNSIGNED NOT NULL
) ENGINE = InnoDB;
ALTER TABLE `h_group_x_user` ADD PRIMARY KEY(`user_ID`, `group_ID`);
ALTER TABLE `h_group_x_user` ADD FOREIGN KEY (`user_ID`) REFERENCES `h_user`(`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `h_group_x_user` ADD FOREIGN KEY (`group_ID`) REFERENCES `h_group`(`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE `hpb`.`h_group_x_protocol`
(
    `group_ID`    INT UNSIGNED NOT NULL,
    `protocol_ID` INT UNSIGNED NOT NULL
) ENGINE = InnoDB;
ALTER TABLE `h_group_x_protocol` ADD PRIMARY KEY(`group_ID`, `protocol_ID`);
ALTER TABLE `h_group_x_protocol` ADD FOREIGN KEY (`group_ID`) REFERENCES `h_group`(`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `h_group_x_protocol` ADD FOREIGN KEY (`protocol_ID`) REFERENCES `pb_protocol`(`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `pb_protocol` ADD `author` INT UNSIGNED NOT NULL AFTER `version`;
ALTER TABLE `pb_protocol` ADD INDEX(`author`);
UPDATE `pb_protocol` SET `author` = '4';
ALTER TABLE `pb_protocol` ADD FOREIGN KEY (`author`) REFERENCES `h_group`(`ID`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- 2025-09-17 v1.1
CREATE TABLE `hpb`.`h_role` (`ID` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT , `name` VARCHAR(255) NOT NULL , PRIMARY KEY (`ID`)) ENGINE = InnoDB;
INSERT INTO `h_role` (`ID`, `name`)
VALUES (1, 'Разработчик'),
       (2, 'Администратор'),
       (3, 'Редактор протокола'),
       (4, 'Гость');

CREATE TABLE `hpb`.`h_role_action` (`role` SMALLINT UNSIGNED NOT NULL , `section` VARCHAR(255) NOT NULL , `action` VARCHAR(255) NOT NULL ) ENGINE = InnoDB;
ALTER TABLE `h_role_action` ADD PRIMARY KEY(`role`, `section`, `action`);
INSERT INTO `h_role_action` (`role`, `section`, `action`)
VALUES (1, 'command', 'copy'),
       (1, 'command', 'delete'),
       (1, 'command', 'delete_parameters'),
       (1, 'command', 'edit'),
       (1, 'command', 'new'),
       (1, 'command', 'view'),
       (1, 'protocol', 'delete'),
       (1, 'protocol', 'edit'),
       (1, 'protocol', 'edit_author'),
       (1, 'protocol', 'groups_editing'),
       (1, 'protocol', 'import'),
       (1, 'protocol', 'import_param_views'),
       (1, 'protocol', 'init_main_xaml'),
       (1, 'protocol', 'init_psn_xml'),
       (1, 'protocol', 'init_tabs_xml'),
       (1, 'protocol', 'manual'),
       (1, 'protocol', 'new'),
       (1, 'protocol', 'system_diagnostic_allocating'),
       (1, 'protocol', 'system_diagnostic_renaming'),
       (1, 'protocol', 'system_diagnostic_tuning'),
       (1, 'protocol', 'view'),
       (1, 'reply_parameter', 'delete'),
       (1, 'reply_parameter', 'delete_view'),
       (1, 'reply_parameter', 'edit'),
       (1, 'reply_parameter', 'edit_view'),
       (1, 'reply_parameter', 'new'),
       (1, 'reply_parameter', 'new_bits'),
       (1, 'reply_parameter', 'new_default_value'),
       (1, 'reply_parameter', 'new_variable'),
       (1, 'reply_parameter', 'new_view'),
       (1, 'reply_parameter', 'view'),
       (1, 'request_parameter', 'delete'),
       (1, 'request_parameter', 'delete_view'),
       (1, 'request_parameter', 'edit'),
       (1, 'request_parameter', 'edit_view'),
       (1, 'request_parameter', 'new'),
       (1, 'request_parameter', 'new_bits'),
       (1, 'request_parameter', 'new_default_value'),
       (1, 'request_parameter', 'new_variable'),
       (1, 'request_parameter', 'new_view'),
       (1, 'request_parameter', 'view'),
       (1, 'subscriber', 'delete'),
       (1, 'subscriber', 'edit'),
       (1, 'subscriber', 'new'),
       (1, 'subscriber', 'view'),
       (1, 'user', 'delete'),
       (1, 'user', 'edit'),
       (1, 'user', 'groups_editing'),
       (1, 'user', 'main'),
       (1, 'user', 'new'),
       (1, 'user', 'password_resetting'),
       (1, 'user_group', 'delete'),
       (1, 'user_group', 'edit'),
       (1, 'user_group', 'main'),
       (1, 'user_group', 'new'),
       (1, 'user_role', 'delete'),
       (1, 'user_role', 'edit'),
       (1, 'user_role', 'main'),
       (1, 'user_role', 'new'),
       (2, 'command', 'copy'),
       (2, 'command', 'delete'),
       (2, 'command', 'delete_parameters'),
       (2, 'command', 'edit'),
       (2, 'command', 'new'),
       (2, 'command', 'view'),
       (2, 'protocol', 'delete'),
       (2, 'protocol', 'edit'),
       (2, 'protocol', 'edit_author'),
       (2, 'protocol', 'groups_editing'),
       (2, 'protocol', 'import'),
       (2, 'protocol', 'import_param_views'),
       (2, 'protocol', 'init_main_xaml'),
       (2, 'protocol', 'init_psn_xml'),
       (2, 'protocol', 'init_tabs_xml'),
       (2, 'protocol', 'manual'),
       (2, 'protocol', 'new'),
       (2, 'protocol', 'system_diagnostic_allocating'),
       (2, 'protocol', 'system_diagnostic_renaming'),
       (2, 'protocol', 'system_diagnostic_tuning'),
       (2, 'protocol', 'view'),
       (2, 'reply_parameter', 'delete'),
       (2, 'reply_parameter', 'delete_view'),
       (2, 'reply_parameter', 'edit'),
       (2, 'reply_parameter', 'edit_view'),
       (2, 'reply_parameter', 'new'),
       (2, 'reply_parameter', 'new_bits'),
       (2, 'reply_parameter', 'new_default_value'),
       (2, 'reply_parameter', 'new_variable'),
       (2, 'reply_parameter', 'new_view'),
       (2, 'reply_parameter', 'view'),
       (2, 'request_parameter', 'delete'),
       (2, 'request_parameter', 'delete_view'),
       (2, 'request_parameter', 'edit'),
       (2, 'request_parameter', 'edit_view'),
       (2, 'request_parameter', 'new'),
       (2, 'request_parameter', 'new_bits'),
       (2, 'request_parameter', 'new_default_value'),
       (2, 'request_parameter', 'new_variable'),
       (2, 'request_parameter', 'new_view'),
       (2, 'request_parameter', 'view'),
       (2, 'subscriber', 'delete'),
       (2, 'subscriber', 'edit'),
       (2, 'subscriber', 'new'),
       (2, 'subscriber', 'view'),
       (2, 'user', 'delete'),
       (2, 'user', 'edit'),
       (2, 'user', 'groups_editing'),
       (2, 'user', 'main'),
       (2, 'user', 'new'),
       (2, 'user', 'password_resetting'),
       (2, 'user_group', 'delete'),
       (2, 'user_group', 'edit'),
       (2, 'user_group', 'main'),
       (2, 'user_group', 'new'),
       (2, 'user_role', 'delete'),
       (2, 'user_role', 'edit'),
       (2, 'user_role', 'main'),
       (2, 'user_role', 'new'),
       (3, 'command', 'copy'),
       (3, 'command', 'delete'),
       (3, 'command', 'delete_parameters'),
       (3, 'command', 'edit'),
       (3, 'command', 'new'),
       (3, 'command', 'view'),
       (3, 'protocol', 'edit'),
       (3, 'protocol', 'manual'),
       (3, 'protocol', 'new'),
       (3, 'protocol', 'system_diagnostic_allocating'),
       (3, 'protocol', 'system_diagnostic_renaming'),
       (3, 'protocol', 'system_diagnostic_tuning'),
       (3, 'protocol', 'view'),
       (3, 'reply_parameter', 'delete'),
       (3, 'reply_parameter', 'delete_view'),
       (3, 'reply_parameter', 'edit'),
       (3, 'reply_parameter', 'edit_view'),
       (3, 'reply_parameter', 'new'),
       (3, 'reply_parameter', 'new_bits'),
       (3, 'reply_parameter', 'new_default_value'),
       (3, 'reply_parameter', 'new_variable'),
       (3, 'reply_parameter', 'new_view'),
       (3, 'reply_parameter', 'view'),
       (3, 'request_parameter', 'delete'),
       (3, 'request_parameter', 'delete_view'),
       (3, 'request_parameter', 'edit'),
       (3, 'request_parameter', 'edit_view'),
       (3, 'request_parameter', 'new'),
       (3, 'request_parameter', 'new_bits'),
       (3, 'request_parameter', 'new_default_value'),
       (3, 'request_parameter', 'new_variable'),
       (3, 'request_parameter', 'new_view'),
       (3, 'request_parameter', 'view'),
       (3, 'subscriber', 'delete'),
       (3, 'subscriber', 'edit'),
       (3, 'subscriber', 'new'),
       (3, 'subscriber', 'view'),
       (4, 'command', 'view'),
       (4, 'protocol', 'init_main_xaml'),
       (4, 'protocol', 'init_psn_xml'),
       (4, 'protocol', 'init_tabs_xml'),
       (4, 'protocol', 'manual'),
       (4, 'reply_parameter', 'view'),
       (4, 'request_parameter', 'view'),
       (4, 'subscriber', 'view');

ALTER TABLE `h_role_action` ADD FOREIGN KEY (`role`) REFERENCES `h_role`(`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `pb_system_diagnostic_block` ADD `hide_for_production` BOOLEAN NOT NULL AFTER `inline`;
UPDATE `h_user` SET `role` = '1' WHERE `h_user`.`ID` IN (1,2);
ALTER TABLE `h_user` ADD INDEX(`role`);
ALTER TABLE `h_user` CHANGE `role` `role` SMALLINT UNSIGNED NOT NULL;
UPDATE `h_user` SET `role`=1;
ALTER TABLE `h_user` ADD FOREIGN KEY (`role`) REFERENCES `h_role`(`ID`) ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE `h_user` ADD UNIQUE(`username`);

ALTER TABLE `pb_protocol` CHANGE `version` `version` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL;

-- 2025-12-11 v1.2

ALTER TABLE `pb_system_diagnostic_chunk` ADD `visibility_converter` TINYINT UNSIGNED NOT NULL AFTER `column_span`;
ALTER TABLE `pb_system_diagnostic_virtual_chunk` ADD `visibility_converter` TINYINT UNSIGNED NOT NULL AFTER `column_span`;
ALTER TABLE `pb_system_diagnostic_aggregate_chunk` ADD `visibility_converter` TINYINT UNSIGNED NOT NULL AFTER `column_span`;

CREATE TABLE `hpb`.`pb_command_parameter_bits` (`GUID` BINARY(16) NOT NULL , `bit` MEDIUMINT UNSIGNED NOT NULL ) ENGINE = InnoDB;
ALTER TABLE `pb_command_parameter_bits` ADD PRIMARY KEY(`GUID`, `bit`);
ALTER TABLE `pb_command_parameter_bits` ADD FOREIGN KEY (`GUID`) REFERENCES `pb_command_parameter`(`GUID`) ON DELETE CASCADE ON UPDATE CASCADE;

DELIMITER $$

CREATE TRIGGER `after_pb_command_parameter_insert` AFTER INSERT ON `pb_command_parameter`
    FOR EACH ROW BEGIN
    DECLARE v_bits VARCHAR(2000);
    DECLARE v_current_pos INT DEFAULT 1;
    DECLARE v_next_comma INT;
    DECLARE v_current_bit VARCHAR(20);

    -- Получаем значение поля bits
    SET v_bits = NEW.bits;

    -- Если пустое значение
    IF NOT (v_bits IS NULL OR TRIM(v_bits) = '' OR v_bits = '[]') THEN
        -- Убираем внешние квадратные скобки
        IF LEFT(v_bits, 1) = '[' THEN
            SET v_bits = SUBSTRING(v_bits, 2);
        END IF;

        IF RIGHT(v_bits, 1) = ']' THEN
            SET v_bits = SUBSTRING(v_bits, 1, LENGTH(v_bits) - 1);
        END IF;

        -- Парсим значения через запятую
        WHILE v_current_pos <= LENGTH(v_bits)
            DO
                -- Ищем следующую запятую
                SET v_next_comma = LOCATE(',', v_bits, v_current_pos);

                IF v_next_comma = 0 THEN
                    -- Последнее значение
                    SET v_current_bit = TRIM(SUBSTRING(v_bits, v_current_pos));
                    SET v_current_pos = LENGTH(v_bits) + 1;
                ELSE
                    -- Есть следующее значение
                    SET v_current_bit = TRIM(SUBSTRING(v_bits, v_current_pos, v_next_comma - v_current_pos));
                    SET v_current_pos = v_next_comma + 1;
                END IF;

                -- Если значение не пустое, вставляем
                IF v_current_bit != '' THEN
                    INSERT INTO pb_command_parameter_bits (GUID, bit)
                    VALUES (NEW.GUID, CAST(v_current_bit AS UNSIGNED));
                END IF;
            END WHILE;
    END IF;
END$$

CREATE TRIGGER `after_pb_command_parameter_update` AFTER UPDATE ON `pb_command_parameter`
    FOR EACH ROW BEGIN
    DECLARE v_bits VARCHAR(2000);
    DECLARE v_current_pos INT DEFAULT 1;
    DECLARE v_next_comma INT;
    DECLARE v_current_bit VARCHAR(20);

    -- Проверяем, изменилось ли поле bits
    IF NOT (NEW.bits <=> OLD.bits) THEN
        -- Удаляем старые записи для этого GUID
        DELETE FROM pb_command_parameter_bits WHERE GUID = NEW.GUID;
        -- Получаем значение поля bits
        SET v_bits = NEW.bits;

        -- Если не пустое значение
        IF NOT (v_bits IS NULL OR TRIM(v_bits) = '' OR v_bits = '[]') THEN
            -- Убираем внешние квадратные скобки
            IF LEFT(v_bits, 1) = '[' THEN
                SET v_bits = SUBSTRING(v_bits, 2);
            END IF;

            IF RIGHT(v_bits, 1) = ']' THEN
                SET v_bits = SUBSTRING(v_bits, 1, LENGTH(v_bits) - 1);
            END IF;

            -- Парсим значения через запятую
            WHILE v_current_pos <= LENGTH(v_bits)
                DO
                    -- Ищем следующую запятую
                    SET v_next_comma = LOCATE(',', v_bits, v_current_pos);

                    IF v_next_comma = 0 THEN
                        -- Последнее значение
                        SET v_current_bit = TRIM(SUBSTRING(v_bits, v_current_pos));
                        SET v_current_pos = LENGTH(v_bits) + 1;
                    ELSE
                        -- Есть следующее значение
                        SET v_current_bit = TRIM(SUBSTRING(v_bits, v_current_pos, v_next_comma - v_current_pos));
                        SET v_current_pos = v_next_comma + 1;
                    END IF;

                    -- Если значение не пустое, вставляем
                    IF v_current_bit != '' THEN
                        INSERT INTO pb_command_parameter_bits (GUID, bit)
                        VALUES (NEW.GUID, CAST(v_current_bit AS UNSIGNED));
                    END IF;
                END WHILE;
        END IF;
    END IF;
END$$

DELIMITER ;


DELIMITER //

CREATE PROCEDURE rebuild_pb_command_parameter_bits()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_guid BINARY(16);
    DECLARE v_bits VARCHAR(2000);
    DECLARE v_current_pos INT;
    DECLARE v_next_comma INT;
    DECLARE v_current_bit VARCHAR(20);

    -- Объявляем курсор для всех записей в таблице pb_command_parameter
    DECLARE cur CURSOR FOR
        SELECT GUID, bits
        FROM pb_command_parameter;

    -- Обработчик для конца данных
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    -- Очищаем целевую таблицу
    TRUNCATE TABLE pb_command_parameter_bits;

    -- Открываем курсор
    OPEN cur;

    -- Читаем записи
    read_loop: LOOP
        FETCH cur INTO v_guid, v_bits;

        IF done THEN
            LEAVE read_loop;
        END IF;

        -- Сбрасываем переменные для новой записи
        SET v_current_pos = 1;
        SET v_next_comma = 0;
        SET v_current_bit = '';

        -- Если пустое значение - пропускаем
        IF NOT (v_bits IS NULL OR TRIM(v_bits) = '' OR v_bits = '[]') THEN
            -- Убираем внешние квадратные скобки
            IF LEFT(v_bits, 1) = '[' THEN
                SET v_bits = SUBSTRING(v_bits, 2);
            END IF;

            IF RIGHT(v_bits, 1) = ']' THEN
                SET v_bits = SUBSTRING(v_bits, 1, LENGTH(v_bits) - 1);
            END IF;

            -- Парсим значения через запятую
            WHILE v_current_pos <= LENGTH(v_bits) DO
                    -- Ищем следующую запятую
                    SET v_next_comma = LOCATE(',', v_bits, v_current_pos);

                    IF v_next_comma = 0 THEN
                        -- Последнее значение
                        SET v_current_bit = TRIM(SUBSTRING(v_bits, v_current_pos));
                        SET v_current_pos = LENGTH(v_bits) + 1;
                    ELSE
                        -- Есть следующее значение
                        SET v_current_bit = TRIM(SUBSTRING(v_bits, v_current_pos, v_next_comma - v_current_pos));
                        SET v_current_pos = v_next_comma + 1;
                    END IF;

                    -- Если значение не пустое, вставляем
                    IF v_current_bit != '' THEN
                        INSERT INTO pb_command_parameter_bits (GUID, bit)
                        VALUES (v_guid, CAST(v_current_bit AS UNSIGNED));
                    END IF;
                END WHILE;
        END IF;
    END LOOP;

    -- Закрываем курсор
    CLOSE cur;

    -- Сообщаем о завершении
    SELECT CONCAT('Обработано записей: ', (SELECT COUNT(*) FROM pb_command_parameter)) AS result;
END//

DELIMITER ;

ALTER TABLE `pb_command` ADD `parameter_length` TINYINT UNSIGNED NOT NULL DEFAULT '2' AFTER `system`;