<?php

namespace Horizon\Auth\DataBase\Tables;

use Horizon\Auth\DataBase\eTable;
use Horizon\DataBaseController\dbTableAI;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\DataBaseController\iTableConfig;
use Horizon\ProtocolBuilder\Exceptions\ActionAccessException;
use Horizon\ProtocolBuilder\Exceptions\DAEx;
use Horizon\ProtocolBuilder\Exceptions\DataAccessException;
use PDO;
use PDOStatement;

final class User extends dbTableAI
{
    protected static iTableConfig $table_config = eTable::h_user;
    public string $username {
        get {
            return $this->username;
        }
        set {
            $this->username = $value;
        }
    }
    public int $role {
        get {
            return $this->role;
        }
        set {
            $this->role = $value;
        }
    }
    protected string $password;
    public string $surname {
        get {
            return $this->surname;
        }
        set {
            $this->surname = $value;
        }
    }
    public string $name = '' {
        get {
            return $this->name;
        }
        set {
            $this->name = $value;
        }
    }
    public string $patronymic {
        get {
            return $this->patronymic;
        }
        set {
            $this->patronymic = $value;
        }
    }
    public bool $ban {
        get {
            return $this->ban;
        }
        set {
            $this->ban = $value;
        }
    }

    private static ?User $current_user = null;


    public function setPassword(string $value): void
    {
        $this->password = password_hash($value, PASSWORD_DEFAULT);
    }

    public function getSNP(): string
    {
        return implode(' ', [$this->surname, $this->name, $this->patronymic]);
    }

    public static function setCurrentUser(?self $user): void
    {
        self::$current_user = $user;
    }

    public function verifyPassword(string $password): bool
    {
        return password_verify($password, $this->password);
    }

    /**
     * @throws DBException
     * @throws DataAccessException
     */
    public function verifyAccess(): void
    {
        if (!$this->exists()) throw new DataAccessException(DAEx::data_not_found);
        $stmt = self::PDO()->prepare("SELECT 
        EXISTS(SELECT * FROM `h_group_x_user` WHERE `user_ID` = :this AND `group_ID` IN (SELECT `slave` AS `gr`
            FROM `h_group_tree` -- все потомки доступных пользователю групп
            WHERE `master` IN (SELECT `group_ID` FROM `h_group_x_user` WHERE `user_ID` = :current_user)
            UNION ALL
            -- все доступные пользователю группы
            (SELECT `group_ID` AS `gr` FROM `h_group_x_user` WHERE `user_ID` = :current_user)));");
        $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
        $stmt->bindValue(':current_user', User::current()?->getID(), PDO::PARAM_INT);
        $stmt->execute();
        if (!$stmt->fetchColumn()) throw new DataAccessException(DAEx::unavailable_data);
    }

    /**
     * @throws ActionAccessException
     * @throws DBException
     */
    public function verifySectionAccess(string $section): void
    {
        if (!$this->exists()) throw new ActionAccessException();
        $stmt = self::PDO()->prepare("SELECT EXISTS(SELECT `role`
              FROM `h_role_action`
              WHERE `role` = (SELECT `role` FROM `h_user` WHERE `ID` = :this)
                AND `section` = :section);");
        $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
        $stmt->bindValue(':section', $section);
        $stmt->execute();
        if (!$stmt->fetchColumn()) throw new ActionAccessException();
    }

    /**
     * @throws ActionAccessException
     * @throws DBException
     */
    public function verifyActionAccess(string $section, ?string $action = null): void
    {
        if (!$this->exists()) throw new ActionAccessException();
        if ($action === null) $this->verifySectionAccess($section);
        else {
        $stmt = self::PDO()->prepare("SELECT EXISTS(SELECT `role`
              FROM `h_role_action`
              WHERE `role` = (SELECT `role` FROM `h_user` WHERE `ID` = :this)
                AND `section` = :section
                AND `action` = :action);");
        $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
        $stmt->bindValue(':section', $section);
        $stmt->bindValue(':action', $action);
        $stmt->execute();
        if (!$stmt->fetchColumn()) throw new ActionAccessException();
        }
    }

    /**
     * @throws DBException
     */
    public function isAdmin(): bool
    {
        $stmt = self::PDO()->prepare("SELECT 
        EXISTS(SELECT * FROM `h_group_x_user` WHERE `user_ID` = :this AND `group_ID` = 1);");
        $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchColumn();
    }

    /**
     * @throws DBException
     */
    public function drawGroups(): string
    {
        $stmt = self::PDO()->prepare("SELECT GROUP_CONCAT(`name` SEPARATOR ', ') FROM `h_group` 
              WHERE `ID` IN (SELECT `group_ID` FROM `h_group_x_user` WHERE `user_ID` = :this);");
        $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchColumn();
    }

    /**
     * @throws DBException
     */
    public function arrGroups(): array
    {
        $stmt = self::PDO()->prepare("SELECT `group_ID` FROM `h_group_x_user` WHERE `user_ID` = :this;");
        $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
        $stmt->execute();
        return $this->asArray($stmt->fetchAll(PDO::FETCH_COLUMN));
    }

    /**
     * @param PDOStatement $stmt
     * @return void
     */
    private function bindDefaultParams(PDOStatement $stmt): void
    {
        $stmt->bindValue(':username', $this->username);
        $stmt->bindValue(':role', $this->role, PDO::PARAM_INT);
        $stmt->bindValue(':password', $this->password);
        $stmt->bindValue(':surname', $this->surname);
        $stmt->bindValue(':name', $this->name);
        $stmt->bindValue(':patronymic', $this->patronymic);
        $stmt->bindValue(':ban', $this->ban, PDO::PARAM_BOOL);
        $stmt->bindValue(':role', $this->role, PDO::PARAM_INT);
    }

    protected function tryInsert(): void
    {
        $stmt = self::PDO()->prepare("INSERT INTO `h_user`(
                     `username`, `role`, `password`, `surname`, `name`, `patronymic`, `ban`, `role`
                     ) VALUES (:username, :role, :password, :surname, :name, :patronymic, :ban, :role);");
        $this->bindDefaultParams($stmt);
        $stmt->execute();
        $this->ID = self::PDO()->lastInsertId();
        $stmt = self::PDO()->prepare("INSERT IGNORE INTO `h_group_x_user`(`group_ID`,`user_ID`) VALUES (2,:this);");
        $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
        $stmt->execute();
    }

    protected function tryUpdate(): void
    {
        $stmt = self::PDO()->prepare("UPDATE `h_user` SET
                `username` = :username, 
                `role` = :role, 
                `password` = :password, 
                `surname` = :surname, 
                `name` = :name, 
                `patronymic` = :patronymic,
                `ban` = :ban,
                `role` = :role
            WHERE `ID` = :ID;");
        $this->bindDefaultParams($stmt);
        $stmt->bindValue(':ID', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
    }

    /**
     * @throws DBException
     */
    public static function dbFind(string $username): ?User
    {
        $stmt = self::PDO()->prepare("SELECT t.*, TRUE AS `exists` 
            FROM `h_user` AS t 
            WHERE t.`username`=:this;");
        $stmt->bindValue(':this', $username);
        $stmt->execute();
        return User::intoNull($stmt->fetchObject(User::class));
    }

    /**
     * @throws DBException
     */
    public static function dbLoad(?int $ID): User
    {
        return User::intoMe(User::PDOStatementForLoad($ID)->fetchObject(User::class));
    }

    /**
     * @throws DBException
     */
    public function dbUpdateGroups(array $groups): void
    {
        User::dbAction(function () use ($groups) {
            if (count($groups) == 0) {
                $stmt = self::PDO()->prepare("DELETE FROM `h_group_x_user` WHERE `user_ID`=:this;");
                $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
                $stmt->execute();
                return;
            }
            $x = implode(', ', array_map(fn($k) => ":x_$k", array_keys($groups)));
            $stmt = self::PDO()->prepare("DELETE FROM `h_group_x_user`  
                WHERE `user_ID`=:this
                  AND `group_ID` NOT IN ($x);");
            $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
            foreach ($groups as $k => $group) $stmt->bindValue(":x_$k", $group, PDO::PARAM_INT);
            $stmt->execute();
            $stmt = self::PDO()->prepare("INSERT IGNORE INTO `h_group_x_user`(`group_ID`,`user_ID`) VALUES (:gr,:this);");
            $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
            foreach ($groups as $group) {
                $stmt->bindValue(':gr', $group, PDO::PARAM_INT);
                $stmt->execute();
            }
        });
    }

    public static function current(): ?self
    {
        return self::$current_user;
    }
}