<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Exception;
use Horizon\ProtocolBuilder\Data\eParameterType;
use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterCheckboxMatrixTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterNameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterTypeHiddenTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterValueInvertedTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterValueNameBlockTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\CreationButton;
use Horizon\UserInterface\Tags\Trace;

class ParameterByBitsCreation extends _PageContentTag
{
    public function __construct(string $header, string $action_URL,
                                string $name, bool $is_value_inverted,
                                array $bits, int $count, array $unavailable_bits)
    {
        parent::__construct($header);
        try {
            $this->add(new MainForm($action_URL)
                ->add(new ParameterNameTag($name))
                ->add(new ParameterValueInvertedTag($is_value_inverted))
                ->add(new ParameterValueNameBlockTag())
                ->add(new ParameterTypeHiddenTag(eParameterType::BitPrm))
                ->add(new ParameterCheckboxMatrixTag($bits, $count, $unavailable_bits))
                ->add(new CreationButton())
            );
        } catch (Exception $exception) {
            $this->add(new Trace($exception));
        }
    }
}