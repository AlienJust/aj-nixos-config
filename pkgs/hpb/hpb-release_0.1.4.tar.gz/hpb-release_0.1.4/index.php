<?php
use Horizon\ProtocolBuilder\UserInterface\UICore;
use Horizon\ProtocolBuilder\UserInterface\Pages\MainPage;
use Horizon\ProtocolBuilder\UserInterface\Pages\SafePage;
use Horizon\ProtocolBuilder\UserInterface\Pages\UnknownPage;

include_once 'components/private/loader.php';

new UICore(
    new MainPage()
        ->setCSS('styles/main.css')
        ->setJS('js/jquery/jquery.js', 'js/jquery/ui/jquery-ui.min.js'),
    new SafePage()
        ->setCSS('styles/main.css'),
    new UnknownPage()
        ->setCSS('styles/main.css')
)->output();
