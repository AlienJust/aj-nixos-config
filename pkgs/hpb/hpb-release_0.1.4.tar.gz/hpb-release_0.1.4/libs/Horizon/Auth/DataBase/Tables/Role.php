<?php

namespace Horizon\Auth\DataBase\Tables;

use Horizon\Auth\DataBase\eTable;
use Horizon\DataBaseController\dbTableAI;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\DataBaseController\iTableConfig;
use PDO;

final class Role extends dbTableAI
{
    protected static iTableConfig $table_config = eTable::h_role;

    /**
     * @var RoleAction[]|null $actions
     */
    public ?array $actions = null {
        get {
            if ($this->actions === null) $this->fillActions();
            return $this->actions;
        }
        set {
            if (is_array($value)) {
                $this->actions = [];
                foreach ($value as $item) {
                    if ($item instanceof RoleAction) $this->actions[] = $item;
                    elseif (is_string($item)) {
                        list($section, $action) = explode('.', $item);
                        $this->actions[] = new RoleAction($this->ID, $section, $action);
                    }
                }
            } else $this->actions = $value;
        }
    }

    public string $name = '' {
        get {
            return $this->name;
        }
        set {
            $this->name = $value;
        }
    }

    /**
     * @throws DBException
     */
    private function fillActions(): void
    {
        $stmt = self::PDO()->prepare("SELECT `role`, `section`, `action` 
            FROM `h_role_action` WHERE `role` = :role");
        $stmt->bindValue('role', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        $this->actions = self::asArray($stmt->fetchAll(PDO::FETCH_FUNC,
            fn(int $role, string $section, string $action): RoleAction => new RoleAction($role, $section, $action)));
    }

    protected function tryInsert(): void
    {
        $stmt = self::PDO()->prepare("INSERT INTO `h_role`(`name`) 
            VALUES (:name);");
        $stmt->bindValue(':name', $this->name);
        $stmt->execute();
        $this->ID = self::PDO()->lastInsertId();
    }

    protected function tryUpdate(): void
    {
        $stmt = self::PDO()->prepare("UPDATE `h_role` SET 
                     `name`=:name
                 WHERE `ID`=:this;");
        $stmt->bindValue(':name', $this->name);
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        $stmt = self::PDO()->prepare("DELETE FROM `h_role_action` WHERE `role` = :role");
        $stmt->bindValue(':role', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        foreach ($this->actions as $action) $action->tryInsert();
    }

    /**
     * @throws DBException
     */
    public static function dbLoad(?int $ID): Role
    {
        $stmt = self::PDO()->prepare("SELECT hr.*, TRUE AS `exists`
            FROM `h_role` AS hr 
            WHERE hr.`ID`=:this;");
        $stmt->bindValue(':this', $ID, PDO::PARAM_INT);
        $stmt->execute();
        return Role::intoMe($stmt->fetchObject(Role::class));
    }
}