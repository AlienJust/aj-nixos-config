<?php

namespace Horizon\Auth\DataBase\Tables;

use Horizon\Auth\DataBase\eTable;
use Horizon\DataBaseController\dbTable;
use Horizon\DataBaseController\Exceptions\DBEx;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\DataBaseController\iTableConfig;
use PDO;

final class RoleAction extends dbTable
{
    protected static iTableConfig $table_config = eTable::h_role_action;

    protected int $role;
    protected string $section;
    protected string $action;

    /**
     * @param int $role
     * @param string $section
     * @param string $action
     */
    public function __construct(int $role, string $section, string $action)
    {
        $this->role = $role;
        $this->section = $section;
        $this->action = $action;
    }

    public function getID(): string
    {
        return implode(".", [$this->section, $this->action]);
    }

    protected function tryInsert(): void
    {
        $stmt = self::PDO()->prepare("INSERT IGNORE INTO `h_role_action`(
                                   `role`, `section`, `action`
                                   ) VALUES (:role, :section, :action);");
        $stmt->bindValue(':role', $this->role, PDO::PARAM_INT);
        $stmt->bindValue(':section', $this->section, PDO::PARAM_STR);
        $stmt->bindValue(':action', $this->action, PDO::PARAM_STR);
        $stmt->execute();
    }

    protected function tryUpdate(): void
    {
        throw new DBException(DBEx::dontUseUpdate);
    }

    protected function tryDelete(): void
    {
        $stmt = self::PDO()->prepare("DELETE FROM `h_role_action` 
            WHERE `role` = :role 
              AND `section` = :section 
              AND `action` = :action;");
        $stmt->bindValue(':role', $this->role, PDO::PARAM_INT);
        $stmt->bindValue(':section', $this->section, PDO::PARAM_STR);
        $stmt->bindValue(':action', $this->action, PDO::PARAM_STR);
        $stmt->execute();
    }
}