<?php

namespace Horizon\Auth\DataBase\ListSources;

use Horizon\Auth\DataBase\Tables\Role;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\DataBaseController\ListSourceTemplate;
use PDO;

class URoleListSource extends ListSourceTemplate
{
    public function __construct(int $page, int $limit, ?int $currentID)
    {
        parent::__construct($page, $limit, $currentID);
    }

    /**
     * @return Role[]
     * @throws DBException
     */
    public function loadData(): array
    {
        $stmt = self::PDO()->prepare("SELECT t.*, TRUE AS `exists`
        FROM `h_role` AS t
        ORDER BY  t.`name`, t.`ID`
        LIMIT :limit OFFSET :offset;");
        $stmt->bindValue(":limit", $this->limit, PDO::PARAM_INT);
        $stmt->bindValue(":offset", $this->offset, PDO::PARAM_INT);
        $stmt->execute();
        return $this->asArray($stmt->fetchAll(PDO::FETCH_CLASS, Role::class));
    }

    public function loadCurrentPage(): int
    {
        $stmt = self::PDO()->prepare("SELECT tt.`page`
            FROM (SELECT FLOOR((ROW_NUMBER() OVER (ORDER BY  t.`name`, t.`ID`) - 1) / :limit) + 1 AS `page`,
                         t.`ID` AS `ID`
                  FROM `h_role` AS t
                  ORDER BY  t.`name`, t.`ID`) AS tt
            WHERE tt.`ID` = :ID;");
        $stmt->bindValue(':limit', $this->limit, PDO::PARAM_INT);
        $stmt->bindValue(':ID', $this->currentID, PDO::PARAM_INT|PDO::PARAM_NULL);
        $stmt->execute();
        $page = $stmt->fetchColumn();
        return $page === false ? 1 : $page;
    }

    protected function loadDataCount(): float
    {
        $stmt = self::PDO()->prepare("SELECT COUNT(*) AS `count` FROM `h_role` AS t;");
        $stmt->execute();
        return (float) $stmt->fetchColumn();
    }
}