<?php

namespace Horizon\Auth\DataBase\PickSources;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\DataBaseController\PickSourceTemplate;
use Horizon\UserInterface\Controls\Components\Option;
use PDO;

class URolePick extends PickSourceTemplate
{
    /**
     * @throws DBException
     * Option[]
     */
    public function init(): array
    {
        $stmt = self::PDO()->prepare("SELECT `ID` AS `value`, `name` AS `label` FROM `h_role`;");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_FUNC,
            fn(string $value, string $label): Option => new Option($value, $label));
    }
}