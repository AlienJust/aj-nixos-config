<?php

namespace Horizon\ProtocolBuilder\Data;

enum eParameterLength: int
{
    case t1 = 1;
    case t2 = 2;

    public function label(): string
    {
        return match ($this) {
            self::t1 => '1 байт',
            self::t2 => '2 байта',
        };
    }
}