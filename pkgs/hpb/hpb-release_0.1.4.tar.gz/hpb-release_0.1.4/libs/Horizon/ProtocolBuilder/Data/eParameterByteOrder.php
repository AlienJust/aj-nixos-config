<?php

namespace Horizon\ProtocolBuilder\Data;

enum eParameterByteOrder: string
{
    case HiLo = 'HiLo';
    case LoHi = 'LoHi';
    case LoHiFromHiLo = 'LoHi[HiLo]x2';
}