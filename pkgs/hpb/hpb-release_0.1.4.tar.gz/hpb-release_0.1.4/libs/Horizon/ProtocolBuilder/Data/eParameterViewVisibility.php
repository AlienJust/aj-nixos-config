<?php

namespace Horizon\ProtocolBuilder\Data;

enum eParameterViewVisibility: string
{
    case v_0 = 'Везде';
    case v_1 = 'В полной версии';
    case v_2 = 'В урезанной версии';
}