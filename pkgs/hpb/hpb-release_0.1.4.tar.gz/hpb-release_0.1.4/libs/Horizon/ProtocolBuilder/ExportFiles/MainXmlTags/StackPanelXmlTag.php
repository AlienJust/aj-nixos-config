<?php

namespace Horizon\ProtocolBuilder\ExportFiles\MainXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class StackPanelXmlTag extends XmlTag
{
    public readonly ?string $Orientation;
    public readonly ?string $Visibility;
    public readonly ?string $Grid___Column;
    public readonly ?string $Grid___Row;

    public function __construct(?string $Orientation = null, ?string $Visibility = null, ?string $Grid___Column = null, ?string $Grid___Row = null)
    {
        parent::__construct('StackPanel');
        $this->Orientation = $Orientation;
        $this->Visibility = $Visibility;
        $this->Grid___Column = $Grid___Column;
        $this->Grid___Row = $Grid___Row;
    }

    public function add(TextBlockXmlTag|app_CommandPartViewXmlTag|app_ParameterViewXmlTag|GridXmlTag|LabelXmlTag $tag): static
    {
        $this->addTag($tag);
        return $this;
    }
}