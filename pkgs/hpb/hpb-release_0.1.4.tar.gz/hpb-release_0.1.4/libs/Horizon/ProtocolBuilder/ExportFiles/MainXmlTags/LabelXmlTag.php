<?php

namespace Horizon\ProtocolBuilder\ExportFiles\MainXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class LabelXmlTag extends XmlTag
{
    public readonly ?string $Background;
    public readonly ?string $FontWeight;
    public readonly ?string $Grid___Column;
    public readonly ?string $Grid___Row;
    public readonly ?string $Visibility;
    public function __construct(?string $Background = '{DynamicResource AccentColorBrush3}', ?string $FontWeight = 'SemiBold',
                                ?string $Grid___Column = null, ?string $Grid___Row = null, ?string $Visibility = null)
    {
        parent::__construct('Label');
        $this->Background = $Background;
        $this->FontWeight = $FontWeight;
        $this->Grid___Column = $Grid___Column;
        $this->Grid___Row = $Grid___Row;
        $this->Visibility = $Visibility;
    }

    public function add(string $text): static
    {
        $this->addText($text);
        return $this;
    }
}