<?php

namespace Horizon\ProtocolBuilder\ExportFiles;

class CommentXmlTag implements iTag
{
    private string $text;
    private string $space = '';
    public function __construct(string $text)
    {
        $this->text = $text;
    }

    public function draw(): string
    {
        return "$this->space<!-- $this->text -->";
    }

    public function addSpace(string $parent_space): void
    {
        $this->space = $parent_space . "  ";
    }
}