<?php

namespace Horizon\ProtocolBuilder\ExportFiles;

interface iTag
{
    function draw(): string;
    function addSpace(string $parent_space): void;
}