<?php

namespace Horizon\ProtocolBuilder\ExportFiles;

use Exception;
use Horizon\Auth\DataBase\Tables\Group;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\Data\eParameterType;
use Horizon\ProtocolBuilder\DataBase\Tables\Command;
use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\UserInterface\eUISA_ReplyParameter;
use Horizon\ProtocolBuilder\UserInterface\eUISA_RequestParameter;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\PresetTags\ValueView;
use Horizon\UserInterface\Tags\Anchor;
use Horizon\UserInterface\Tags\Division;
use Horizon\UserInterface\Tags\Header;
use Horizon\UserInterface\Tags\LineBreak;
use Horizon\UserInterface\Tags\Table;
use Horizon\UserInterface\Tags\TableData;
use Horizon\UserInterface\Tags\TableHeader;
use Horizon\UserInterface\Tags\TableRow;
use Horizon\UserInterface\TagsPack;

class Specification
{
    private Protocol $protocol;
    public function __construct(Protocol $protocol)
    {
        $this->protocol = $protocol;
    }

    /**
     * @throws DBException
     * @throws Exception
     */
    public function content(): TagsPack
    {
        $document = new TagsPack();
        $document->add(
            new ValueView(eProtocolField::GUID->label(), $this->protocol->GUID),
            new ValueView(eProtocolField::name->label(), $this->protocol->name),
            new ValueView(eProtocolField::version->label(), $this->protocol->version),
            new ValueView(eProtocolField::description->label(), $this->protocol->description),
            new ValueView(eProtocolField::author->label(), Group::dbLoad($this->protocol->author)->name),
        );
        foreach ($this->protocol->arrSubscribers() as $subscriber) {
            $document->add(new Header(2,$subscriber->getName()));
            foreach ($subscriber->arrCommands() as $command) {
                $document->add(new Header(3, $command->getName()));

                $request = $command->refRequest();
                $request_header_length = $request->getHeaderLength();
                $reply = $command->refReply();
                $reply_header_length = $reply->getHeaderLength();

                $document->add($table = new Table());

                if (//$request_header_length == 7 && $reply_header_length == 6 ||
                    //$request_header_length == 6 && $reply_header_length == 3
                    $command->getParameterLength() == 2
                ) {
                    if ($request_header_length == $request->getLength() - 2)
                        $this->fillPack(false, $command, $table,
                            $request_header_length, $request->getLength());
                    else $this->fillDuoPack(false, $command, $table,
                        $subscriber->getAddress(), $request_header_length, $request->getLength());

                    $document->add(new LineBreak(), $table = new Table());

                    if ($reply_header_length == $reply->getLength() - 2)
                        $this->fillPack(true, $command, $table,
                            $reply_header_length, $reply->getLength());
                    else $this->fillDuoPack(true, $command, $table,
                        $subscriber->getAddress(), $reply_header_length, $reply->getLength());

                } else {
                    $this->fillPack(false, $command, $table,
                        $request_header_length, $request->getLength());

                    $document->add(new LineBreak(), $table = new Table());
                    $this->fillPack(true, $command, $table,
                        $reply_header_length, $reply->getLength());
                }
            }
        }
        return $document;
    }

    private function drawByteNumber(int $byte): string
    {
        return "$byte – " . ($byte + 1);
    }

    private function drawParameterNumber(int $subscriber, int $number): string
    {
        return "$subscriber.$number";
    }

    /**
     * @throws DBException
     */
    private function fillDuoPack(bool $package, Command $command, Table $table, int $subscriber_address, int $header_length, int $length): void
    {
        $type = $package ? 'Ответ' : 'Запрос';
        $table->add(new TableRow()->add(
            new TableHeader("Номер байта")->addClass('little'),//->addStyle('min-width','7rem')->addAttribute(Attribute::width, '7rem'),
            new TableHeader("Номер сигнала")->addClass('little'),//->addStyle('min-width','7rem')->addAttribute(Attribute::width, '7rem'),
            new TableHeader("$type команды &quot;" . $command->getName() . "&quot;"),
            new TableHeader("Примечание")
        ));
        $add_is_full = false;

        for ($i = 0; $i < $header_length; $i++) {
            $bits = $this->initBits($i);
            $table->add(new TableRow()->add(
                new TableData($i),
                new TableData(),
                new TableData()->add($pack = new TagsPack()),
                new TableData()->add($pack_add = new TagsPack()),
            ));
            $this->fillParameters($pack, $pack_add, $package, $command, $bits, 0);
            if ($pack_add->countContent() > 0) $add_is_full = true;
        }
        $n = 0;
        for ($i = $header_length; $i < $length - 2; $i += 2) {
            $bits = $this->initBits($i, $i + 1);
            $table->add(new TableRow()->add(
                new TableData($this->drawByteNumber($i)),
                new TableData($this->drawParameterNumber($subscriber_address, $n)),
                new TableData()->add($pack = new TagsPack()),
                new TableData()->add($pack_add = new TagsPack()),
            ));
            $this->fillParameters($pack, $pack_add, $package, $command, $bits, $header_length, 2);
            if ($pack_add->countContent() > 0) $add_is_full = true;
            $n++;
        }
        $table->add(new TableRow()->add(
            new TableData($this->drawByteNumber($length - 2)),
            new TableData(),
            new TableData("CRC"),
            new TableData()
        ));
        if (!$add_is_full) foreach($table->rows() as $row) $row->cut(3);
    }

    /**
     * @throws DBException
     */
    private function fillPack(bool $package, Command $command, Table $table, int $header_length, int $length): void
    {
        $type = $package ? 'Ответ' : 'Запрос';
        $table->add(new TableRow()->add(
            new TableHeader("Номер байта")->addClass('little'),//->addStyle('min-width','7rem')->addAttribute(Attribute::width, '7rem'),
            new TableHeader("$type команды &quot;" . $command->getName() . "&quot;"),
            new TableHeader("Примечание")
        ));
        $add_is_full = false;

        for ($i = 0; $i < $header_length; $i++) {
            $bits = $this->initBits($i);
            $table->add(new TableRow()->add(
                new TableData($i),
                new TableData()->add($pack = new TagsPack()),
                new TableData()->add($pack_add = new TagsPack()),
            ));
            $this->fillParameters($pack, $pack_add, $package, $command, $bits, 0);
            if ($pack_add->countContent() > 0) $add_is_full = true;
        }
        for ($i = $header_length; $i < $length - 2; $i++) {
            $bits = $this->initBits($i);
            $table->add(new TableRow()->add(
                new TableData($i),
                new TableData()->add($pack = new TagsPack()),
                new TableData()->add($pack_add = new TagsPack()),
            ));
            $this->fillParameters($pack, $pack_add, $package, $command, $bits, $header_length);
            if ($pack_add->countContent() > 0) $add_is_full = true;
        }
        $table->add(new TableRow()->add(
            new TableData($this->drawByteNumber($length - 2)),
            new TableData("CRC"),
            new TableData()
        ));
        if (!$add_is_full) foreach($table->rows() as $row) $row->cut(2);
    }

    private function initBits(int $first_byte, ?int $last_byte = null): array
    {
        $last_byte = $last_byte ?? $first_byte;
        return range($first_byte * 8, $last_byte * 8 + 7);
    }

    private function calcBit(int $step, int $header_length, int $bit): int
    {
        return (7 * $step + ($step - 1)) - ($bit - $header_length * (8 * ($step - 1))) % (8 * $step);
    }

    /**
     * @throws DBException
     */
    private function fillParameters(TagsPack $pack, TagsPack $pack_add, bool $package, Command $command, array $bits, int $header_length, int $step = 1): void
    {
        $parameters = $package
            ? $command->arrParametersToReplyByBits($bits)
            : $command->arrParametersToRequestByBits($bits);
        $controller = $package
            ? eUISA_ReplyParameter::edit->initController()
            : eUISA_RequestParameter::edit->initController();
        foreach ($parameters as $parameter) {
            $type = eParameterType::tryFrom($parameter->getType());
            switch ($type) {
                case eParameterType::DefVal:
                    $pack->add(new Division($parameter->getValue() . " – ")->add(new Anchor(
                        $controller
                            ->setParameter($parameter)
                            ->refURL()
                            ->draw(),
                        $parameter->getName())));
                    break;
                case eParameterType::VarVal:
                    $pack->add(new Division()->add(new Anchor(
                        $controller
                            ->setParameter($parameter)
                            ->refURL()
                            ->draw(),
                        $parameter->getName())));
                    break;
                case eParameterType::CpzPrm:
                    $p_bits = $parameter->getBits();
                    $p_i_bits = array_intersect($p_bits, $bits);
                    if (count($p_i_bits) < count($bits)) {
                        $pack->add($div = new Division());
                        $address = implode(" " , array_map(function (int $p_bit) use ($step, $header_length) {
                            return "D" . $this->calcBit($step, $header_length, $p_bit);
                        }, $p_i_bits));
                        $div->add($address . " – ", new Anchor(
                            $controller
                                ->setParameter($parameter)
                                ->refURL()
                                ->draw(),
                            $parameter->getName()));
                    } elseif (count($p_bits) > count($bits)) {
                        $pack->add(new Division()->add(new Anchor(
                            $controller
                                ->setParameter($parameter)
                                ->refURL()
                                ->draw(),
                            $parameter->getName()), " (" . $parameter->getByteOrder() . ")"));
                    } else {
                        $pack->add(new Division()->add(new Anchor(
                            $controller
                                ->setParameter($parameter)
                                ->refURL()
                                ->draw(),
                            $parameter->getName())));
                        if (count($p_bits) > 8) $pack_add->add(new Division($parameter->getByteOrder()));
                        $ldp = $parameter->getLowestDigitPrice();
                        if ($ldp != 1) $pack_add->add(new Division("ЦМР = $ldp"));
                    }
                    break;
                case eParameterType::BitPrm:
                    $bit = $this->calcBit($step, $header_length, $parameter->getSortingBit());
                    $pack->add(new Division("D$bit – ")->add(new Anchor(
                        $controller
                            ->setParameter($parameter)
                            ->refURL()
                            ->draw(),
                         $parameter->getName())));
                    break;
            }
        }
    }
}