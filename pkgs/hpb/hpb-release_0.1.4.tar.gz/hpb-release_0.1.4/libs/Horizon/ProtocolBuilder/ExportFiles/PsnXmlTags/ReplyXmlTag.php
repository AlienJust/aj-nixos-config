<?php

namespace Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags;

class ReplyXmlTag extends RCmdPartXmlTag
{
    public readonly ?string $IsRequestRequired;
    public readonly string $Length;
    public readonly string $Position;

    public function __construct(string $Length, string $Position, ?string $IsRequestRequired)
    {
        parent::__construct('Reply');
        $this->Length = $Length;
        $this->Position = $Position;
        $this->IsRequestRequired = $IsRequestRequired;
    }


}