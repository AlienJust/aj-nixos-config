<?php

namespace Horizon\ProtocolBuilder\Exceptions;

enum VEx: int
{
    case empty = 0;
    case unknownParameterType = 1;
    case brokenBits = 2;
    case emptyParameters = 3;
    case notPackageType = 4;
    case brokenGUID = 5;
    case undefinedChunkType = 6;

    public function message(...$options): string
    {
        return match ($this) {
            self::empty => "Параметр $options[0] не может быть пустым",
            self::unknownParameterType => 'Неизвестный тип параметра',
            self::brokenBits => 'Ошибка при формировании битов параметра',
            self::emptyParameters => 'Параметры не были выбраны',
            self::notPackageType => 'Не определен package type',
            self::brokenGUID => "GUID $options[0] неверного формата",
            self::undefinedChunkType => "Тип элемента $options[0] не реализован",
        };
    }
}
