<?php

namespace Horizon\ProtocolBuilder\Exceptions;

use Exception;

class ActionAccessException extends Exception
{
    public function __construct()
    {
        parent::__construct("Доступ к функционалу ограничен ролью пользователя");
    }
}