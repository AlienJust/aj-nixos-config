<?php

namespace Horizon\ProtocolBuilder\LogicItems;

use Horizon\ProtocolBuilder\Data\eParameterByteOrder;

class ParameterExpression
{
    private bool $is_signed;
    private ?string $lowest_digit_price;
    private ?string $formula;
    private ?eParameterByteOrder $byte_order;

    public readonly string $value;
    public function __construct(array $bits, bool $is_signed, float $lowest_digit_price, ?string $byte_order, ?string $formula)
    {
        $this->lowest_digit_price = $lowest_digit_price == 1 ? null
            : (' * ' . ($lowest_digit_price == floor($lowest_digit_price)
                    ? sprintf("%01.1f", $lowest_digit_price)
                    : rtrim(sprintf("%.10f", $lowest_digit_price), '0')));
        $this->formula = $formula;
        $this->byte_order = eParameterByteOrder::tryFrom($byte_order ?? '');
        $this->is_signed = $is_signed;

        $this->initValue($bits);
    }

    private function applyFormula(string $x): string
    {
        $x = is_null($this->formula) ? $x : str_replace('x', "($x)", $this->formula);
        if (!is_null($this->lowest_digit_price)) {
            if (str_contains($x, '+') || str_contains($x, '-'))
                $x = "($x)$this->lowest_digit_price";
            else $x = "$x$this->lowest_digit_price";
        }
        return $x;
    }

    private function initValue(array $bits): void
    {
        /** @var ValueByte[] $bytes */
        $bytes = [];
        foreach ($bits as $key => $bit) {
            if ($key == 0) $bytes[] = new ValueByte($bit);
            else {
                $byte = end($bytes)->addBit($bit);
                if ($byte instanceof ValueByte) $bytes[] = $byte;
            }
        }
        if ($this->byte_order == eParameterByteOrder::LoHiFromHiLo) {
            $exponent_out = 0;
            $result = [];
            for ($i = 0; $i < count($bytes); $i += 2) {
                $exponent = 0;
                if (isset($bytes[$i + 1])) $bytes[$i + 1] = $bytes[$i + 1]->draw($exponent, true);
                if ($i > count($bytes) - 3) {
                    $bytes[$i]->setSign($this->is_signed);
                }
                $bytes[$i] = $bytes[$i]->draw($exponent, true);
                $power = $exponent_out == 0 ? '' : sprintf(" * %01.1f", pow(2, $exponent_out));
                $result[] = '(' . $bytes[$i] . ' + ' . ($bytes[$i + 1] ?? '0') . ')' . $power;
                $exponent_out += 16;
            }
            $this->value = $this->applyFormula(implode(' + ', $result));
        } else {
            if ($this->byte_order == eParameterByteOrder::HiLo) {
                $bytes = array_reverse($bytes);
                foreach ($bytes as $byte) $byte->reverse();
            }
            $exponent = 0;
            end($bytes)->setSign($this->is_signed);
            $hide_null_exponent = count($bytes) > 1 || !is_null($this->lowest_digit_price);
            foreach ($bytes as &$byte) {
                $byte = $byte->draw($exponent, $hide_null_exponent);
            }
            if ($this->byte_order == eParameterByteOrder::HiLo) {
                $bytes = array_reverse($bytes);
            }
            $this->value = $this->applyFormula(implode(' + ', $bytes));
        }
    }
}