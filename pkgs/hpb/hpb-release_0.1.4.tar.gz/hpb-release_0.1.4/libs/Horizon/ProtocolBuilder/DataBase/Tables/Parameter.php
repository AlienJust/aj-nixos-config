<?php

namespace Horizon\ProtocolBuilder\DataBase\Tables;

use Horizon\DataBaseController\dbTable;
use Horizon\DataBaseController\Exceptions\DBEx;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\DataBaseController\iTableConfig;
use Horizon\ProtocolBuilder\Data\eParameterByteOrder;
use Horizon\ProtocolBuilder\Data\eParameterName;
use Horizon\ProtocolBuilder\Data\eParameterType;
use Horizon\ProtocolBuilder\DataBase\eTable;
use Horizon\ProtocolBuilder\Exceptions\VEx;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\LogicItems\ParameterAddress;
use PDO;

abstract class Parameter extends dbTable
{
    protected static iTableConfig $table_config = eTable::pb_command_parameter;
    protected const ?bool PACKAGE_TYPE = null;

    protected string $GUID;
    protected int $command;
    protected ?string $conflicted_GUID = null;
    protected bool $package;
    protected string $name;
    protected string $type;
    protected ?string $byte_order = null;
    protected ?string $value_conversion_formula = null;
    protected float $lowest_digit_price = 1;
    protected bool $signed = false;
    protected string $bits;
    protected ?int $sorting_bit;
    protected ?string $value = null;
    protected bool $value_inverted = false;
    protected ?string $description = null;

    protected Command $REF_command;

    /**
     * @throws VException
     */
    public function __construct(?int $command = null)
    {
        $this->package = static::PACKAGE_TYPE ?? throw new VException(VEx::notPackageType);
        if (!is_null($command)) $this->command = $command;
    }

    /**
     * @throws DBException
     */
    public function __clone()
    {
        $this->initGUID();
    }

    public function setCommand(Command $command): void
    {
        $this->command = $command->getID();
        $this->REF_command = $command;
    }


    /**
     * @throws DBException
     */
    protected function setGUID(string $value): static
    {
        if (preg_match("/^(\{)?[a-f\d]{8}(-[a-f\d]{4}){4}[a-f\d]{8}(?(1)})$/i", $value))
            $this->GUID = mb_strtolower($value);
        else $this->GUID = self::UUID();
        return $this;
    }

    /**
     * @throws DBException
     */
    public function initGUID(): static
    {
        $this->GUID = self::UUID();
        $this->setToNotExists();
        return $this;
    }

    public function setName(string $name): static
    {
        $this->name = $name;
        return $this;
    }

    /**
     * @throws VException
     */
    public function setType(string $type): static
    {
        if (is_null(eParameterType::tryFrom($type)))
            throw new VException(VEx::unknownParameterType);
        $this->type = $type;
        return $this;
    }

    public function setByteOrder(?string $byte_order): static
    {
        $this->byte_order = eParameterByteOrder::tryFrom($byte_order ?? '')?->value;
        return $this;
    }

    public function setValueConversionFormula(?string $value_conversion_formula): static
    {
        $this->value_conversion_formula = $value_conversion_formula;
        return $this;
    }

    public function setLowestDigitPrice(float $lowest_digit_price): static
    {
        $this->lowest_digit_price = $lowest_digit_price;
        return $this;
    }

    public function setSigned(bool $signed): static
    {
        $this->signed = $signed;
        return $this;
    }

    /**
     * @throws VException
     */
    public function setBits(array $bits): static
    {
        $string = json_encode($bits);
        if ($string === false) throw new VException(VEx::brokenBits);
        $this->bits = $string;
        $this->sorting_bit = $bits[0] ?? null;
        return $this;
    }

    public function setValue(?string $value): static
    {
        $this->value = $value;
        return $this;
    }

    public function setValueInverted(bool $value_inverted): static
    {
        $this->value_inverted = $value_inverted;
        return $this;
    }

    public function setDescription(?string $description): void
    {
        $description = trim($description);
        if ($description == '') $description = null;
        $this->description = $description;
    }


    /**
     * @throws DBException
     */
    public function getGUID(): string
    {
        return $this->GUID ?? ($this->GUID = self::UUID());
    }

    public function getCommand(): int
    {
        return $this->command;
    }

    public function getName(): string
    {
        return $this->name ?? '';
    }

    public function getType(): string
    {
        return $this->type ?? '';
    }

    public function getByteOrder(): ?string
    {
        return $this->byte_order;
    }

    public function getValueConversionFormula(): ?string
    {
        return $this->value_conversion_formula;
    }

    public function getLowestDigitPrice(): float
    {
        return $this->lowest_digit_price;
    }

    public function isSigned(): bool
    {
        return $this->signed;
    }

    public function getBits(): array
    {
        return json_decode($this->bits ?? '') ?? [];
    }

    public function getSortingBit(): ?int
    {
        return $this->sorting_bit;
    }

    public function getValue(): ?string
    {
        return $this->value;
    }

    public function isValueInverted(): bool
    {
        return $this->value_inverted;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function isPackage(): bool
    {
        return $this->package;
    }

    /**
     * @throws DBException
     */
    public function getHeaderLength(): int
    {
        return $this->package
            ? $this->refCommand()->refReply()->getHeaderLength()
            : $this->refCommand()->refRequest()->getHeaderLength();
    }

    /**
     * @throws DBException
     */
    public function refCommand(): Command
    {
        return $this->REF_command ?? ($this->REF_command = Command::dbLoad($this->command));
    }

    /**
     * @throws DBException
     */
    public function refAddress(): ParameterAddress
    {
        return new ParameterAddress($this->getSortingBit(), $this->getHeaderLength(), count($this->getBits()));
    }

    /**
     * @return ParameterView[]
     * @throws DBException
     */
    public function arrViews(): array
    {
        $stmt = self::PDO()->prepare('SELECT 
                pcpv.`protocol`, 
                pcpv.`code`, 
                BinToUUID(pcpv.`identifier`) AS `identifier`, 
                pcpv.`comment`, 
                pcpv.`custom_name`, 
                pcpv.`format`,
                pcpv.`mask`,
                TRUE AS `exists` 
            FROM `pb_command_parameter_view` AS pcpv 
            WHERE pcpv.`identifier`=UUIDToBin(:this)
            ORDER BY pcpv.`code`;');
        $stmt->bindValue(':this', $this->GUID);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, ParameterView::class));
    }

    /**
     * @throws DBException
     */
    public function initCommentForView(): string
    {
        return$this->refCommand()->getName() . ': ' . ($this->package ? 'ответ' : 'запрос') . ' – ' . $this->name;
    }

    /**
     * @throws DBException
     */
    public function initCodeForView(?string $add = null): string
    {
        return $this->package
            ? $this->refCommand()->refReply()->initCodeForParameterView(null, $add)
            : $this->refCommand()->refRequest()->initCodeForParameterView(null, $add);
    }

    /**
     * @throws DBException
     */
    protected function initView(): void
    {
        $stmt = self::PDO()->prepare('SELECT COUNT(`code`) 
            FROM `pb_command_parameter_view` 
            WHERE `identifier`=UUIDToBin(:GUID);');
        $stmt->bindValue(':GUID', $this->GUID);
        $stmt->execute();
        $count = $stmt->fetchColumn();
        if ($count < 1 && is_null(eParameterName::tryFrom($this->name)))
            new ParameterView($this->refCommand()->refSubscriber()->getProtocol(), $this->initCodeForView())
                ->setIdentifier($this->GUID)
                ->setComment($this->initCommentForView())
                ->tryInsert();
    }

    /**
     * @throws DBException
     */
    public function linkByCommand(?int $command): static
    {
        if ($this->exists() && $this->command !== $command) {
            $this->conflicted_GUID = $this->GUID;
            $this->initGUID();
        }
        if ($command !== null) $this->command = $command;
        return $this;
    }

    protected function tryInsert(): void
    {
        $stmt = self::PDO()->prepare('INSERT INTO `pb_command_parameter`(
                `GUID`, `command`, `conflicted_GUID`,
                `package`, `name`, `type`, `byte_order`, `value_conversion_formula`, `lowest_digit_price`, 
                `signed`, `bits`, `sorting_bit`, `value`, `value_inverted`, `description`
            ) VALUES (UUIDToBin(:GUID), :command, IF(:conflicted_GUID IS NOT NULL, UUIDToBin(:conflicted_GUID), NULL), 
                :package, :name, :type, :byte_order, :value_conversion_formula, :lowest_digit_price, 
                :signed, :bits, :sorting_bit, :value, :value_inverted, :description);');
        $stmt->bindValue(':GUID', $this->GUID);
        $stmt->bindValue(':command', $this->command, PDO::PARAM_INT);
        $stmt->bindValue(':conflicted_GUID', $this->conflicted_GUID, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->bindValue(':package', $this->package, PDO::PARAM_BOOL);
        $stmt->bindValue(':name', $this->name);
        $stmt->bindValue(':type', $this->type);
        $stmt->bindValue(':byte_order', $this->byte_order, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->bindValue(':value_conversion_formula', $this->value_conversion_formula, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->bindValue(':lowest_digit_price', $this->lowest_digit_price);
        $stmt->bindValue(':signed', $this->signed, PDO::PARAM_BOOL);
        $stmt->bindValue(':bits', $this->bits);
        $stmt->bindValue(':sorting_bit', $this->sorting_bit, PDO::PARAM_INT|PDO::PARAM_NULL);
        $stmt->bindValue(':value', $this->value, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->bindValue(':value_inverted', $this->value_inverted, PDO::PARAM_BOOL);
        $stmt->bindValue(':description', $this->description, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->execute();
        //$this->initView();
    }

    protected function tryUpdate(): void
    {
        $stmt = self::PDO()->prepare('UPDATE `pb_command_parameter` SET 
                `name`=:name,
                `type`=:type,
                `byte_order`=:byte_order,
                `value_conversion_formula`=:value_conversion_formula,
                `lowest_digit_price`=:lowest_digit_price,
                `signed`=:signed,
                `bits`=:bits,
                `sorting_bit`=:sorting_bit,
                `value`=:value, 
                `value_inverted`=:value_inverted,
                `description`=:description 
            WHERE `GUID`=UUIDToBin(:GUID);');
        $stmt->bindValue(':name', $this->name);
        $stmt->bindValue(':type', $this->type);
        $stmt->bindValue(':byte_order', $this->byte_order, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->bindValue(':value_conversion_formula', $this->value_conversion_formula, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->bindValue(':lowest_digit_price', $this->lowest_digit_price);
        $stmt->bindValue(':signed', $this->signed, PDO::PARAM_BOOL);
        $stmt->bindValue(':bits', $this->bits);
        $stmt->bindValue(':sorting_bit', $this->sorting_bit, PDO::PARAM_INT|PDO::PARAM_NULL);
        $stmt->bindValue(':value', $this->value, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->bindValue(':value_inverted', $this->value_inverted, PDO::PARAM_BOOL);
        $stmt->bindValue(':description', $this->description, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->bindValue(':GUID', $this->GUID);
        $stmt->execute();
    }

    protected function tryDelete(): void
    {
        $stmt = self::PDO()->prepare('DELETE FROM `pb_command_parameter` WHERE `GUID` = UUIDToBin(:GUID);');
        $stmt->bindValue(':GUID', $this->GUID);
        $stmt->execute();
    }

    /**
     * @throws DBException
     * @throws VException
     */
    protected function tryMassBitsInsert(array $names): void
    {
        $bits = $this->getBits();
        $c = count($bits) - 1;
        $name = trim($this->getName()) == "" ? "" : trim($this->getName()) . ': ';
        if ($c < 1) $this->tryInsert();
        else foreach ($bits as $i => $bit) {
            $parameter = clone $this;
            $parameter->setName($name . ($names[$i] ?? 'D' . ($c - $i) . ' Резерв'));
            $parameter->setBits([$bit]);
            $parameter->tryInsert();
            $this->GUID = $parameter->getGUID();
        }
    }

    /**
     * @throws DBException
     */
    public function dbMassBitsInsert(array $names): void
    {
        self::dbAction($this->tryMassBitsInsert(...), DBEx::notInsert, $names);
    }

    /**
     * @throws DBException|VException
     */
    public static function dbLoad(?string $GUID, ?int $command = null): static
    {
        if (preg_match("/^(\{)?[a-f\d]{8}(-[a-f\d]{4}){4}[a-f\d]{8}(?(1)})$/i", $GUID)) {
            $stmt = self::PDO()->prepare('SELECT BinToUUID(`GUID`) AS `GUID`, 
                `command`, IF(`conflicted_GUID` IS NULL, NULL, BinToUUID(`conflicted_GUID`)) AS `conflicted_GUID`,
                `package`, `name`, `type`, `byte_order`, `value_conversion_formula`, 
                `lowest_digit_price`, `signed`, `bits`, `sorting_bit`, `value`, `value_inverted`, `description`  
            FROM `pb_command_parameter`
            WHERE `GUID`=UUIDToBin(:this)
              AND `package`=:package;');
            $stmt->bindValue(':this', $GUID);
            $stmt->bindValue(':package', static::PACKAGE_TYPE, PDO::PARAM_BOOL);
            $stmt->execute();
            return static::intoMe($stmt->fetchObject(static::class, [$command]), $command)->setGUID($GUID);
        } else return new static($command)->setToNotExists()->setGUID($GUID);
    }

    /**
     * Сначала ищет подходящий параметр с аналогичным конфликтным GUID и командой, затем переходит к обычному поиску
     * @throws DBException|VException
     */
    public static function dbLoadByImport(?string $GUID, ?int $command): static
    {
        if (preg_match("/^(\{)?[a-f\d]{8}(-[a-f\d]{4}){4}[a-f\d]{8}(?(1)})$/i", $GUID)) {
            if ($command !== null) {
                $stmt = self::PDO()->prepare('SELECT BinToUUID(`GUID`) AS `GUID`, 
                    `command`, IF(`conflicted_GUID` IS NULL, NULL, BinToUUID(`conflicted_GUID`)) AS `conflicted_GUID`,
                    `package`, `name`, `type`, `byte_order`, `value_conversion_formula`, 
                    `lowest_digit_price`, `signed`, `bits`, `sorting_bit`, `value`, `value_inverted`, `description`  
                FROM `pb_command_parameter`
                WHERE `conflicted_GUID`=UUIDToBin(:this)
                  AND `command`=:command
                  AND `package`=:package;');
                $stmt->bindValue(':this', $GUID);
                $stmt->bindValue(':command', $command, PDO::PARAM_INT);
                $stmt->bindValue(':package', static::PACKAGE_TYPE, PDO::PARAM_BOOL);
                $stmt->execute();
                $param = static::intoMe($stmt->fetchObject(static::class, [$command]), $command);
                if (!$param->exists()) $param = static::dbLoad($GUID);
                return $param;
            } else return static::dbLoad($GUID);
        } else return new static($command)->setToNotExists()->setGUID($GUID);
    }

    /**
     * @throws DBException|VException
     */
    public static function actualizeGUID(string $GUID, int $protocol): string
    {
        if (preg_match("/^(\{)?[a-f\d]{8}(-[a-f\d]{4}){4}[a-f\d]{8}(?(1)})$/i", $GUID)) {
            $stmt = self::PDO()->prepare('SELECT BinToUUID(`GUID`) AS `GUID` FROM `pb_command_parameter`
                WHERE `conflicted_GUID`=UUIDToBin(:this)
                  AND `command` IN (SELECT `ID` FROM `pb_command` 
                                                WHERE `subscriber` IN (SELECT `ID` FROM `pb_subscriber` 
                                                                                   WHERE `protocol`=:protocol));');
            $stmt->bindValue(':this', $GUID);
            $stmt->bindValue(':protocol', $protocol, PDO::PARAM_INT);
            $stmt->execute();
            $new_GUID = $stmt->fetchColumn();
            if ($new_GUID === false) $new_GUID = null;
            return $new_GUID ?? $GUID;
        } else throw new VException(VEx::brokenGUID, $GUID);
    }
}