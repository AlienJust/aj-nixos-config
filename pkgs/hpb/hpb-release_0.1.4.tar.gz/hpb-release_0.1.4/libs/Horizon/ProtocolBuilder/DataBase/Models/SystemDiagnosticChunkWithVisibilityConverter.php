<?php

namespace Horizon\ProtocolBuilder\DataBase\Models;

use Horizon\ProtocolBuilder\LogicItems\ParameterAddress;

readonly class SystemDiagnosticChunkWithVisibilityConverter
{

    public string $type;
    public string $chunk_id;

    public string $name;

    protected ?int $bit;
    protected ?int $header_length;
    protected ?int $length;

    public int $row_id;
    public int $visibility_converter;

    public function getRowId(): int
    {
        return $this->row_id;
    }

    public function getLabel(): string
    {
        $address = $this->getAddress();
        $name = $this->name;
        return "$address - $name";
    }

    public function getAddress(): string
    {
        return $this->bit === null ? '' : new ParameterAddress($this->bit, $this->header_length, $this->length)->draw();
    }
}