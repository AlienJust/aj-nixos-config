<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISectionProtected;

interface iUISectionActionEnum
{
    public function code(): string;
    public function name(): string;
    public function buttonName(): string;
    public static function controlPanel(): array;
    public function initController(array $post = []): UISection|UISectionProtected;
    public function unlimitedAccess(): bool;
}
