<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\DataBase\Tables\SystemDiagnosticAggregateChunk;
use Horizon\ProtocolBuilder\DataBase\Tables\SystemDiagnosticChunk;
use Horizon\ProtocolBuilder\DataBase\Tables\SystemDiagnosticVirtualChunk;
use Horizon\ProtocolBuilder\Exceptions\UploadException;
use Horizon\ProtocolBuilder\Exceptions\VEx;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\LogicItems\ToIntRequiredHandler;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Protocol;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Executor;

class ExecProtocolSystemDiagnosticVisibilityEditing extends Executor
{

    /**
     * @throws DBException
     * @throws UploadException
     * @throws VException
     */
    public function __construct(Protocol $protocol, array $chunks)
    {
        foreach($chunks as $type => $chunk_data) {
            foreach ($chunk_data as $chunk_id => $data) {
                $visibility = ToIntRequiredHandler::run(eProtocolField::parameter_view_visibility->get($data),
                    eProtocolField::parameter_view_visibility->name);
                switch ($type) {
                    case 'chunk':
                        $chunk = SystemDiagnosticChunk::dbFind($protocol->getID(), $chunk_id);
                        $chunk->setVisibilityConverter($visibility);
                        $chunk->dbUpdate();
                        break;
                    case 'aggregate_chunk':
                        $chunk = SystemDiagnosticAggregateChunk::dbLoad($chunk_id, $protocol->getID());
                        $chunk->setVisibilityConverter($visibility);
                        $chunk->dbUpdate();
                        break;
                    case 'virtual_chunk':
                        $chunk = SystemDiagnosticVirtualChunk::dbFind($protocol->getID(), $chunk_id);
                        $chunk->setVisibilityConverter($visibility);
                        $chunk->dbUpdate();
                        break;
                    default:
                        throw new VException(VEx::undefinedChunkType, $type);
                }
            }
        }
        parent::__construct(eUISA_Protocol::system_diagnostic_visibility_editing
            ->initController()->setProtocol($protocol)->getURL());
    }
}