<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Controls\InputText;

class ParameterValueConversionFormulaTag extends InputText
{
    public function __construct(?string $value)
    {
        $field = eParameterField::value_conversion_formula;
        parent::__construct($field->code(), $value ?? '', $field->label(), $field->title());
    }
}