<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_UGroup;

enum eUISA_UGroup: string implements iUISectionActionEnum
{
    case main = 'main';
    case new = 'new';
    case edit = 'edit';
    case delete = 'delete';

    public function code(): string
    {
        return $this->name;
    }

    public function name(): string
    {
        return match ($this) {
            self::new => 'Создание группы',
            self::edit => 'Изменение группы',
            self::delete => 'Удаление группы',
            self::main => 'Группы доступа к протоколам',
        };
    }

    public function buttonName(): string
    {
        return match ($this) {
            self::main => 'Группы доступа',
            self::new => '+ группа',
            self::edit => 'Изменить',
            self::delete => 'Удалить',
        };
    }

    public static function controlPanel(): array
    {
        return [
            self::edit,
        ];
    }

    public function initController(array $post = []): UISection_UGroup
    {
        return new UISection_UGroup($this, $post);
    }

    public function unlimitedAccess(): bool
    {
        return false;
    }
}