<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCommandField;
use Horizon\UserInterface\Controls\InputNumber;

class CommandReplyHeaderLengthTag extends InputNumber
{
    public function __construct(string $value)
    {
        $field = eCommandField::reply_header_length;
        parent::__construct($field->code(), $value, $field->label(), $field->title(), true);
    }
}