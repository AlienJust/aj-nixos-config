<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Controls\InputTextarea;

class ParameterDescriptionTag extends InputTextarea
{
    public function __construct(string $value)
    {
        $field = eParameterField::description;
        parent::__construct($field->code(), $value, $field->label(), $field->title(), 2000);
    }
}