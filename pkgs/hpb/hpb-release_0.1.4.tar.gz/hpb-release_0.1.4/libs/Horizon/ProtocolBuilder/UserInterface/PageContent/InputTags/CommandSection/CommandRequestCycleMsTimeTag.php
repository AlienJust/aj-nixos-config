<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCommandField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Constants\DataAttribute;
use Horizon\UserInterface\Controls\InputNumber;

class CommandRequestCycleMsTimeTag extends InputNumber
{
    public function __construct(?float $value)
    {
        $format_value = $value === null ? '' : number_format($value, 4, '.', '');
        $field = eCommandField::request_cycle_ms_time;
        parent::__construct($field->code(), $format_value, $field->label(), $field->title());
        $this->addAttribute(DataAttribute::min, '0');
        $this->addAttribute(Attribute::step, '0.0001');
    }
}