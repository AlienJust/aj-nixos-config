<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields;

enum eCommandField implements iTransmissionField
{
    case name;
    case request_length;
    case request_start;
    case reply_length;
    case reply_start;
    case parameters;
    case request_header_length;
    case reply_header_length;
    case init_way;
    case system;
    case reply_request_required;
    case request_cycle_ms_time;
    case source;
    case parameter_length;

    public function code(mixed ...$options): string
    {
        return match ($this) {
            self::request_length => 'request[length]',
            self::request_start => 'request[start]',
            self::request_header_length => 'request[header_length]',
            self::request_cycle_ms_time => 'request[cycle_ms_time]',
            self::reply_request_required => 'reply[request_required]',
            self::reply_length => 'reply[length]',
            self::reply_start => 'reply[start]',
            self::reply_header_length => 'reply[header_length]',
            self::name,
            self::parameters,
            self::init_way,
            self::source,
            self::system,
            self::parameter_length => $this->name,
        };
    }
    
    public function get(array $post): null|string|float|array
    {
        return match ($this) {
            self::name => $post[$this->code()] ?? null,
            self::request_length => $post['request']['length'] ?? null,
            self::request_start => $post['request']['start'] ?? null,
            self::request_header_length => $post['request']['header_length'] ?? null,
            self::request_cycle_ms_time => ($post['request']['cycle_ms_time'] ?? null) == '' ? null : $post['request']['cycle_ms_time'],
            self::reply_request_required => $post['reply']['request_required'] ?? false,
            self::reply_length => $post['reply']['length'] ?? null,
            self::reply_start => $post['reply']['start'] ?? null,
            self::reply_header_length => $post['reply']['header_length'] ?? null,
            self::parameters => array_keys($post[$this->code()] ?? []),
            self::init_way => $post[$this->code()] ?? '',
            self::system => $post['system'] ?? false,
            self::source => $post['source'] ?? null,
            self::parameter_length => $post['parameter_length'] ?? 1,
        };
    }

    public function label(): string
    {
        return match ($this) {
            self::name => 'Наименование команды',
            self::request_length => 'Длина запроса (в байтах)',
            self::request_start => throw new \Exception('To be implemented'),
            self::reply_length => 'Длина ответа (в байтах)',
            self::reply_start => throw new \Exception('To be implemented'),
            self::parameters => throw new \Exception('To be implemented'),
            self::request_header_length => 'Длина заголовка запроса (в байтах)',
            self::reply_header_length => 'Длина заголовка ответа (в байтах)',
            self::init_way => throw new \Exception('To be implemented'),
            self::system => 'Пометить системной',
            self::reply_request_required => throw new \Exception('To be implemented'),
            self::request_cycle_ms_time => 'Время цикла',
            self::source => throw new \Exception('To be implemented'),
            self::parameter_length => 'Длина параметров для расчётов',
        };
    }

    public function title(): string
    {
        return match ($this) {
            self::name => 'Введите наименование команды',
            self::request_length => 'Введите длину запроса в байтах',
            self::request_start => throw new \Exception('To be implemented'),
            self::reply_length => 'Введите длину ответа в байтах',
            self::reply_start => throw new \Exception('To be implemented'),
            self::parameters => throw new \Exception('To be implemented'),
            self::request_header_length => 'Введите длину заголовка запроса в байтах',
            self::reply_header_length => 'Введите длину заголовка ответа в байтах',
            self::init_way => throw new \Exception('To be implemented'),
            self::system => 'Отметьте, если команду и параметры не нужно отображать пользователю',
            self::reply_request_required => throw new \Exception('To be implemented'),
            self::request_cycle_ms_time => 'Введите длительность цикла в миллисекундах',
            self::source => throw new \Exception('To be implemented'),
            self::parameter_length => 'Выберите длину параметров для расчётов в байтах',
        };
    }
}
