<?php

namespace Horizon\ProtocolBuilder\UserInterface\Menu\Bricks;

use Horizon\UserInterface\Tags\Division;

class MenuText extends Division
{
    public function __construct(string $text)
    {
        parent::__construct($text);
        $this->addClass('menu-item');
    }
}