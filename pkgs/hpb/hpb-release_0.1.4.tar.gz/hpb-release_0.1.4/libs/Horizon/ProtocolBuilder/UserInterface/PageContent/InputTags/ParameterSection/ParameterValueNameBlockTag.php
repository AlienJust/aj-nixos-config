<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Controls\InputTextarea;

class ParameterValueNameBlockTag extends InputTextarea
{
    public function __construct()
    {
        $field = eParameterField::value_name_block;
        parent::__construct($field->code(), '', $field->label(), $field->title(), 4000);
    }
}