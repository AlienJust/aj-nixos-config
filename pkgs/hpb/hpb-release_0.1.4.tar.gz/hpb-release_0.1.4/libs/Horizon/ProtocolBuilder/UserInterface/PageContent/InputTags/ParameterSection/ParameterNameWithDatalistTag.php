<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\Data\eParameterName;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\Components\DataList;
use Horizon\UserInterface\Controls\Components\Option;
use Horizon\UserInterface\HTMLException;
use Horizon\UserInterface\TagsPack;

class ParameterNameWithDatalistTag extends TagsPack
{
    protected const string PARAMETER_NAME_LIST_ID = 'parameter_name_list';

    public function __construct(string $value)
    {
        parent::__construct();
        $this->add(new ParameterNameTag($value)->addAttribute(Attribute::list, self::PARAMETER_NAME_LIST_ID))
            ->add($this->initNameDataListTag());
    }

    protected function initNameDataListTag(): DataList
    {
        $datalist = new DataList(self::PARAMETER_NAME_LIST_ID);
        try {
            foreach (eParameterName::cases() as &$case) $datalist->add(new Option($case->value, ''));
        } catch (HTMLException $e) {
            $this->add($e->getMessage());
        }
        return $datalist;
    }
}