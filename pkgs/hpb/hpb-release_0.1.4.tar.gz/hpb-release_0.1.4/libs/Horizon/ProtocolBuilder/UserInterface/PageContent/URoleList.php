<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\PageContent\Tables\URolesTable;

class URoleList extends _PageContentTag
{
    private URolesTable $roles;
    public function __construct(?string $header = null)
    {
        parent::__construct($header);
        $this->roles = new URolesTable();
        $this->add($this->roles);
    }

    public function addItem(string $name, string $description, ?string $edit_URL): static
    {
        $this->roles->addItem($name, $description, $edit_URL);
        return $this;
    }
}