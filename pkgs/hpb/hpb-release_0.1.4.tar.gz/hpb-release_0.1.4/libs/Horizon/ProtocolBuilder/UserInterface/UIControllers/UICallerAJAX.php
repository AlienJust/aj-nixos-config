<?php

namespace Horizon\ProtocolBuilder\UserInterface\UIControllers;

use Horizon\ProtocolBuilder\Exceptions\UploadException;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\UserInterface\eUICallerAJAXAction;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCallerAJAXFields;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewInjectionValueItemTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewInjectionValueListTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewNumberItemTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewNumberListTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewValueItemTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterViewValueListTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\SystemDiagnosticListEmptyRowDestinationTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\SystemDiagnosticListEmptyRowTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolAggregateGroupItemTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolAggregateGroupListTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolAggregateParameterItemTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolAggregateParameterListTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolBlockItemTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolBlockListTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolVirtualParameterItemTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolVirtualParameterListTag;
use Horizon\UserInterface\HTMLException;
use Horizon\UserInterface\iTag;
use Horizon\UserInterface\TagsPack;

class UICallerAJAX
{
    protected array $post;
    protected array $files;

    private ?eUICallerAJAXAction $action;
    public function __construct(?eUICallerAJAXAction $action, array $post, array $files = [])
    {
        $this->post = $post;
        $this->files = $files;
        $this->action = $action;
    }

    /**
     * @throws UploadException
     * @throws HTMLException
     * @throws VException
     */
    public function tag(): iTag
    {
        $properties = eCallerAJAXFields::properties->get($this->post);
        return match ($this->action) {
            eUICallerAJAXAction::summon_system_diagnostic_block => new ProtocolBlockListTag()
                ->increaseCounter($COUNTER = eProtocolField::summon_system_diagnostic_block_counter->get($properties))
                ->tagNewItem(new ProtocolBlockItemTag($COUNTER, null, '', 1, false, false)),
            eUICallerAJAXAction::summon_parameter_view_value => new ParameterViewValueListTag()
                ->increaseCounter($COUNTER = eParameterField::summon_view_values_counter->get($properties))
                ->tagNewItem(new ParameterViewValueItemTag($COUNTER,
                    $COUNTER == 0 ? '[value] < 0.5' : ($COUNTER == 1 ? '[value] > 0.5' : "[value] == $COUNTER"),
                    $COUNTER == 0 ? '--' : ($COUNTER == 1 ? 'V' : ''),
                    '',
                    null
                )),
            eUICallerAJAXAction::summon_parameter_view_number => new ParameterViewNumberListTag()
                ->increaseCounter($COUNTER = eParameterField::summon_view_numbers_counter->get($properties))
                ->tagNewItem(new ParameterViewNumberItemTag($COUNTER, '[value]', 'f0', null)),
            eUICallerAJAXAction::summon_system_diagnostic_empty_row => new TagsPack()
                ->add(new SystemDiagnosticListEmptyRowTag())
                ->add(new SystemDiagnosticListEmptyRowDestinationTag()),
            eUICallerAJAXAction::summon_parameter_view_injection_value => new ParameterViewInjectionValueListTag()
                ->increaseCounter($COUNTER = eParameterField::summon_view_injection_values_counter->get($properties))
                ->tagNewItem(new ParameterViewInjectionValueItemTag($COUNTER, null, '')),
            eUICallerAJAXAction::summon_system_diagnostic_virtual_parameter => new ProtocolVirtualParameterListTag()
                ->increaseCounter($COUNTER = eProtocolField::summon_system_diagnostic_virtual_parameter_counter->get($properties))
                ->tagNewItem(new ProtocolVirtualParameterItemTag($COUNTER, null, '')),
            eUICallerAJAXAction::summon_system_diagnostic_aggregate_group => new ProtocolAggregateGroupListTag()
                ->increaseCounter($COUNTER = eProtocolField::summon_system_diagnostic_aggregate_group_counter->get($properties))
                ->tagNewItem(new ProtocolAggregateGroupItemTag($COUNTER, null, '')),
            eUICallerAJAXAction::summon_system_diagnostic_aggregate_parameter =>
            new ProtocolAggregateParameterListTag(eProtocolField::aggregate_group_counter->get($properties))
                ->increaseCounter($COUNTER = eProtocolField::summon_system_diagnostic_aggregate_parameter_counter->get($properties))
                ->tagNewItem(new ProtocolAggregateParameterItemTag(
                    eProtocolField::aggregate_group_counter->get($properties),
                    $COUNTER,
                    ''
                )),
        };
    }
}