<?php
namespace Horizon\ProtocolBuilder\UserInterface\Pages;

use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\Menu;
use Horizon\ProtocolBuilder\UserInterface\PageContent\_PageContentTag;
use Horizon\ProtocolBuilder\UserInterface\PageParts\ControlPanel;
use Horizon\ProtocolBuilder\UserInterface\PageParts\ControlPanelItem;
use Horizon\ProtocolBuilder\UserInterface\PageParts\PathToPage;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputCheckbox;
use Horizon\UserInterface\TagsPack;

class MainPage extends Page
{
    private _PageContentTag $content;
    public bool $isHiddenSidebar = false {
        set {
            $this->isHiddenSidebar = $value;
        }
    }
    private TagsPack $sidebar;
    private Menu $last_menu;
    private PathToPage $path; // Обратный путь страницы, который отображается в подзаголовке
    private ControlPanel $control_panel;

    public function __construct()
    {
        $this->sidebar = new TagsPack();
        $this->path = new PathToPage();
        $this->control_panel = new ControlPanel();
    }

    public function setPath(PathToPage $path): void
    {
        $this->path = $path;
    }

    public function addControlPanelItem(ControlPanelItem $item): void
    {
        $this->control_panel->addItem($item);
    }

    public function setContent(_PageContentTag $content, ?string ...$title): void
    {
        $this->content = $content;
        $title = array_filter($title, fn ($m) => $m != "");
        $this->title = implode(" · ", array_merge(["КП"], $title));
    }

    public function addMenu(Menu $menu): void
    {
        $this->sidebar->add($menu);
        $this->last_menu = $menu;
    }

    public function is()
    {

    }

    private function drawSidebar(): string
    {
        $this->last_menu->setCurrent(true);
        return $this->sidebar->draw();
    }

    protected function drawBody(): string
    {//<label class="sidebar-button" for="hamburger" onclick="Array.from(document.getElementsByClassName(\'sidebar\')).forEach(x => x.removeAttribute(\'style\'));">
        return
        '<label class="sidebar-button" for="hamburger">
            <span class="line"></span>
            <span class="line"></span>
            <span class="line"></span>
        </label>
        '
            . new InputCheckbox('hamburger', $this->isHiddenSidebar)
                ->addClass('hide')
                ->addAttribute(Attribute::id, 'hamburger')
                ->addAttribute(Attribute::form, 'main')
                ->draw()
            . $this->drawSidebar()
            . '
        <div class="page">
            ' . $this->path->draw() . '
            ' . $this->control_panel->draw(). '
            <div class="content" id="content">' . $this->content->draw() . '</div>
        </div>';
    }
}