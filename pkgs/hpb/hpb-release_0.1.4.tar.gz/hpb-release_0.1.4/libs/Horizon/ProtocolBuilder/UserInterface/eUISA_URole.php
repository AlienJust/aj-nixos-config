<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_URole;

enum eUISA_URole: string implements iUISectionActionEnum
{
    case main = 'main';
    case new = 'new';
    case edit = 'edit';
    case delete = 'delete';

    public function code(): string
    {
        return $this->name;
    }

    public function name(): string
    {
        return match ($this) {
            self::new => 'Создание роли',
            self::edit => 'Изменение роли',
            self::delete => 'Удаление роли',
            self::main => 'Роли пользователей',
        };
    }

    public function buttonName(): string
    {
        return match ($this) {
            self::main => 'Роли пользователей',
            self::new => '+ роль',
            self::edit => 'Изменить',
            self::delete => 'Удалить',
        };
    }

    public static function controlPanel(): array
    {
        return [
            self::edit,
        ];
    }

    public function initController(array $post = []): UISection_URole
    {
        return new UISection_URole($this, $post);
    }

    public function unlimitedAccess(): bool
    {
        return false;
    }
}