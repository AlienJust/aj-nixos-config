<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\Data\eParameterByteOrder;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Controls\Components\Option;
use Horizon\UserInterface\Controls\InputSelect;

class ParameterByteOrderTag extends InputSelect
{
    public function __construct(?string $value)
    {
        $field = eParameterField::byte_order;
        parent::__construct($field->code(), $value ?? '', $field->label(), $field->title(), true);
        $this->addOptions(true, ...Option::initFromStringBackedEnumCases(eParameterByteOrder::cases()));
    }
}