<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\Tables;

use Horizon\ProtocolBuilder\UserInterface\PageContent\Tables\RefButtons\EditButton;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Tags\Table;
use Horizon\UserInterface\Tags\TableData;
use Horizon\UserInterface\Tags\TableHeader;
use Horizon\UserInterface\Tags\TableRow;

class UsersTable extends Table
{
    public function __construct()
    {
        parent::__construct();
        $this->add(new TableRow()->add(
            new TableHeader()->addAttribute(Attribute::width, '2rem'),
            new TableHeader('ФИО'),
            new TableHeader('Имя учётной записи'),
            new TableHeader('Роль'),
            new TableHeader('Группы доступа'),
            new TableHeader('Состояние')
        ));
    }

    public function addItem(string $SNP, string $username, string $role, string $groups, bool $ban, ?string $edit_URL): static
    {
        $state = $ban? 'BLOCK' : 'OK';
        $this->add(new TableRow()->add(
            new TableData()->add($edit_URL === null? null : new EditButton($edit_URL)),
            new TableData($SNP)->addClassIf('attention', $ban),
            new TableData($username)->addClassIf('attention', $ban),
            new TableData($role)->addClassIf('attention', $ban),
            new TableData($groups)->addClassIf('attention', $ban),
            new TableData($state)->addClassIf('attention', $ban)
        ));
        return $this;
    }
}