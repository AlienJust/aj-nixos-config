<?php

namespace Horizon\ProtocolBuilder\UserInterface\UIControllers;

use Horizon\Auth\DataBase\ListSources\URoleListSource;
use Horizon\Auth\DataBase\Tables\Role;
use Horizon\Auth\DataBase\Tables\User;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\Exceptions\ActionAccessException;
use Horizon\ProtocolBuilder\Exceptions\UIEx;
use Horizon\ProtocolBuilder\Exceptions\UIException;
use Horizon\ProtocolBuilder\LogicItems\URL;
use Horizon\ProtocolBuilder\UserInterface\eUISA_URole;
use Horizon\ProtocolBuilder\UserInterface\eUISection;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecURoleCreation;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecURoleDeleting;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecURoleEditing;
use Horizon\ProtocolBuilder\UserInterface\iUISectionActionEnum;
use Horizon\ProtocolBuilder\UserInterface\PageContent\_PageContentTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eURoleField;
use Horizon\ProtocolBuilder\UserInterface\PageContent\URoleCreation;
use Horizon\ProtocolBuilder\UserInterface\PageContent\URoleDeleting;
use Horizon\ProtocolBuilder\UserInterface\PageContent\URoleEditing;
use Horizon\ProtocolBuilder\UserInterface\PageContent\URoleList;
use Horizon\UserInterface\Executor;

class UISection_URole extends UISectionProtected
{
    protected static eUISection $section = eUISection::user_role;
    //private ?eUISA_URole $action;
    private Role $role;
    public function __construct(eUISA_URole $action, array $post = [])
    {
        parent::__construct($post);
        $this->action = $action;
    }

    public function setRole(Role $role): static
    {
        $this->role = $role;
        return $this;
    }

    /**
     * @throws DBException
     */
    public function refRole(): Role
    {
        return $this->role ?? ($this->role = Role::dbLoad($this->getID()));
    }

    public function refAction(): ?eUISA_URole
    {
        return $this->action;
    }

    private function prepareActions(Role $role): array
    {
        $result = [];
        foreach ($role->actions as $action) {
            $result[] = $action->getID();
        }
        return $result;
    }

    /**
     * @throws DBException
     * @throws UIException
     */
    public function tag(): _PageContentTag
    {
        return match ($this->action) {
            eUISA_URole::main => $this->listTag(),
            eUISA_URole::new => new URoleCreation($this->getHeader(), $this->getURL(),
                '',
            ),
            eUISA_URole::edit => new URoleEditing($this->getHeader(), $this->getURL(),
                $this->refRole()->name, $this->prepareActions($this->refRole())
            )->addActionBlock(new URoleDeleting($this->refRole()->name,
                eUISA_URole::delete->initController()->setRole($this->refRole())->getURL())),
            default => throw new UIException(UIEx::actionNotImplemented)
        };
    }

    public function initExecutor(): Executor
    {
        return match ($this->action) {
            eUISA_URole::new => new ExecURoleCreation($this->refRole(),
                eURoleField::name->get($this->post),
            ),
            eUISA_URole::edit => new ExecURoleEditing($this->refRole(),
                eURoleField::name->get($this->post),
                eURoleField::actions->get($this->post)
            ),
            eUISA_URole::delete => new ExecURoleDeleting($this->refRole()),
            default => throw new UIException(UIEx::executeNotImplemented, $this->action->name())
        };
    }

    public function getCurrentID(): ?string
    {
        return $this->role->getID();
    }

    public function refURL(): URL
    {
        try {
            $ID = $this->refRole()->exists() ? $this->refRole()->getID() : null;
        } catch (DBException) {
            $ID = null;
        }
        return new URL()
            ->setSectionAction(static::$section->value, $this->action?->value)
            ->setAnyID($ID);
    }

    /**
     * @throws DBException
     */
    private function listTag(): URoleList
    {
        $edit_controller = eUISA_URole::edit->initController();
        $tag = new URoleList($this->refAction()->name());
        $viewer = new URoleListSource(1, 3000, null);
        $roles = $viewer->loadData();
        foreach ($roles as $role) {
            $description = [];
            $actions = $this->prepareActions($role);
            foreach (eUISection::cases() as $section) {
                $all_actions = array_filter($section->actions(), fn(iUISectionActionEnum $enum) =>
                    in_array(implode(".", [$section->name, $enum->code()]), $actions)
                );
                if ($all_actions) $description[] =
                    "<h4>" . $section->name() . "</h4><ul><li>" . implode(
                        "<li>", array_map(fn(iUISectionActionEnum $enum) => $enum->name(), $all_actions)
                    ) . "</ul>";
            }
            $tag->addItem($role->name, "<div class='columns'>".implode("", $description)."</div>", $edit_controller->setRole($role)->getURL());
        }
        return $tag;
    }

    public static function initWithAction(?iUISectionActionEnum $action): ?static
    {
        // TODO: Implement initWithAction() method.
    }
}