<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields;

use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\LogicItems\ArrayKeysRequiredHandler;
use Horizon\ProtocolBuilder\LogicItems\ToStringRequiredHandler;

enum eURoleField implements iTransmissionField
{
    case name;
    case actions;

    public function code(...$options): string
    {
        return match ($this) {
            self::name => $this->name,
            self::actions => "$this->name[$options[0]]",
        };
    }

    /**
     * @throws VException
     */
    public function get(array $post): string|int|array|null
    {
        return match ($this) {
            self::name => ToStringRequiredHandler::run($post[$this->code()] ?? '', $this->name),
            self::actions => ArrayKeysRequiredHandler::run($post[$this->name] ?? [], $this->name),
        };
    }
}