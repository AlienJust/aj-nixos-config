<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection\UserBanTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection\UserNameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection\UserPasswordDefaultTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection\UserPatronymicTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection\UserRoleTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection\UserSurnameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection\UserUsernameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\CreationButton;
use Horizon\UserInterface\PresetTags\Division2Columns;
use Horizon\UserInterface\Tags\LineBreak;

class UserCreation extends _PageContentTag
{
    /**
     * @throws DBException
     */
    public function __construct(string $header, string $action_URL,
                                string $username, string $surname, string $name, string $patronymic,
                                bool $ban, int $role
    ) {
        parent::__construct($header);
        $this->add(new MainForm($action_URL)->add(
            new UserBanTag($ban),
            new LineBreak(),
            new Division2Columns()->add(new UserUsernameTag($username), new UserRoleTag($role)),
            new UserPasswordDefaultTag(),
            new UserSurnameTag($surname),
            new UserNameTag($name),
            new UserPatronymicTag($patronymic),
            new CreationButton()
        ));
    }
}