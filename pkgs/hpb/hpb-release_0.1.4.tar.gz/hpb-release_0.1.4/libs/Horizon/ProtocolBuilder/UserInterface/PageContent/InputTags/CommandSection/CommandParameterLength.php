<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection;

use Horizon\ProtocolBuilder\Data\eParameterLength;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCommandField;
use Horizon\UserInterface\Controls\Components\Option;
use Horizon\UserInterface\Controls\InputSelect;

class CommandParameterLength extends InputSelect
{
    public function __construct(int $value)
    {
        parent::__construct(eCommandField::parameter_length->code(), $value,
            eCommandField::parameter_length->label(),
            eCommandField::parameter_length->title());
        $this->addOptions(true, ...array_map(fn(eParameterLength $case): Option => new Option($case->value, $case->label()), eParameterLength::cases()));
    }
}