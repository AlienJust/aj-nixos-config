<?php

namespace Horizon\ProtocolBuilder\UserInterface\Menu;

use Exception;
use Horizon\ProtocolBuilder\DataBase\Tables\Command;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToReply;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToRequest;
use Horizon\ProtocolBuilder\UserInterface\eUISA_ReplyParameter;
use Horizon\ProtocolBuilder\UserInterface\eUISA_RequestParameter;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\Menu;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\MenuBlock;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_ReplyParameter;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_RequestParameter;
use Horizon\UserInterface\Tags\Trace;

class ParametersMenu extends Menu
{
    public function __construct(Command $command, ?string $current_ID = null,
                                eUISA_RequestParameter|eUISA_ReplyParameter|null $action = null)
    {
        parent::__construct('parameters');
        try {
            $empty_request_parameter = new ParameterToRequest($command->getID());
            $empty_reply_parameter = new ParameterToReply($command->getID());
            $this
                ->addBlock($request_block = new MenuBlock('Параметры запроса')
                    ->addItem(
                        $this->initMenuAction(
                            eUISA_RequestParameter::new->initController()->setParameter($empty_request_parameter),
                            $action
                        ),
                        $this->initMenuAction(
                            eUISA_RequestParameter::new_default_value->initController()->setParameter($empty_request_parameter),
                            $action
                        ),
                        $this->initMenuAction(
                            eUISA_RequestParameter::new_variable->initController()->setParameter($empty_request_parameter),
                            $action
                        ),
                        $this->initMenuAction(
                            eUISA_RequestParameter::new_bits->initController()->setParameter($empty_request_parameter),
                            $action
                        )))
                ->addBlock($reply_block = new MenuBlock('Параметры ответа')
                    ->addItem(
                        $this->initMenuAction(
                            eUISA_ReplyParameter::new->initController()->setParameter($empty_reply_parameter),
                            $action
                        ),
                        $this->initMenuAction(
                            eUISA_ReplyParameter::new_default_value->initController()->setParameter($empty_reply_parameter),
                            $action
                        ),
                        $this->initMenuAction(
                            eUISA_ReplyParameter::new_variable->initController()->setParameter($empty_reply_parameter),
                            $action
                        ),
                        $this->initMenuAction(
                            eUISA_ReplyParameter::new_bits->initController()->setParameter($empty_reply_parameter),
                            $action
                        )));

            $parameters_to_request = $command->arrParametersToRequest();
            $parameters_to_reply = $command->arrParametersToReply();

            $request_controller = UISection_RequestParameter::initWithAction($action);
            $reply_controller = UISection_ReplyParameter::initWithAction($action);

            foreach ($parameters_to_request as $parameter) {
                $request_controller?->setParameter($parameter);
                $request_block->addItem($this->initMenuItem($request_controller, $parameter->getName(),
                    $parameter->getGUID() == $current_ID
                ));
            }
            foreach ($parameters_to_reply as $parameter) {
                $reply_controller?->setParameter($parameter);
                $reply_block->addItem($this->initMenuItem($reply_controller, $parameter->getName(),
                    $parameter->getGUID() == $current_ID
                ));
            }

        } catch (Exception $e) {
            $this->addBlock(new MenuBlock("Ошибка")->add(new Trace($e)));
        }
    }
}