<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Controls\InputText;

class ParameterNameTag extends InputText
{
    public function __construct(string $value, bool $required = true)
    {
        $field = eParameterField::name;
        parent::__construct($field->code(), htmlspecialchars($value), $field->label(), $field->title(), $required);
    }
}