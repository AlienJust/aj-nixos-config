<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\Auth\DataBase\Tables\User;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_User;
use Horizon\UserInterface\Executor;

class ExecUserPasswordResetting extends Executor
{
    /**
     * @throws DBException
     */
    public function __construct(User $user, string $password)
    {
        $user->setPassword($password);
        $user->dbUpdate();
        parent::__construct(eUISA_User::main->initController()->setUser($user)->getURL());
    }
}