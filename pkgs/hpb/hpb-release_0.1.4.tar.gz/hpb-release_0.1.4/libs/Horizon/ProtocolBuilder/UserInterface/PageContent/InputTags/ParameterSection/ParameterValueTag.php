<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Controls\InputText;

class ParameterValueTag extends InputText
{
    public function __construct(string $value)
    {
        $field = eParameterField::value;
        parent::__construct($field->code(), $value, $field->label(), $field->title());
    }
}