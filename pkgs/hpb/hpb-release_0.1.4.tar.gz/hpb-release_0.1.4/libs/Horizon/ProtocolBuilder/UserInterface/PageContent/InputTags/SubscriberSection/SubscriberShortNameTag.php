<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\SubscriberSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eSubscriberField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputText;

class SubscriberShortNameTag extends InputText
{
    public function __construct(string $value)
    {
        $field = eSubscriberField::short_name;
        parent::__construct($field->code(), $value, $field->label(), $field->title(), true);
        $this->addAttribute(Attribute::maxlength, '16');
    }
}