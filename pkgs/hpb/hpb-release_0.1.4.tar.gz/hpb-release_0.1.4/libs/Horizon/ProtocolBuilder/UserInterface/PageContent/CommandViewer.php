<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCommandField;
use Horizon\UserInterface\PresetTags\PostViewMatrix;
use Horizon\UserInterface\PresetTags\ValueView;
use Horizon\UserInterface\Tags\Fieldset;

class CommandViewer extends _PageContentTag
{
    public function __construct(string $header, string $name, bool $system,
                                int $request_length, int $reply_length,
                                int $request_header_length, int $reply_header_length,
                                array $request_params, array $reply_params, ?float $cycle_ms_time)
    {
        parent::__construct($header);
        $this->add(
            new Fieldset('Запрос')->add($request_tag = new PostViewMatrix($request_length, $request_header_length)),
            new Fieldset('Ответ')->add($reply_tag = new PostViewMatrix($reply_length, $reply_header_length)),
            new ValueView(eCommandField::name->label(), $name),
            new ValueView(eCommandField::request_length->label(), $request_length),
            new ValueView(eCommandField::request_header_length->label(), $request_header_length),
            new ValueView(eCommandField::reply_length->label(), $reply_length),
            new ValueView(eCommandField::reply_header_length->label(), $reply_header_length),
            new ValueView(eCommandField::request_cycle_ms_time->label(), $cycle_ms_time),
            new ValueView(eCommandField::system->label(), $system ? 'Да' : 'Нет'),
        );
        foreach ($request_params as $param) $request_tag->setParameter($param['name'], $param['bits']);
        foreach ($reply_params as $param) $reply_tag->setParameter($param['name'], $param['bits']);
    }
}