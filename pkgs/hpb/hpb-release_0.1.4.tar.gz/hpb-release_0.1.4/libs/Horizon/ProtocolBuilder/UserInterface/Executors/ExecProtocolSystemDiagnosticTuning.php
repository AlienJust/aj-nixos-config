<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\DataBase\Tables\SystemDiagnosticAggregateChunk;
use Horizon\ProtocolBuilder\DataBase\Tables\SystemDiagnosticAggregateParameter;
use Horizon\ProtocolBuilder\DataBase\Tables\SystemDiagnosticBlock;
use Horizon\ProtocolBuilder\DataBase\Tables\SystemDiagnosticVirtualChunk;
use Horizon\ProtocolBuilder\Exceptions\UploadException;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Protocol;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Executor;

class ExecProtocolSystemDiagnosticTuning extends Executor
{
    /**
     * @throws DBException
     * @throws UploadException
     * @throws VException
     */
    public function __construct(Protocol $protocol, array $parameter_views, array $blocks,
                                array $virtual_chunks, array $aggregate_chunks)
    {
        $sort = 0;
        foreach ($blocks as &$block) {
            $b = SystemDiagnosticBlock::dbLoad(eProtocolField::block_id->get($block), $protocol->getID())
                ->setSort($sort)
                ->setName(eProtocolField::block_name->get($block))
                ->setColumnsCount(eProtocolField::block_columns_count->get($block))
                ->setInline(eProtocolField::block_inline->get($block))
                ->setHideForProduction(eProtocolField::block_hide_for_production->get($block));
            $b->dbInsertUpdate();
            $sort++;
            $block = $b->getID();
        }
        foreach ($virtual_chunks as &$virtual_chunk) {
            try {
                $vc = SystemDiagnosticVirtualChunk::dbFind(
                    $protocol->getID(),
                    eProtocolField::virtual_parameter_code->get($virtual_chunk)
                )->setCode(eProtocolField::virtual_parameter_new_code->get($virtual_chunk));
            } catch (DBException) {
                $vc = new SystemDiagnosticVirtualChunk(null, 0, 0, $protocol->getID(),
                    eProtocolField::virtual_parameter_new_code->get($virtual_chunk));
            }
            $vc->dbInsertUpdate();
            $virtual_chunk = $vc->getCode();
        }
        foreach ($aggregate_chunks as &$aggregate_chunk) {
            $parameters = eProtocolField::aggregate_parameters->get($aggregate_chunk);
            $ac = SystemDiagnosticAggregateChunk::dbLoad(eProtocolField::aggregate_group_id->get($aggregate_chunk), $protocol->getID())
                ->setLabel(eProtocolField::aggregate_group_label->get($aggregate_chunk))
                ->setParamCount(count($parameters));
            $ac->dbInsertUpdate();
            $ac->dbClearParameters(); // Всегда заново создаем все агрегированные параметры группы
            $aggregate_chunk = $ac->getID();
            $sort = 0;
            foreach ($parameters as &$parameter) {
                $p = new SystemDiagnosticAggregateParameter(
                    $aggregate_chunk,
                    $protocol->getID(),
                    eProtocolField::aggregate_parameter_code->get($parameter),
                    $sort
                );
                $p->dbInsert();
                $sort++;
            }
        }
        $protocol->dbClearBlocks($blocks);
        $protocol->dbClearVirtualChunks($virtual_chunks);
        $protocol->dbUpdateChunks($parameter_views);
        $protocol->dbClearAggregateChunks($aggregate_chunks);
        parent::__construct(eUISA_Protocol::system_diagnostic_tuning->initController()->setProtocol($protocol)->getURL());
    }
}