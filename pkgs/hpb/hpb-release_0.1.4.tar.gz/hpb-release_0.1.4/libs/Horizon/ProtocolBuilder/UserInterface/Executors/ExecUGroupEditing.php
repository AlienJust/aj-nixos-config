<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\Auth\DataBase\Tables\Group;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_UGroup;
use Horizon\UserInterface\Executor;

class ExecUGroupEditing extends Executor
{
    /**
     * @throws DBException
     */
    public function __construct(Group $group, string $name, string $description, ?int $ownerID)
    {
        $group->name = $name;
        $group->description = $description;
        $group->setOwner($ownerID);
        $group->dbUpdate();
        parent::__construct(eUISA_UGroup::main->initController()->setGroup($group)->getURL());
    }
}