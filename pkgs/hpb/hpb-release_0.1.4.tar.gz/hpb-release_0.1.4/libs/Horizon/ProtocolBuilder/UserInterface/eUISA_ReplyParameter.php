<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_ReplyParameter;

enum eUISA_ReplyParameter: string implements iUISectionActionEnum
{
    case view = 'view';
    case new = 'new';
    case new_default_value = 'new_default_value';
    case new_variable = 'new_variable';
    case new_bits = 'new_bits';
    case edit = 'edit';
    case delete = 'delete';
    case new_view = 'new_view';
    case edit_view = 'edit_view';
    case delete_view = 'delete_view';

    public function code(): string
    {
        return $this->name;
    }

    public function name(): string
    {
        return match ($this) {
            self::view => 'Просмотр параметра',
            self::new => 'Создание в ответе параметра',
            self::new_default_value => 'Создание в ответе значения',
            self::new_variable => 'Создание в ответе переменной',
            self::new_bits => 'Создание в ответе битовых флагов',
            self::edit => 'Изменение параметра ответа',
            self::delete => 'Удаление параметра ответа',
            self::new_view => 'Создание представления параметра',
            self::edit_view => 'Редактирование представлений параметра',
            self::delete_view => 'Удаление представления параметра',
        };
    }

    public function buttonName(): string
    {
        return match ($this) {
            self::view => 'Обзор',
            self::new => '+ параметр',
            self::new_default_value => '+ значение',
            self::new_variable => '+ переменная',
            self::new_bits => '+ битовые флаги',
            self::edit => 'Изменить',
            self::delete => 'Удалить',
            self::new_view => 'Представления',
            self::edit_view => '',
            self::delete_view => 'Удалить представление',
        };
    }

    public static function controlPanel(): array
    {
        return [
            self::view,
            self::edit,
            self::new_view,
        ];
    }

    public static function actionOrder(): array
    {
        return [self::edit, self::view];
    }

    public function initController(array $post = []): UISection_ReplyParameter
    {
        return new UISection_ReplyParameter($this, $post);
    }

    public function unlimitedAccess(): bool
    {
        return false;
    }
}