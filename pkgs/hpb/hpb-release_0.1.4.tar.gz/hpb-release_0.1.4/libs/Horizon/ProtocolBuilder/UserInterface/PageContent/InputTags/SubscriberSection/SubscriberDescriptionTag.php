<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\SubscriberSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eSubscriberField;
use Horizon\UserInterface\Controls\InputTextarea;

class SubscriberDescriptionTag extends InputTextarea
{
    public function __construct(string $value)
    {
        $field = eSubscriberField::description;
        parent::__construct($field->code(), $value, $field->label(), $field->title(), 2000);
    }
}