<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\SubscriberSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eSubscriberField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputNumber;

class SubscriberAddressTag extends InputNumber
{
    public function __construct(string $value)
    {
        $field = eSubscriberField::address;
        parent::__construct($field->code(), $value, $field->label(), $field->title(), true);
        $this->addAttribute(Attribute::min, '0')
            ->addAttribute(Attribute::max, '65535')
            ->addAttribute(Attribute::step, '1');
    }
}