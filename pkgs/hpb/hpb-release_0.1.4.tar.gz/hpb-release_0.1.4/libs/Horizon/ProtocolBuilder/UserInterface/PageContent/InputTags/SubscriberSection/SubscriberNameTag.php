<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\SubscriberSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eSubscriberField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputText;

class SubscriberNameTag extends InputText
{
    public function __construct(string $value)
    {
        $field = eSubscriberField::name;
        parent::__construct($field->code(), $value, $field->label(), $field->title(), true);
        $this->addAttribute(Attribute::maxlength, '255');
    }
}