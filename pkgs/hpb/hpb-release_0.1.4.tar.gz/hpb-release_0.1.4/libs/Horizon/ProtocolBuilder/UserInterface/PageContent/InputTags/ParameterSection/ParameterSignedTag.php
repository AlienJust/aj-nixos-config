<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Controls\CheckboxBool;

class ParameterSignedTag extends CheckboxBool
{
    public function __construct(bool $value)
    {
        $field = eParameterField::signed;
        parent::__construct($field->code(), $value, $field->label(), $field->title());
    }
}