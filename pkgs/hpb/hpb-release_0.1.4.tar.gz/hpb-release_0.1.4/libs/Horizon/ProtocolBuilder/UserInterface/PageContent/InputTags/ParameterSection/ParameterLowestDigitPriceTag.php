<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputNumber;

class ParameterLowestDigitPriceTag extends InputNumber
{
    public function __construct(float $value)
    {
        $field = eParameterField::lowest_digit_price;
        parent::__construct($field->code(), $value, $field->label(), $field->title(), true);
        $this->addAttribute(Attribute::step, '0.0000000000001');
    }
}