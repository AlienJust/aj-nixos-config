<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\URoleSection\NameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\CreationButton;
class URoleCreation extends _PageContentTag
{

    public function __construct(string $header, string $action_URL,
                                string $name
    ){
        parent::__construct($header);
        $this->add(new MainForm($action_URL)
            ->add(new NameTag($name))
            ->add(new CreationButton()));
    }
}