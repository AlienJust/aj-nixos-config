<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolParameterViewVisibilityTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\UpdatingButton;
use Horizon\UserInterface\Tags\Division;
use Horizon\UserInterface\Tags\Header;
use Horizon\UserInterface\Tags\ListItem;
use Horizon\UserInterface\Tags\UnorderedList;
use Horizon\UserInterface\TagsPack;

class ProtocolSystemDiagnosticVisibilityEditing extends _PageContentTag
{
    private TagsPack $main_pack;
    private Division $last_block;
    private UnorderedList $last_column;
    public function __construct(string $id, string $header, string $action_URL)
    {
        parent::__construct($header, $id);
        $this->add(new MainForm($action_URL)
            ->add($this->main_pack = new TagsPack())
            ->add(new UpdatingButton()));
    }

    public function addBlock(int $sort, string $name): static
    {
        $this->main_pack->add(new Header(2, "#$sort $name"));
        $this->main_pack->add($this->last_block = new Division()->addClass('renaming-block'));
        return $this;
    }

    public function addColumn(): static
    {
        $this->last_block->add($this->last_column = new UnorderedList()->addClass('renaming-column'));
        return $this;
    }

    public function addChunk(string $type, string $chunk_id, string $address, string $name, int $visibility): static
    {
        $this->last_column->add(new ListItem()
            ->add(new Division(htmlspecialchars("$address $name")))
            ->add(new ProtocolParameterViewVisibilityTag($type, $chunk_id, $visibility))
        );
        return $this;
    }
}