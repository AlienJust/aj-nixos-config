<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Controls\InputText;

class ProtocolVersionTag extends InputText
{
    public function __construct(string $value)
    {
        $field = eProtocolField::version;
        parent::__construct($field->code(), $value, $field->label(), $field->title(), true);
    }
}