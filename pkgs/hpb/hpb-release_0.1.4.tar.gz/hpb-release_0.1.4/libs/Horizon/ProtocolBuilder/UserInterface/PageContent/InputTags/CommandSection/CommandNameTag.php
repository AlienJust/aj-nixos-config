<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCommandField;
use Horizon\UserInterface\Controls\InputText;

class CommandNameTag extends InputText
{
    public function __construct(string $value)
    {
        $field = eCommandField::name;
        parent::__construct($field->code(), $value, $field->label(), $field->title(), true);
    }
}