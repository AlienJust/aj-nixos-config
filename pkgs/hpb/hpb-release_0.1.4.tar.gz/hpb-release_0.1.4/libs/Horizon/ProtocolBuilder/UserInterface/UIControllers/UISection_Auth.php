<?php

namespace Horizon\ProtocolBuilder\UserInterface\UIControllers;

use Horizon\Auth\AccessDeniedEx;
use Horizon\Auth\AccessDeniedException;
use Horizon\ProtocolBuilder\Exceptions\UIEx;
use Horizon\ProtocolBuilder\Exceptions\UIException;
use Horizon\ProtocolBuilder\LogicItems\URL;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Auth;
use Horizon\ProtocolBuilder\UserInterface\eUISection;
use Horizon\ProtocolBuilder\UserInterface\PageContent\_PageContentTag;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecAuthLogin;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecAuthLogout;
use Horizon\UserInterface\Executor;

class UISection_Auth extends UISection
{
    protected static eUISection $section = eUISection::auth;

    public function __construct(eUISA_Auth $action, array $post = [])
    {
        parent::__construct($post);
        $this->action = $action;
    }

    public function refAction(): ?eUISA_Auth
    {
        return $this->action;
    }

    public function tag(): _PageContentTag
    {
        throw new UIException(UIEx::sectionNotImplemented);
    }

    /**
     * @throws AccessDeniedException
     */
    public function initExecutor(): Executor
    {
        return match ($this->action) {
            eUISA_Auth::login => new ExecAuthLogin(
                $this->post['username'] ?? throw new AccessDeniedException(AccessDeniedEx::not_data),
                $this->post['password'] ?? throw new AccessDeniedException(AccessDeniedEx::not_data),
                $this->post['path'] ?? "/"
            ),
            eUISA_Auth::logout => new ExecAuthLogout("/"),
        };
    }

    public function getCurrentID(): ?string
    {
        return null;
    }

    public function refURL(): URL
    {
        return new URL()->setSectionAction(static::$section->value, $this->action?->value);
    }
}