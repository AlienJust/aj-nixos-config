<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\PresetTags\ValueView;

class ProtocolViewer extends _PageContentTag
{
    public function __construct(string $header, string $GUID, string $name, string $version, string $description, string $author)
    {
        parent::__construct($header);
        $this->add(
            new ValueView(eProtocolField::GUID->label(), $GUID),
            new ValueView(eProtocolField::name->label(), $name),
            new ValueView(eProtocolField::version->label(), $version),
            new ValueView(eProtocolField::description->label(), $description),
            new ValueView(eProtocolField::author->label(), $author),
        );
    }
}