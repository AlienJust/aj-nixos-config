<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\URoleSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eURoleField;
use Horizon\UserInterface\Controls\CheckboxBool;

class ActionCheckboxTag extends CheckboxBool
{
    public function __construct(string $ID, string $name, bool $value)
    {
        parent::__construct(eURoleField::actions->code($ID), $value, $name,
            'Отметьте действие «' . $name . '», если нужно разрешить к нему доступ', false);
    }
}