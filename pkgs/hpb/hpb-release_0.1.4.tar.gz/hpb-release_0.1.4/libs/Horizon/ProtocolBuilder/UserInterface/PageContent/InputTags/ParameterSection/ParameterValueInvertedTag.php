<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Controls\CheckboxBool;

class ParameterValueInvertedTag extends CheckboxBool
{
    public function __construct(bool $value)
    {
        $field = eParameterField::value_inverted;
        parent::__construct($field->code(), $value, $field->label(), $field->title());
    }
}