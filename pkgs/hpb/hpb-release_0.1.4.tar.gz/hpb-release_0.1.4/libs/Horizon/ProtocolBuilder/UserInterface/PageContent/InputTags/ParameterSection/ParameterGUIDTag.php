<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputText;

class ParameterGUIDTag extends InputText
{
    public function __construct(string $value)
    {
        $field = eParameterField::GUID;
        parent::__construct($field->code(), $value, $field->label(), $field->title(), true);
        $this->addAttribute(Attribute::readonly, true);
    }
}