<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Controls\CheckboxBool;
use Horizon\UserInterface\Controls\InputCheckbox;
use Horizon\UserInterface\Controls\InputHiddenValue;
use Horizon\UserInterface\Controls\InputNumber;
use Horizon\UserInterface\Controls\InputText;
use Horizon\UserInterface\PresetTags\Division2Columns;
use Horizon\UserInterface\TagsPack;

class ProtocolBlockItemTag extends TagsPack
{
    public function __construct(int $COUNTER, ?int $id, string $name, int $columns_count, bool $is_inline, bool $is_hide_for_production)
    {
        parent::__construct();
        $this->add(new Division2Columns()
            ->add(is_null($id) ? null : new InputHiddenValue(eProtocolField::block_id->code($COUNTER), $id))
            ->add(new Division2Columns()
                ->add(new InputText(eProtocolField::block_name->code($COUNTER), $name,
                    'Наименование блока', 'Введите наименование блока'))
                ->add(new CheckboxBool(eProtocolField::block_hide_for_production->code($COUNTER), $is_hide_for_production,
                    'Скрывать в урезанной версии', 'Отметьте, если блок нужно скрыть в урезанной версии программы'))
            )
            ->add(new Division2Columns()
                ->add(new InputNumber(eProtocolField::block_columns_count->code($COUNTER), $columns_count,
                    'Количество столбцов', 'Введите количество столбцов в блоке', true))
                ->add(new CheckboxBool(eProtocolField::block_inline->code($COUNTER), $is_inline,
                    'В одну строку с предыдущим', 'Расположить блок в одной строке с предыдущим блоком?'))
            )
        );
    }
}