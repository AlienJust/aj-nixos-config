<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\eUISection;
use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\URoleSection\ActionCheckboxTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\URoleSection\NameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\UpdatingButton;
use Horizon\UserInterface\Tags\Fieldset;
use Horizon\UserInterface\TagsPack;

class URoleEditing extends _PageContentTag
{
    private array $actions;
    public function __construct(string $header, string $action_URL, string $name, array $actions
    ){
        parent::__construct($header);
        $this->actions = $actions;
        $this->add(new MainForm($action_URL)
            ->add(new NameTag($name))
            ->add($this->actionsTag())
            ->add(new UpdatingButton()));
    }

    private function actionsTag(): TagsPack
    {
        $tag = new TagsPack();
        foreach (eUISection::cases() as $section) {
            $actions = $section->actions();
            if ($actions) {
                $tag->add($set = new Fieldset($section->name())->addClass('columns'));
                foreach ($actions as $action) {
                    $ID = $section->name . '.' . $action->code();
                    $set->add(new ActionCheckboxTag($ID, $action->name(), in_array($ID, $this->actions)));
                }
            }
        }
        return $tag;
    }
}