<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\Data\eParameterType;
use Horizon\ProtocolBuilder\LogicItems\ParameterAddress;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\PresetTags\ValueView;
use Horizon\UserInterface\Tags\Header;

class ParameterViewer extends _PageContentTag
{
    public function __construct(string $header, string $GUID,
                                string $name, ?string $description, string $type, ?string $value,
                                ?string $value_conversion_formula, float  $lowest_digit_price, bool $signed, bool $inverted,
                                array  $bits, ?string $byte_order, int $count, ParameterAddress $address)
    {
        parent::__construct($header);
        $type = eParameterType::tryFrom($type);
        $this->add(
            new Header(3, ($type?->label() ?? '').' '. $address->draw()),
            new ValueView(eParameterField::GUID->label(), $GUID),
            new ValueView(eParameterField::name->label(), $name),
        );
        switch ($type) {
            case eParameterType::DefVal:
                $this->add(new ValueView(eParameterField::value->label(), $value));
                break;
            case eParameterType::CpzPrm:
                $this->add(
                    new ValueView(eParameterField::value_conversion_formula->label(), $value_conversion_formula),
                    new ValueView(eParameterField::lowest_digit_price->label(), $lowest_digit_price),
                    new ValueView(eParameterField::signed->label(), $signed ? 'Да' : 'Нет'),
                    count($bits) > 8 ? new ValueView(eParameterField::byte_order->label(), $byte_order) : null
                );
                break;
            case eParameterType::BitPrm:
                $this->add(new ValueView(eParameterField::value_inverted->label(), $inverted ? 'Да' : 'Нет'));
            default:
        }
        $this->add(new ValueView(eParameterField::description->label(), $description));
    }
}