<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\URoleSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eURoleField;
use Horizon\UserInterface\Controls\InputText;

class NameTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eURoleField::name->code(), $value,
            'Наименование роли', 'Введите наименование роли пользователей', true);
    }
}