<?php

namespace Horizon\ProtocolBuilder\UserInterface\UIControllers;

use Horizon\Auth\AccessDeniedEx;
use Horizon\Auth\AccessDeniedException;
use Horizon\Auth\DataBase\Tables\User;
use Horizon\Auth\TemporaryBlockingException;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\Exceptions\ActionAccessException;
use Horizon\ProtocolBuilder\Exceptions\DataAccessException;
use Horizon\ProtocolBuilder\Exceptions\UIException;
use Horizon\ProtocolBuilder\Exceptions\UploadException;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\LogicItems\URL;
use Horizon\ProtocolBuilder\UserInterface\eUISection;
use Horizon\ProtocolBuilder\UserInterface\iUISectionActionEnum;
use Horizon\ProtocolBuilder\UserInterface\PageContent\_PageContentTag;
use Horizon\UserInterface\Executor;
use Random\RandomException;

abstract class UISection
{
    protected static eUISection $section;
    protected ?iUISectionActionEnum $action = null;
    protected array $post;
    protected array $files;

    public function __construct(array $post, array $files = [])
    {
        $this->post = $post;
        $this->files = $files;
    }

    public function getTitle(): ?string
    {
        return (static::$section ?? null)?->name();
    }

    protected function getID(): ?int
    {
        $ID = $this->post['ID'] ?? null;
        return $ID == '' ? null : (int)$ID;
    }

    public abstract function refAction(): ?iUISectionActionEnum;
    protected function getHeader(): string
    {
        return $this->refAction()?->name() ?? '';
    }

    /**
     * @throws UIException
     */
    public abstract function tag(): _PageContentTag;

    /**
     * @return Executor
     * @throws AccessDeniedException|DBException|VException|UIException|UploadException|TemporaryBlockingException|RandomException
     */
    public abstract function initExecutor(): Executor;

    /**
     * @return string|null
     * @deprecated Нигде не используется?
     */
    public abstract function getCurrentID(): ?string;

    public function refURL(): URL
    {
        return new URL()
            ->setSectionAction(static::$section->value == '' ? null : static::$section->value, null);
    }

    final public function getURL(): string
    {
        return $this->refURL()->draw();
    }
}