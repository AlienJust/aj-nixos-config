<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Horizon\ProtocolBuilder\Exceptions\UIEx;
use Horizon\ProtocolBuilder\Exceptions\UIException;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_Main;

enum eUISection: string
{
    case main = '';
    case auth = 'auth';
    case protocol = 'protocol';
    case subscriber = 'subscriber';
    case command = 'command';
    case request_parameter = 'request_parameter';
    case reply_parameter = 'reply_parameter';
    case user = 'user';
    case user_group = 'user_group';
    case user_role = 'user_role';

    public function name(): string
    {
        return match ($this) {
            self::main => '',
            self::auth => 'Авторизация',
            self::protocol => 'Протоколы',
            self::subscriber => 'Абоненты',
            self::command => 'Команды',
            self::request_parameter => 'Параметры запроса',
            self::reply_parameter => 'Параметры ответа',
            self::user => 'Пользователи',
            self::user_group => 'Группы пользователей',
            self::user_role => 'Роли пользователей',
        };
    }

    /**
     * @throws UIException
     */
    public function action(string $action): ?iUISectionActionEnum
    {
        return match ($this) {
            self::main => null,
            self::auth => eUISA_Auth::tryFrom($action),
            self::protocol => eUISA_Protocol::tryFrom($action),
            self::subscriber => eUISA_Subscriber::tryFrom($action),
            self::command => eUISA_Command::tryFrom($action),
            self::request_parameter => eUISA_RequestParameter::tryFrom($action),
            self::reply_parameter => eUISA_ReplyParameter::tryFrom($action),
            self::user => eUISA_User::tryFrom($action),
            self::user_group => eUISA_UGroup::tryFrom($action),
            self::user_role => eUISA_URole::tryFrom($action),
            default => throw new UIException(UIEx::sectionNotImplemented)
        };
    }

    /**
     * @throws UIException
     */
    public function controller(string $action, array $post, array $files): ?UISection
    {
        return match ($this) {
            self::main => new UISection_Main(),
            self::auth => eUISA_Auth::tryFrom($action)->initController($post),
            self::protocol => eUISA_Protocol::tryFrom($action)->initController($post, $files),
            self::subscriber => eUISA_Subscriber::tryFrom($action)->initController($post),
            self::command => eUISA_Command::tryFrom($action)->initController($post),
            self::request_parameter => eUISA_RequestParameter::tryFrom($action)->initController($post),
            self::reply_parameter => eUISA_ReplyParameter::tryFrom($action)->initController($post),
            self::user => eUISA_User::tryFrom($action)?->initController($post),
            self::user_group => eUISA_UGroup::tryFrom($action)?->initController($post),
            self::user_role => eUISA_URole::tryFrom($action)?->initController($post),
            default => throw new UIException(UIEx::sectionNotImplemented)
        };
    }

    /**
     * @return iUISectionActionEnum[]
     */
    public function actions(): array
    {
        return array_filter (match ($this) {
            self::main => [],
            self::auth => eUISA_Auth::cases(),
            self::protocol => eUISA_Protocol::cases(),
            self::subscriber => eUISA_Subscriber::cases(),
            self::command => eUISA_Command::cases(),
            self::request_parameter => eUISA_RequestParameter::cases(),
            self::reply_parameter => eUISA_ReplyParameter::cases(),
            self::user => eUISA_User::cases(),
            self::user_group => eUISA_UGroup::cases(),
            self::user_role => eUISA_URole::cases(),
        }, fn(iUISectionActionEnum $section) => !$section->unlimitedAccess());
    }
}
