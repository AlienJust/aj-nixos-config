<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToReply;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToRequest;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_ReplyParameter;
use Horizon\ProtocolBuilder\UserInterface\eUISA_RequestParameter;
use Horizon\UserInterface\Executor;

class ExecParameterByBitsCreation extends Executor
{
    /**
     * @throws DBException
     * @throws VException
     */
    public function __construct(ParameterToRequest|ParameterToReply $parameter,
                                string $name, string $type, array $bits, bool $value_inverted, string $name_block)
    {
        $parameter->setName($name);
        $parameter->setType($type);
        $parameter->setBits($bits);
        $parameter->setValueInverted($value_inverted);
        $parameter->dbMassBitsInsert($name_block == "" ? [] : preg_split('/\r\n|\r|\n/', $name_block));
        parent::__construct(($parameter::class == ParameterToRequest::class
            ? eUISA_RequestParameter::edit
            : eUISA_ReplyParameter::edit
        )->initController()->setParameter($parameter)->getURL());
    }
}