<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\Tables;

use Horizon\ProtocolBuilder\UserInterface\PageContent\Tables\RefButtons\EditButton;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Tags\Table;
use Horizon\UserInterface\Tags\TableData;
use Horizon\UserInterface\Tags\TableHeader;
use Horizon\UserInterface\Tags\TableRow;

class URolesTable extends Table
{
    public function __construct()
    {
        parent::__construct();
        $this->add(new TableRow()->add(
            new TableHeader()->addAttribute(Attribute::width, '2rem'),
            new TableHeader('Наименование'),
            new TableHeader('Описание'),
        ));
    }

    public function addItem(string $name, string $description, ?string $edit_URL): static
    {
        $this->add(new TableRow()->add(
            new TableData()->add($edit_URL === null? null : new EditButton($edit_URL)),
            new TableData($name),
            new TableData($description),
        ));
        return $this;
    }
}