<?php

namespace Horizon\ProtocolBuilder\UserInterface\UIControllers;

use Exception;
use Horizon\Auth\AccessDeniedException;
use Horizon\Auth\DataBase\ListSources\UGroupFriendlyListSource;
use Horizon\Auth\DataBase\Tables\Group;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\DataBase\Tables\SystemDiagnosticBlock;
use Horizon\ProtocolBuilder\Exceptions\ActionAccessException;
use Horizon\ProtocolBuilder\Exceptions\DataAccessException;
use Horizon\ProtocolBuilder\Exceptions\UIEx;
use Horizon\ProtocolBuilder\Exceptions\UIException;
use Horizon\ProtocolBuilder\Exceptions\UploadException;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\LogicItems\URL;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Protocol;
use Horizon\ProtocolBuilder\UserInterface\eUISection;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecProtocolAuthorEditing;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecProtocolGroupsEditing;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecProtocolSystemDiagnosticVisibilityEditing;
use Horizon\ProtocolBuilder\UserInterface\iUISectionActionEnum;
use Horizon\ProtocolBuilder\UserInterface\PageContent\_PageContentTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ProtocolAuthorEditing;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ProtocolCreation;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ProtocolDeleting;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ProtocolEditing;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ProtocolExport;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ProtocolGroupsEditing;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ProtocolImport;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ProtocolImportParameterViews;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ProtocolInitMainXml;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ProtocolInitPsnXml;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ProtocolInitTabsXml;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ProtocolSpecification;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ProtocolSystemDiagnosticAllocating;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ProtocolSystemDiagnosticRenaming;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ProtocolSystemDiagnosticTuning;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ProtocolSystemDiagnosticVisibilityEditing;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ProtocolViewer;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ViewTags\ManualView;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecProtocolCreation;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecProtocolDeleting;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecProtocolEditing;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecProtocolImport;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecProtocolImportParameterViews;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecProtocolSystemDiagnosticAllocating;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecProtocolSystemDiagnosticRenaming;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecProtocolSystemDiagnosticTuning;
use Horizon\UserInterface\Executor;

class UISection_Protocol extends UISectionProtected
{
    protected static eUISection $section = eUISection::protocol;
    private Protocol $protocol;
    public function __construct(eUISA_Protocol $action, array $post = [], array $files = [])
    {
        parent::__construct($post, $files);
        $this->action = $action;
    }

    public function setProtocol(Protocol $protocol): static
    {
        $this->protocol = $protocol;
        return $this;
    }

    /**
     * @throws DBException
     */
    public function refProtocol(): Protocol
    {
        return $this->protocol ?? ($this->protocol = Protocol::dbLoad($this->getID()));
    }

    public function refAction(): ?eUISA_Protocol
    {
        return $this->action;
    }

    public function verifyAccessByData(): void
    {
        match ($this->action) {
            eUISA_Protocol::manual,
            eUISA_Protocol::new,
            eUISA_Protocol::import => null,
            eUISA_Protocol::edit_author,
            eUISA_Protocol::delete,
            eUISA_Protocol::groups_editing,
            eUISA_Protocol::import_param_views => $this->refProtocol()->checkAuthor() ? null : throw new ActionAccessException(),
            default => $this->refProtocol()->verifyAccess()
        };
    }

    /**
     * @throws UIException
     * @throws DBException
     * @throws VException
     */
    public function tag(): _PageContentTag
    {
        return match ($this->action) {
            null => '',
            eUISA_Protocol::view => new ProtocolViewer($this->refAction()->name(),
                $this->refProtocol()->GUID,
                $this->refProtocol()->name,
                $this->refProtocol()->version,
                $this->refProtocol()->description,
                Group::dbLoad($this->refProtocol()->author)->name,
            )->addActionBlock(new ProtocolExport(
                eUISA_Protocol::specification->initController()->setProtocol($this->refProtocol())
            )),
            eUISA_Protocol::new => new ProtocolCreation(
                $this->refAction()->name(),
                $this->getURL(),
                $this->refProtocol()->GUID,
                '', '', '', 0
            ),
            eUISA_Protocol::import => new ProtocolImport(
                $this->refAction()->name(),
                $this->getURL()
            ),
            eUISA_Protocol::edit => new ProtocolEditing(
                $this->refAction()->name(),
                $this->getURL(),
                $this->refProtocol()->GUID,
                $this->refProtocol()->name,
                $this->refProtocol()->version,
                $this->refProtocol()->description,
            )->addActionBlock($this->protocolAuthorEditingTag()
            )->addActionBlock(new ProtocolExport(
                eUISA_Protocol::init_psn_xml->initController()->setProtocol($this->refProtocol()),
                eUISA_Protocol::init_tabs_xml->initController()->setProtocol($this->refProtocol()),
                eUISA_Protocol::init_main_xaml->initController()->setProtocol($this->refProtocol())
            ))->addActionBlock($this->protocolDeletingTag()),
            //eUISA_Protocol::delete => throw new \Exception('To be implemented'),
            eUISA_Protocol::init_psn_xml => new ProtocolInitPsnXml($this->refAction()->name(), $this->refProtocol()),
            eUISA_Protocol::init_tabs_xml => new ProtocolInitTabsXml($this->refAction()->name(), $this->refProtocol()),
            eUISA_Protocol::init_main_xaml => new ProtocolInitMainXml($this->refAction()->name(), $this->refProtocol()),
            eUISA_Protocol::specification => new ProtocolSpecification($this->refAction()->name(), $this->refProtocol()),
            eUISA_Protocol::import_param_views => new ProtocolImportParameterViews(
                $this->refAction()->name(),
                $this->getURL()
            ),
            eUISA_Protocol::system_diagnostic_tuning => $this->protocolSystemDiagnosticTuningTag(),
            eUISA_Protocol::system_diagnostic_renaming => $this->protocolSystemDiagnosticRenamingTag(),
            eUISA_Protocol::system_diagnostic_visibility_editing => $this->protocolSystemDiagnosticVisibilityEditingTag(),
            eUISA_Protocol::manual => new ManualView('data/private/manual.md'),
            eUISA_Protocol::groups_editing => $this->groupsEditingTag(),
            default => throw new UIException(UIEx::actionNotImplemented)
        };
    }

    /**
     * @throws DBException
     */
    private function protocolDeletingTag(): ?_PageContentTag
    {
        $ctrl = eUISA_Protocol::delete->initController()->setProtocol($this->refProtocol());
        try {
            $ctrl->verifyAccess();
            $ctrl->verifyAccessByData();
            return new ProtocolDeleting(
                $this->refProtocol()->GUID,
                $ctrl->getURL()
            );
        } catch (Exception){
            return null;
        }
    }

    /**
     * @throws DBException
     */
    private function protocolAuthorEditingTag(): ?_PageContentTag
    {
        $ctrl = eUISA_Protocol::edit_author->initController()->setProtocol($this->refProtocol());
        try {
            $ctrl->verifyAccess();
            $ctrl->verifyAccessByData();
            return new ProtocolAuthorEditing(
                $ctrl->refAction()->name(),
                $ctrl->getURL(),
                $this->refProtocol()->author
            );
        } catch (Exception){
            return null;
        }
    }

    /**
     * @throws DBException
     * @throws VException
     */
    private function protocolSystemDiagnosticTuningTag(): ProtocolSystemDiagnosticAllocating
    {
        $alloc_form = new ProtocolSystemDiagnosticAllocating(
            eUISA_Protocol::system_diagnostic_allocating->value,
            eUISA_Protocol::system_diagnostic_allocating->name(),
            eUISA_Protocol::system_diagnostic_allocating->initController()->setProtocol($this->protocol)->getURL()
        );
        $block = SystemDiagnosticBlock::dbLoad(null, $this->refProtocol()->getID());
        foreach ($block->arrChunksWithNameForColumn(0) as $chunk)
            $alloc_form->addChunk($chunk->code, $chunk->getLabel(), $chunk->getURL());
        foreach ($block->arrVirtualChunksForColumn(0) as $chunk)
            $alloc_form->addVirtualChunk($chunk->getCode());
        foreach ($block->arrAggregateChunksForColumn(0) as $chunk)
            $alloc_form->addAggregateChunk($chunk->getID(), $chunk->getLabel(), $chunk->getParamCount());
        foreach ($this->refProtocol()->arrBlocks() as $block) {
            $alloc_form->addBlock($block->getID(), $block->getSort(), $block->getName());
            foreach (range(0, $block->getColumnsCount() - 1) as $column_id) {
                $alloc_form->addColumn($column_id);
                $chunks = [];
                $virtual_chunks = [];
                $aggregate_chunks = [];
                foreach ($block->arrChunksWithNameForColumn($column_id) as $chunk) {
                    $chunks[$chunk->getRowId()] = $chunk;
                }
                foreach ($block->arrVirtualChunksForColumn($column_id) as $chunk) {
                    $virtual_chunks[$chunk->getRowId()] = $chunk;
                }
                foreach ($block->arrAggregateChunksForColumn($column_id) as $chunk) {
                    $aggregate_chunks[$chunk->getRowId()] = $chunk;
                }
                $rows = array_merge(array_keys($chunks), array_keys($virtual_chunks), array_keys($aggregate_chunks));
                sort($rows);
                if (count($rows) > 0) {
                    $max_row = max($rows);
                    for ($i = 0; $i <= $max_row; $i++) {
                        if (isset($chunks[$i])) $alloc_form->addChunk($chunks[$i]->code, $chunks[$i]->getLabel(), $chunks[$i]->getURL());
                        elseif (isset($virtual_chunks[$i])) $alloc_form->addVirtualChunk($virtual_chunks[$i]->getCode());
                        elseif (isset($aggregate_chunks[$i])) $alloc_form->addAggregateChunk(
                            $aggregate_chunks[$i]->getID(),
                            $aggregate_chunks[$i]->getLabel(),
                            $aggregate_chunks[$i]->getParamCount()
                        );
                        else $alloc_form->addEmptyRow();
                    }
                }
            }
        }

        $tag = new ProtocolSystemDiagnosticTuning(
            $this->refAction()->name(),
            $this->getURL()
        );
        foreach ($this->refProtocol()->arrSubscribers() as $subscriber)
            foreach ($subscriber->arrCommands() as $command)
                $tag->addCommandName($subscriber->getName() .' – '. $command->getName(),
                    $command->arrParameterViewsToRequest(),
                    $command->arrParameterViewsToReply()
                );
        foreach ($this->refProtocol()->arrBlocks() as $block)
            $tag->addBlock($block->getID(), $block->getName(), $block->getColumnsCount(), $block->isInline(), $block->isHideForProduction());
        foreach ($this->refProtocol()->arrVirtualParameters() as $virtual_parameter)
            $tag->addVirtualParameter($virtual_parameter->getCode());
        foreach ($this->refProtocol()->arrAggregateGroups() as $group) {
            $tag->addAggregateGroup($group->getID(), $group->getLabel());
            foreach($group->arrParameters() as $parameter) $tag->addAggregateParameter($parameter->getCode());
        }

        $alloc_form->addActionBlock($tag);
        return $alloc_form;
    }

    /**
     * @throws DBException
     * @throws VException
     */
    private function protocolSystemDiagnosticRenamingTag(): ProtocolSystemDiagnosticRenaming
    {
        $tag = new ProtocolSystemDiagnosticRenaming(
            $this->refAction()->value,
            $this->refAction()->name(),
            $this->getURL()
        );
        foreach ($this->refProtocol()->arrBlocks() as $block) {
            $tag->addBlock($block->getSort(), $block->getName());
            foreach (range(0, $block->getColumnsCount()-1) as $column_id) {
                $tag->addColumn();
                foreach($block->arrChunksWithNameForColumn($column_id) as $chunk)
                    $tag->addChunk($chunk->code, $chunk->getAddress(), $chunk->name, $chunk->custom_name, $chunk->getURL());
            }
        }
        return $tag;
    }

    /**
     * @throws DBException
     */
    private function protocolSystemDiagnosticVisibilityEditingTag(): ProtocolSystemDiagnosticVisibilityEditing
    {
        $tag = new ProtocolSystemDiagnosticVisibilityEditing(
            $this->refAction()->value,
            $this->refAction()->name(),
            $this->getURL()
        );
        foreach ($this->refProtocol()->arrBlocks() as $block) {
            $tag->addBlock($block->getSort(), $block->getName());
            foreach (range(0, $block->getColumnsCount()-1) as $column_id) {
                $tag->addColumn();
                foreach($block->arrChunksWithVisibilityControllerForColumn($column_id) as $chunk)
                    $tag->addChunk($chunk->type, $chunk->chunk_id, $chunk->getAddress(), $chunk->name, $chunk->visibility_converter);
            }
        }
        return $tag;
    }

    /**
     * @throws DBException
     */
    private function groupsEditingTag(): ProtocolGroupsEditing
    {
        $tag = new ProtocolGroupsEditing($this->refAction()->name(), $this->getURL());
        $groups = new UGroupFriendlyListSource(1, 3000, null)->loadData();
        $protocol_groups = $this->refProtocol()->arrGroups();
        foreach ($groups as $group) $tag
            ->addGroup(
                $group->getID(),
                $group->name,
                in_array($group->getID(), $protocol_groups) || $group->getID() == $this->refProtocol()->author,
                $group->getLevel(),
                $group->getID() == $this->refProtocol()->author
            );
        return $tag;
    }

    /**
     * @throws DBException|VException|UIException|UploadException
     */
    public function initExecutor(): Executor
    {
        return match ($this->action) {
            eUISA_Protocol::new => new ExecProtocolCreation($this->refProtocol(),
                eProtocolField::name->get($this->post),
                eProtocolField::description->get($this->post),
                eProtocolField::version->get($this->post),
                eProtocolField::GUID->get($this->post),
                eProtocolField::author->get($this->post)),
            eUISA_Protocol::edit => new ExecProtocolEditing($this->refProtocol(),
                eProtocolField::name->get($this->post),
                eProtocolField::description->get($this->post),
                eProtocolField::version->get($this->post),
                eProtocolField::GUID->get($this->post)),
            eUISA_Protocol::edit_author => new ExecProtocolAuthorEditing($this->refProtocol(),
                eProtocolField::author->get($this->post)),
            eUISA_Protocol::delete => new ExecProtocolDeleting($this->refProtocol()),
            eUISA_Protocol::import => new ExecProtocolImport(
                eProtocolField::psn_file->get($this->files),
                eProtocolField::author->get($this->post)
            ),
            eUISA_Protocol::import_param_views => new ExecProtocolImportParameterViews($this->refProtocol(),
                eProtocolField::tabs_file->get($this->files)
            ),
            eUISA_Protocol::system_diagnostic_tuning => new ExecProtocolSystemDiagnosticTuning($this->refProtocol(),
                eProtocolField::parameter_views->get($this->post),
                eProtocolField::blocks->get($this->post),
                eProtocolField::virtual_parameters->get($this->post),
                eProtocolField::aggregate_groups->get($this->post),
            ),
            eUISA_Protocol::system_diagnostic_allocating => new ExecProtocolSystemDiagnosticAllocating(
                $this->refProtocol(),
                eProtocolField::diagnostic_list->get($this->post)
            ),
            eUISA_Protocol::system_diagnostic_renaming => new ExecProtocolSystemDiagnosticRenaming(
                $this->refProtocol(),
                eProtocolField::parameter_view->get($this->post)
            ),
            eUISA_Protocol::system_diagnostic_visibility_editing => new ExecProtocolSystemDiagnosticVisibilityEditing(
                $this->refProtocol(),
                eProtocolField::parameter_view->get($this->post)
            ),
            eUISA_Protocol::groups_editing => new ExecProtocolGroupsEditing($this->refProtocol(),
                eProtocolField::groups->get($this->post)
            ),
            default => throw new UIException(UIEx::actionNotImplemented)
        };
    }

    /**
     * @throws DBException
     */
    public function getCurrentID(): ?string
    {
        return $this->refProtocol()->getID();
    }

    /**
     * @throws DBException
     */
    public function refURL(): URL
    {
        return new URL()
            ->setSectionAction(static::$section->value, $this->action?->value)
            ->setProtocol(
                $this->refProtocol()->getID()
            );
    }

    /**
     * @throws DBException
     */
    public static function initWithAction(eUISA_Protocol|iUISectionActionEnum|null $action): ?static
    {
        $order = eUISA_Protocol::actionOrder();
        $controller = !is_null($action)
            ? $action->initController()
            : eUISA_Protocol::tryFrom($action?->value)?->initController();
        if ($controller !== null) try {
            $controller->verifyAccess();
            return $controller;
        } catch (AccessDeniedException|ActionAccessException|DataAccessException) {
            return static::initDefault($order);
        } else return static::initDefault($order);
    }
}