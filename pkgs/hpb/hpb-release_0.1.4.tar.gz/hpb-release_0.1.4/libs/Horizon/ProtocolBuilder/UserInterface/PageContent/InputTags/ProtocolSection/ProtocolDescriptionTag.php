<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Controls\InputText;

class ProtocolDescriptionTag extends InputText
{
    public function __construct(string $value)
    {
        $field = eProtocolField::description;
        parent::__construct($field->code(), $value, $field->label(), $field->title(), true);
    }
}