<?php

namespace Horizon\ProtocolBuilder\UserInterface\UIControllers;

use Horizon\Auth\AccessDeniedEx;
use Horizon\Auth\AccessDeniedException;
use Horizon\Auth\DataBase\Tables\User;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\Exceptions\ActionAccessException;
use Horizon\ProtocolBuilder\Exceptions\DataAccessException;
use Horizon\ProtocolBuilder\UserInterface\iUISectionActionEnum;

abstract class UISectionProtected extends UISection
{
    /**
     * @throws ActionAccessException
     * @throws DataAccessException
     * @throws DBException
     * @throws AccessDeniedException
     */
    public function verifyAccess(): void
    {
        $user = User::current();
        if ($user === null) throw new AccessDeniedException(AccessDeniedEx::fail);
        $user->verifyActionAccess(static::$section->name, $this->action->code());
    }

    /**
     * @throws ActionAccessException
     * @throws DBException
     * @throws DataAccessException
     */
    public function verifyAccessByData(): void
    {

    }

    /**
     * @param iUISectionActionEnum[] $order
     * @throws DBException
     */
    final protected static function initDefault(array $order): ?static
    {
        foreach ($order as $item) try {
            $controller = $item->initController();
            $controller->verifyAccess();
            return $controller;
        } catch (AccessDeniedException|ActionAccessException|DataAccessException) {}
        return null;
    }
    abstract public static function initWithAction(iUISectionActionEnum|null $action): ?static;
}