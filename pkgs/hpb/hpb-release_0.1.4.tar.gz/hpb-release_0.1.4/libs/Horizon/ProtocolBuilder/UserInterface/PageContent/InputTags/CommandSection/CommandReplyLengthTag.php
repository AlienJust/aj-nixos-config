<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCommandField;
use Horizon\UserInterface\Controls\InputNumber;

class CommandReplyLengthTag extends InputNumber
{
    public function __construct(string $value)
    {
        $field = eCommandField::reply_length;
        parent::__construct($field->code(), $value, $field->label(), $field->title(), true);
    }
}