<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

class URoleDeleting extends _Deleting
{
    public function __construct(string $name, string $action_URL)
    {
        parent::__construct('роли', 'роль', $name, $action_URL);
    }
}