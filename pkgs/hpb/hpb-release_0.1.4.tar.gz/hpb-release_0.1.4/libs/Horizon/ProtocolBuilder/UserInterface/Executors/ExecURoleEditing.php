<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\Auth\DataBase\Tables\Role;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_URole;
use Horizon\UserInterface\Executor;

class ExecURoleEditing extends Executor
{
    /**
     * @throws DBException
     */
    public function __construct(Role $role, string $name, array $actions)
    {
        $role->name = $name;
        $role->actions = $actions;
        $role->dbUpdate();
        parent::__construct(eUISA_URole::main->initController()->setRole($role)->getURL());
    }
}