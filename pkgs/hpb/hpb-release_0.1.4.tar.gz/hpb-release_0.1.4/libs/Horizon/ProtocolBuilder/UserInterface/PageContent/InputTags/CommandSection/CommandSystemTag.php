<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCommandField;
use Horizon\UserInterface\Controls\CheckboxBool;

class CommandSystemTag extends CheckboxBool
{
    public function __construct(bool $value)
    {
        $field = eCommandField::system;
        parent::__construct($field->code(), $value, $field->label(), $field->title());
    }
}