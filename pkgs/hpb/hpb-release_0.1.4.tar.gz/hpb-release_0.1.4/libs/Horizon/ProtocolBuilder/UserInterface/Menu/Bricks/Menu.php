<?php

namespace Horizon\ProtocolBuilder\UserInterface\Menu\Bricks;

use Exception;
use Horizon\ProtocolBuilder\UserInterface\iUISectionActionEnum;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISectionProtected;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Tags\Division;

class Menu extends Division
{
    public function __construct(string $id)
    {
        parent::__construct();
        $this->addClass('sidebar');
        $this->addAttribute(Attribute::id, $id);
    }

    public function addBlock(MenuBlock $block): static
    {
        $this->add($block);
        return $this;
    }

    public function setCurrent(bool $is_current): static
    {
        $this->addClassIf('current', $is_current);
        return $this;
    }

    protected function initMenuAction(UISectionProtected $ctrl, ?iUISectionActionEnum $action): ?MenuAction
    {
        try {
            $ctrl->verifyAccess();
            return new MenuAction($ctrl, $action);
        } catch (Exception) {
            return null;
        }
    }
    protected function initMenuItem(?UISectionProtected $controller, string $text, bool $is_current): MenuItem|MenuText
    {
        return $controller === null
            ? new MenuText($text)
            : new MenuItem(
                $controller,
                $text,
                $is_current
            );
    }
}