<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\Command;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Command;
use Horizon\UserInterface\Executor;

class ExecCommandEditing extends Executor
{
    /**
     * @throws DBException
     */
    public function __construct(Command $command, string $name, int $parameter_length, int $request_length, int $reply_length,
                                int $request_header_length, int $reply_header_length, bool $system,
                                ?float $cycle_ms_time)
    {
        $request_required = $reply_header_length == $request_header_length && $reply_length == $request_length;
        $command->setName($name)->setSystem($system)->setParameterLength($parameter_length);
        $command->setRequest($request_length, 0, $request_header_length, $cycle_ms_time);
        $command->setReply($reply_length, $request_length, $reply_header_length, $request_required);
        $command->dbUpdate();
        parent::__construct(eUISA_Command::edit->initController()->setCommand($command)->getURL());
    }
}