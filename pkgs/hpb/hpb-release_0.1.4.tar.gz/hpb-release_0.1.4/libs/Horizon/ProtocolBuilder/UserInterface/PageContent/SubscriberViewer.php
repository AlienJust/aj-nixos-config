<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eSubscriberField;
use Horizon\UserInterface\PresetTags\ValueView;

class SubscriberViewer extends _PageContentTag
{
    public function __construct(string $header, int $address, string $name, string $sort_name, string $description, bool $hide_to_production)
    {
        parent::__construct($header);
        $this->add(
            new ValueView(eSubscriberField::address->label(), $address),
            new ValueView(eSubscriberField::name->label(), $name),
            new ValueView(eSubscriberField::short_name->label(), $sort_name),
            new ValueView(eSubscriberField::description->label(), $description),
            new ValueView(eSubscriberField::hide_for_production->label(), $hide_to_production ? 'Да' : 'Нет'),
        );
    }
}