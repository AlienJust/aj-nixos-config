<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputText;

class ProtocolGUIDTag extends InputText
{
    public function __construct(string $value)
    {
        $field = eProtocolField::GUID;
        parent::__construct($field->code(), $value, $field->label(), $field->title(), true);
        //$this->addAttribute(Attribute::readonly, true);
    }
}