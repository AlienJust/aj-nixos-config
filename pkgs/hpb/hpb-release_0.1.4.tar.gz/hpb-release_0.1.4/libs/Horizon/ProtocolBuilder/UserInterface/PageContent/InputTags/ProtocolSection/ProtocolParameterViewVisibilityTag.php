<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\Data\eParameterViewVisibility;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Controls\Components\Option;
use Horizon\UserInterface\Controls\InputSelect;

class ProtocolParameterViewVisibilityTag extends InputSelect
{
    public function __construct(string $type, string $code, string $value)
    {
        parent::__construct(eProtocolField::parameter_view_visibility->code($type, $code), $value,
            eProtocolField::parameter_view_visibility->label(),
            eProtocolField::parameter_view_visibility->title(), true);
        $this->addOptions(true, ...Option::initFromStringBackedEnumCasesByOrder(eParameterViewVisibility::cases()));
    }
}