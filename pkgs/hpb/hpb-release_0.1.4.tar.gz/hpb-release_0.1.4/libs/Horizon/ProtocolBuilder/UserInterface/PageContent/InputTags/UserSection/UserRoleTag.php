<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\UserSection;

use Horizon\Auth\DataBase\PickSources\URolePick;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eUserField;
use Horizon\UserInterface\Controls\InputSelect;

class UserRoleTag extends InputSelect
{
    /**
     * @throws DBException
     */
    public function __construct(array|string $value)
    {
        parent::__construct(eUserField::role->code(), $value, 'Роль пользователя',
            'Выберите роль, которая определит уровень доступа к функционалу системы', true);
        $this->addOptions(true, ...new URolePick()->init());
    }
}