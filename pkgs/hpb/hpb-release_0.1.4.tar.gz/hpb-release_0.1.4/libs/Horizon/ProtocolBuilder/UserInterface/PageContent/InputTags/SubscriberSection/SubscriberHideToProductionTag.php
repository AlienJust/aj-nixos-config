<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\SubscriberSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eSubscriberField;
use Horizon\UserInterface\Controls\CheckboxBool;

class SubscriberHideToProductionTag extends CheckboxBool
{
    public function __construct(bool $value)
    {
        $field = eSubscriberField::hide_for_production;
        parent::__construct($field->code(), $value, $field->label(), $field->title());
    }
}