<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\Auth\DataBase\Tables\Role;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_URole;
use Horizon\UserInterface\Executor;

class ExecURoleCreation extends Executor
{
    /**
     * @throws DBException
     */
    public function __construct(Role $role, string $name)
    {
        $role->name = $name;
        $role->dbInsert();
        parent::__construct(eUISA_URole::main->initController()->setRole($role)->getURL());
    }
}