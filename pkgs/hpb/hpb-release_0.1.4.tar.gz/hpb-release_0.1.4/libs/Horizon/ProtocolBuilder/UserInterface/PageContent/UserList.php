<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\PageContent\Tables\UsersTable;

class UserList extends _PageContentTag
{
    private UsersTable $users;
    public function __construct(?string $header = null)
    {
        parent::__construct($header);
        $this->users = new UsersTable();
        $this->add($this->users);
    }

    public function addItem(string $SNP, string $username, string $role, string $groups, bool $ban, ?string $edit_URL): static
    {
        $this->users->addItem($SNP, $username, $role, $groups, $ban, $edit_URL);
        return $this;
    }
}