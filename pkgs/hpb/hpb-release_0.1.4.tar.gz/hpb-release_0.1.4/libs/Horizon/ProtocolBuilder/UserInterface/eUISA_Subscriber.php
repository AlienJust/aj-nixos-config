<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_Subscriber;

enum eUISA_Subscriber: string implements iUISectionActionEnum
{
    case view = 'view';
    case new = 'new';
    case edit = 'edit';
    case delete = 'delete';

    public function code(): string
    {
        return $this->name;
    }

    public function name(): string
    {
        return match ($this) {
            self::view => 'Просмотр абонента',
            self::new => 'Создание абонента',
            self::edit => 'Изменение абонента',
            self::delete => 'Удаление абонента',
        };
    }

    public function buttonName(): string
    {
        return match ($this) {
            self::view => 'Обзор',
            self::new => '+ абонент',
            self::edit => 'Изменить',
            self::delete => 'Удалить',
        };
    }

    public static function controlPanel(): array
    {
        return [
            self::view,
            self::edit,
        ];
    }
    
    public static function actionOrder(): array
    {
        return [
            self::edit,
            self::view,
        ];
    }

    public function initController(array $post = []): UISection_Subscriber
    {
        return new UISection_Subscriber($this, $post);
    }

    public function unlimitedAccess(): bool
    {
        return false;
    }
}