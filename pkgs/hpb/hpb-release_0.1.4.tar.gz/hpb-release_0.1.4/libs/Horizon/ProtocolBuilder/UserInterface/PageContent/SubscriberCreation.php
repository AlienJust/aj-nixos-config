<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\SubscriberSection\SubscriberAddressTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\SubscriberSection\SubscriberDescriptionTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\SubscriberSection\SubscriberHideToProductionTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\SubscriberSection\SubscriberNameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\SubscriberSection\SubscriberShortNameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\CreationButton;

class SubscriberCreation extends _PageContentTag
{
    public function __construct(string $header, string $action_URL, int $address, string $name, string $short_name, string $description, bool $hide_to_production)
    {
        parent::__construct($header);
        $this->add(new MainForm($action_URL)
            ->add(new SubscriberNameTag($name))
            ->add(new SubscriberShortNameTag($short_name))
            ->add(new SubscriberAddressTag($address))
            ->add(new SubscriberDescriptionTag($description))
            ->add(new SubscriberHideToProductionTag($hide_to_production))
            ->add(new CreationButton()));
    }
}