<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\ExportFiles\Specification;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Tags\Division;

class ProtocolSpecification extends _PageContentTag
{
    /**
     * @throws DBException
     */
    public function __construct(string $header, Protocol $protocol)
    {
        parent::__construct($header);
        $this->add(new Division()->addClass('copy')
            ->addAttribute(Attribute::onclick, "document.execCommand('copy');")
            ->add(new Specification($protocol)->content()));
    }
}