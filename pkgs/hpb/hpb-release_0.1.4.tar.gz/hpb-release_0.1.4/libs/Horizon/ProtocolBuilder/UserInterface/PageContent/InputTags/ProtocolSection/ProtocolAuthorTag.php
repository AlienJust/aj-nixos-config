<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Controls\InputSelect;

class ProtocolAuthorTag extends InputSelect
{
    public function __construct(string $value)
    {
        $field = eProtocolField::author;
        parent::__construct($field->code(), $value, $field->label(), $field->title(), true);
    }
}