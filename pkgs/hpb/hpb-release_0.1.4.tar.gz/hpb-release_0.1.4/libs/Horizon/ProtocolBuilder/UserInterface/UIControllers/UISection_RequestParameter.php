<?php

namespace Horizon\ProtocolBuilder\UserInterface\UIControllers;

use Horizon\Auth\AccessDeniedException;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\Data\eParameterType;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToRequest;
use Horizon\ProtocolBuilder\Exceptions\ActionAccessException;
use Horizon\ProtocolBuilder\Exceptions\DataAccessException;
use Horizon\ProtocolBuilder\Exceptions\UIEx;
use Horizon\ProtocolBuilder\Exceptions\UIException;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\LogicItems\MultiViewExpression;
use Horizon\ProtocolBuilder\LogicItems\URL;
use Horizon\ProtocolBuilder\UserInterface\eUISA_RequestParameter;
use Horizon\ProtocolBuilder\UserInterface\eUISection;
use Horizon\ProtocolBuilder\UserInterface\iUISectionActionEnum;
use Horizon\ProtocolBuilder\UserInterface\PageContent\_PageContentTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ParameterByBitsCreation;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ParameterByDefaultValueCreation;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ParameterByVariableCreation;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ParameterCreation;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ParameterDeleting;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ParameterEditing;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ParameterViewCreation;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ParameterViewEditing;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecParameterByBitsCreation;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecParameterCreation;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecParameterDeleting;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecParameterEditing;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecParameterViewCreation;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecParameterViewDeleting;
use Horizon\ProtocolBuilder\UserInterface\Executors\ExecParameterViewEditing;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ParameterViewer;
use Horizon\UserInterface\HTMLException;
use Horizon\UserInterface\Executor;

class UISection_RequestParameter extends UISectionProtected
{
    protected static eUISection $section = eUISection::request_parameter;
    private ParameterToRequest $parameter;

    public function __construct(eUISA_RequestParameter $action, array $post = [])
    {
        parent::__construct($post);
        $this->action = $action;
    }

    public function setParameter(ParameterToRequest $parameter): static
    {
        $this->parameter = $parameter;
        return $this;
    }

    public function refParameter(): ParameterToRequest
    {
        return $this->parameter;
    }

    public function refAction(): ?eUISA_RequestParameter
    {
        return $this->action;
    }

    public function verifyAccessByData(): void
    {
        $this->refParameter()->refCommand()->refSubscriber()->refProtocol()->verifyAccess();
    }

    /**
     * @throws DBException
     * @throws UIException|HTMLException
     */
    public function tag(): _PageContentTag
    {
        return match ($this->action) {
            eUISA_RequestParameter::view => new ParameterViewer($this->refAction()->name(),
                $this->refParameter()->getGUID(),
                $this->refParameter()->getName(),
                $this->refParameter()->getDescription(),
                $this->refParameter()->getType(),
                $this->refParameter()->getValue(),
                $this->refParameter()->getValueConversionFormula(),
                $this->refParameter()->getLowestDigitPrice(),
                $this->refParameter()->isSigned(),
                $this->refParameter()->isValueInverted(),
                $this->refParameter()->getBits(),
                $this->refParameter()->getByteOrder(),
                $this->refParameter()->refCommand()->refReply()->getLength(),
                $this->refParameter()->refAddress(),
            ),
            eUISA_RequestParameter::new => new ParameterCreation($this->refAction()->name(),
                $this->getURL(),
                $this->refParameter()->getGUID(),
                $this->refParameter()->getName(),
                $this->refParameter()->getValueConversionFormula(),
                $this->refParameter()->getLowestDigitPrice(),
                true,
                $this->refParameter()->getBits(),
                $this->refParameter()->refCommand()->refRequest()->getLength(),
                $this->refParameter()->refCommand()->refRequest()->getUnavailableBits()), // А надо ли? Бывает, что на один и тех же битов есть битовые и обычные параметры
            eUISA_RequestParameter::new_bits => new ParameterByBitsCreation($this->refAction()->name(),
                $this->getURL(),
                $this->refParameter()->getName(),
                false,
                $this->refParameter()->getBits(),
                $this->refParameter()->refCommand()->refRequest()->getLength(),
                $this->refParameter()->refCommand()->refRequest()->getUnavailableBits()),
            eUISA_RequestParameter::new_default_value => new ParameterByDefaultValueCreation($this->refAction()->name(),
                $this->getURL(),
                $this->refParameter()->getGUID(),
                '',
                $this->refParameter()->getName(),
                $this->refParameter()->getBits(),
                $this->refParameter()->refCommand()->refRequest()->getLength(),
                $this->refParameter()->refCommand()->refRequest()->getUnavailableBits()),
            eUISA_RequestParameter::new_variable => new ParameterByVariableCreation($this->refAction()->name(),
                $this->getURL(),
                $this->refParameter()->getGUID(),
                $this->refParameter()->getName(),
                $this->refParameter()->getBits(),
                $this->refParameter()->refCommand()->refRequest()->getLength(),
                $this->refParameter()->refCommand()->refRequest()->getUnavailableBits()),
            eUISA_RequestParameter::edit => new ParameterEditing($this->refAction()->name(), $this->getURL(),
                $this->refParameter()->getGUID(),
                $this->refParameter()->getName(),
                $this->refParameter()->getDescription(),
                $this->refParameter()->getType(),
                $this->refParameter()->getValue(),
                $this->refParameter()->getValueConversionFormula(),
                $this->refParameter()->getLowestDigitPrice(),
                $this->refParameter()->isSigned(),
                $this->refParameter()->isValueInverted(),
                $this->refParameter()->getBits(),
                $this->refParameter()->getByteOrder(),
                $this->refParameter()->refCommand()->refRequest()->getLength(),
                $this->refParameter()->refAddress(),
            )->addActionBlock(new ParameterDeleting($this->refParameter()->getGUID(),
                eUISA_RequestParameter::delete->initController()->setParameter($this->refParameter())->getURL())),
            eUISA_RequestParameter::delete => throw new \Exception('To be implemented'),
            eUISA_RequestParameter::new_view => $this->parameterViewTuning(),
            default => throw new UIException(UIEx::actionNotImplemented)
        };
    }

    /**
     * @throws DBException
     * @throws HTMLException
     */
    private function parameterViewTuning(): ParameterViewCreation
    {
        $tag = new ParameterViewCreation($this->refAction()->name(), $this->getURL(),
            $this->refParameter()->initCodeForView(),
            $this->refParameter()->initCommentForView(),
            $this->refParameter()->getType(),
            $this->refParameter()->refAddress()->word_number
        );
        $tag->addActionBlock($editing_page = new ParameterViewEditing(
            eUISA_RequestParameter::edit_view->value,
            eUISA_RequestParameter::edit_view->name(),
            eUISA_RequestParameter::edit_view->initController()->setParameter($this->parameter)->getURL(),
            eUISA_RequestParameter::delete_view->initController()->setParameter($this->parameter)->getURL()
        ));
        foreach ($this->refParameter()->arrViews() as $view) {
            $injection = $view->refInjection();
            $editing_page->addView(
                $view->getCode(), $view->getComment(), $view->getCustomName(), $view->getFormat(), $view->getMask(),
                new MultiViewExpression($view->getMask(), !is_null($view->getFormat()), $view->countViewValues(), 0)->value,
                $injection?->getParamNumberInPackage() ?? $this->refParameter()->refAddress()->word_number,
                $injection?->getConvertExpression(), $injection?->isInvertBytesOrder(),
                $injection?->getMinValue(), $injection?->getMaxValue(), $injection?->getIntervalValue(),
                $view->isLinkToSystemDiagnostic()
            );
            foreach ($view->arrViewValues() as $value) $editing_page
                ->addViewValue($value->getExpression(), $value->getResultTrue(), $value->getResultFalse(), $value->getColor());
            foreach ($view->arrViewNumbers() as $number) $editing_page
                ->addViewNumber($number->getExpression(), $number->getFormat(), $number->getColor());
            foreach ($injection?->arrInjectValues() ?? [] as $value) $editing_page
                ->addInjectionValue($value->getValue(), $value->getText());
        }
        return $tag;
    }

    /**
     * @throws DBException
     * @throws VException
     * @throws UIException
     */
    public function initExecutor(): Executor
    {
        return match ($this->action) {
            eUISA_RequestParameter::new => new ExecParameterCreation($this->refParameter(),
                eParameterField::name->get($this->post),
                eParameterField::type->get($this->post),
                eParameterField::bits->get($this->post),
                null,
                eParameterField::byte_order->get($this->post),
                eParameterField::value_conversion_formula->get($this->post),
                eParameterField::lowest_digit_price->get($this->post),
                eParameterField::signed->get($this->post),
            ),
            eUISA_RequestParameter::new_bits => new ExecParameterByBitsCreation($this->refParameter(),
                eParameterField::name->get($this->post),
                eParameterType::BitPrm->value,
                eParameterField::bits->get($this->post),
                eParameterField::value_inverted->get($this->post),
                eParameterField::value_name_block->get($this->post),
            ),
            eUISA_RequestParameter::new_default_value => new ExecParameterCreation($this->refParameter(),
                eParameterField::name->get($this->post),
                eParameterType::DefVal->value,
                eParameterField::bits->get($this->post),
                eParameterField::value->get($this->post),
            ),
            eUISA_RequestParameter::new_variable => new ExecParameterCreation($this->refParameter(),
                eParameterField::name->get($this->post),
                eParameterType::VarVal->value,
                eParameterField::bits->get($this->post),
            ),
            eUISA_RequestParameter::edit => new ExecParameterEditing($this->refParameter(),
                eParameterField::name->get($this->post),
                $this->refParameter()->getType(),
                eParameterField::value_conversion_formula->get($this->post),
                eParameterField::lowest_digit_price->get($this->post) ?? $this->refParameter()->getLowestDigitPrice(),
                eParameterField::signed->get($this->post) ?? $this->refParameter()->isSigned(),
                eParameterField::value_inverted->get($this->post) ?? $this->refParameter()->isValueInverted(),
                eParameterField::bits->get($this->post),
                eParameterField::byte_order->get($this->post),
                eParameterField::value->get($this->post),
                eParameterField::description->get($this->post),
            ),
            eUISA_RequestParameter::new_view => new ExecParameterViewCreation($this->refParameter(),
                eParameterField::view_new_code->get($this->post),
                eParameterField::view_comment->get($this->post),
                eParameterField::view_custom_name->get($this->post),
                eParameterField::view_format->get($this->post),
                eParameterField::view_mask->get($this->post),
                eParameterField::view_values->get($this->post),
                eParameterField::view_numbers->get($this->post),
                eParameterField::injection_on->get($this->post),
                eParameterField::injection_number->get($this->post),
                eParameterField::injection_expression->get($this->post),
                eParameterField::injection_order->get($this->post),
                eParameterField::injection_values->get($this->post),
                eParameterField::injection_min_value->get($this->post),
                eParameterField::injection_max_value->get($this->post),
                eParameterField::injection_interval_value->get($this->post),
            ),
            eUISA_RequestParameter::edit_view => new ExecParameterViewEditing($this->refParameter(),
                eParameterField::view_code->get($this->post),
                eParameterField::view_new_code->get($this->post),
                eParameterField::view_comment->get($this->post),
                eParameterField::view_custom_name->get($this->post),
                eParameterField::view_format->get($this->post),
                eParameterField::view_mask->get($this->post),
                eParameterField::view_values->get($this->post),
                eParameterField::view_numbers->get($this->post),
                eParameterField::injection_on->get($this->post),
                eParameterField::injection_number->get($this->post),
                eParameterField::injection_expression->get($this->post),
                eParameterField::injection_order->get($this->post),
                eParameterField::injection_values->get($this->post),
                eParameterField::injection_min_value->get($this->post),
                eParameterField::injection_max_value->get($this->post),
                eParameterField::injection_interval_value->get($this->post),
            ),
            eUISA_RequestParameter::delete => new ExecParameterDeleting($this->refParameter()),
            eUISA_RequestParameter::delete_view => new ExecParameterViewDeleting($this->refParameter(),
                eParameterField::view_code->get($this->post),
            ),
            default => throw new UIException(UIEx::actionNotImplemented)
        };
    }

    /**
     * @throws DBException
     */
    public function getCurrentID(): ?string
    {
        return $this->refParameter()->getGUID();
    }

    /**
     * @throws DBException
     */
    public function refURL(): URL
    {
        return new URL()
            ->setSectionAction(static::$section->value, $this->action?->value)
            ->setParameter(
                $this->refParameter()->refCommand()->refSubscriber()->getProtocol(),
                $this->refParameter()->refCommand()->getSubscriber(),
                $this->refParameter()->getCommand(),
                $this->refParameter()->getGUID()
            );
    }

    /**
     * @throws DBException
     */
    public static function initWithAction(eUISA_RequestParameter|iUISectionActionEnum|null $action): ?static
    {
        $order = eUISA_RequestParameter::actionOrder();
        $controller = !is_null($action) && $action::class == eUISA_RequestParameter::class
            ? $action->initController()
            : eUISA_RequestParameter::tryFrom($action?->value)?->initController();
        if ($controller !== null) try {
            $controller->verifyAccess();
            return $controller;
        } catch (AccessDeniedException|ActionAccessException|DataAccessException) {
            return static::initDefault($order);
        } else return static::initDefault($order);
    }
}