<?php

namespace Horizon\ProtocolBuilder\UserInterface\Executors;

use Horizon\Auth\DataBase\Tables\Role;
use Horizon\DataBaseController\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_URole;
use Horizon\UserInterface\Executor;

class ExecURoleDeleting extends Executor
{
    /**
     * @throws DBException
     */
    public function __construct(Role $role)
    {
        $role->dbDelete();
        parent::__construct(eUISA_URole::main->initController()->getURL());
    }
}