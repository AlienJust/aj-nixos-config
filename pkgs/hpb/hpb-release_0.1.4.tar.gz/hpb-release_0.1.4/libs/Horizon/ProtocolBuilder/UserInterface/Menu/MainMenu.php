<?php

namespace Horizon\ProtocolBuilder\UserInterface\Menu;

use Exception;
use Horizon\Auth\DataBase\ListSources\ProtocolListSources;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Protocol;
use Horizon\ProtocolBuilder\UserInterface\eUISA_UGroup;
use Horizon\ProtocolBuilder\UserInterface\eUISA_URole;
use Horizon\ProtocolBuilder\UserInterface\eUISA_User;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\Menu;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\MenuAction;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\MenuBlock;
use Horizon\ProtocolBuilder\UserInterface\Menu\Bricks\MenuLogo;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_Protocol;
use Horizon\UserInterface\Tags\Trace;
use const HORIZON_SETTINGS as HS;

class MainMenu extends Menu
{
    public function __construct(?int $current_ID = null, ?eUISA_Protocol $action = null)
    {
        parent::__construct('protocols');
        $this->add(new MenuLogo());
        try {
            $this->addBlock(new MenuBlock(HS['ui']['version'])
                ->addItem(
                    new MenuAction(eUISA_Protocol::manual->initController(), $action),
                    $this->initMenuAction(eUISA_User::main->initController(), $action),
                    $this->initMenuAction(eUISA_UGroup::main->initController(), $action),
                    $this->initMenuAction(eUISA_URole::main->initController(), $action),
                )
            )->addBlock($block = new MenuBlock('Протоколы')
                ->addItem(
                    $this->initMenuAction(eUISA_Protocol::new->initController(), $action),
                    $this->initMenuAction(eUISA_Protocol::import->initController(), $action)
                ));

            $protocols = new ProtocolListSources(1, 3000, null)->loadData();

            $controller = UISection_Protocol::initWithAction($action);

            foreach ($protocols as $protocol) {
                $controller?->setProtocol($protocol);
                $block->addItem(
                    $this->initMenuItem($controller, $protocol->name, $protocol->getID() == $current_ID)
                );
            }

        } catch (Exception $e) {
            $this->addBlock(new MenuBlock("Ошибка")->add(new Trace($e)));
        }
    }
}