<?php

namespace Horizon\UserInterface\PresetTags;

use Horizon\UserInterface\Tags\Division;

class ValueView extends Division2Columns
{

    public function __construct(string $title, ?string $value)
    {
        parent::__construct();
        if ($value == '') $value = '&nbsp;';
        $this->addClass('value-view')->add(
            new Division($title)->addClass('value-title'),
            new Division($value)->addClass('value-value')
        );
    }
}