<?php

namespace Horizon\UserInterface\PresetTags;

use Horizon\UserInterface\Controls\InputHiddenValue;
use Horizon\UserInterface\iTag;
use Horizon\UserInterface\Tags\Division;

class Division2Columns extends Division
{
    public function __construct()
    {
        parent::__construct();
        parent::addClass('flex-box-2-columns');
    }

    public function add(iTag|string|null ...$content): static
    {
        foreach ($content as $tag) if (!is_null($tag)) {
            if (is_string($tag)) parent::add(new Division()->add($tag));
            elseif($tag::class == InputHiddenValue::class || $tag::class == Division::class) parent::add($tag);
            else parent::add(new Division()->add($tag));
        }
        return $this;
    }
}