<?php
include_once 'components/private/loader.php';

(new \Horizon\ProtocolBuilder\UserInterface\UICore(
    \Horizon\ProtocolBuilder\UserInterface\MainPage::go()
        ->setCSS('styles/main.css')
        ->setJS('js/jquery/jquery.js', 'js/jquery/ui/jquery-ui.min.js')
))->output();
