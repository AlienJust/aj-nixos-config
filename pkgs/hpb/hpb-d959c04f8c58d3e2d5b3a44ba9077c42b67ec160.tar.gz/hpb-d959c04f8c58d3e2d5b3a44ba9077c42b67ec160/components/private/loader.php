<?php
$ROOT = $_SERVER['DOCUMENT_ROOT'];
$loader = require_once $ROOT . '/libs/Horizon/ClassLoader.php';
$loader->setNamespaces('Horizon');
date_default_timezone_set('Asia/Yekaterinburg');
define('HORIZON_SETTINGS',
    parse_ini_file($ROOT . '/data/private/horizon.ini', true, INI_SCANNER_TYPED));
