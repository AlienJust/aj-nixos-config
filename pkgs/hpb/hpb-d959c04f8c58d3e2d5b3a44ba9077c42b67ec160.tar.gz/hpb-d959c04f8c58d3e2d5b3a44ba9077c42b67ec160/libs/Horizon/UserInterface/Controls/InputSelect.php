<?php

namespace Horizon\UserInterface\Controls;

use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\Components\Option;
use Horizon\UserInterface\Controls\Components\OptionGroup;
use Horizon\UserInterface\HTMLEx;
use Horizon\UserInterface\HTMLException;
use Horizon\UserInterface\iTag;
use Horizon\UserInterface\Tag;
use Horizon\UserInterface\Tags\Label;

class InputSelect extends Tag
{
    protected Label $label;
    protected array $value;
    public function __construct(string $name, array|string $value, string $label, string $title, bool $required = false)
    {
        parent::__construct('select');
        $this->label = new Label();
        $this->label->add($label);
        $this->addAttribute(Attribute::name, $name)
            ->addAttribute(Attribute::title, $title);
        if ($required) $this->addAttribute(Attribute::required, $required);
        $this->value = is_array($value) ? $value : [$value];
    }

    /**
     * @throws HTMLException
     */
    public function add(iTag|string|null ...$content): static
    {
        foreach($content as $tag) if (is_string($tag) || is_object($tag) && !in_array(get_class($tag), [OptionGroup::class, Option::class]))
            throw new HTMLException(HTMLEx::tagNotSupport);
        return parent::add(...$content);
    }

    /**
     * @throws HTMLException
     */
    public function addOptions(bool $nullable, Option|OptionGroup ...$options): static
    {
        if ($nullable) $this->add(new Option('', '...'));
        foreach ($options as $option) {
            if ($option::class == Option::class && in_array($option->getValue(), $this->value))
                $option->addAttribute(Attribute::selected, true);
            elseif ($option::class == OptionGroup::class) foreach ($option->arrContent() as $opt)
                if ($opt::class == Option::class && in_array($opt->getValue(), $this->value))
                    $opt->addAttribute(Attribute::selected, true);
            $this->add($option);
        }
        return $this;
    }

    public function draw(): string
    {
        $label = clone $this->label;
        return $label->add(parent::draw())->draw();
    }
}