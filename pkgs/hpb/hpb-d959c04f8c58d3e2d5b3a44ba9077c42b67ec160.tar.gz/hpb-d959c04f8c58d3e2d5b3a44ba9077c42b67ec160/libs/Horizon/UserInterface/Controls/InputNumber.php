<?php

namespace Horizon\UserInterface\Controls;

use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Tags\Label;

class InputNumber extends Input
{
    protected Label $label;
    public function __construct(string $name, string $value, string $label, string $title, bool $required = false)
    {
        parent::__construct('number', $name, $value);
        $this->label = new Label();
        $this->label->add($label);
        $this->addAttribute(Attribute::title, $title);
        if ($required) $this->addAttribute(Attribute::required, $required);
    }

    public function draw(): string
    {
        $label = clone $this->label;
        return $label->add(parent::draw())->draw();
    }
}