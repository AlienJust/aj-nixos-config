<?php

namespace Horizon\UserInterface\Controls;

use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Tags\Division;
use Horizon\UserInterface\Tags\Label;

class CheckboxBool extends Label
{
    public function __construct(string $name, bool $value, string $label, string $title, bool $stable = true)
    {
        parent::__construct();
        $this->addClass('checkbox');
        if ($stable) $this->add(new InputHiddenValue($name, '0'));
        $this->add((new InputCheckbox($name, $value))->addClass('hide'));
        $this->add((new Division())->add(new Division()))->add($label);
        $this->addAttribute(Attribute::title, $title);
    }
}