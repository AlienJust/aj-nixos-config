<?php

namespace Horizon\UserInterface\Controls;

use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\Components\Textarea;
use Horizon\UserInterface\iTag;
use Horizon\UserInterface\Tags\Label;

class InputTextarea extends Label
{
    private Textarea $textarea;
    public function __construct(string $name, string $value, string $label, string $title,
                                ?int $maxlength = null, bool $required = false)
    {
        parent::__construct();
        parent::add($label);
        parent::add($this->textarea = new Textarea($name, $value, $maxlength));
        $this->textarea->addAttribute(Attribute::title, $title);
        if ($required) $this->textarea->addAttribute(Attribute::required, $required);
    }

    public function add(iTag|string|null ...$content): static
    {
        foreach($content as $tag) $this->textarea->add($tag);
        return $this;
    }
}