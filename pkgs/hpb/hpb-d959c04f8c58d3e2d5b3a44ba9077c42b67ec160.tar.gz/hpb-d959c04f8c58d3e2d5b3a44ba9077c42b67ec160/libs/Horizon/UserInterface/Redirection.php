<?php

namespace Horizon\UserInterface;

class Redirection
{
    private string $URL = '';

    public function __construct(string $URL)
    {
        $this->URL = $URL;
    }

    public function getURL(): string
    {
        return $this->URL;
    }

    public function output(): void
    {
        header('Location:' . $this->URL);
    }
}