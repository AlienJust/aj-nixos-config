<?php

namespace Horizon\UserInterface\PresetTags;

use Horizon\UserInterface\Constants\DataAttribute;
use Horizon\UserInterface\Tags\Division;
use Horizon\UserInterface\Tags\Label;

class PostViewMatrix extends Division
{
    /** @var Division[] $bits */
    private array $bits;
    private int $current_id = 0;
    public function __construct(int $count)
    {
        parent::__construct();
        $this->addClass('bytes view');
        for ($i = 0; $i < $count; $i++) {
            $this->add($div = (new Division())->addClass('bits')
                ->add((new Label())->addClass('byte')
                    ->add(new Division())));
            for ($j = 0; $j < 8; $j++)
                $div->add((new Label())->addClass('bit')
                    ->add($this->bits[] = new Division()));
        }
    }
    public function setParameter(string $name, array $bits): void
    {
        foreach ($bits as $bit) $this->bits[$bit]
            ->addClass('fill')
            ->addClass('prm-' . $this->current_id)
            ->addAttribute(DataAttribute::title, $name);
        $this->current_id++;
    }
}