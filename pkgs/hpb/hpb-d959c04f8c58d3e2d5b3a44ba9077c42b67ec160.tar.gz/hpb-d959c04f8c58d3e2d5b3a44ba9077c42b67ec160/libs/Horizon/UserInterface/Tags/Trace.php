<?php

namespace Horizon\UserInterface\Tags;

use Horizon\ePHP_ini;
use Horizon\UserInterface\TagsPack;
use Throwable;

class Trace extends TagsPack
{
    public function __construct(Throwable $exception)
    {
        parent::__construct();
        $this->add($exception->getMessage());
        if (ePHP_ini::display_errors->get()) $this->add(' | ' . $exception->getFile() . ' – line ' . $exception->getLine());
        if (!is_null($exception->getPrevious())) $this->add(' :: ')->add(new Trace($exception->getPrevious()));
    }
}