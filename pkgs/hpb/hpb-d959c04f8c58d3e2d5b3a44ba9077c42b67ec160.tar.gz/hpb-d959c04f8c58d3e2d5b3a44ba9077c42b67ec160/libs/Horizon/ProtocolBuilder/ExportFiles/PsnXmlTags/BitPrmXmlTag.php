<?php

namespace Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class BitPrmXmlTag extends XmlTag
{
    public readonly string $Byte;
    public readonly string $Bit;
    public readonly string $IsValueInverted;
    public readonly string $Name;
    public readonly string $Id;

    public function __construct(string $Byte, string $Bit, string $IsValueInverted, string $Name, string $Id)
    {
        parent::__construct('BitPrm');
        $this->Byte = $Byte;
        $this->Bit = $Bit;
        $this->IsValueInverted = $IsValueInverted;
        $this->Name = $Name;
        $this->Id = $Id;
    }


}