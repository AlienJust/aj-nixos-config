<?php

namespace Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class CpzPrmXmlTag extends XmlTag
{
    public readonly string $Name;
    public readonly string $Expression;
    public readonly string $Id;

    public function __construct(string $Name, string $Expression, string $Id)
    {
        parent::__construct('CpzPrm');
        $this->Name = $Name;
        $this->Expression = $Expression;
        $this->Id = $Id;
    }


}