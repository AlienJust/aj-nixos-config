<?php

namespace Horizon\ProtocolBuilder\ExportFiles\PsnXmlTags;

use Horizon\ProtocolBuilder\ExportFiles\XmlTag;

class DefValXmlTag extends XmlTag
{
    public readonly string $Position;
    public readonly string $Length;
    public readonly ?string $Value;
    public readonly string $Name;
    public readonly string $Id;

    public function __construct(string $Position, string $Length, ?string $Value, string $Name, string $Id)
    {
        parent::__construct('DefVal');
        $this->Position = $Position;
        $this->Length = $Length;
        $this->Value = $Value;
        $this->Name = $Name;
        $this->Id = $Id;
    }


}