<?php

namespace Horizon\ProtocolBuilder\DataBase\Tables;

final class ParameterToRequest extends Parameter
{
    protected const PACKAGE_TYPE = false;
}