<?php

namespace Horizon\ProtocolBuilder\DataBase\Tables;

use Horizon\ProtocolBuilder\DataBase\dbTable;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use PDO;

class ParameterViewInjection extends dbTable
{
    protected int $protocol;
    protected string $code;
    protected int $param_number_in_package;
    protected string $convert_expression;
    protected bool $invert_bytes_order;
    protected ?float $min_value;
    protected ?float $max_value;
    protected ?float $interval_value;
    /** @var ParameterViewInjectValue[] $ARR_values */
    protected ?array $ARR_values = null;

    public function __construct(?int $protocol = null, ?string $code = null)
    {
        if (!is_null($protocol)) $this->protocol = $protocol;
        if (!is_null($code)) $this->code = $code;
    }

    public function setProtocol(int $protocol): self
    {
        $this->protocol = $protocol;
        return $this;
    }

    public function setCode(string $code): self
    {
        $this->code = $code;
        return $this;
    }

    public function setParamNumberInPackage(int $param_number_in_package): self
    {
        $this->param_number_in_package = $param_number_in_package;
        return $this;
    }

    public function setConvertExpression(string $convert_expression): self
    {
        $this->convert_expression = $convert_expression;
        return $this;
    }

    public function setInvertBytesOrder(bool $invert_bytes_order): self
    {
        $this->invert_bytes_order = $invert_bytes_order;
        return $this;
    }

    public function setMinValue(?float $min_value): self
    {
        $this->min_value = $min_value;
        return $this;
    }

    public function setMaxValue(?float $max_value): self
    {
        $this->max_value = $max_value;
        return $this;
    }

    public function setIntervalValue(?float $interval_value): self
    {
        $this->interval_value = $interval_value;
        return $this;
    }

    public function addValue(ParameterViewInjectValue ...$values): void
    {
        if (is_null($this->ARR_values)) $this->ARR_values = [];
        foreach ($values as $value) $this->ARR_values[] = $value;
    }

    public function getParamNumberInPackage(): int
    {
        return $this->param_number_in_package;
    }

    public function getConvertExpression(): string
    {
        return $this->convert_expression;
    }

    public function isInvertBytesOrder(): bool
    {
        return $this->invert_bytes_order;
    }

    public function getMinValue(): ?float
    {
        return $this->min_value;
    }

    public function getMaxValue(): ?float
    {
        return $this->max_value;
    }

    public function getIntervalValue(): ?float
    {
        return $this->interval_value;
    }

    public function getStringFormat(): ?string
    {
        if (is_null($this->interval_value)) return null;
        return "f" . mb_strlen(explode('.', $this->interval_value)[1] ?? '');
    }

    /**
     * @return ParameterViewInjectValue[]
     * @throws DBException
     */
    public function arrInjectValues(): array
    {
        $stmt = self::PDO()->prepare('SELECT pcpviv.*, TRUE AS `exists` 
            FROM `pb_command_parameter_view_inject_value` AS pcpviv 
            WHERE pcpviv.`protocol`=:protocol
              AND pcpviv.`code`=:code
            ORDER BY pcpviv.`id`;');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, ParameterViewInjectValue::class));
    }

    protected function tryInsert(): void
    {
        $stmt = self::PDO()->prepare('INSERT INTO `pb_command_parameter_view_injection`(
            `protocol`, `code`, `param_number_in_package`, `convert_expression`, `invert_bytes_order`, `min_value`, `max_value`, `interval_value`
        ) VALUES (:protocol, :code, :param_number_in_package, :convert_expression, :invert_bytes_order, :min_value, :max_value, :interval_value);');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->bindValue(':param_number_in_package', $this->param_number_in_package, PDO::PARAM_INT);
        $stmt->bindValue(':convert_expression', $this->convert_expression);
        $stmt->bindValue(':invert_bytes_order', $this->invert_bytes_order, PDO::PARAM_BOOL);
        $stmt->bindValue(':min_value', $this->min_value ?? null, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->bindValue(':max_value', $this->max_value ?? null, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->bindValue(':interval_value', $this->interval_value ?? null, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->execute();
        if (!is_null($this->ARR_values)) foreach ($this->ARR_values as $value)
            $value->setProtocol($this->protocol)->setCode($this->code)->tryInsert();
    }

    protected function tryUpdate(): void
    {
        $stmt = self::PDO()->prepare('UPDATE `pb_command_parameter_view_injection` SET
                `param_number_in_package`=:param_number_in_package, 
                `convert_expression`=:convert_expression, 
                `invert_bytes_order`=:invert_bytes_order,
                `min_value`=:min_value,
                `max_value`=:max_value,
                `interval_value`=:interval_value
            WHERE `protocol`=:protocol 
              AND `code`=:code;');
        $stmt->bindValue(':param_number_in_package', $this->param_number_in_package, PDO::PARAM_INT);
        $stmt->bindValue(':convert_expression', $this->convert_expression);
        $stmt->bindValue(':invert_bytes_order', $this->invert_bytes_order, PDO::PARAM_BOOL);
        $stmt->bindValue(':min_value', $this->min_value, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->bindValue(':max_value', $this->max_value, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->bindValue(':interval_value', $this->interval_value, PDO::PARAM_STR|PDO::PARAM_NULL);
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->execute();
        if (!is_null($this->ARR_values)) foreach ($this->ARR_values as $value)
            $value->setCode($this->code)->tryInsert();
    }

    protected function tryDelete(): void
    {
        $stmt = self::PDO()->prepare('DELETE
            FROM `pb_command_parameter_view_injection` AS pcpvi 
            WHERE pcpvi.`protocol`=:protocol 
              AND pcpvi.`code`=:code;');
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->execute();
    }

    public static function dbLoad(int $protocol, string $code): static
    {
        $stmt = self::PDO()->prepare('SELECT pcpvi.*, TRUE AS `exists` 
            FROM `pb_command_parameter_view_injection` AS pcpvi 
            WHERE pcpvi.`protocol`=:protocol 
              AND pcpvi.`code`=:code;');
        $stmt->bindValue(':protocol', $protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $code);
        $stmt->execute();
        return static::intoMe($stmt->fetchObject(static::class, [$protocol, $code]), $protocol, $code);
    }
}