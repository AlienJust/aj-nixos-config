<?php

namespace Horizon\ProtocolBuilder\DataBase\Tables;

use Horizon\ProtocolBuilder\DataBase\dbTableAI;
use Horizon\ProtocolBuilder\DataBase\eTable;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\Exceptions\VEx;
use Horizon\ProtocolBuilder\Exceptions\VException;
use PDO;

final class Protocol extends dbTableAI
{
    protected static eTable $db_table = eTable::pb_protocol;
    private string $name = '';
    private string $description = '';
    private string $version = '';
    private string $GUID;

    public function __construct(?int $ID = null)
    {
        if (!is_null($ID)) $this->ID = $ID;
    }

    /**
     * @throws VException
     */
    public function setName(string $value): static
    {
        $this->name = trim($value);
        if ($this->name == '') throw new VException(VEx::emptyName);
        return $this;
    }

    /**
     * @throws VException
     */
    public function setDescription(string $description): static
    {
        $this->description = trim($description);
        if ($this->description == '') throw new VException(VEx::emptyName);
        return $this;
    }

    /**
     * @throws VException
     */
    public function setVersion(string $version): static
    {
        $this->version = trim($version);
        if ($this->version == '') throw new VException(VEx::emptyName);
        return $this;
    }

    /**
     * @throws DBException
     */
    public function setGUID(?string $value): static
    {
        $this->GUID = $value ?? self::UUID();
        return $this;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getDescription(): string
    {
        return $this->description;
    }

    public function getVersion(): string
    {
        return $this->version;
    }

    /**
     * @throws DBException
     */
    public function getGUID(): string
    {
        return $this->GUID ?? ($this->GUID = self::UUID());
    }

    /**
     * @return Subscriber[]
     * @throws DBException
     */
    public function arrSubscribers(): array
    {
        $stmt = self::PDO()->prepare('SELECT pbs.*, TRUE AS `exists` 
            FROM `pb_subscriber` AS pbs 
            WHERE pbs.`protocol`=:this;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, Subscriber::class));
    }

    /**
     * @return SystemDiagnosticBlock[]
     * @throws DBException
     */
    public function arrBlocks():array
    {
        $stmt = self::PDO()->prepare('SELECT psdb.*, TRUE AS `exists` 
            FROM `pb_system_diagnostic_block` AS psdb 
            WHERE psdb.`protocol`=:this
            ORDER BY psdb.`sort`, psdb.`ID`;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, SystemDiagnosticBlock::class));
    }

    /**
     * @return SystemDiagnosticBlock[]
     * @throws DBException
     */
    public function arrMainBlocks(): array
    {
        $stmt = self::PDO()->prepare('SELECT psdb.*, TRUE AS `exists` 
            FROM `pb_system_diagnostic_block` AS psdb 
            WHERE psdb.`protocol`=:this
              AND psdb.`inline` IS FALSE
            ORDER BY psdb.`sort`, psdb.`ID`;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, SystemDiagnosticBlock::class));
    }

    /**
     * @return SystemDiagnosticVirtualChunk[]
     * @throws DBException
     */
    public function arrVirtualParameters(): array
    {
        $stmt = self::PDO()->prepare('SELECT 
                psdvc.`block`, psdvc.`row_id`, psdvc.`column_id`, psdvc.`protocol`, psdvc.`code` 
            FROM `pb_system_diagnostic_virtual_chunk` AS psdvc 
            WHERE psdvc.`protocol`=:this
            ORDER BY psdvc.`code`;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_FUNC, SystemDiagnosticVirtualChunk::fromDataBase(...)));
    }

    /**
     * @return SystemDiagnosticAggregateChunk[]
     * @throws DBException
     */
    public function arrAggregateGroups(): array
    {
        $stmt = self::PDO()->prepare('SELECT 
                psdac.*, TRUE AS `exists` 
            FROM `pb_system_diagnostic_aggregate_chunk` AS psdac 
            WHERE psdac.`protocol`=:this
            ORDER BY psdac.`ID`;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, SystemDiagnosticAggregateChunk::class));
    }

    /**
     * @return ParameterView[]
     * @throws DBException
     */
    public function arrParameterViews(): array
    {
        $stmt = self::PDO()->prepare('SELECT 
                pcpv.`protocol`, 
                pcpv.`code`, 
                BinToUUID(pcpv.`identifier`) AS `identifier`, 
                pcpv.`comment`, 
                pcpv.`custom_name`, 
                pcpv.`format`, 
                pcpv.`mask`,
                TRUE AS `exists` 
            FROM `pb_command_parameter_view` AS pcpv 
            WHERE pcpv.`protocol`=:this
            ORDER BY pcpv.`code`;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_CLASS, ParameterView::class));
    }

    /**
     * @throws DBException
     */
    public function dbUpdateChunks(array $parameter_views): void
    {
        self::dbAction(function () use ($parameter_views) {
            if (count($parameter_views) > 0) {
                $x = implode(', ', array_map(fn($idx) => ":x_$idx", range(0, count($parameter_views) - 1)));
                $stmt = self::PDO()->prepare("DELETE
                FROM `pb_system_diagnostic_chunk`
                WHERE (`block` IS NULL OR `block` IN (SELECT `ID` FROM `pb_system_diagnostic_block` WHERE `protocol` = :this))
                  AND `protocol` = :this
                  AND `code` NOT IN ($x);");
                foreach ($parameter_views as $idx => $code) $stmt->bindValue(":x_$idx", $code);
            } else {
                $stmt = self::PDO()->prepare("DELETE
                FROM `pb_system_diagnostic_chunk`
                WHERE (`block` IS NULL OR `block` IN (SELECT `ID` FROM `pb_system_diagnostic_block` WHERE `protocol` = :this))
                  AND `protocol` = :this;");
            }
            $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
            $stmt->execute();

            $row = self::PDO()->query('SELECT 
                    IFNULL(MAX(`row_id`), 0) + 1 
                FROM `pb_system_diagnostic_chunk` 
                WHERE `block` IS NULL AND `column_id`=0;')->fetchColumn();
            foreach ($parameter_views as $code) try {
                SystemDiagnosticChunk::dbFind($this->getID(), $code)
                    ->tryUpdate();
            } catch (DBException) {
                (new SystemDiagnosticChunk(null, $row, 0, $this->getID(), $code))
                    ->tryInsert();
                $row++;
            }
        });
    }

    /**
     * @throws DBException
     */
    public function dbClearBlocks(array $blocks): void
    {
        self::dbAction(function () use ($blocks) {
            $blocks = array_values($blocks);
            if (count($blocks) > 0) {
                $x = implode(', ', array_map(fn($idx) => ":x_$idx", range(0, count($blocks) - 1)));
                $stmt = self::PDO()->prepare("DELETE
                    FROM `pb_system_diagnostic_block`
                    WHERE `protocol` = :this
                      AND `ID` NOT IN ($x);");
                $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
                foreach ($blocks as $idx => $code) $stmt->bindValue(":x_$idx", $code);
                $stmt->execute();
            } else {
                $stmt = self::PDO()->prepare("DELETE
                    FROM `pb_system_diagnostic_block`
                    WHERE `protocol` = :this;");
                $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
                $stmt->execute();
            }
        });
    }

    /**
     * @throws DBException
     */
    public function dbClearVirtualChunks(array $chunks): void
    {
        self::dbAction(function () use ($chunks) {
            $chunks = array_values($chunks);
            if (count($chunks) > 0) {
                $x = implode(', ', array_map(fn($idx) => ":x_$idx", range(0, count($chunks) - 1)));
                $stmt = self::PDO()->prepare("DELETE
                    FROM `pb_system_diagnostic_virtual_chunk`
                    WHERE `protocol` = :this
                      AND `code` NOT IN ($x);");
                $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
                foreach ($chunks as $idx => $code) $stmt->bindValue(":x_$idx", $code);
                $stmt->execute();
            } else {
                $stmt = self::PDO()->prepare("DELETE
                    FROM `pb_system_diagnostic_virtual_chunk`
                    WHERE `protocol` = :this;");
                $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
                $stmt->execute();
            }
        });
    }

    /**
     * @param [] $chunks
     * @return void
     * @throws DBException
     */
    public function dbClearAggregateChunks(array $chunks): void
    {
        self::dbAction(function () use ($chunks) {
            $chunks = array_values($chunks);
            if (count($chunks) > 0) {
                $x = implode(', ', array_map(fn($idx) => ":x_$idx", range(0, count($chunks) - 1)));
                $stmt = self::PDO()->prepare("DELETE
                    FROM `pb_system_diagnostic_aggregate_chunk`
                    WHERE `protocol` = :this
                      AND `ID` NOT IN ($x);");
                $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
                foreach ($chunks as $idx => $id) $stmt->bindValue(":x_$idx", $id);
                $stmt->execute();
            } else {
                $stmt = self::PDO()->prepare("DELETE
                    FROM `pb_system_diagnostic_aggregate_chunk`
                    WHERE `protocol` = :this;");
                $stmt->bindValue(':this', $this->getID(), PDO::PARAM_INT);
                $stmt->execute();
            }
        });
    }

    protected function tryInsert(): void
    {
        $stmt = self::PDO()->prepare('INSERT INTO `pb_protocol`(`GUID`,`name`, `description`, `version`) 
            VALUES (UUIDToBin(:GUID),:name, :description, :version);');
        $stmt->bindValue(':GUID', $this->GUID);
        $stmt->bindValue(':name', $this->name);
        $stmt->bindValue(':description', $this->description);
        $stmt->bindValue(':version', $this->version);
        $stmt->execute();
        $this->ID = self::PDO()->lastInsertId();
    }

    protected function tryUpdate(): void
    {
        $stmt = self::PDO()->prepare('UPDATE `pb_protocol` SET 
                         `GUID`=UUIDToBin(:GUID),
                         `name`=:name,
                         `description`=:description,
                         `version`=:version
                     WHERE `ID`=:this;');
        $stmt->bindValue(':GUID', $this->GUID);
        $stmt->bindValue(':name', $this->name);
        $stmt->bindValue(':description', $this->description);
        $stmt->bindValue(':version', $this->version);
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
    }


    /**
     * @return Protocol[]
     * @throws DBException
     */
    public static function list(): array
    {
        return self::PDO()->query('SELECT 
                pbp.`ID`,
                BinToUUID(pbp.`GUID`) AS `GUID`, 
                pbp.`name`, 
                pbp.`description`, 
                pbp.`version`, 
                TRUE AS `exists` 
            FROM `pb_protocol` AS pbp 
            ORDER BY pbp.`name`, pbp.`ID`;')->fetchAll(PDO::FETCH_CLASS, static::class);

    }

    /**
     * @throws DBException
     */
    public static function dbLoad(?int $ID): static
    {
        $stmt = self::PDO()->prepare('SELECT 
                pbp.`ID`,
                BinToUUID(pbp.`GUID`) AS `GUID`, 
                pbp.`name`, 
                pbp.`description`, 
                pbp.`version`
            FROM `pb_protocol` AS pbp
            WHERE pbp.`ID`=:this;');
        $stmt->bindValue(':this', $ID);
        $stmt->execute();
        return static::intoMe($stmt->fetchObject(static::class, [$ID]), $ID);
    }

    /**
     * @throws DBException
     */
    public static function dbFind(?string $GUID): static
    {
        $stmt = self::PDO()->prepare('SELECT 
                pbp.`ID`,
                BinToUUID(pbp.`GUID`) AS `GUID`, 
                pbp.`name`, 
                pbp.`description`, 
                pbp.`version`
            FROM `pb_protocol` AS pbp
            WHERE pbp.`GUID`=UUIDToBin(:this);');
        $stmt->bindValue(':this', $GUID);
        $stmt->execute();
        return static::intoMe($stmt->fetchObject(static::class))->setGUID($GUID);
    }
}