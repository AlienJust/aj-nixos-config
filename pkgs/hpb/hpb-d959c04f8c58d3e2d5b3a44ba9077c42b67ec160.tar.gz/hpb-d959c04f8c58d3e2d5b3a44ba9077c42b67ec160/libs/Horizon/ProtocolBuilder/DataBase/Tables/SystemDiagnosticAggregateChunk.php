<?php

namespace Horizon\ProtocolBuilder\DataBase\Tables;

use Horizon\ProtocolBuilder\DataBase\dbTableAI;
use Horizon\ProtocolBuilder\DataBase\eTable;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use PDO;

final class SystemDiagnosticAggregateChunk extends dbTableAI
{
    protected static eTable $db_table = eTable::pb_system_diagnostic_aggregate_chunk;

    protected ?int $block = null;
    protected int $row_id = 0;
    protected int $column_id = 0;
    protected ?int $column_span = null;
    protected int $protocol;
    protected string $label;
    protected int $param_count;

    public function __construct(?int $protocol = null)
    {
        if (!is_null($protocol)) $this->protocol = $protocol;
        $this->exists = $this->exists ?? false;
    }

    public function setBlock(?int $block): self
    {
        $this->block = $block;
        return $this;
    }

    public function setRowId(int $row_id): self
    {
        $this->row_id = $row_id;
        return $this;
    }

    public function setColumnId(int $column_id): self
    {
        $this->column_id = $column_id;
        return $this;
    }

    public function setLabel(string $label): self
    {
        $this->label = $label;
        return $this;
    }

    public function setParamCount(int $param_count): self
    {
        $this->param_count = $param_count;
        return $this;
    }

    public function setColumnSpan(?int $column_span): self
    {
        $this->column_span = $column_span;
        return $this;
    }

    public function getBlock(): ?int
    {
        return $this->block;
    }

    public function getRowId(): int
    {
        return $this->row_id;
    }

    public function getColumnId(): int
    {
        return $this->column_id;
    }

    public function getLabel(): string
    {
        return $this->label;
    }

    public function getParamCount(): int
    {
        return $this->param_count;
    }

    public function getColumnSpan(): ?int
    {
        return $this->column_span;
    }

    /**
     * @return SystemDiagnosticAggregateParameter[]
     * @throws DBException
     */
    public function arrParameters(): array
    {
        $stmt = self::PDO()->prepare('SELECT `chunk`, `protocol`, `code`, `sort`
            FROM `pb_system_diagnostic_aggregate_parameter`
            WHERE `chunk`=:this 
              AND `protocol` = :protocol
            ORDER BY `sort`;');
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->execute();
        return self::PDOInspect($stmt->fetchAll(PDO::FETCH_FUNC, SystemDiagnosticAggregateParameter::fromDataBase(...)));
    }

    /**
     * @throws DBException
     */
    public function dbClearParameters(): void
    {
        self::dbAction(function () {
            $stmt = self::PDO()->prepare('DELETE FROM `pb_system_diagnostic_aggregate_parameter` 
                WHERE `chunk`=:this;');
            $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
            $stmt->execute();
        });
    }

    protected function tryInsert(): void
    {
        $stmt = self::PDO()->prepare('INSERT INTO `pb_system_diagnostic_aggregate_chunk`(
                                         `block`, `row_id`, `column_id`, `column_span`, `protocol`, `label`, `param_count`
                                         ) VALUES (:block, :row_id, :column_id, :column_span, :protocol, :label, :param_count);');
        $stmt->bindValue(':block', $this->block, PDO::PARAM_INT|PDO::PARAM_NULL);
        $stmt->bindValue(':row_id', $this->row_id, PDO::PARAM_INT);
        $stmt->bindValue(':column_id', $this->column_id, PDO::PARAM_INT);
        $stmt->bindValue(':column_span', $this->column_span, PDO::PARAM_INT|PDO::PARAM_NULL);
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':label', $this->label);
        $stmt->bindValue(':param_count', $this->param_count, PDO::PARAM_INT);
        $stmt->execute();
        $this->ID = self::PDO()->lastInsertId();
    }

    protected function tryUpdate(): void
    {
        $stmt = self::PDO()->prepare('UPDATE `pb_system_diagnostic_aggregate_chunk` SET
                 `label`=:label,
                 `param_count`=:param_count,
                 `block`=:block, 
                 `row_id`=:row_id, 
                 `column_id`=:column_id,
                 `column_span`=:column_span
            WHERE `protocol`=:protocol AND `ID`=:this;');
        $stmt->bindValue(':label', $this->label);
        $stmt->bindValue(':param_count', $this->param_count, PDO::PARAM_INT);
        $stmt->bindValue(':block', $this->block, PDO::PARAM_INT|PDO::PARAM_NULL);
        $stmt->bindValue(':row_id', $this->row_id, PDO::PARAM_INT);
        $stmt->bindValue(':column_id', $this->column_id, PDO::PARAM_INT);
        $stmt->bindValue(':column_span', $this->column_span, PDO::PARAM_INT|PDO::PARAM_NULL);
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':this', $this->ID, PDO::PARAM_INT);
        $stmt->execute();
    }

    /**
     * @throws DBException
     */
    public static function dbLoad(?int $ID, int $protocol): self
    {
        return self::intoMe(self::PDOStatementForLoad($ID)->fetchObject(self::class, [$protocol]), $protocol);
    }
}