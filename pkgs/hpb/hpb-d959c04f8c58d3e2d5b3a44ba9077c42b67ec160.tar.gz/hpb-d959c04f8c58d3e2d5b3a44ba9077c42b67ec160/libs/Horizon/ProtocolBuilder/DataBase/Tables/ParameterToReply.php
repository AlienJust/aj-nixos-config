<?php

namespace Horizon\ProtocolBuilder\DataBase\Tables;

final class ParameterToReply extends Parameter
{
    protected const PACKAGE_TYPE = true;
}