<?php

namespace Horizon\ProtocolBuilder\DataBase\Tables;

use Horizon\ProtocolBuilder\DataBase\dbTable;
use Horizon\ProtocolBuilder\DataBase\eTable;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use PDO;

final class SystemDiagnosticVirtualChunk extends dbTable
{
    protected static eTable $db_table = eTable::pb_system_diagnostic_virtual_chunk;

    protected ?int $block;
    protected int $row_id;
    protected int $column_id;
    protected int $protocol;
    protected string $code;
    protected ?string $new_code = null;

    public function __construct(?int $block, int $row_id, int $column_id, int $protocol, string $code)
    {
        $this->block = $block;
        $this->row_id = $row_id;
        $this->column_id = $column_id;
        $this->protocol = $protocol;
        $this->code = $code;
        $this->exists = $this->exists ?? false;
    }

    public function setBlock(?int $block): self
    {
        $this->block = $block;
        return $this;
    }

    public function setRowId(int $row_id): self
    {
        $this->row_id = $row_id;
        return $this;
    }

    public function setColumnId(int $column_id): self
    {
        $this->column_id = $column_id;
        return $this;
    }

    public function setCode(string $code): self
    {
        $this->new_code = $code;
        return $this;
    }

    public function getBlock(): ?int
    {
        return $this->block;
    }

    public function getRowId(): int
    {
        return $this->row_id;
    }

    public function getColumnId(): int
    {
        return $this->column_id;
    }

    public function getCode(): string
    {
        return $this->code;
    }

    protected function tryInsert(): void
    {
        $stmt = self::PDO()->prepare('INSERT INTO `pb_system_diagnostic_virtual_chunk`(
                                         `block`, `row_id`, `column_id`, `protocol`, `code`
                                         ) VALUES (:block, :row_id, :column_id, :protocol, :code);');
        $stmt->bindValue(':block', $this->block, PDO::PARAM_INT|PDO::PARAM_NULL);
        $stmt->bindValue(':row_id', $this->row_id, PDO::PARAM_INT);
        $stmt->bindValue(':column_id', $this->column_id, PDO::PARAM_INT);
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->execute();
    }

    protected function tryUpdate(): void
    {
        $stmt = self::PDO()->prepare('UPDATE `pb_system_diagnostic_virtual_chunk` SET
                 `code`=:new_code,
                 `block`=:block, 
                 `row_id`=:row_id, 
                 `column_id`=:column_id
            WHERE `protocol`=:protocol AND `code`=:code;');
        $stmt->bindValue(':new_code', $this->new_code ?? $this->code);
        $stmt->bindValue(':block', $this->block, PDO::PARAM_INT|PDO::PARAM_NULL);
        $stmt->bindValue(':row_id', $this->row_id, PDO::PARAM_INT);
        $stmt->bindValue(':column_id', $this->column_id, PDO::PARAM_INT);
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->execute();
        $this->code = $this->new_code ?? $this->code;
    }

    protected function tryDelete(): void
    {
        // TODO: Implement tryDelete() method.
    }

    public static function fromDataBase(?int $block, int $row_id, int $column_id, int $protocol, string $code): self
    {
        return (new self($block, $row_id, $column_id, $protocol,$code))->setToExists();
    }

    /**
     * @throws DBException
     */
    public static function dbFind(int $protocol, string $code): self
    {
        $stmt = self::PDO()->prepare('SELECT `block`, `row_id`, `column_id`, `protocol`, `code`
            FROM `pb_system_diagnostic_virtual_chunk`
            WHERE `protocol`=:protocol
              AND `code`=:code;');
        $stmt->bindValue(':protocol', $protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $code);
        $stmt->execute();
        return self::PDOObjectInspect($stmt->fetchAll(PDO::FETCH_FUNC, self::fromDataBase(...))[0] ?? null);
    }
}