<?php

namespace Horizon\ProtocolBuilder\DataBase;

use Horizon\ProtocolBuilder\Exceptions\DBEx;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use PDO;

abstract class ConnectedToDataBase
{
    private static PDO $entry_point;


    /**
     * @throws DBException
     */
    final protected static function PDO(): PDO
    {
        return self::$entry_point ?? (self::$entry_point = MySQL::connect());
    }

    /**
     * @throws DBException
     */
    final protected static function PDOInspect(array|false $result): array
    {
        if ($result === false) throw new DBException(DBEx::badStatement);
        return $result;
    }

    /**
     * @throws DBException
     */
    final protected static function PDOObjectInspect(mixed $result): mixed
    {
        if ($result === false) throw new DBException(DBEx::badStatement);
        if (is_null($result)) throw new DBException(DBEx::notData);
        return $result;
    }
}