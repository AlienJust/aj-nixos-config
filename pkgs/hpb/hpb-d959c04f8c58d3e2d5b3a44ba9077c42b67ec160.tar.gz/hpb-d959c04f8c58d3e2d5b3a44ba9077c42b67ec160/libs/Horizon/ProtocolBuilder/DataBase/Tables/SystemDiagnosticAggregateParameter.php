<?php

namespace Horizon\ProtocolBuilder\DataBase\Tables;

use Horizon\ProtocolBuilder\DataBase\dbTable;
use Horizon\ProtocolBuilder\DataBase\eTable;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use PDO;

class SystemDiagnosticAggregateParameter extends dbTable
{
    protected static eTable $db_table = eTable::pb_system_diagnostic_aggregate_parameter;

    protected int $chunk;
    protected int $protocol;
    protected string $code;
    protected int $sort;

    public function __construct(int $chunk, int $protocol, string $code, int $sort)
    {
        $this->chunk = $chunk;
        $this->protocol = $protocol;
        $this->code = $code;
        $this->sort = $sort;
        $this->exists = $this->exists ?? false;
    }

    public function setCode(string $code): self
    {
        $this->code = $code;
        return $this;
    }

    public function setSort(int $sort): self
    {
        $this->sort = $sort;
        return $this;
    }

    public function getCode(): string
    {
        return $this->code;
    }

    public function getSort(): int
    {
        return $this->sort;
    }

    protected function tryInsert(): void
    {
        $stmt = self::PDO()->prepare('INSERT INTO `pb_system_diagnostic_aggregate_parameter`(
                                         `chunk`, `protocol`, `code`, `sort`
                                         ) VALUES (:chunk, :protocol, :code, :sort) 
                                        ON DUPLICATE KEY UPDATE `sort`=:sort;');
        $stmt->bindValue(':chunk', $this->chunk, PDO::PARAM_INT);
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->bindValue(':sort', $this->sort, PDO::PARAM_INT);
        $stmt->execute();
    }

    protected function tryUpdate(): void
    {
        $this->tryInsert();
    }

    protected function tryDelete(): void
    {
        $stmt = self::PDO()->prepare('DELETE FROM `pb_system_diagnostic_aggregate_parameter`
                WHERE chunk=:chunk 
                  AND protocol=:protocol 
                  AND code=:code;');
        $stmt->bindValue(':chunk', $this->chunk, PDO::PARAM_INT);
        $stmt->bindValue(':protocol', $this->protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $this->code);
        $stmt->execute();
    }

    public static function fromDataBase(int $chunk, int $protocol, string $code, int $sort): self
    {
        return (new self($chunk, $protocol, $code, $sort))->setToExists();
    }

    /**
     * @throws DBException
     */
    public static function dbFind(int $protocol, int $chunk, string $code): self
    {
        $stmt = self::PDO()->prepare('SELECT `chunk`, `protocol`, `code`, `sort`
            FROM `pb_system_diagnostic_aggregate_parameter`
            WHERE `chunk`=:chunk
              AND `protocol`=:protocol
              AND `code`=:code;');
        $stmt->bindValue(':chunk', $chunk, PDO::PARAM_INT);
        $stmt->bindValue(':protocol', $protocol, PDO::PARAM_INT);
        $stmt->bindValue(':code', $code);
        $stmt->execute();
        return self::PDOObjectInspect($stmt->fetchAll(PDO::FETCH_FUNC, self::fromDataBase(...))[0] ?? null);
    }
}