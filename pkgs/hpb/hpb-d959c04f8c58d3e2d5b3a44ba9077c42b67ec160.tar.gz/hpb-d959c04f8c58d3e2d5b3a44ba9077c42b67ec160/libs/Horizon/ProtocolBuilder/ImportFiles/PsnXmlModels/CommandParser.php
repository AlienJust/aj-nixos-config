<?php

namespace Horizon\ProtocolBuilder\ImportFiles\PsnXmlModels;

use Horizon\ProtocolBuilder\Data\eParameterType;
use Horizon\ProtocolBuilder\DataBase\Tables\Command;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToReply;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToRequest;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\Exceptions\VException;

class CommandParser
{
    private array $subscribers_list;
    private string $name;
    private int $request_length;
    private int $request_start;
    private bool $request_required;
    private int $reply_length;
    private int $reply_start;

    /** @var ParameterParser[] $request_parameters */
    private array $request_parameters = [];
    /** @var ParameterParser[] $reply_parameters */
    private array $reply_parameters = [];

    private int $subscriber;

    public function __construct(array $subscribers_list, string $name)
    {
        $this->subscribers_list = $subscribers_list;
        $this->name = $name;
    }

    public function setRequest(int $length, int $start): void
    {
        $this->request_length = $length;
        $this->request_start = $start;
    }

    public function setReply(int $length, int $start, bool $request_required): void
    {
        $this->reply_length = $length;
        $this->reply_start = $start;
        $this->request_required = $request_required;
    }

    public function addParameter(ParameterParser $tag): void
    {
        if (isset($this->reply_length)) $this->reply_parameters[] = $tag;
        else {
            $this->request_parameters[] = $tag;
            if ($tag->type == eParameterType::DefVal->value && $tag->name == '#ADDR')
                $this->subscriber = $this->subscribers_list[hexdec($tag->value)];
        }
    }

    /**
     * @throws DBException
     * @throws VException
     */
    public function upload(): void
    {
        if (!isset($this->subscriber)) return;
        $command = Command::dbFind($this->subscriber, $this->name)
            ->setRequest($this->request_length, $this->request_start, 0)
            ->setReply($this->reply_length, $this->reply_start, 0, $this->request_required)
            ->dbInsertUpdate()
            ->getID();
        foreach ($this->request_parameters as &$parameter) {
            ParameterToRequest::dbLoad($parameter->GUID, $command)
                ->setName($parameter->name)
                ->setType($parameter->type)
                ->setByteOrder($parameter->byte_order)
                ->setBits($parameter->bits)
                ->setValue($parameter->value)
                ->setValueInverted($parameter->value_inverted)
                ->setLowestDigitPrice($parameter->lowest_digit_price)
                ->setSigned($parameter->signed)
                ->dbInsertUpdate();

        }
        foreach ($this->reply_parameters as &$parameter) {
            ParameterToReply::dbLoad($parameter->GUID, $command)
                ->setName($parameter->name)
                ->setType($parameter->type)
                ->setByteOrder($parameter->byte_order)
                ->setBits($parameter->bits)
                ->setValue($parameter->value)
                ->setValueInverted($parameter->value_inverted)
                ->setLowestDigitPrice($parameter->lowest_digit_price)
                ->setSigned($parameter->signed)
                ->dbInsertUpdate();
        }
    }
}