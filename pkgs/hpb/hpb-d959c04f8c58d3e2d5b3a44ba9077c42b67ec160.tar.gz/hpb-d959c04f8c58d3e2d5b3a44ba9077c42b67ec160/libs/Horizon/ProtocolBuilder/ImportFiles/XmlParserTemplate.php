<?php

namespace Horizon\ProtocolBuilder\ImportFiles;

use XMLParser;

abstract class XmlParserTemplate
{
    protected readonly XMLParser $parser;

    public function __construct()
    {
        $this->parser = xml_parser_create();
        xml_set_object($this->parser, $this);
        xml_set_element_handler($this->parser, "onTagOpenHandler", "onTagCloseHandler");
        xml_set_character_data_handler($this->parser, "onCharacterDataHandler");
    }

    final public function parse($data): void
    {
        xml_parse($this->parser, $data);
    }

    abstract function onTagOpenHandler(XMLParser $parser, string $tag, array $attributes): void;
    abstract function onCharacterDataHandler(XMLParser $parser, string $cdata): void;
    abstract function onTagCloseHandler(XMLParser $parser, string $tag): void;

    final public function __destruct()
    {
        xml_parse($this->parser, '', true);
        xml_parser_free($this->parser);
    }
}