<?php

namespace Horizon\ProtocolBuilder\ImportFiles;

use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\DataBase\Tables\Subscriber;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\ImportFiles\PsnXmlModels\CommandParser;
use Horizon\ProtocolBuilder\ImportFiles\PsnXmlModels\ParameterParser;
use XMLParser;

class PsnXmlParser extends XmlParserTemplate
{
    private Protocol $protocol;
    private array $subscribers;
    private CommandParser $command_parser;

    public function refProtocol(): Protocol
    {
        return $this->protocol;
    }

    /**
     * @throws DBException
     * @throws VException
     */
    function onTagOpenHandler(XMLParser $parser, string $tag, array $attributes): void
    {

        switch (ePsnXmlTag::tryFrom($tag)) {
            case ePsnXmlTag::PSNCONFIGURATION:
                $this->protocol = Protocol::dbFind($attributes['ID'] ?? null)
                    ->setName($attributes['NAME'] ?? '')
                    ->setVersion($attributes['VERSION'] ?? '')
                    ->setDescription($attributes['DESCRIPTION'] ?? '')
                    ->dbInsertUpdate();
                break;
            case ePsnXmlTag::PSNMETER:
                var_dump($tag, $attributes);
                $this->subscribers[hexdec($attributes['ADDRESS'] ?? '')] = Subscriber::dbFind(
                    $this->protocol->getID(),
                    hexdec($attributes['ADDRESS'] ?? ''),
                    $attributes['NAME'] ?? ''
                )->dbInsertUpdate()->getID();
                break;
            case ePsnXmlTag::CMDMASK:
                $this->command_parser = new CommandParser($this->subscribers, $attributes['NAME'] ?? '');
                break;
            case ePsnXmlTag::REQUEST:
                $this->command_parser->setRequest(
                    $attributes['LENGTH'] ?? 0,
                    $attributes['POSITION'] ?? 0
                );
                break;
            case ePsnXmlTag::REPLY:
                $this->command_parser->setReply(
                    $attributes['LENGTH'] ?? 0,
                    $attributes['POSITION'] ?? 0,
                    $attributes['ISREQUESTREQUIRED'] ?? false
                );
                break;
            case ePsnXmlTag::DEFVAL:
                $this->command_parser->addParameter(ParameterParser::fromDefVal(
                    (int)$attributes['POSITION'] ?? 0,
                    (int)$attributes['LENGTH'] ?? 0,
                    $attributes['VALUE'] ?? null,
                    $attributes['NAME'] ?? '',
                    $attributes['ID'] ?? ''
                ));
                break;
            case ePsnXmlTag::VARVAL:
                $this->command_parser->addParameter(ParameterParser::fromVarVal(
                    (int)$attributes['POSITION'] ?? 0,
                    (int)$attributes['LENGTH'] ?? 0,
                    $attributes['NAME'] ?? '',
                    $attributes['ID'] ?? ''
                ));
                break;
            case ePsnXmlTag::BITPRM:
                $this->command_parser->addParameter(ParameterParser::fromBitPrm(
                    (int)$attributes['BYTE'] ?? '',
                    (int)$attributes['BIT'] ?? '',
                    ($attributes['ISVALUEINVERTED'] ?? 'False') == 'True',
                    $attributes['NAME'] ?? '',
                    $attributes['ID'] ?? ''
                ));
                break;
            case ePsnXmlTag::CPZPRM:
                $this->command_parser->addParameter(ParameterParser::fromCpzPrm(
                    $attributes['EXPRESSION'] ?? '',
                    $attributes['NAME'] ?? '',
                    $attributes['ID'] ?? ''
                ));
        }
    }

    function onCharacterDataHandler(XMLParser $parser, string $cdata): void
    {
        // в нашем файле нет текстовых данных внутри тегов
    }

    /**
     * @throws DBException
     * @throws VException
     */
    function onTagCloseHandler(XMLParser $parser, string $tag): void
    {
        switch (ePsnXmlTag::tryFrom($tag)) {
            case ePsnXmlTag::CMDMASK:
                $this->command_parser->upload();
                unset($this->command_parser);
                break;
        }
    }
}