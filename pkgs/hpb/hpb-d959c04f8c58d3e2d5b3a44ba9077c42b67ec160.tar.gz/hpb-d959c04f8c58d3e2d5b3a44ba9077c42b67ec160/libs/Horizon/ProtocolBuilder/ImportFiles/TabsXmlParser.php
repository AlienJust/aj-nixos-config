<?php

namespace Horizon\ProtocolBuilder\ImportFiles;

use Exception;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterView;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterViewInjection;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterViewInjectValue;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterViewNumber;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterViewValue;
use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use XMLParser;

class TabsXmlParser extends XmlParserTemplate
{
    private readonly Protocol $protocol;
    private ?ParameterView $current_parameter_view;

    public function __construct(Protocol $protocol)
    {
        parent::__construct();
        $this->protocol = $protocol;
    }

    function onTagOpenHandler(XMLParser $parser, string $tag, array $attributes): void
    {
        switch (eTabsXmlTag::tryFrom($tag)) {
            case eTabsXmlTag::PARAMETER:
                try {
                    $this->current_parameter_view = ParameterView::dbLoad($this->protocol->getID(), $attributes['KEY'])
                        ->setIdentifier($attributes['IDENTIFIER'])
                        ->setComment($attributes['COMMENT'] ?? '')
                        ->setCustomName($attributes['CUSTOMNAME'] ?? null)
                        ->dbInsertUpdate();
                } catch (Exception) {
                    //echo $attributes['KEY'];
                }
                break;
            case eTabsXmlTag::NUMBERVIEW:
                try {
                    if ($attributes['EXPRESSION'] == "[value]")
                        $this->current_parameter_view->setFormat($attributes['STRINGFORMAT'])->dbUpdate();
                    else {
                        $this->current_parameter_view->addViewNumber((new ParameterViewNumber(
                            $this->protocol->getID(),
                            $this->current_parameter_view->getCode(),
                            $this->current_parameter_view->getNexIDForViewNumbers()
                        ))->setExpression($attributes['EXPRESSION'])
                            ->setFormat($attributes['STRINGFORMAT'])
                            ->setColor($attributes['COLOR'] ?? null)
                        )->dbUpdate();
                    }
                } catch (Exception) {
                }
                break;
            case eTabsXmlTag::BOOLEANVIEW:
                try {
                    (new ParameterViewValue(
                        $this->current_parameter_view->getProtocol(),
                        $this->current_parameter_view->getCode(),
                        $this->current_parameter_view->countViewValues()
                    ))->setExpression($attributes['EXPRESSION'])
                        ->setResultTrue($attributes['RESULTTRUE'])
                        ->setResultFalse($attributes['RESULTFALSE'])
                        ->setColor($attributes['COLOR'] ?? null)
                        ->dbInsert();
                } catch (Exception) {
                }
                break;
            case eTabsXmlTag::INJECTION:
                try {
                    (new ParameterViewInjection(
                        $this->current_parameter_view->getProtocol(),
                        $this->current_parameter_view->getCode()
                    ))->setParamNumberInPackage($attributes['PARAMNUMBERINPACKAGE'])
                        ->setConvertExpression($attributes['CONVERTEXPRESSION'])
                        ->setInvertBytesOrder($attributes['INVERTBYTESORDER'] == 'True')
                        ->dbInsert();
                } catch (Exception) {
                }
                break;
            case eTabsXmlTag::INJECTTEXTVALUE:
                try {
                    (new ParameterViewInjectValue(
                        $this->current_parameter_view->getProtocol(),
                        $this->current_parameter_view->getCode(),
                        $this->current_parameter_view->countViewInjectValues()
                    ))->setText($attributes['TEXT'])
                        ->setValue($attributes['VALUE'])
                        ->dbInsert();
                } catch (Exception) {
                }
                break;
            case eTabsXmlTag::MULTIVIEW:
                try {
                    if ($attributes['EXPRESSION'] != '{$value}')
                        $this->current_parameter_view->setMask($attributes['EXPRESSION'])->dbUpdate();
                } catch (Exception) {
                }
                break;
            //case eTabsXmlTag::PARAMETERS:
        }
    }

    function onCharacterDataHandler(XMLParser $parser, string $cdata): void
    {
        // TODO: Implement onCharacterDataHandler() method.
    }

    function onTagCloseHandler(XMLParser $parser, string $tag): void
    {
        // TODO: Implement onTagCloseHandler() method.
    }
}