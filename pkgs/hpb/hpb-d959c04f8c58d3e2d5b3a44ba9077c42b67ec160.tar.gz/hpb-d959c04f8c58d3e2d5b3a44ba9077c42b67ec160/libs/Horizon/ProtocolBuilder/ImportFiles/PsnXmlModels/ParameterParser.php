<?php

namespace Horizon\ProtocolBuilder\ImportFiles\PsnXmlModels;

use Horizon\ProtocolBuilder\Data\eParameterByteOrder;
use Horizon\ProtocolBuilder\Data\eParameterType;

final class ParameterParser
{
    public readonly string $GUID;
    public readonly int $command;
    public readonly string $name;
    public readonly string $type;
    public readonly ?string $byte_order;
    public readonly array $bits;
    public readonly float $lowest_digit_price;
    public readonly bool $signed;
    public readonly ?string $value;
    public readonly bool $value_inverted;

    private function __construct(string $GUID, string $name, string $type, array $bits,
                                 float $lowest_digit_price = 1, bool $signed = false,
                                 ?eParameterByteOrder $byte_order = null,
                                 ?string $value = null, bool $value_inverted = false)
    {
        $this->GUID = $GUID;
        $this->name = $name;
        $this->type = $type;
        $this->byte_order = $byte_order?->value;
        $this->bits = $bits;
        $this->lowest_digit_price = $lowest_digit_price;
        $this->signed = $signed;
        $this->value = $value;
        $this->value_inverted = $value_inverted;
    }

    public static function fromVarVal(int $position, int $length, string $name, string $GUID): self
    {
        return new self($GUID, $name, eParameterType::VarVal->value,
            range($position * 8, $position * 8 + $length - 1));
    }

    public static function fromDefVal(int $position, int $length, ?string $value, string $name, string $GUID): self
    {
        return new self($GUID, $name, eParameterType::DefVal->value,
            range($position * 8, $position * 8 + $length - 1), 1, false, null, $value);
    }

    public static function fromBitPrm(int $byte, int $bit, bool $is_value_inverted, string $name, string $GUID): self
    {
        return new self($GUID, $name, eParameterType::BitPrm->value,
            [($byte + 1) * 8 - ($bit + 1)], 1, false,null, null, $is_value_inverted);
    }

    public static function fromCpzPrm(string $expression, string $name, string $GUID): self
    {
        $signed = false;
        $expression = str_replace(' ', '', $expression);
        preg_match_all('/\[(.+?)]/', $expression, $bytes);
        $bits = [];
        // @todo: при импорте обрабатывается только порядок HiLo, LoHi игнорируется!
        foreach ($bytes[1] as &$byte) {
            $first_symbol = mb_substr($byte, 0, 1);
            if (is_numeric($first_symbol)) {
                list($byte, $bit, $count) = explode('.', $byte);
                $bits = range($byte * 8 + 8 - $bit - $count, $byte * 8 + 8 - $bit - 1);
            } else {
                if ($first_symbol == 's') $signed = true;
                $byte = (int)mb_substr($byte, 1);
                $bits = array_merge($bits, range($byte * 8, ($byte + 1) * 8 - 1));
            }
        }
        $strings = explode('*', $expression);
        $price_of_the_lowest_digit = array_pop($strings);
        if (!is_numeric($price_of_the_lowest_digit)) $price_of_the_lowest_digit = 1;

        $byte_order = null;
        if (str_contains($expression, '256')) {
            $formula = preg_replace('/\s*/', '', $expression);
            print_r($formula);
            $byte_order = (str_contains($formula, '*256.0+') || str_contains($formula, '*256+'))
                ? eParameterByteOrder::HiLo
                : eParameterByteOrder::LoHi;
        }

        return new self($GUID, $name, eParameterType::CpzPrm->value, $bits, $price_of_the_lowest_digit, $signed, $byte_order);
    }
}