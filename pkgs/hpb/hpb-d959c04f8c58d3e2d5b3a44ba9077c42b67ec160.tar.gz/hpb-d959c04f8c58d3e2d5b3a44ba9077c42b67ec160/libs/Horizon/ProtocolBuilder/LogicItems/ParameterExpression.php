<?php

namespace Horizon\ProtocolBuilder\LogicItems;

use Horizon\ProtocolBuilder\Data\eParameterByteOrder;

class ParameterExpression
{
    private bool $is_signed;
    private ?string $lowest_digit_price;
    private ?string $formula;
    private ?eParameterByteOrder $byte_order;

    public readonly string $value;
    public function __construct(array $bits, bool $is_signed, float $lowest_digit_price, ?string $byte_order, ?string $formula)
    {
        $this->lowest_digit_price = $lowest_digit_price == 1 ? null
            : (' * ' . ($lowest_digit_price == floor($lowest_digit_price)
                    ? sprintf("%01.1f", $lowest_digit_price)
                    : $lowest_digit_price));
        $this->formula = $formula;
        $this->byte_order = eParameterByteOrder::tryFrom($byte_order ?? '');
        $this->is_signed = $is_signed;

        $this->initValue($bits);
    }

    private function applyFormula(string $x): string
    {
        $x = is_null($this->formula) ? $x : str_replace('x', "($x)", $this->formula);
        if (!is_null($this->lowest_digit_price)) $x = "($x)$this->lowest_digit_price";
        return $x;
    }
/*
    private function initForMultiBytes(array $bits): void
    {
        $max_index = $this->bits_count/8 - 1;
        $start = $bits[0]/8;
        $end = $start + $max_index;
        $bytes = range($start, $end);
        $exponents = match ($this->byte_order) {
            eParameterByteOrder::HiLo => range($max_index, 0, -1),
            default => range(0, $max_index), // LoHi
        };
        array_map(function($byte, $exponent) use ($max_index) {
            $sign = $exponent == $max_index ? $this->is_signed : 'u';
            $power = $max_index > 0 && $exponent == 0 ? ''
                : sprintf("* %01.1f", pow(256, $exponent));
            return "[$sign$byte]$power";
        }, $bytes, $exponents);
        $this->value = $this->applyFormula(implode(' + ', $bytes));
    }

    private function initForSomeBits(array $bits): void
    {
        $byte = floor($bits[0]/8);
        $bit_number = 7 - end($bits) % 8;
        $this->value = $this->applyFormula("[$byte.$bit_number.$this->bits_count]");
    }

    private function prepareBytes(array $bits): array
    {

    }
*/
    private function initValue(array $bits): void
    {
        /** @var ValueByte[] $bytes */
        $bytes = [];
        foreach ($bits as $key => $bit) {
            if ($key == 0) $bytes[] = new ValueByte($bit);
            else {
                $byte = end($bytes)->addBit($bit);
                if ($byte instanceof ValueByte) $bytes[] = $byte;
            }
        }
        if ($this->byte_order == eParameterByteOrder::HiLo) {
            $bytes = array_reverse($bytes);
            foreach ($bytes as $byte) $byte->reverse();
        }
        $exponent = 0;
        end($bytes)->setSign($this->is_signed);
        $hide_null_exponent = count($bytes) > 1;
        foreach ($bytes as &$byte) {
            $byte = $byte->draw($exponent, $hide_null_exponent);
        }
        if ($this->byte_order == eParameterByteOrder::HiLo) {
            $bytes = array_reverse($bytes);
        }
        $this->value = $this->applyFormula(implode(' + ', $bytes));
    }
}