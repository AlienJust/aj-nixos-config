<?php

namespace Horizon\ProtocolBuilder\LogicItems;

class StringToNullHandler
{
    private function __construct()
    {
    }

    public static function run(?string $text): ?string
    {
        if (is_string($text)) {
            $text = trim($text);
            if ($text == '') $text = null;
        }
        return $text;
    }
}