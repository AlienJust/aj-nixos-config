<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Exception;
use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandNameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandReplyHeaderLengthTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandReplyLengthTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandRequestHeaderLengthTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandRequestLengthTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandSystemTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\DeleteButton;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\UpdatingButton;
use Horizon\UserInterface\PresetTags\Division2Columns;
use Horizon\UserInterface\PresetTags\PostViewMatrix;
use Horizon\UserInterface\Tags\Header;
use Horizon\UserInterface\Tags\HorizontalRule;
use Horizon\UserInterface\Tags\LineBreak;
use Horizon\UserInterface\Tags\Paragraph;
use Horizon\UserInterface\Tags\Trace;

class CommandEditing extends _PageContentTag
{
    public function __construct(string $header, string $action_URL, string $name, bool $system,
                                int $request_length, int $reply_length,
                                int $request_header_length, int $reply_header_length,
                                array $request_params, array $reply_params)
    {
        parent::__construct($header);
        $this->add($request_tag = new PostViewMatrix($request_length))
            ->add($reply_tag = new PostViewMatrix($reply_length))
            ->add((new MainForm($action_URL))
                ->add(new CommandNameTag($name))
                ->add((new Division2Columns())
                    ->add(new CommandRequestLengthTag($request_length))
                    ->add(new CommandRequestHeaderLengthTag($request_header_length))
                    ->add(new CommandReplyLengthTag($reply_length))
                    ->add(new CommandReplyHeaderLengthTag($reply_header_length)))
                ->add(new CommandSystemTag($system))
                ->add(new UpdatingButton()));
        foreach ($request_params as $param) $request_tag->setParameter($param['name'], $param['bits']);
        foreach ($reply_params as $param) $reply_tag->setParameter($param['name'], $param['bits']);
    }

    public function setDelete(string $action_URL): static
    {
        try {
            $this->add(new LineBreak())
                ->add(new HorizontalRule())
                ->add(new Header(2, 'Удаление команды'))
                ->add((new MainForm($action_URL))
                    ->add(new Paragraph('Чтобы удалить команду, нажмите кнопку ниже:'))
                    ->add(new DeleteButton()));
        } catch (Exception $exception) {
            $this->add(new Trace($exception));
        }

        return $this;
    }
}