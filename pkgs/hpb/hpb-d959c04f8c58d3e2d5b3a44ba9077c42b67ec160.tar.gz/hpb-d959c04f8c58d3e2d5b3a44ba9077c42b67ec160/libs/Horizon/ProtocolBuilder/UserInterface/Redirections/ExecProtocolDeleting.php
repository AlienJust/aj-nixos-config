<?php

namespace Horizon\ProtocolBuilder\UserInterface\Redirections;

use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Protocol;
use Horizon\UserInterface\Redirection;

class ExecProtocolDeleting extends Redirection
{
    /**
     * @throws DBException
     */
    public function __construct(Protocol $protocol)
    {
        $protocol->dbDelete();
        parent::__construct(eUISA_Protocol::new->controller()->getURL());
    }
}