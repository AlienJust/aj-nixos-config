<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields;

use Horizon\ProtocolBuilder\Exceptions\UIEx;
use Horizon\ProtocolBuilder\Exceptions\UIException;
use Horizon\ProtocolBuilder\Exceptions\UploadException;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputModels\TempFile;

enum eProtocolField implements iTransmissionField
{
    case name;
    case description;
    case version;
    case GUID;
    case psn_file;
    case tabs_file;
    case parameter_views;
    case summon_system_diagnostic_block_counter;
    case summon_system_diagnostic_virtual_parameter_counter;
    case summon_system_diagnostic_aggregate_group_counter;
    case summon_system_diagnostic_aggregate_parameter_counter;
    case blocks;
    case block_id;
    case block_name;
    case block_columns_count;
    case block_inline;
    case diagnostic_list;
    case parameter_view;
    case parameter_view_name;
    case virtual_parameters;
    case virtual_parameter_code;
    case virtual_parameter_new_code;
    case aggregate_groups;
    case aggregate_group_counter;
    case aggregate_group_id;
    case aggregate_group_label;
    case aggregate_parameters;
    case aggregate_parameter_code;

    public function code(mixed ...$options): string
    {
        return match ($this) {
            self::name,
            self::description,
            self::version,
            self::GUID,
            self::psn_file,
            self::tabs_file,
            self::parameter_views,
            self::summon_system_diagnostic_block_counter,
            self::summon_system_diagnostic_virtual_parameter_counter,
            self::summon_system_diagnostic_aggregate_group_counter,
            self::blocks,
            self::virtual_parameters,
            self::aggregate_groups,
            self::parameter_view => $this->name,
            self::block_id => self::blocks->code() . "[$options[0]][id]",
            self::block_name => self::blocks->code() . "[$options[0]][name]",
            self::block_columns_count => self::blocks->code() . "[$options[0]][columns_count]",
            self::block_inline => self::blocks->code() . "[$options[0]][inline]",
            self::diagnostic_list => $this->name . "[]",
            self::parameter_view_name => self::parameter_view->code() . "[$options[0]][name]",
            self::virtual_parameter_code => self::virtual_parameters->code() . "[$options[0]][code]",
            self::virtual_parameter_new_code => self::virtual_parameters->code() . "[$options[0]][new_code]",
            self::aggregate_group_counter => self::aggregate_groups->code() ."[$options[0]][counter]",
            self::aggregate_group_id => self::aggregate_groups->code() ."[$options[0]][id]",
            self::aggregate_group_label => self::aggregate_groups->code() ."[$options[0]][label]",
            self::summon_system_diagnostic_aggregate_parameter_counter => self::aggregate_groups->code() ."[$options[0]][parameter_counter]",
            self::aggregate_parameters => self::aggregate_groups->code() ."[$options[0]][parameters]",
            self::aggregate_parameter_code => self::aggregate_groups->code() ."[$options[0]][parameters][$options[1]][code]",
        };
    }

    /**
     * @throws UploadException
     */
    public function get(array $post): null|string|array|bool|TempFile
    {
        return match ($this) {
            self::name,
            self::description,
            self::version,
            self::GUID => $post[$this->code()] ?? '',
            self::psn_file, self::tabs_file => TempFile::fromFILES($_FILES[$this->code()]),
            self::parameter_views => array_keys($post[$this->code()] ?? []),
            self::summon_system_diagnostic_block_counter,
            self::summon_system_diagnostic_virtual_parameter_counter,
            self::summon_system_diagnostic_aggregate_group_counter => $post[$this->code()] ?? 0,
            self::blocks,
            self::virtual_parameters,
            self::aggregate_groups,
            self::diagnostic_list,
            self::parameter_view => $post[$this->name] ?? [],
            self::block_id,
            self::aggregate_group_id => $post['id'] ?? null,
            self::aggregate_group_counter => $this->getFromArrayProperties($post, '/^' .self::aggregate_groups->code() . '\{(.*)\}\{counter\}$/i') ?? 0,
            self::block_name,
            self::parameter_view_name => $post['name'] ?? '',
            self::block_columns_count => $post['columns_count'] ?? 1,
            self::block_inline => $post['inline'] ?? 0 == 1,
            self::virtual_parameter_code => $post['code'] ?? '',
            self::virtual_parameter_new_code => $post['new_code'] ?? '',
            self::aggregate_group_label => $post['label'] ?? '',
            self::summon_system_diagnostic_aggregate_parameter_counter => $this->getFromArrayProperties($post, '/^' .self::aggregate_groups->code() . '\{(.*)\}\{parameter_counter\}$/i') ?? 0,
            self::aggregate_parameters => $post['parameters'] ?? [],
            self::aggregate_parameter_code => $post['code'] ?? [],
        };
    }

    private function getFromArrayProperties(array $properties, string $pattern): null|string|array|bool|TempFile
    {
        foreach ($properties as $name => $value) if (preg_match($pattern, $name))
            return $value;
        return null;
    }
}
