<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandInitWayTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandNameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandReplyHeaderLengthTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandReplyLengthTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandRequestHeaderLengthTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandRequestLengthTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandSystemTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\CreationButton;
use Horizon\UserInterface\PresetTags\Division2Columns;

class CommandCreation extends _PageContentTag
{
    public function __construct(string $header, string $action_URL, string $name, bool $system,
                                int $request_length, int $reply_length,
                                int $request_header_length, int $reply_header_length)
    {
        parent::__construct($header);
        $this->add((new MainForm($action_URL))
            ->add(new CommandNameTag($name))
            ->add((new Division2Columns())
                ->add(new CommandRequestLengthTag($request_length))
                ->add(new CommandRequestHeaderLengthTag($request_header_length))
                ->add(new CommandReplyLengthTag($reply_length))
                ->add(new CommandReplyHeaderLengthTag($reply_header_length)))
            ->add(new CommandSystemTag($system))
            ->add(new CommandInitWayTag())
            ->add(new CreationButton()));
    }
}