<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Exception;
use Horizon\UserInterface\Tags\Trace;

class ExceptionView extends _PageContentTag
{
    public function __construct(Exception $exception)
    {
        parent::__construct('Произошла ошибка');
        $this->add(new Trace($exception));
    }
}