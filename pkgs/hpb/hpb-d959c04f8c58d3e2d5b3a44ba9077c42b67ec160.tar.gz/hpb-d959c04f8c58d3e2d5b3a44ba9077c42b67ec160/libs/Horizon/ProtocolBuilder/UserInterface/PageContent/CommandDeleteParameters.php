<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection\CommandParameterCheckboxTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\DeleteButton;
use Horizon\UserInterface\PresetTags\Division2Columns;
use Horizon\UserInterface\Tags\Division;
use Horizon\UserInterface\Tags\Header;
use Horizon\UserInterface\TagsPack;

class CommandDeleteParameters extends _PageContentTag
{
    public function __construct(string $header, string $action_URL, array $request_parameters, array $reply_parameters)
    {
        parent::__construct($header);
        $request_tag = (new TagsPack())->add(new Header(2, 'Запрос'));
        foreach ($request_parameters as $GUID => $name) $request_tag->add(new CommandParameterCheckboxTag($GUID, $name));
        $reply_tag = (new TagsPack())->add(new Header(2, 'Ответ'));
        foreach ($reply_parameters as $GUID => $name) $reply_tag->add(new CommandParameterCheckboxTag($GUID, $name));
        $this->add((new MainForm($action_URL))
            ->add((new Division)->add((new Division2Columns())->add($request_tag)->add($reply_tag)))
            ->add(new DeleteButton())
        );
    }
}