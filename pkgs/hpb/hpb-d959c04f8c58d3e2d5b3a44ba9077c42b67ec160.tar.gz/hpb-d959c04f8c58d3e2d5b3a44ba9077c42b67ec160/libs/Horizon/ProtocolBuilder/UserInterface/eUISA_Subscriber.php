<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_Subscriber;

enum eUISA_Subscriber: string implements iUISectionActionEnum
{
    case new = 'new';
    case edit = 'edit';
    case delete = 'delete';

    public function name(): string
    {
        return match ($this) {
            self::new => 'Создание абонента',
            self::edit => 'Изменение абонента',
            self::delete => 'Удаление абонента',
        };
    }

    public static function controlPanel(): array
    {
        return [
            'Изменить' => self::edit,
        ];
    }

    public function controller(array $post = []): UISection_Subscriber
    {
        return new UISection_Subscriber($this, $post);
    }
}