<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\Exceptions\UIEx;
use Horizon\ProtocolBuilder\Exceptions\UIException;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_Main;

enum eUISection: string
{
    case main = '';
    case protocol = 'protocol';
    case subscriber = 'subscriber';
    case command = 'command';
    //case parameter = 'parameter';
    case request_parameter = 'request_parameter';
    case reply_parameter = 'reply_parameter';

    public function name(): string
    {
        return match ($this) {
            self::main => '',
            self::protocol => 'Протоколы',
            self::subscriber => 'Абоненты',
            self::command => 'Команды',
            self::request_parameter, self::reply_parameter => 'Параметры',
        };
    }

    /**
     * @throws UIException
     */
    public function controller(string $action, array $post, array $files): UISection
    {
        return match ($this) {
            self::main => new UISection_Main(),
            self::protocol => eUISA_Protocol::tryFrom($action)->controller($post, $files),
            self::subscriber => eUISA_Subscriber::tryFrom($action)->controller($post),
            self::command => eUISA_Command::tryFrom($action)->controller($post),
            self::request_parameter => eUISA_RequestParameter::tryFrom($action)->controller($post),
            self::reply_parameter => eUISA_ReplyParameter::tryFrom($action)->controller($post),
            default => throw new UIException(UIEx::sectionNotImplemented)
        };
    }


}
