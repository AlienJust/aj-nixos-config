<?php

namespace Horizon\ProtocolBuilder\UserInterface\Redirections;

use Horizon\ProtocolBuilder\DataBase\Tables\Command;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Command;
use Horizon\UserInterface\Redirection;

class ExecCommandEditing extends Redirection
{
    /**
     * @throws DBException
     */
    public function __construct(Command $command, string $name, int $request_length, int $reply_length,
                                int $request_header_length, int $reply_header_length, bool $system)
    {
        $request_required = $reply_header_length == $request_header_length && $reply_length == $request_length;
        $command->setName($name)->setSystem($system);
        $command->setRequest($request_length, 0, $request_header_length);
        $command->setReply($reply_length, $request_length, $reply_header_length, $request_required);
        $command->dbUpdate();
        parent::__construct(eUISA_Command::edit->controller()->setCommand($command)->getURL());
    }
}