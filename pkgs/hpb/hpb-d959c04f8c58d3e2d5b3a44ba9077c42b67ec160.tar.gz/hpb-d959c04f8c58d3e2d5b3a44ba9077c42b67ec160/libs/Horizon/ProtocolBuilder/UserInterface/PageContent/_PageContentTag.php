<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\iTag;
use Horizon\UserInterface\Tags\Header;
use Horizon\UserInterface\Tags\HorizontalRule;
use Horizon\UserInterface\Tags\LineBreak;
use Horizon\UserInterface\TagsPack;

abstract class _PageContentTag extends TagsPack
{
    public function __construct(string $header, ?string $id = null)
    {
        parent::__construct();
        $this->add($header = new Header(1, $header));
        if (!is_null($id)) $header->addAttribute(Attribute::id, $id);
    }

    /**
     * @param string $header
     * @param iTag $tag
     * @return $this
     * @deprecated
     */
    public function addActionBlockDeprecated(string $header, iTag $tag): static
    {
        $this->add(new LineBreak())
            ->add(new HorizontalRule())
            ->add(new Header(2, $header))
            ->add($tag);
        return $this;
    }

    public function addActionBlock(_PageContentTag $page): static
    {
        $this->add(new LineBreak())
            ->add(new HorizontalRule())
            ->add($page);
        return $this;
    }
}