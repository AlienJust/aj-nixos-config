<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection;

use Horizon\ProtocolBuilder\DataBase\Tables\Command;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCommandField;
use Horizon\UserInterface\Controls\InputSelect;
use Horizon\UserInterface\HTMLException;

class CommandSourceTag extends InputSelect
{
    /**
     * @throws HTMLException
     * @throws DBException
     */
    public function __construct()
    {
        parent::__construct(eCommandField::source->code(), '',
            'Исходная команда для копирования',
            'Выберите команду, которую нужно скопировать');
        $this->addOptions(true, ...Command::arrList());//...array_map(fn(eCommandInitWay $case): Option => new Option($case->value, $case->label()), eCommandInitWay::cases()));
    }
}