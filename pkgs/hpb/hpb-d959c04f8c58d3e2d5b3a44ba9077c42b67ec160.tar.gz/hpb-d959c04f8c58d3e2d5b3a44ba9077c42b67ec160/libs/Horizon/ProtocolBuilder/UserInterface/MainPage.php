<?php
namespace Horizon\ProtocolBuilder\UserInterface;

use Horizon\ProtocolBuilder\UserInterface\PageContent\_PageContentTag;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputCheckbox;
use Horizon\UserInterface\Tags\Anchor;
use Horizon\UserInterface\Tags\Division;
use Horizon\UserInterface\Tags\Image;
use Horizon\UserInterface\Tags\Trace;
use Horizon\UserInterface\TagsPack;

class MainPage
{
    private array $CSS_links = [];
    private array $JS_scripts = [];
    private _PageContentTag $content;
    private bool $isHiddenSidebar = false;
    private TagsPack $first_menu;
    private TagsPack $second_menu;
    private TagsPack $third_menu;
    private TagsPack $fourth_menu;
    private TagsPack $path;
    private TagsPack $control_panel;

    private function __construct()
    {
        $this->first_menu = new TagsPack();
        $this->second_menu = new TagsPack();
        $this->third_menu = new TagsPack();
        $this->fourth_menu = new TagsPack();
        $this->path = new TagsPack();
        $this->control_panel = new TagsPack();
    }

    public function setCSS(string ...$links): static
    {
        $this->CSS_links = $links;
        return $this;
    }

    public function setJS(string ...$src): static
    {
        $this->JS_scripts = $src;
        return $this;
    }

    public function addPathItem(string $name, string $href = null): static
    {
        if (!$this->path->isEmpty()) $this->path->add('&nbsp;&nbsp; › &nbsp;&nbsp;');
        if (is_null($href)) $this->path->add($name);
        else $this->path->add(new Anchor($href, $name));
        return $this;
    }

    public function addControlPanelItem(string $name, string $href, bool $is_current = false): void
    {
        $this->control_panel->add($a = new Anchor($href, $name));
        if ($is_current) $a->addClass('current');
    }

    public function setContent(_PageContentTag $content): void
    {
        $this->content = $content;
    }

    public function setIsHiddenSidebar(bool $isHiddenSidebar): void
    {
        $this->isHiddenSidebar = $isHiddenSidebar;
    }

    private function setMenu(TagsPack $menu, string $name, Anchor|Trace ...$actions): Division
    {
        $block = new Division();
        $box = (new Division())->addClass('title-box');
        $menu->add($block->add($box->add((new Division($name))->addClass('title'))));
        foreach ($actions as &$action) $box->add($action);
        return $block;
    }

    public function setFirstMenu(string $name, Anchor|Trace ...$items): Division
    {
        return $this->setMenu($this->first_menu, $name, ...$items);
    }

    public function setSecondMenu(string $name, Anchor|Trace ...$items): Division
    {
        return $this->setMenu($this->second_menu, $name, ...$items);
    }

    public function setThirdMenu(string $name, Anchor|Trace ...$items): Division
    {
        return $this->setMenu($this->third_menu, $name, ...$items);
    }

    public function setFourthMenu(string $name, Anchor|Trace ...$items): Division
    {
        return $this->setMenu($this->fourth_menu, $name, ...$items);
    }

    private function drawCSSLinks(): string
    {
        return implode("\n",
            array_map(fn($href) => '<link rel="stylesheet" type="text/css" href="' . $href . '" />', $this->CSS_links));
    }

    private function drawJSScripts(): string
    {
        return implode("\n",
            array_map(fn($src) => '<script type="text/javascript" src="' . $src . '"></script>', $this->JS_scripts));
    }

    private function drawSidebar(): string
    {
        return (new TagsPack)
            ->add((new Division())->addClass('sidebar'
                . (!$this->first_menu->isEmpty() && $this->third_menu->isEmpty() ? ' current' : ''))
                ->addAttribute(Attribute::id, 'protocols')
                ->add((new Anchor("/", null))->addClass('main')
                    ->add((new Image('/styles/images/logo_light.png'))->addClass('logo')
                        ->addAttribute(Attribute::alt, 'ООО НПО Горизонт')))
                ->add($this->first_menu))
            ->add((new Division())->addClass('sidebar'
                . (!$this->second_menu->isEmpty() && $this->fourth_menu->isEmpty() ? ' current' : ''))
                ->addAttribute(Attribute::id, 'subscribers')
                ->add($this->second_menu))
            ->add((new Division())->addClass('sidebar'
                . (!$this->third_menu->isEmpty() && $this->fourth_menu->isEmpty() ? ' current' : ''))
                ->addAttribute(Attribute::id, 'commands')
                ->add($this->third_menu))
            ->add((new Division())->addClass('sidebar'
                . (!$this->fourth_menu->isEmpty() ? ' current' : ''))
                ->addAttribute(Attribute::id, 'parameters')
                ->add($this->fourth_menu))
            ->draw();
    }

    public function draw(): string
    {//<label class="sidebar-button" for="hamburger" onclick="Array.from(document.getElementsByClassName(\'sidebar\')).forEach(x => x.removeAttribute(\'style\'));">
        return '<!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <meta http-equiv="Content-Language" content="ru"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title></title>' . $this->drawCSSLinks() . $this->drawJSScripts() . '
        <script type="text/javascript" src="/js/horizon.js"></script>
        <script>
            window.onload = function () {
                window.horizon = new Horizon();
            };
        </script>
    </head>
    <body>
        
        <label class="sidebar-button" for="hamburger">
            <span class="line"></span>
            <span class="line"></span>
            <span class="line"></span>
        </label>
        '
            . (new InputCheckbox('hamburger', $this->isHiddenSidebar))
                ->addClass('hide')
                ->addAttribute(Attribute::id, 'hamburger')
                ->addAttribute(Attribute::form, 'main')
                ->draw()
            . $this->drawSidebar()
            . '
        <div class="page">
            <div class="path">' . $this->path->draw() . '</div>
            <div class="control-panel">' . $this->control_panel->draw() . '</div>
            <div class="content" id="content">' . $this->content->draw() . '</div>
        </div>
    </body>
</html>';
    }

    public static function go(): static
    {
        return new static();
    }
}