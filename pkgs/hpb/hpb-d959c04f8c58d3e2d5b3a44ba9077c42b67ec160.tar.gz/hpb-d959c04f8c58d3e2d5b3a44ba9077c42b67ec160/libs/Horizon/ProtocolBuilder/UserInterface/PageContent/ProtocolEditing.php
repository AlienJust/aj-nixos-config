<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Exception;
use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolDescriptionTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolGUIDTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolNameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolVersionTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\DeleteButton;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\UpdatingButton;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_Protocol;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Tags\Anchor;
use Horizon\UserInterface\Tags\ListItem;
use Horizon\UserInterface\Tags\Paragraph;
use Horizon\UserInterface\Tags\Trace;
use Horizon\UserInterface\Tags\UnorderedList;

class ProtocolEditing extends _PageContentTag
{
    public function __construct(string $header, string $action_URL, string $GUID, string $name, string $version, string $description)
    {
        parent::__construct($header);
        $this->add((new MainForm($action_URL))
            ->add(new ProtocolGUIDTag($GUID))
            ->add(new ProtocolNameTag($name))
            ->add(new ProtocolVersionTag($version))
            ->add(new ProtocolDescriptionTag($description))
            ->add(new UpdatingButton()));
    }

    public function setInitXML(UISection_Protocol ...$controller): static
    {
        try {
            $this->addActionBlockDeprecated('Экспорт протокола', $list = new UnorderedList());
            foreach ($controller as $item) $list
                ->add((new ListItem())->add(new Anchor($item->getURL(), $item->refAction()->name())));
        } catch (Exception $exception) {
            $this->add(new Trace($exception));
        }
        return $this;
    }

    public function setDelete(string $action_URL): static
    {
        try {
            $this->addActionBlockDeprecated('Удаление протокола',
                (new MainForm($action_URL))
                    ->addAttribute(Attribute::id, 'delete')
                    ->add(new Paragraph('Чтобы удалить протокол, нажмите кнопку ниже:'))
                    ->add(new DeleteButton()));
        } catch (Exception $exception) {
            $this->add(new Trace($exception));
        }
        return $this;
    }
}