<?php

namespace Horizon\ProtocolBuilder\UserInterface\UIControllers;

use Horizon\ProtocolBuilder\DataBase\Tables\Subscriber;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\Exceptions\UIEx;
use Horizon\ProtocolBuilder\Exceptions\UIException;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\LogicItems\URL;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Subscriber;
use Horizon\ProtocolBuilder\UserInterface\eUISection;
use Horizon\ProtocolBuilder\UserInterface\PageContent\_PageContentTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eSubscriberField;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubscriberCreation;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubscriberEditing;
use Horizon\ProtocolBuilder\UserInterface\Redirections\ExecSubscriberCreation;
use Horizon\ProtocolBuilder\UserInterface\Redirections\ExecSubscriberDeleting;
use Horizon\ProtocolBuilder\UserInterface\Redirections\ExecSubscriberEditing;
use Horizon\UserInterface\Redirection;

class UISection_Subscriber extends UISection
{
    protected static eUISection $section = eUISection::subscriber;
    private ?eUISA_Subscriber $action;
    private Subscriber $subscriber;

    public function __construct(?eUISA_Subscriber $action = null, array $post = [])
    {
        parent::__construct($post);
        $this->action = $action;
    }

    public function setSubscriber(Subscriber $subscriber): static
    {
        $this->subscriber = $subscriber;
        return $this;
    }

    /**
     * @throws DBException
     */
    public function refSubscriber(): Subscriber
    {
        return $this->subscriber ?? ($this->subscriber = Subscriber::dbLoad($this->getID(), $this->post['protocol']));
    }

    public function refAction(): ?eUISA_Subscriber
    {
        return $this->action;
    }

    /**
     * @throws DBException
     * @throws UIException
     */
    public function tag(): _PageContentTag
    {
        return match ($this->action) {
            //null => '',
            eUISA_Subscriber::new => new SubscriberCreation($this->refAction()->name(), $this->getURL(),
                0,
                '',
                '',
                ''),
            eUISA_Subscriber::edit => (new SubscriberEditing($this->refAction()->name(), $this->getURL(),
                $this->refSubscriber()->getAddress(),
                $this->refSubscriber()->getName(),
                $this->refSubscriber()->getShortName(),
                $this->refSubscriber()->getDescription()
            ))->setDelete(eUISA_Subscriber::delete->controller()->setSubscriber($this->refSubscriber())->getURL()),
            //eUIAction_Subscriber::delete => throw new \Exception('To be implemented'),
            default => throw new UIException(UIEx::actionNotImplemented)
        };
    }

    /**
     * @throws DBException|VException
     */
    public function execute(): Redirection
    {
        return match ($this->action) {
            eUISA_Subscriber::new => new ExecSubscriberCreation($this->refSubscriber(),
                eSubscriberField::name->get($this->post),
                eSubscriberField::short_name->get($this->post),
                eSubscriberField::address->get($this->post),
                eSubscriberField::description->get($this->post),
            ),
            eUISA_Subscriber::edit => new ExecSubscriberEditing($this->refSubscriber(),
                eSubscriberField::name->get($this->post),
                eSubscriberField::short_name->get($this->post),
                eSubscriberField::address->get($this->post),
                eSubscriberField::description->get($this->post),
            ),
            eUISA_Subscriber::delete => new ExecSubscriberDeleting($this->refSubscriber()),
        };
    }

    /**
     * @throws DBException
     */
    public function getCurrentID(): ?string
    {
        return $this->refSubscriber()->getID();
    }

    /**
     * @throws DBException
     */
    public function refURL(): URL
    {
        return (new URL())
            ->setSectionAction(static::$section->value, $this->action?->value)
            ->setSubscriber(
                $this->refSubscriber()->getProtocol(),
                $this->refSubscriber()->getID()
            );
    }
}