<?php

namespace Horizon\ProtocolBuilder\UserInterface\Redirections;

use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Protocol;
use Horizon\UserInterface\Redirection;

class ExecProtocolEditing extends Redirection
{
    /**
     * @throws DBException
     * @throws VException
     */
    public function __construct(Protocol $protocol, string $name, string $description, string $version, string $GUID)
    {
        $protocol->setName($name);
        $protocol->setDescription($description);
        $protocol->setVersion($version);
        $protocol->setGUID($GUID);
        $protocol->dbUpdate();
        parent::__construct(eUISA_Protocol::edit->controller()->setProtocol($protocol)->getURL());
    }
}