<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\InputText;

class ParameterViewCommentTag extends InputText
{
    public function __construct(string $value)
    {
        parent::__construct(eParameterField::view_comment->code(), $value,
            'Комментарий', 'Введите комментарий для отображения параметра', true);
        $this->addAttribute(Attribute::maxlength, '255');
    }
}