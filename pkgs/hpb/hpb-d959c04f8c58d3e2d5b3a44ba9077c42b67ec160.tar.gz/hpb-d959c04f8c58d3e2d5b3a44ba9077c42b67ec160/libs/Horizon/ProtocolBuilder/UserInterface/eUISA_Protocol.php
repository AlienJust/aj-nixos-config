<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_Protocol;

enum eUISA_Protocol: string implements iUISectionActionEnum
{
    case new = 'new';
    case import = 'import';
    case edit = 'edit';
    case delete = 'delete';
    case init_psn_xml = 'init_psn_xml';
    case init_tabs_xml = 'init_tabs_xml';
    case init_main_xaml = 'init_main_xaml';

    case import_param_views = 'import_param_views';
    case system_diagnostic_tuning = 'system_diagnostic_tuning';
    case system_diagnostic_allocating = 'system_diagnostic_allocating';
    case system_diagnostic_renaming = 'system_diagnostic_editing';

    public function name(): string
    {
        return match ($this) {
            self::new => 'Создание протокола',
            self::import => 'Импорт протокола',
            self::edit => 'Изменение протокола',
            self::delete => 'Удаление протокола',
            self::init_psn_xml => 'Инициализация psn.xml',
            self::init_tabs_xml => 'Инициализация tabs.xml',
            self::init_main_xaml => 'Инициализация main.xaml',
            self::import_param_views => 'Импорт представлений параметров',
            self::system_diagnostic_tuning => 'Настройка контента окна "Диагностика системы"',
            self::system_diagnostic_allocating => 'Распределение контента в окне "Диагностика системы"',
            self::system_diagnostic_renaming => 'Переименование параметров в окне "Диагностика системы',
        };
    }

    public static function controlPanel(): array
    {
        return [
            'Изменить' => self::edit,
            'Импорт ПП' => self::import_param_views,
            'PSN.XML' => self::init_psn_xml,
            'TABS.XML' => self::init_tabs_xml,
            'MAIN.XAML' => self::init_main_xaml,
            'Диагностика системы' => self::system_diagnostic_tuning,
            'ДС: переименование' => self::system_diagnostic_renaming,
        ];
    }

    public function controller(array $post = [], array $files = []): UISection_Protocol
    {
        return new UISection_Protocol($this, $post, $files);
    }
}