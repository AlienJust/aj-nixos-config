<?php

namespace Horizon\ProtocolBuilder\UserInterface\Redirections;

use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToReply;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToRequest;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterView;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_ReplyParameter;
use Horizon\ProtocolBuilder\UserInterface\eUISA_RequestParameter;
use Horizon\UserInterface\Redirection;

class ExecParameterViewDeleting extends Redirection
{
    /**
     * @throws DBException
     */
    public function __construct(ParameterToRequest|ParameterToReply $parameter, string $code)
    {
        ParameterView::dbLoad($parameter->refCommand()->refSubscriber()->getProtocol(), $code)->dbDelete();
        parent::__construct(($parameter::class == ParameterToRequest::class
            ? eUISA_RequestParameter::new_view
            : eUISA_ReplyParameter::new_view
        )->controller()->setParameter($parameter)->getURL());
    }
}