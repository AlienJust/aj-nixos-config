<?php

namespace Horizon\ProtocolBuilder\UserInterface\Redirections;

use Horizon\ProtocolBuilder\DataBase\Tables\ParameterView;
use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\DataBase\Tables\SystemDiagnosticChunk;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\Exceptions\UploadException;
use Horizon\ProtocolBuilder\LogicItems\StringToNullHandler;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Protocol;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eProtocolField;
use Horizon\UserInterface\Redirection;

class ExecProtocolSystemDiagnosticRenaming extends Redirection
{

    /**
     * @throws DBException
     * @throws UploadException
     */
    public function __construct(Protocol $protocol, array $parameter_views)
    {
        foreach ($parameter_views as $code => $view_data) {
            $name = StringToNullHandler::run(eProtocolField::parameter_view_name->get($view_data));
            $chunk = SystemDiagnosticChunk::dbFind($protocol->getID(), $code);
            if ($chunk->exists()) {
                $view = ParameterView::dbLoad($protocol->getID(), $code)->refSystemDiagnosticView();
                if ($view->getCustomName() != $name) {
                    $view->setCustomName($name)->dbInsertUpdate();
                    if ($view->getCode() != $code)
                        SystemDiagnosticChunk::dbFind($protocol->getID(), $code)->setCode($view->getCode())->dbUpdate();
                }
            }
        }
        parent::__construct(eUISA_Protocol::system_diagnostic_renaming->controller()->setProtocol($protocol)->getURL());
    }
}