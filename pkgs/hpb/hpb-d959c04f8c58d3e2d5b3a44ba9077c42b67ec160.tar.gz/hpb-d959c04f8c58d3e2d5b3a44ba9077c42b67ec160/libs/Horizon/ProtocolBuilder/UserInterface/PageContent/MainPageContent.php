<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\UserInterface\Tags\Header;
use Horizon\UserInterface\Tags\Paragraph;

class MainPageContent extends _PageContentTag
{
    public function __construct()
    {
        parent::__construct('Конструктор протоколов');
        $this->add(new Header(2, 'Версия HPB-0.0.0 – 2023.03.01'))
            ->add(new Paragraph('© ООО «НПО Горизонт», ' . $this->getYears()));
    }

    private function getYears(): string
    {
        $start_year = '2023';
        $current_year = (new \DateTime())->format('Y');
        return $start_year == $current_year ? $start_year : "$start_year – $current_year";
    }
}