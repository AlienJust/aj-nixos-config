<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\CommandSection;

use Horizon\ProtocolBuilder\Data\eCommandInitWay;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eCommandField;
use Horizon\UserInterface\Controls\Components\Option;
use Horizon\UserInterface\Controls\InputSelect;
use Horizon\UserInterface\HTMLException;

class CommandInitWayTag extends InputSelect
{
    /**
     * @throws HTMLException
     */
    public function __construct()
    {
        parent::__construct(eCommandField::init_way->code(), '',
            'Алгоритм для инициализации заголовков',
            'Выберите алгоритм для автоматической инициализации заголовков');
        $this->addOptions(true, ...array_map(fn(eCommandInitWay $case): Option => new Option($case->value, $case->label()), eCommandInitWay::cases()));
    }
}