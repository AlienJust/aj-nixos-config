<?php

namespace Horizon\ProtocolBuilder\UserInterface\Redirections;

use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToReply;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToRequest;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_ReplyParameter;
use Horizon\ProtocolBuilder\UserInterface\eUISA_RequestParameter;
use Horizon\UserInterface\Redirection;

class ExecParameterCreation extends Redirection
{
    /**
     * @throws DBException
     * @throws VException
     */
    public function __construct(ParameterToRequest|ParameterToReply $parameter,
                                string $name, string $type, array $bits, ?string $value = null,
                                ?string $byte_order = null, ?int $value_conversion_formula = null,
                                float $lowest_digit_price = 1, bool $signed = false)
    {
        $parameter->setName($name);
        $parameter->setType($type);
        $parameter->setByteOrder($byte_order);
        $parameter->setValueConversionFormula($value_conversion_formula);
        $parameter->setBits($bits);
        $parameter->setValue($value);
        $parameter->setLowestDigitPrice($lowest_digit_price);
        $parameter->setSigned($signed);
        $parameter->dbInsert();
        parent::__construct(($parameter::class == ParameterToRequest::class
            ? eUISA_RequestParameter::edit
            : eUISA_ReplyParameter::edit
        )->controller()->setParameter($parameter)->getURL());
    }
}