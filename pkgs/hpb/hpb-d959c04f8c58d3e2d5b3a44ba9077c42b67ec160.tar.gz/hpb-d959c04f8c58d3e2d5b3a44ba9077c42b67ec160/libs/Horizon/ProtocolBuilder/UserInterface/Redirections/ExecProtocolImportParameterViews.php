<?php

namespace Horizon\ProtocolBuilder\UserInterface\Redirections;

use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\ImportFiles\TabsXmlParser;
use Horizon\ProtocolBuilder\ImportFiles\XmlParserController;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Protocol;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputModels\TempFile;
use Horizon\UserInterface\Redirection;

class ExecProtocolImportParameterViews extends Redirection
{

    public function __construct(Protocol $protocol, TempFile $file)
    {
        $parser = new TabsXmlParser($protocol);
        (new XmlParserController($parser, $file->path))->run();
        parent::__construct(eUISA_Protocol::edit->controller()->setProtocol($protocol)->getURL());
    }
}