<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\Data\eParameterType;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Controls\Components\Option;
use Horizon\UserInterface\Controls\InputSelect;
use Horizon\UserInterface\HTMLException;

class ParameterTypeTag extends InputSelect
{
    /**
     * @throws HTMLException
     */
    public function __construct(array|string $value)
    {
        parent::__construct(eParameterField::type->code(), $value,
            'Выберите тип параметра', 'Выберите тип параметра', true);
        $this->addOptions(true, ...Option::init(eParameterType::all()));
    }
}