<?php

namespace Horizon\ProtocolBuilder\UserInterface\Redirections;

use Horizon\ProtocolBuilder\DataBase\Tables\Command;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Subscriber;
use Horizon\UserInterface\Redirection;

class ExecCommandDeleting extends Redirection
{
    /**
     * @throws DBException
     */
    public function __construct(Command $command)
    {
        $command->dbDelete();
        parent::__construct(eUISA_Subscriber::edit->controller()->setSubscriber($command->refSubscriber())->getURL());
    }
}