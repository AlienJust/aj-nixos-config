<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\Data\eParameterByteOrder;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Controls\Components\Option;
use Horizon\UserInterface\Controls\InputSelect;
use Horizon\UserInterface\HTMLException;

class ParameterByteOrderTag extends InputSelect
{
    /**
     * @throws HTMLException
     */
    public function __construct(?string $value)
    {
        parent::__construct(eParameterField::byte_order->code(), $value ?? '',
            'Порядок байтов', 'Выберите порядок байтов в параметре', true);
        $this->addOptions(true, ...array_map(fn($v) => new Option($v->value, $v->value), eParameterByteOrder::cases()));
    }
}