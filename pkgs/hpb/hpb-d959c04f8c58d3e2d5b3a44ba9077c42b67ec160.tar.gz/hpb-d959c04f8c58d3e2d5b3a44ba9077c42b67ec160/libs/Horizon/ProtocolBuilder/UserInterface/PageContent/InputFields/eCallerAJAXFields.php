<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields;

enum eCallerAJAXFields implements iTransmissionField
{
    case action;
    case destination;
    case properties;

    public function code(mixed ...$options) : string
    {
        return $this->name;
    }

    public function get(array $post): null|string|array
    {
        return match ($this) {
            self::action,
            self::destination => $post[$this->code()] ?? null,
            self::properties => $post[$this->code()] ?? []
        };
    }
}