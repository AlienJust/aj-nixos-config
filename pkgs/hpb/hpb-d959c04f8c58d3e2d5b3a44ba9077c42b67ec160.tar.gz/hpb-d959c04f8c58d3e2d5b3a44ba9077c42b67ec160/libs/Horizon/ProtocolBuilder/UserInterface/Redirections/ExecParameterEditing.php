<?php

namespace Horizon\ProtocolBuilder\UserInterface\Redirections;

use Horizon\ProtocolBuilder\Data\eParameterType;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToReply;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToRequest;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_ReplyParameter;
use Horizon\ProtocolBuilder\UserInterface\eUISA_RequestParameter;
use Horizon\UserInterface\Redirection;

class ExecParameterEditing extends Redirection
{
    /**
     * @throws DBException
     * @throws VException
     */
    public function __construct(ParameterToRequest|ParameterToReply $parameter,
                                string $name, string $type, ?string $value_conversion_formula, float $lowest_digit_price,
                                bool $signed, bool $inverted, array $bits, ?string $byte_order,
                                ?string $value, ?string $description)
    {
        $parameter->setName($name);
        $type = eParameterType::tryFrom($type);
        switch ($type) {
            case eParameterType::DefVal:
                $parameter->setValue($value);
                break;
            case eParameterType::CpzPrm:
                $parameter->setValueConversionFormula($value_conversion_formula);
                $parameter->setLowestDigitPrice($lowest_digit_price);
                $parameter->setSigned($signed);
                $parameter->setByteOrder($byte_order);
                break;
            case eParameterType::BitPrm:
                $parameter->setValueInverted($inverted);
            default:
        }
        $parameter->setBits($bits);
        $parameter->setDescription($description);
        $parameter->dbUpdate();
        parent::__construct(($parameter::class == ParameterToRequest::class
            ? eUISA_RequestParameter::edit
            : eUISA_ReplyParameter::edit
        )->controller()->setParameter($parameter)->getURL());
    }
}