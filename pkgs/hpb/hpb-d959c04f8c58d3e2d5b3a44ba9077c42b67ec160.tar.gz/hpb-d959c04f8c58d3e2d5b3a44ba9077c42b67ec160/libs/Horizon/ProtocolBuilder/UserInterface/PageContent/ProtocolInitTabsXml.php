<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\ExportFiles\TabsXml;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Tags\PreformattedText;

class ProtocolInitTabsXml extends _PageContentTag
{
    /**
     * @throws DBException
     */
    public function __construct(string $header, Protocol $protocol)
    {
        parent::__construct($header);
        $this->add((new PreformattedText())->addClass('copy')
            ->addAttribute(Attribute::onclick, "document.execCommand('copy');")
            ->add(htmlspecialchars((new TabsXml($protocol))->content())));
    }
}