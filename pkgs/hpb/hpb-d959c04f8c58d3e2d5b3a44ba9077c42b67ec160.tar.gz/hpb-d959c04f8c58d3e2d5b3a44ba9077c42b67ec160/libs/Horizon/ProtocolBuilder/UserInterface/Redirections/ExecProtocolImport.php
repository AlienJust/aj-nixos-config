<?php

namespace Horizon\ProtocolBuilder\UserInterface\Redirections;

use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\ImportFiles\PsnXmlParser;
use Horizon\ProtocolBuilder\ImportFiles\XmlParserController;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Protocol;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputModels\TempFile;
use Horizon\UserInterface\Redirection;

class ExecProtocolImport extends Redirection
{

    /**
     * @throws DBException
     */
    public function __construct(TempFile $file)
    {
        $parser = new PsnXmlParser();
        (new XmlParserController($parser, $file->path))->run();
        parent::__construct(eUISA_Protocol::edit->controller()->setProtocol($parser->refProtocol())->getURL());
    }
}