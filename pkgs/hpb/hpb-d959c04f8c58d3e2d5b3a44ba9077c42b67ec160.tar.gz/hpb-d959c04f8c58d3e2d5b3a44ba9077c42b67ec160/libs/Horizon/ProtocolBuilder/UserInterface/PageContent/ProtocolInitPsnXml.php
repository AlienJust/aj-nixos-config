<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\ExportFiles\PsnXml;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Tags\PreformattedText;

class ProtocolInitPsnXml extends _PageContentTag
{
    /**
     * @throws DBException
     */
    public function __construct(string $header, Protocol $protocol)
    {
        parent::__construct($header);
        /* @todo: сформировать тут файл и отобразить ссылку для его скачивания
         * отметить, когда сформирован файл
         * в этой же таблице отмечать, когда было произведено последнее изменение протокола
         * Если файл свежий, то его и показывать, а если нет, то формировать новый
         *
         * ИЛИ! Формировать здесь уже готовый файл для скачивания и выплевывать его в браузер как xml документ,
         * а ссылку на эту операцию сделать ссылкой для скачивания файла или открытия в новом окне
         * */

        $this->add((new PreformattedText())->addClass('copy')
            ->addAttribute(Attribute::onclick, "document.execCommand('copy');")
            //->addAttribute(Attribute::sandbox, 'allow-same-origin')
            //->addAttribute(Attribute::type, 'application/xml')
            /*->addAttribute(Attribute::src, 'data:application/xml;UTF-8,<?xml version=&quot;1.0&quot; encoding=&quot;utf-8&quot;?>*/
            ->add(htmlspecialchars((new PsnXml($protocol))->content())));
    }
}