<?php

namespace Horizon\ProtocolBuilder\UserInterface\UIControllers;

use Horizon\ProtocolBuilder\UserInterface\eUISection;
use Horizon\ProtocolBuilder\UserInterface\PageContent\MainPageContent;
use Horizon\ProtocolBuilder\UserInterface\PageContent\_PageContentTag;
use Horizon\UserInterface\Redirection;

class UISection_Main extends UISection
{
    protected static eUISection $section = eUISection::main;
    public function __construct()
    {
        parent::__construct([]);
    }

    public function tag(): _PageContentTag
    {
        return new MainPageContent();
    }

    public function execute(): Redirection
    {
        return new Redirection('');
    }

    public function getCurrentID(): ?string
    {
        return '';
    }
}