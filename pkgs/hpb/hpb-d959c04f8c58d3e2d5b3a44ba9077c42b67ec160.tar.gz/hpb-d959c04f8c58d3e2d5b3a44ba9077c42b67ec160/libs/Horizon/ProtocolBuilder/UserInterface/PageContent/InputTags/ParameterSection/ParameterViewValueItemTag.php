<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\Data\eParameterColor;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Controls\Components\Option;
use Horizon\UserInterface\Controls\InputSelect;
use Horizon\UserInterface\Controls\InputText;
use Horizon\UserInterface\HTMLException;
use Horizon\UserInterface\PresetTags\Division2Columns;
use Horizon\UserInterface\TagsPack;

class ParameterViewValueItemTag extends TagsPack
{
    /**
     * @throws HTMLException
     */
    public function __construct(int $COUNTER, string $expression, string $result_true, string $result_false, ?string $color)
    {
        parent::__construct();
        $this->add((new Division2Columns())
            ->add((new InputText(eParameterField::view_value_expression->code($COUNTER), $expression,
                'Условное выражение', 'Введите условное выражение, например, [value] == 0', true))
                ->addAttribute(Attribute::maxlength, '255'))
            ->add((new InputSelect(eParameterField::view_value_color->code($COUNTER), $color ?? '',
                'Цвет, если истина', 'Введите значение цвета, если условие выполняется'))
                ->addOptions(true, ...(array_map(fn(eParameterColor $case): Option => new Option($case->value, $case->label()), eParameterColor::cases()))))
            ->add(new InputText(eParameterField::view_value_result_true->code($COUNTER), $result_true,
                'Значение, если истина', 'Введите значение, если условие выполняется', true))
            ->add(new InputText(eParameterField::view_value_result_false->code($COUNTER), $result_false,
                'Значение, если ложь', 'Введите значение, если условие не выполняется'))
        );
    }
}