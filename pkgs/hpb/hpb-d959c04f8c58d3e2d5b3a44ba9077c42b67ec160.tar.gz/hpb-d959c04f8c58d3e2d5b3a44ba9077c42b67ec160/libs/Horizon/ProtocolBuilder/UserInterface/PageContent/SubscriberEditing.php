<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Exception;
use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\SubscriberSection\SubscriberAddressTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\SubscriberSection\SubscriberDescriptionTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\SubscriberSection\SubscriberNameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\SubscriberSection\SubscriberShortNameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\DeleteButton;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\UpdatingButton;
use Horizon\UserInterface\Tags\Header;
use Horizon\UserInterface\Tags\HorizontalRule;
use Horizon\UserInterface\Tags\LineBreak;
use Horizon\UserInterface\Tags\Paragraph;
use Horizon\UserInterface\Tags\Trace;

class SubscriberEditing extends _PageContentTag
{
    public function __construct(string $header, string $action_URL, int $address, string $name, string $sort_name, string $description)
    {
        parent::__construct($header);
        $this->add((new MainForm($action_URL))
            ->add(new SubscriberNameTag($name))
            ->add(new SubscriberShortNameTag($sort_name))
            ->add(new SubscriberAddressTag($address))
            ->add(new SubscriberDescriptionTag($description))
            ->add(new UpdatingButton()));
    }

    public function setDelete(string $action_URL): static
    {
        try {
            $this->add(new LineBreak())
                ->add(new HorizontalRule())
                ->add(new Header(2, 'Удаление абонента'))
                ->add((new MainForm($action_URL))
                    ->add(new Paragraph('Чтобы удалить абонента, нажмите кнопку ниже:'))
                    ->add(new DeleteButton()));
        } catch (Exception $exception) {
            $this->add(new Trace($exception));
        }
        return $this;
    }
}