<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Exception;
use Horizon\ProtocolBuilder\Data\eParameterType;
use Horizon\ProtocolBuilder\LogicItems\ParameterAddress;
use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterByteOrderTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterCheckboxMatrixTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterDescriptionTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterGUIDTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterLowestDigitPriceTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterNameWithDatalistTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterSignedTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterValueInvertedTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterValueConversionFormulaTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection\ParameterValueTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\DeleteButton;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\UpdatingButton;
use Horizon\UserInterface\PresetTags\Division2Columns;
use Horizon\UserInterface\Tags\Header;
use Horizon\UserInterface\Tags\HorizontalRule;
use Horizon\UserInterface\Tags\LineBreak;
use Horizon\UserInterface\Tags\Paragraph;
use Horizon\UserInterface\Tags\Trace;

class ParameterEditing extends _PageContentTag
{
    private string $GUID;
    public function __construct(string $header, string $action_URL, string $GUID,
                                string $name, ?string $description, string $type, ?string $value,
                                ?string $value_conversion_formula, float  $lowest_digit_price, bool $signed, bool $inverted,
                                array  $bits, ?string $byte_order, int $count, ParameterAddress $address)
    {
        parent::__construct($header);
        $this->GUID = $GUID;
        try {
            $type = eParameterType::tryFrom($type);
            $this->add($form = (new MainForm($action_URL))
                ->add((new Division2Columns())
                    ->add(new Header(3, ($type?->label() ?? '').' '. $address->draw()))
                    ->add(new ParameterGUIDTag($GUID))
                    ->add(new ParameterNameWithDatalistTag($name))
                ));
            switch ($type) {
                case eParameterType::DefVal:
                    $form->add(new ParameterValueTag((string)$value));
                    break;
                case eParameterType::CpzPrm:
                    $form->add((new Division2Columns())
                        ->add(new ParameterValueConversionFormulaTag($value_conversion_formula))
                        ->add(new ParameterLowestDigitPriceTag($lowest_digit_price))
                        ->add(new ParameterSignedTag($signed))
                        ->add(count($bits) > 8 ? new ParameterByteOrderTag($byte_order) : null));
                    break;
                case eParameterType::BitPrm:
                    $form->add(new ParameterValueInvertedTag($inverted));
                default:
            }
            $form->add(new ParameterDescriptionTag((string)$description))
                ->add(new ParameterCheckboxMatrixTag($bits, $count, []))
                ->add(new UpdatingButton());
        } catch (Exception $exception) {
            $this->add(new Trace($exception));
        }
    }

    public function setDelete(string $action_URL): static
    {
        try {
            $this->add(new LineBreak())
                ->add(new HorizontalRule())
                ->add(new Header(2, 'Удаление параметра ' . $this->GUID))
                ->add((new MainForm($action_URL))
                    //->add($this->initGUIDTag($this->GUID))
                    ->add(new Paragraph('Чтобы удалить параметр, нажмите кнопку ниже:'))
                    ->add(new DeleteButton()));
        } catch (Exception $exception) {
            $this->add(new Trace($exception));
        }
        return $this;
    }
}