<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\ProtocolBuilder\UserInterface\MainForm;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolDescriptionTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolGUIDTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolNameTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ProtocolSection\ProtocolVersionTag;
use Horizon\ProtocolBuilder\UserInterface\PageContent\SubmitTags\CreationButton;

class ProtocolCreation extends _PageContentTag
{
    public function __construct(string $header, string $action_URL, string $GUID, string $name, string $version, string $description)
    {
        parent::__construct($header);
        $this->add((new MainForm($action_URL))
            ->add(new ProtocolGUIDTag($GUID))
            ->add(new ProtocolNameTag($name))
            ->add(new ProtocolVersionTag($version))
            ->add(new ProtocolDescriptionTag($description))
            ->add(new CreationButton()));
    }
}