<?php

namespace Horizon\ProtocolBuilder\UserInterface\Redirections;

use Horizon\ProtocolBuilder\DataBase\Tables\Command;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Command;
use Horizon\UserInterface\Redirection;

class ExecCommandDeleteParameters extends Redirection
{
    /**
     * @throws DBException
     */
    public function __construct(Command $command, array $parameters)
    {
        $command->dbDeleteParameters($parameters);
        parent::__construct(eUISA_Command::delete_parameters->controller()->setCommand($command)->getURL());
    }
}