<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields;

enum eSubscriberField implements iTransmissionField
{
    case name;
    case short_name;
    case address;
    case description;

    public function code(mixed ...$options): string
    {
        return match ($this) {
            self::name,
            self::short_name,
            self::address,
            self::description => $this->name,
        };
    }
    
    public function get(array $post): null|string|array
    {
        return match ($this) {
            self::name,
            self::short_name,
            self::address,
            self::description => $post[$this->code()] ?? null,
        };
    }
}
