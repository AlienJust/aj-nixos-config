<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent;

use Horizon\UserInterface\Redirection;
use Horizon\UserInterface\Tags\Anchor;

class RedirectionView extends _PageContentTag
{
    public function __construct(Redirection $redirection)
    {
        parent::__construct('Перенаправление на другую страницу');
        $this->add('Если автоматическая переадресация не сработала, перейдите по ссылке: ')
            ->add(new Anchor($redirection->getURL(), $redirection->getURL()));
    }
}