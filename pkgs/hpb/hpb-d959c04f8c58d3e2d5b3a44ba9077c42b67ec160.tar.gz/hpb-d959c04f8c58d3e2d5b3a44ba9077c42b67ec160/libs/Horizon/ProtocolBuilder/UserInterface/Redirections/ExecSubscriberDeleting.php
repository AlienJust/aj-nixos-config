<?php

namespace Horizon\ProtocolBuilder\UserInterface\Redirections;

use Horizon\ProtocolBuilder\DataBase\Tables\Subscriber;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Protocol;
use Horizon\UserInterface\Redirection;

class ExecSubscriberDeleting extends Redirection
{
    /**
     * @throws DBException
     */
    public function __construct(Subscriber $subscriber)
    {
        $subscriber->dbDelete();
        parent::__construct(eUISA_Protocol::edit->controller()->setProtocol($subscriber->refProtocol())->getURL());
    }
}