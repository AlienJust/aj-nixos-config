<?php

namespace Horizon\ProtocolBuilder\UserInterface\Redirections;

use Horizon\ProtocolBuilder\DataBase\Tables\Subscriber;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\Exceptions\VException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Subscriber;
use Horizon\UserInterface\Redirection;

class ExecSubscriberEditing extends Redirection
{
    /**
     * @throws DBException
     * @throws VException
     */
    public function __construct(Subscriber $subscriber, string $name, string $short_name, int $address, string $description)
    {
        $subscriber->setName($name);
        $subscriber->setShortName($short_name);
        $subscriber->setAddress($address);
        $subscriber->setDescription($description);
        $subscriber->dbUpdate();
        parent::__construct(eUISA_Subscriber::edit->controller()->setSubscriber($subscriber)->getURL());
    }
}