<?php

namespace Horizon\ProtocolBuilder\UserInterface\Redirections;

use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToReply;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToRequest;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterView;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterViewInjection;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterViewInjectValue;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterViewNumber;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterViewValue;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_ReplyParameter;
use Horizon\ProtocolBuilder\UserInterface\eUISA_RequestParameter;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Redirection;

class ExecParameterViewCreation extends Redirection
{
    /**
     * @throws DBException
     */
    public function __construct(ParameterToRequest|ParameterToReply $parameter, string $code, string $comment,
                                ?string $custom_name, ?string $format, ?string $mask, array $values, array $numbers,
                                bool $injection_on, int $injection_number, string $injection_expression, bool $injection_order,
                                array $injection_values, ?float $injection_min_value,
                                ?float $injection_max_value, ?float $injection_interval_value)
    {
        $view = new ParameterView($parameter->refCommand()->refSubscriber()->getProtocol(), $code);
        $view->setIdentifier($parameter->getGUID())
            ->setComment($comment)
            ->setCustomName($custom_name)
            ->setFormat($format)
            ->setMask($mask);
        $sort = 0;
        foreach ($values as $datum) {
            $value = new ParameterViewValue($parameter->refCommand()->refSubscriber()->getProtocol(), $code, $sort);
            $value->setExpression(eParameterField::view_value_expression->get($datum))
                ->setResultTrue(eParameterField::view_value_result_true->get($datum))
                ->setResultFalse(eParameterField::view_value_result_false->get($datum))
                ->setColor(eParameterField::view_value_color->get($datum));
            $sort++;
            $view->addViewValue($value);
        }
        $sort = 0;
        foreach ($numbers as $datum) {
            $number = new ParameterViewNumber($parameter->refCommand()->refSubscriber()->getProtocol(), $code, $sort);
            $number->setExpression(eParameterField::view_value_expression->get($datum))
                ->setFormat(eParameterField::view_number_format->get($datum))
                ->setColor(eParameterField::view_number_color->get($datum));
            $sort++;
            $view->addViewNumber($number);
        }
        $injection = !$injection_on ? null : ParameterViewInjection::dbLoad($view->getProtocol(), $view->getCode())
            ->setParamNumberInPackage($injection_number)
            ->setConvertExpression($injection_expression)
            ->setInvertBytesOrder($injection_order)
            ->setMinValue($injection_min_value)
            ->setMaxValue($injection_max_value)
            ->setIntervalValue($injection_interval_value);
        $view->setInjection($injection);
        $sort = 0;
        foreach ($injection_values as $datum) {
            $value = new ParameterViewInjectValue($view->getProtocol(), $view->getCode(), $sort);
            $value->setValue(eParameterField::injection_value_value->get($datum))
                ->setText(eParameterField::injection_value_text->get($datum));
            $sort++;
            $injection->addValue($value);
        }
        $view->dbInsert();
        parent::__construct(($parameter::class == ParameterToRequest::class
            ? eUISA_RequestParameter::new_view
            : eUISA_ReplyParameter::new_view
        )->controller()->setParameter($parameter)->getURL());
    }

}