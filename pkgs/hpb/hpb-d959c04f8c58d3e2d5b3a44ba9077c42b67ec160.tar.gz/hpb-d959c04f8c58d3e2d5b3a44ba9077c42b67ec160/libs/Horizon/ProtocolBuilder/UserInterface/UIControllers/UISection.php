<?php

namespace Horizon\ProtocolBuilder\UserInterface\UIControllers;

use Horizon\ProtocolBuilder\Exceptions\UIException;
use Horizon\ProtocolBuilder\LogicItems\URL;
use Horizon\ProtocolBuilder\UserInterface\eUISection;
use Horizon\ProtocolBuilder\UserInterface\PageContent\_PageContentTag;
use Horizon\UserInterface\Redirection;

abstract class UISection
{
    protected static eUISection $section;
    protected array $post;
    protected array $files;

    public function __construct(array $post, array $files = [])
    {
        $this->post = $post;
        $this->files = $files;
    }

    protected function getID(): ?int
    {
        $ID = $this->post['ID'] ?? null;
        return $ID == '' ? null : (int)$ID;
    }

    /**
     * @throws UIException
     */
    public abstract function tag(): _PageContentTag;
    public abstract function execute(): Redirection;

    /**
     * @return string|null
     * @deprecated Нигде не используется?
     */
    public abstract function getCurrentID(): ?string;

    public function refURL(): URL
    {
        return (new URL())
            ->setSectionAction(static::$section->value == '' ? null : static::$section->value, null);
    }

    final public function getURL(): string
    {
        return $this->refURL()->draw();
    }

}