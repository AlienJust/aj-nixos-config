<?php

namespace Horizon\ProtocolBuilder\UserInterface\PageContent\InputTags\ParameterSection;

use Horizon\ProtocolBuilder\Data\eParameterVariableName;
use Horizon\ProtocolBuilder\UserInterface\PageContent\InputFields\eParameterField;
use Horizon\UserInterface\Controls\Components\Option;
use Horizon\UserInterface\Controls\InputSelect;
use Horizon\UserInterface\HTMLException;

class ParameterVariableNameTag extends InputSelect
{
    /**
     * @throws HTMLException
     */
    public function __construct(array|string $value)
    {
        parent::__construct(eParameterField::name->code(), $value,
            'Наименование переменной', 'Выберите наименование переменной', true);
        $this->addOptions(true, ...Option::initFromStringBackedEnumCases(eParameterVariableName::cases()));
    }
}