<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_RequestParameter;

enum eUISA_RequestParameter: string implements iUISectionActionEnum
{
    case new = 'new';
    case new_default_value = 'new_default_value';
    case new_variable = 'new_variable';
    case new_bits = 'new_bits';
    case edit = 'edit';
    case delete = 'delete';
    case new_view = 'new_view';
    case edit_view = 'edit_view';
    case delete_view = 'delete_view';

    public function name(): string
    {
        return match ($this) {
            self::new => 'Создание в запросе параметра',
            self::new_default_value => 'Создание в запросе значения',
            self::new_variable => 'Создание в запросе переменной',
            self::new_bits => 'Создание в запросе битовых флагов',
            self::edit => 'Изменение параметра запроса',
            self::delete => 'Удаление параметра запроса',
            self::new_view => 'Создание представления параметра',
            self::edit_view => 'Редактирование представлений параметра',
            self::delete_view => 'Удаление представления параметра',
        };
    }

    public static function controlPanel(): array
    {
        return [
            'Изменить' => self::edit,
            'Представления' => self::new_view,
        ];
    }

    public function controller(array $post = []): UISection_RequestParameter
    {
        return new UISection_RequestParameter($this, $post);
    }
}