<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_Command;

enum eUISA_Command: string implements iUISectionActionEnum
{
    case new = 'new';
    case copy = 'copy';
    case edit = 'edit';
    case delete = 'delete';
    case delete_parameters = 'delete_parameters';

    public function name(): string
    {
        return match ($this) {
            self::new => 'Создание команды',
            self::copy => 'Копирование команды',
            self::edit => 'Изменение команды',
            self::delete => 'Удаление команды',
            self::delete_parameters => 'Удаление параметров',
        };
    }

    public static function controlPanel(): array
    {
        return [
            'Изменить' => self::edit,
            'Удалить параметры' => self::delete_parameters,
        ];
    }

    public function controller(array $post = []): UISection_Command
    {
        return new UISection_Command($this, $post);
    }
}
