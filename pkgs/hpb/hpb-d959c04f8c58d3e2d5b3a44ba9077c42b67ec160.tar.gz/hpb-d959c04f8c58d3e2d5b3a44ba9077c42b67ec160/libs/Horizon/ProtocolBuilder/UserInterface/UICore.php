<?php

namespace Horizon\ProtocolBuilder\UserInterface;

use Exception;
use Horizon\ProtocolBuilder\DataBase\Tables\Command;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToReply;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToRequest;
use Horizon\ProtocolBuilder\DataBase\Tables\Protocol;
use Horizon\ProtocolBuilder\DataBase\Tables\Subscriber;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\PageContent\ExceptionView;
use Horizon\ProtocolBuilder\UserInterface\PageContent\RedirectionView;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_Command;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_ReplyParameter;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_RequestParameter;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_Protocol;
use Horizon\ProtocolBuilder\UserInterface\UIControllers\UISection_Subscriber;
use Horizon\UserInterface\Constants\Attribute;
use Horizon\UserInterface\Redirection;
use Horizon\UserInterface\Tags\Anchor;
use Horizon\UserInterface\Tags\Trace;
use Horizon\UserInterface\VariableView;

class UICore
{
    private MainPage $page;
    private ?Redirection $redirection = null;

    private ?string $protocol;
    private ?string $subscriber;
    private ?string $command;
    private string|int|null $ID;


    public function __construct(MainPage $page)
    {
        $this->page = $page;

        //VariableView::output($_POST, $_GET);

        $post = empty($_POST) ? $_GET : array_merge($_GET, $_POST);

        $section = eUISection::tryFrom($this->pull($post, 'section') ?? '');
        $action = $this->pull($post, 'action') ?? '';
        $this->protocol = $this->pull($post, 'protocol');
        $this->subscriber = $this->pull($post, 'subscriber');
        $this->command = $this->pull($post, 'command');
        $this->ID = $this->pullID($post);

        // Формируем меню
        $this->page->setIsHiddenSidebar(($this->pull($post,'hamburger') ?? '0') == '1');

        // Формируем контент или переадресацию
        try {
            $controller = $section->controller($action, $post, $_FILES);
            switch (get_class($controller)) {
                case UISection_Protocol::class:
                    $protocol = Protocol::dbLoad($this->ID);
                    $this->initPath($protocol);
                    if ($protocol->exists()) foreach (eUISA_Protocol::controlPanel() as $name=>$item)
                        $this->page->addControlPanelItem($name, $item->controller()->setProtocol($protocol)->getURL(),
                            $item == eUISA_Protocol::tryFrom($action));

                    $controller->setProtocol($protocol);
                    $this->initFirstMenu($this->ID, $controller->refAction());
                    if ($controller->refProtocol()->exists()) $this->initSecondMenu($controller->refProtocol());
                    break;
                case UISection_Subscriber::class:
                    $protocol = Protocol::dbLoad($this->protocol);
                    $subscriber = Subscriber::dbLoad($this->ID, $this->protocol);
                    $this->initPath($protocol, $subscriber);
                    if ($subscriber->exists()) foreach (eUISA_Subscriber::controlPanel() as $name=>$item)
                        $this->page->addControlPanelItem($name, $item->controller()->setSubscriber($subscriber)->getURL(),
                            $item == eUISA_Subscriber::tryFrom($action));

                    $controller->setSubscriber($subscriber);
                    $this->initFirstMenu($this->protocol);
                    $this->initSecondMenu($protocol, $this->ID, $controller->refAction());
                    if ($controller->refSubscriber()->exists()) $this->initThirdMenu($controller->refSubscriber());
                    break;
                case UISection_Command::class:
                    $protocol = Protocol::dbLoad($this->protocol);
                    $subscriber = Subscriber::dbLoad($this->subscriber);
                    $command = Command::dbLoad($this->ID, $this->subscriber);
                    $this->initPath($protocol, $subscriber, $command);
                    if ($command->exists()) foreach (eUISA_Command::controlPanel() as $name=>$item)
                        $this->page->addControlPanelItem($name, $item->controller()->setCommand($command)->getURL(),
                            $item == eUISA_Command::tryFrom($action));

                    $controller->setCommand($command);
                    $this->initFirstMenu($this->protocol);
                    $this->initSecondMenu($protocol, $this->subscriber);
                    $this->initThirdMenu($subscriber, $this->ID, $controller->refAction());
                    if ($controller->refCommand()->exists()) $this->initFourthMenu($controller->refCommand());
                    break;
                case UISection_ReplyParameter::class:
                    $protocol = Protocol::dbLoad($this->protocol);
                    $subscriber = Subscriber::dbLoad($this->subscriber);
                    $command = Command::dbLoad($this->command);
                    $parameter = ParameterToReply::dbLoad($this->ID, $this->command);
                    $this->initPath($protocol, $subscriber, $command, $parameter);
                    if ($parameter->exists()) foreach (eUISA_ReplyParameter::controlPanel() as $name=>$item)
                        $this->page->addControlPanelItem($name, $item->controller()->setParameter($parameter)->getURL(),
                            $item == eUISA_ReplyParameter::tryFrom($action));

                    $controller->setParameter($parameter);
                    $this->initFirstMenu($this->protocol);
                    $this->initSecondMenu($protocol, $this->subscriber);
                    $this->initThirdMenu($subscriber, $this->command);
                    $this->initFourthMenu($command, $this->ID, $controller->refAction());
                    break;
                case UISection_RequestParameter::class:
                    $protocol = Protocol::dbLoad($this->protocol);
                    $subscriber = Subscriber::dbLoad($this->subscriber);
                    $command = Command::dbLoad($this->command);
                    $parameter = ParameterToRequest::dbLoad($this->ID, $this->command);
                    $this->initPath($protocol, $subscriber, $command, $parameter);
                    if ($parameter->exists()) foreach (eUISA_RequestParameter::controlPanel() as $name=>$item)
                        $this->page->addControlPanelItem($name, $item->controller()->setParameter($parameter)->getURL(),
                            $item == eUISA_RequestParameter::tryFrom($action));

                    $controller->setParameter($parameter);
                    $this->initFirstMenu($this->protocol);
                    $this->initSecondMenu($protocol, $this->subscriber);
                    $this->initThirdMenu($subscriber, $this->command);
                    $this->initFourthMenu($command, $this->ID, $controller->refAction());
                    break;
                default:
                    $this->initFirstMenu();
            }
            $this->initContent($controller, !is_null($this->pull($post, 'execute')));
        } catch (Exception $e) {
            $this->page->setContent(new ExceptionView($e));
        }
    }

    private function initPath(Protocol $protocol, ?Subscriber $subscriber = null, ?Command $command = null,
                              ParameterToReply|ParameterToRequest|null $parameter = null): void
    {
        try {
            if ($protocol->exists()) $this->page->addPathItem($protocol->getName(),
                is_null($subscriber) ? null : eUISA_Protocol::edit->controller()->setProtocol($protocol)->getURL());
            if (!is_null($subscriber) && $subscriber->exists()) $this->page->addPathItem($subscriber->getName(),
                is_null($command) ? null : eUISA_Subscriber::edit->controller()->setSubscriber($subscriber)->getURL());
            if (!is_null($command) && $command->exists()) $this->page->addPathItem($command->getName(),
                is_null($parameter) ? null : eUISA_Command::edit->controller()->setCommand($command)->getURL());
            if (!is_null($parameter) && $parameter->exists()) $this->page->addPathItem($parameter->getName());
        } catch (DBException $e) {
            $this->page->addPathItem('## DB Exception: ' . $e->getMessage(),'');
        }
    }

    private function initContent(UISection $controller, bool $execute): void
    {
        try {
            if ($execute) {
                $this->redirection = $controller->execute();
                $this->page->setContent(new RedirectionView($this->redirection));
            } else $this->page->setContent($controller->tag());
        } catch (Exception $e) {
            $this->page->setContent(new ExceptionView($e));
        }
    }

    private function initFirstMenu(?int $current_ID = null, ?eUISA_Protocol $action = null): void
    {
        try {
            $protocols = Protocol::list();
            $ref_controller = eUISA_Protocol::edit->controller();

            $action_new = [
                self::getActionAnchorNowrapTag('+ протокол', eUISA_Protocol::new === $action,
                    eUISA_Protocol::new->controller()
                ),
                self::getActionAnchorNowrapTag('Импорт', eUISA_Protocol::import === $action,
                    eUISA_Protocol::import->controller()
                )
            ];

            foreach ($protocols as &$protocol) $protocol = self::getActionAnchorTag(
                $protocol->getName(),$protocol->getID() == $current_ID,
                $ref_controller->setProtocol($protocol)
            );

            $this->page->setFirstMenu('Протоколы', ...$action_new)->add(...$protocols);
        } catch (Exception $e) {
            $this->page->setFirstMenu('Ошибка!', new Trace($e));
        }
    }

    private function initSecondMenu(Protocol $protocol, ?int $current_ID = null, ?eUISA_Subscriber $action = null): void
    {
        try {
            $subscribers = $protocol->arrSubscribers();
            $ref_controller = eUISA_Subscriber::edit->controller();

            $action_new = self::getActionAnchorNowrapTag('+ абонент', eUISA_Subscriber::new === $action,
                eUISA_Subscriber::new->controller()->setSubscriber(new Subscriber($protocol->getID()))
            );

            foreach ($subscribers as &$subscriber) $subscriber = self::getActionAnchorTag(
                $subscriber->getName(),$subscriber->getID() == $current_ID,
                $ref_controller->setSubscriber($subscriber)
            );

            $this->page->setSecondMenu('Абоненты', $action_new)->add(...$subscribers);
        } catch (Exception $e) {
            $this->page->setSecondMenu('Ошибка!', new Trace($e));
        }
    }

    private function initThirdMenu(Subscriber $subscriber, ?int $current_ID = null, ?eUISA_Command $action = null): void
    {
        try {
            $commands = $subscriber->arrCommands();
            $ref_controller = eUISA_Command::edit->controller();

            $action_new = self::getActionAnchorNowrapTag('+ команда', eUISA_Command::new === $action,
                eUISA_Command::new->controller()->setCommand(new Command($subscriber->getID()))
            );

            foreach ($commands as &$command) $command = self::getActionAnchorTag(
                $command->getName(), $command->getID() == $current_ID,
                $ref_controller->setCommand($command)
            );

            $this->page->setThirdMenu('Команды', $action_new)->add(...$commands);
        } catch (Exception $e) {
            $this->page->setThirdMenu('Ошибка!', new Trace($e));
        }
    }

    private function initFourthMenu(Command $command, ?string $current_ID = null,
                                    eUISA_RequestParameter|eUISA_ReplyParameter|null $action = null): void
    {
        try {
            $parameters_to_request = $command->arrParametersToRequest();
            $parameters_to_reply = $command->arrParametersToReply();

            $ref_request_controller = eUISA_RequestParameter::edit->controller();
            $ref_reply_controller = eUISA_ReplyParameter::edit->controller();

            $action_new_to_request = [
                self::getActionAnchorNowrapTag('+ параметр', eUISA_RequestParameter::new === $action,
                    eUISA_RequestParameter::new->controller()->setParameter(new ParameterToRequest($command->getID()))),
                self::getActionAnchorNowrapTag('+ значение', eUISA_RequestParameter::new_default_value === $action,
                    eUISA_RequestParameter::new_default_value->controller()->setParameter(new ParameterToRequest($command->getID()))),
                self::getActionAnchorNowrapTag('+ переменная', eUISA_RequestParameter::new_variable === $action,
                    eUISA_RequestParameter::new_variable->controller()->setParameter(new ParameterToRequest($command->getID()))),
                self::getActionAnchorNowrapTag('+ битовые флаги', eUISA_RequestParameter::new_bits === $action,
                    eUISA_RequestParameter::new_bits->controller()->setParameter(new ParameterToRequest($command->getID())))
            ];

            $action_new_to_reply = [
                self::getActionAnchorNowrapTag('+ параметр', eUISA_ReplyParameter::new === $action,
                    eUISA_ReplyParameter::new->controller()->setParameter(new ParameterToReply($command->getID()))),
                self::getActionAnchorNowrapTag('+ значение', eUISA_ReplyParameter::new_default_value === $action,
                    eUISA_ReplyParameter::new_default_value->controller()->setParameter(new ParameterToReply($command->getID()))),
                self::getActionAnchorNowrapTag('+ переменная', eUISA_ReplyParameter::new_variable === $action,
                    eUISA_ReplyParameter::new_variable->controller()->setParameter(new ParameterToReply($command->getID()))),
                self::getActionAnchorNowrapTag('+ битовые флаги', eUISA_ReplyParameter::new_bits === $action,
                    eUISA_ReplyParameter::new_bits->controller()->setParameter(new ParameterToReply($command->getID())))
            ];

            foreach ($parameters_to_request as &$parameter) $parameter = self::getActionAnchorTag(
                $parameter->getName(), $parameter->getGUID() == $current_ID,
                $ref_request_controller->setParameter($parameter)
            );
            foreach ($parameters_to_reply as &$parameter) $parameter = self::getActionAnchorTag(
                $parameter->getName(), $parameter->getGUID() == $current_ID,
                $ref_reply_controller->setParameter($parameter)
            );

            $this->page->setFourthMenu('Параметры запроса', ...$action_new_to_request)->add(...$parameters_to_request);
            $this->page->setFourthMenu('Параметры ответа', ...$action_new_to_reply)->add(...$parameters_to_reply);

        } catch (Exception $e) {
            $this->page->setFourthMenu('Ошибка!', new Trace($e));
        }
    }

    private static function getActionAnchorTag(?string $text, bool $is_current, UISection $controller): Anchor
    {
        return (new Anchor($controller->getURL(), $text))->addClassIf('current', $is_current)
            ->addAttribute(Attribute::id, $controller->refURL()->getBookmark());
    }

    private static function getActionAnchorNowrapTag(?string $text, bool $is_current, UISection $controller): Anchor
    {
        return self::getActionAnchorTag($text, $is_current, $controller)->addClass('action');
    }

    public function output(): void
    {
        if (!is_null($this->redirection)) $this->redirection->output();
        echo $this->page->draw();
    }

    private function pull(array &$post, string $code): ?string
    {
        $value = $post[$code] ?? null;
        if (isset($post[$code])) unset($post[$code]);
        return $value;
    }

    private function pullID(array &$post): string|int|null
    {
        $ID = $this->pull($post, 'ID');
        if ($ID == '') $ID = null;
        if (is_numeric($ID)) $ID = (int)$ID;
        return $ID;
    }
}