<?php

namespace Horizon\ProtocolBuilder\UserInterface\Redirections;

use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToReply;
use Horizon\ProtocolBuilder\DataBase\Tables\ParameterToRequest;
use Horizon\ProtocolBuilder\Exceptions\DBException;
use Horizon\ProtocolBuilder\UserInterface\eUISA_Command;
use Horizon\UserInterface\Redirection;

class ExecParameterDeleting extends Redirection
{
    /**
     * @throws DBException
     */
    public function __construct(ParameterToRequest|ParameterToReply $parameter)
    {
        $parameter->dbDelete();
        parent::__construct(eUISA_Command::edit->controller()->setCommand($parameter->refCommand())->getURL());
    }
}