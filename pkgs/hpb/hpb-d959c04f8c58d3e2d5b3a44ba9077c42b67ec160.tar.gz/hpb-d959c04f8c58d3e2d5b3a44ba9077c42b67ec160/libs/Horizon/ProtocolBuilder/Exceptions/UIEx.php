<?php

namespace Horizon\ProtocolBuilder\Exceptions;

enum UIEx: int
{
    case sectionNotImplemented = 0;
    case actionNotImplemented = 1;
    case fieldIsHidden = 2;

    public function message(): string
    {
        return match ($this) {
            self::sectionNotImplemented => 'Секция не реализована',
            self::actionNotImplemented => 'Операция не реализована',
            self::fieldIsHidden => 'Нельзя обращаться к полю напрямую'
        };
    }
}
