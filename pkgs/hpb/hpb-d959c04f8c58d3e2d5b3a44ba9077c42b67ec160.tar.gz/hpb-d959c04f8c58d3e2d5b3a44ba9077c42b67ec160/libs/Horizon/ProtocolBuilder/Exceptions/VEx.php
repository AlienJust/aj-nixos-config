<?php

namespace Horizon\ProtocolBuilder\Exceptions;

enum VEx: int
{
    case emptyName = 0;
    case unknownParameterType = 1;
    case brokenBits = 2;
    case emptyParameters = 3;
    case notPackageType = 4;

    public function message(): string
    {
        return match ($this) {
            self::emptyName => 'Наименование не может быть пустым',
            self::unknownParameterType => 'Неизвестный тип параметра',
            self::brokenBits => 'Ошибка при формировании битов параметра',
            self::emptyParameters => 'Параметры не были выбраны',
            self::notPackageType => 'Не определен package type',
        };
    }
}
