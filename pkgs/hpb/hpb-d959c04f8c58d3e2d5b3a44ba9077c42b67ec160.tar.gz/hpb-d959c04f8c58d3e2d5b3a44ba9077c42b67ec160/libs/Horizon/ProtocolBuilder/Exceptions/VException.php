<?php

namespace Horizon\ProtocolBuilder\Exceptions;

use Exception;

class VException extends Exception
{
    public function __construct(VEx $exception)
    {
        parent::__construct($exception->message(), $exception->value);
    }
}